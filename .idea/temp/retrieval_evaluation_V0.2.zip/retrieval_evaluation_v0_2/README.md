# Retrieval Evaluation Framework V0.2

Evaluate an **embedding-search system within each PDF**, using document-specific, category-specific queries and four levels of ground-truth relevance. This package includes complete Python code, tests, CSV examples, and sample model results. The default production output is Parquet.

**Key change from V0.1:** `less_relevant` is **positive**. Only `not_relevant` is negative. The prediction file now also carries your **externally thresholded 0/1 decisions**, enabling evaluation of queries that have *no positive chunks*.

## Quick start

Use Python 3.10+.

```bash
# From this directory
python -m pip install -r requirements.txt

# Evaluate an embedding model using your files
python evaluate_retrieval.py \
  --ground-truth ground_truth_V0.1.parquet \
  --predictions predictions_model_A_V0.2.parquet \
  --run-id model_A_v1 \
  --model-id embedding_model_A \
  --output-dir evaluation_results
```

The command creates:

```text
evaluation_results/
  model_A_v1/
    metadata.json
    summary.csv
    per_query.parquet
```

No existing run folder will be overwritten. Use a unique `--run-id` for every experiment (for example, `model_A_t0p55_v2`).

**Try it without Parquet:** CSV input is supported with no third-party dependencies. The included example files and results use CSV because PyArrow was unavailable in the environment where this package was assembled.

```bash
python evaluate_retrieval.py \
  --ground-truth examples/ground_truth_V0.1.csv \
  --predictions examples/predictions_model_A_V0.2.csv \
  --run-id local_demo \
  --output-dir evaluation_results \
  --per-query-format csv
```

This produces `per_query.csv` instead of `per_query.parquet`. In normal use, omit `--per-query-format csv` to get Parquet.

## 1. What is being evaluated?

- A PDF belongs to one `audit_id` and has multiple **chunks**.
- Each PDF has its **own set of queries**, organized into five categories.
- Every `(PDF, category, query)` is evaluated **independently** over the chunks of *that PDF only*.
- Each chunk has an **ordinal ground-truth label**, a **numeric model score**, and a **thresholded binary prediction** for each query.
- Chunks are sorted in descending order of **numeric score**. Binary decisions **do not affect ranking**.
- Metrics are computed **per `(audit_id, pdf_filename, category, query)`**, then macro-averaged equally across query instances.
- A document with 10 queries contributes 10 observations; a document with 2 queries contributes 2.

The chunk ID follows your existing pipeline format:

```text
{audit_id}:{pdf_filename}:{page_number}:{chunk_number}
```

Example: `AUD123:report.pdf:12:3`. The evaluator does **not** create chunks. Your actual chunking uses 256-token, non-overlapping chunks; that setting is informational, not used by the metric code.

### Categories (exact keys)

| Key | Human-readable name |
|---|---|
| `code_resolver` | Code resolver |
| `signs_and_symptoms` | Signs and symptoms |
| `therapeutic_treatment` | Therapeutic treatment |
| `diagnostic_procedure` | Diagnostic procedure |
| `clinical_evaluation` | Clinical evaluation |

### Ground-truth mapping

| String label | Grade (for nDCG) | Binary ground truth |
|---|---:|---:|
| `highly_relevant` | 3 | 1 |
| `relevant` | 2 | 1 |
| `less_relevant` | 1 | 1 |
| `not_relevant` | 0 | 0 |

**A no-positive query means every chunk for that query is `not_relevant` (grade 0).** All three other labels count as positive.

## 2. Input files

Supports `.csv` and `.parquet` for each input, independently. For CSV, nested dictionaries are JSON strings. For Parquet, nested values can be native maps/struct-like dictionaries or JSON strings. The same query's exact key must be used throughout the PDF.

### Ground truth V0.1: exactly two columns

Filename example: `ground_truth_V0.1.parquet`

- `chunk_id`: string.
- `labels`: nested `category -> query -> ground-truth label` dictionary.

**One decoded input row:**

```json
{
  "chunk_id": "AUD123:report.pdf:12:3",
  "labels": {
    "code_resolver": {"DRG code": "highly_relevant"},
    "signs_and_symptoms": {"fever": "less_relevant"},
    "therapeutic_treatment": {"antibiotics": "not_relevant"},
    "diagnostic_procedure": {"MRI": "relevant"},
    "clinical_evaluation": {"risk": "not_relevant"}
  }
}
```

### Predictions V0.2: exactly three columns

Filename example: `predictions_model_A_V0.2.parquet`

- `chunk_id`: string, matching ground truth.
- `labels`: nested `category -> query -> numeric score` dictionary. Higher = better; any **finite numeric score** is allowed.
- `binary_predictions`: nested `category -> query -> 0 or 1` dictionary. These values are already thresholded **by your pipeline**, not by the evaluator.

**Corresponding decoded row:**

```json
{
  "chunk_id": "AUD123:report.pdf:12:3",
  "labels": {
    "code_resolver": {"DRG code": 0.94},
    "signs_and_symptoms": {"fever": 0.66},
    "therapeutic_treatment": {"antibiotics": 0.31},
    "diagnostic_procedure": {"MRI": 0.84},
    "clinical_evaluation": {"risk": 0.22}
  },
  "binary_predictions": {
    "code_resolver": {"DRG code": 1},
    "signs_and_symptoms": {"fever": 1},
    "therapeutic_treatment": {"antibiotics": 0},
    "diagnostic_procedure": {"MRI": 1},
    "clinical_evaluation": {"risk": 0}
  }
}
```

**Important:** a numeric score and 0/1 decision are separate pieces of information. The evaluator does not require any global threshold relationship between them. It reads each as provided and never recomputes the binary value.

### Strict input validation

The evaluator **fails** on missing or mismatching information rather than guessing:

- Identical chunk ID sets in ground truth and prediction files; no duplicate chunk IDs.
- For a given PDF, all its chunks have ground truth for the same complete `(category, query)` set. A different PDF can have completely different queries.
- For each chunk, score and binary dictionaries have the exact same `(category, query)` keys as its ground truth.
- Only the five categories and four labels above are accepted.
- Score values must be finite numbers; binary values must be literal integers `0` or `1` (not booleans, floats, or strings).
- File column names are exact. Extra/missing columns fail.
- Empty inputs and malformed `chunk_id`s fail.

If your production data intentionally leaves some chunk-query pairs unlabeled, **this version is not directly compatible**. Do not silently treat missing labels as negative. Decide and document an explicit missing-judgment policy before changing the code.

## 3. Metrics: two separate evaluation perspectives

Compute at **K = 10, 20, 50, 100** by default.

### A. Ranking metrics (scores + ground truth)

| Metric in `summary.csv` | Meaning | Ideal |
|---|---|---:|
| `ndcg` | Ranking quality using 4 grades; grade-3 gains more than grade-1 | 1 |
| `recall` | Share of **all** positive chunks found within top K | 1 |
| `normalized_recall` | Top-K recall normalized by maximum reachable coverage | 1 |
| `precision` | Share of top-K slots containing positive chunks | 1 |
| `map` | Mean of per-query AP@K, considering all positives in its denominator | 1 |
| `mrr` | Mean reciprocal rank of first positive chunk | 1 |

**Ranking uses scores, not binary predictions.** Ground-truth `less_relevant` contributes grade 1 to nDCG and counts as positive for the other five metrics. Within-category label ties are genuinely tied: swapping two chunks of the same grade does not change nDCG. Numeric *prediction-score* ties are resolved deterministically by ascending `chunk_id`.

For **no-positive** queries, all six ranking metrics are `null` and excluded from the averages. This includes `precision` and `mrr`, as a *reporting policy*. It prevents the 30–40% no-positive share from reducing ranking scores even if the model orders available positive evidence perfectly. The no-positive subset is evaluated separately using binary rejection metrics.

### B. Binary metrics (your thresholded 0/1 decisions)

| Metric in `summary.csv` | Calculated on | Meaning | Ideal |
|---|---|---|---:|
| `correct_rejection_rate` (CRR@K) | No-positive queries | Fraction where **all top-K chunks** have predicted `0` | 1 |
| `false_alarm_rate` (FAR@K) | No-positive queries | Fraction where **any top-K chunk** has predicted `1` | 0 |
| `false_positive_rate` (FPR@K) | No-positive queries | Average per-query fraction of top-K chunks predicted `1` | 0 |
| `positive_evidence_hit_rate` | Positive queries | Fraction where at least one **truly positive** chunk in top K is predicted `1` | 1 |

**CRR + FAR = 1** when both are defined. FAR indicates whether a query triggers any false alarm; FPR indicates *how many* chunks were falsely accepted. These are distinct. Positive evidence hit rate is about having at least one **true positive**, not merely any predicted-positive chunk.

The binary metrics inspect the **top K chunks by score, before dropping any predicted-negative chunks**. There is no full-document binary-metric output in V0.2; using `K >= n_chunks` lets you evaluate the complete candidate pool with the same method.

### A miniature example

A no-positive query has top-5 binary flags `[0, 0, 1, 0, 0]`. Ground truth is `0` for all five.

- `false_alarm_at_k = 1` (there is one predicted-positive chunk)
- `correct_rejection_at_k = 0`
- `false_positive_rate_at_k = 1/5 = 0.20`

A positive query's top-5 grade/flag pairs are `[(0, 1), (2, 0), (3, 1), (0, 0), (1, 0)]`. Since the grade-3 chunk is predicted `1`, its `positive_evidence_hit_at_k = 1` despite another chunk being a false positive.

**Exact formulas and special cases:** see [`evaluation.md`](evaluation.md).

## 4. Per-query evaluation and category/overall aggregation

Unit of evaluation:

```text
(audit_id, pdf_filename, category, query)
```

No chunks or scores from another PDF enter its ranking. The same query text in two different PDFs produces two independent query instances. The same query text in two different categories also creates two instances.

After computing metrics per query, aggregate **with equal weight per query instance**, by category and overall. There is **no equal-document weighting** and **no average-of-five-category-means**. Null metrics are excluded independently per metric, and a `n_valid_*` column shows how many queries contributed to every reported mean.

Summary has **72 rows** for four Ks:

```text
(5 named categories + overall) x (all + positive + no_positive) x (10,20,50,100)
= 6 x 3 x 4 = 72
```

- `all`: all queries counted in `n_queries`. Ranking scores aggregate over **positive queries only**, while rejection scores aggregate over **no-positive queries only**; `positive_evidence_hit_rate` aggregates over positive queries.
- `positive`: only queries with at least one grade ≥ 1.
- `no_positive`: only queries with grade 0 in every chunk.

Therefore, `all` is **not a single population shared by every metric**; always check `n_valid_<metric>` when interpreting a value. The `positive` and `no_positive` groups make each metric's population explicit.

### `summary.csv` main columns

| Column | Interpretation |
|---|---|
| `category` | One of five categories, or `overall` |
| `query_group` | `all`, `positive`, `no_positive` |
| `k` | Requested top-K cutoff |
| `n_queries` | Number of query instances in this row's group |
| `n_category_queries` | Total query instances in this category, across both groups |
| `n_documents` | Number of unique PDFs represented by this row's group |
| `n_positive_queries` | Positive-query count in the entire category (same across the 3 group rows) |
| `n_no_positive_queries` | No-positive-query count in the entire category (same across groups) |
| `no_positive_rate` | `n_no_positive_queries / n_category_queries` (same across groups) |
| `n_short_pools` | Number of query instances whose PDF has fewer than K chunks |
| `mean_effective_k` | Mean of `min(K, n_chunks)` for this group |
| `n_valid_<metric>` | Number of non-null query scores contributing to `<metric>` |
| `<metric>` | Arithmetic mean of its applicable query scores, or blank if undefined |

All metric values are stored as **fractions 0–1**, not percentages. Empty CSV cells correspond to undefined `null` values.

### `per_query.parquet` main columns

One row per **query and cutoff**. Includes `(audit_id, pdf_filename, category, query)`, `query_group`, `k`, `effective_k`, `n_chunks`, positive/negative label counts, top-K TP/FP/TN/FN counts, score-tie count, and all per-query metric values. Columns for binary metrics use names such as `false_alarm_at_k` and `positive_evidence_hit_at_k`. Use this file for error analysis and query-level comparisons.

### `metadata.json`

Includes run/model IDs, UTC timestamp, input file paths and SHA-256 hashes, evaluation and input-schema versions, selected K values, full metric conventions, positive-label definition, threshold notes, and counts of positive/no-positive queries. It preserves the provenance of every experiment.

### Example summary interpretation

From `sample_results/sample_model_A/summary.csv` at `category=overall`, `K=10`:

- `all`: 11 queries; 7 positive and 4 no-positive (`no_positive_rate` ≈ 36.36%).
- Ranking scores in `all` use the 7 positive queries; CRR/FAR/FPR in `all` use the 4 no-positive queries.
- `positive` has no CRR/FAR/FPR values; `no_positive` has no ranking scores.

The example files are synthetic, not representative benchmarks.

## 5. Multiple models and comparisons

Keep one folder per prediction/evaluation run:

```text
evaluation_results/
  model_A_v1/
    metadata.json
    summary.csv
    per_query.parquet
  model_A_v2/
    metadata.json
    summary.csv
    per_query.parquet
  model_B_v1/
    metadata.json
    summary.csv
    per_query.parquet
```

Compare runs with identical ground truth and metric configurations:

```bash
python compare_runs.py \
  evaluation_results/model_A_v1 \
  evaluation_results/model_B_v1 \
  --output evaluation_results/model_comparison.csv
```

`model_comparison.csv` contains **all 72 summary rows per model**, with two extra columns: `run_id` and `model_id`. It does not invent a single combined score or rank models. The script **refuses** to compare runs with different ground-truth hashes, cutoff sets, relevance conventions, metric-version settings, or score-tie conventions.

It does not require the same prediction hash, because different predictions are exactly what you want to compare.

**Practical note:** to attribute improvements in binary rejection quality, keep the external thresholding procedure consistent, or record its threshold/configuration in `--threshold-notes` and compare threshold choices explicitly.

## 6. Important edge cases and decisions

| Case | V0.2 behavior |
|---|---|
| No-positive query (all grade 0) | Six ranking metrics are `null`; evaluate CRR/FAR/FPR |
| Positive query with no positive *inside top K* | Recall/precision/normalized recall/AP/RR may be `0`; nDCG may be `0` |
| No-positive query, all binary flags `0` | CRR=`1`, FAR=`0`, FPR=`0` |
| Positive query with no correctly thresholded relevant chunk in top K | Positive Evidence Hit=`0` |
| K exceeds PDF chunk count | `effective_k=min(K,n_chunks)`; no artificial missing slots |
| Missing category globally | Emits empty category summary rows with `n_queries=0` and blank metric scores |
| Missing judgment/score/binary flag on any chunk-query | **Error**; no imputation |
| Same-grade ground-truth ties | Equal nDCG gain; reordering those grades does not matter |
| Same numeric similarity scores | Tie resolved by ascending `chunk_id`; `n_score_ties` recorded |
| AP normalization | `R`, number of **all** positive chunks; not `min(K,R)` |
| No-positive prevalence | Reported separately for each category and overall; unchanged by K |
| Top-K retrieval | Compute ranking on all scored chunks; binary flags do not filter the ranking |
| Score thresholds | Already applied outside the evaluator; never estimated or modified here |

### Two often-confused details

**Traditional recall can be low even for an ideal top K.** If 1,000 chunks are positive and K=10, perfect recall@10 is only 1%. Normalized recall divides by the maximum reachable number of positive chunks. If `R >= effective_k`, it is numerically identical to precision. Keeping both is intentional because traditional recall exposes evidence coverage and informs cutoff selection.

**Thresholded FPR@K is defined for the no-positive subset only in this version.** Its denominator is the number of examined top-K chunks per no-positive query, then averages those per-query fractions. It is not the global micro-averaged false positive rate over negative chunks pooled across every query. The distinction avoids overweighting longer PDFs.

## 7. Validation and tests

```bash
python -m pip install -r requirements-dev.txt
python -m pytest -q
```

Tests cover relevance mapping, formulas, graded ties, all-negative queries, rejection statistics, positive evidence hits, short documents, score ties, strict input validation, query aggregation, CSV end-to-end runs, and model comparison.

One integration test exercises **native nested Parquet maps** and a Parquet output. It runs when PyArrow is installed; otherwise pytest skips it. CSV-based functional and integration tests work without PyArrow.

The sample input generator is deterministic:

```bash
python examples/generate_examples.py
```

It creates two PDFs, 20 chunks, 11 query instances, and four no-positive queries. Precomputed results are in `sample_results/` for models A and B. The sample output is CSV rather than Parquet only because of the build environment.

## 8. CLI reference

```text
--ground-truth PATH          Ground truth CSV/Parquet (required)
--predictions PATH           Predictions CSV/Parquet with binary_predictions (required)
--run-id ID                  Unique run directory (required)
--model-id TEXT              Optional human-readable model identifier
--output-dir PATH            Parent output directory (default: evaluation_results)
--ks 10,20,50,100            Requested Ks (default: 10,20,50,100)
--per-query-format parquet   parquet (default), or csv for testing
--threshold-notes TEXT       Optional documentation of how 0/1 flags were produced
```

Example for alternate cutoffs:

```bash
python evaluate_retrieval.py \
  --ground-truth ground_truth_V0.1.csv \
  --predictions predictions_model_B_V0.2.csv \
  --run-id B_k_5_10_25 \
  --ks 5,10,25 \
  --per-query-format csv
```

## 9. Scope and limitations

- Full labeled coverage and predicted scores/flags for **every PDF chunk / query combination** are required. This is an **in-PDF candidate-pool ranking benchmark**, not recall against all PDFs in an external corpus.
- Currently loads both inputs and per-query results into RAM, so very large datasets may require a streaming or partitioned implementation.
- Does not perform chunking, embedding generation, external thresholding, threshold optimization, score calibration, significance tests, or cross-document retrieval.
- Does not assign a unified score combining ranking and rejection. Compare the relevant dimensions separately.

[`evaluation.md`](evaluation.md) is the **formal metric contract**. If README examples and implementation ever disagree, treat that disagreement as a bug and use tests and explicit formula review to resolve it, rather than silently changing definitions.
