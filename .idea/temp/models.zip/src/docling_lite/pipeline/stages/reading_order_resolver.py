import hashlib
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import pandas as pd
from docling.datamodel.base_models import (
    AssembledUnit,
    BasePageElement,
    ContainerElement,
    FigureElement,
    Page,
    Table,
    TextElement,
)
from docling_core.types.doc import (
    DocItemLabel,
    DoclingDocument,
    DocumentOrigin,
    GroupLabel,
    NodeItem,
    ProvenanceItem,
    RefItem,
    RichTableCell,
    TableData,
)
from docling_ibm_models.list_item_normalizer.list_marker_processor import (
    ListItemMarkerProcessor,
)
from docling_ibm_models.reading_order.reading_order_rb import (
    PageElement as ReadingOrderPageElement,
    ReadingOrderPredictor,
)
from docling_core.types.doc.document import ContentLayer
from pydantic import BaseModel, ConfigDict

from docling_lite.core.config import READING_ORDER_CONFIG
from docling_lite.core.logging import log_function_calls, logger


@dataclass
class _FileReadingOrderContext:
    file_name: str
    document_hash: str
    pages: list[Page]
    assembled: AssembledUnit


class ReadingOrderResolverOptions(BaseModel):
    model_config = ConfigDict(protected_namespaces=())
    list_item_infer_enumerated: bool = True


class ReadingOrderResolver:
    def __init__(self, options: ReadingOrderResolverOptions | None = None):
        self.options = options or self._build_options_from_config()
        self._ro_page_element_cls = ReadingOrderPageElement
        self.ro_model = ReadingOrderPredictor()
        self.list_item_processor = ListItemMarkerProcessor(
            infer_enumerated=self.options.list_item_infer_enumerated
        )


    @staticmethod
    def _build_options_from_config() -> ReadingOrderResolverOptions:
        cfg = READING_ORDER_CONFIG
        return ReadingOrderResolverOptions(
            list_item_infer_enumerated=bool(
                cfg.get("list_item_infer_enumerated", True)
            )
        )


    @staticmethod
    def _collect_pages(file_df: pd.DataFrame) -> list[Page]:
        page_by_no: dict[int, Page] = {}
        for page in file_df["docling_page_obj"]:
            if not isinstance(page, Page):
                raise TypeError("Each 'docling_page_obj' entry must be a docling Page.")
            page_by_no.setdefault(page.page_no, page)
        return [page_by_no[page_no] for page_no in sorted(page_by_no)]

    @staticmethod
    def _row_page_key(file_name: Any, page_no: Any) -> tuple[str, int]:
        return str(file_name), int(page_no)

    @staticmethod
    def _build_file_context(file_name: str, pages: list[Page]) -> _FileReadingOrderContext:
        elements, headers, body = [], [], []
        page_signature_parts: list[str] = []

        for page in pages:
            assembled = page.assembled or AssembledUnit()
            elements.extend(assembled.elements)
            headers.extend(assembled.headers)
            body.extend(assembled.body)
            page_signature_parts.append(
                f"{page.page_no}:{len(assembled.elements)}:{len(assembled.headers)}:{len(assembled.body)}"
            )

        signature = f"{file_name}|{'|'.join(page_signature_parts)}"
        document_hash = hashlib.sha256(signature.encode("utf-8")).hexdigest()
        assembled_unit = AssembledUnit(elements=elements, headers=headers, body=body)

        return _FileReadingOrderContext(
            file_name=file_name,
            document_hash=document_hash,
            pages=pages,
            assembled=assembled_unit,
        )

    def _assembled_to_readingorder_elements(
        self, ctx: _FileReadingOrderContext
    ) -> list[Any]:
        page_map = {page.page_no: page for page in ctx.pages}
        ro_elements: list[Any] = []

        for element in ctx.assembled.elements:
            page = page_map.get(element.page_no)
            if page is None or page.size is None:
                raise ValueError(
                    f"Page metadata missing for element page_no={element.page_no}."
                )

            bbox = element.cluster.bbox.to_bottom_left_origin(page.size.height)
            ro_elements.append(
                self._ro_page_element_cls(
                    cid=len(ro_elements),
                    ref=RefItem(cref=f"#/{element.page_no}/{element.cluster.id}"),
                    text=element.text or "",
                    page_no=element.page_no,
                    page_size=page.size,
                    label=element.label,
                    l=bbox.l,
                    r=bbox.r,
                    b=bbox.b,
                    t=bbox.t,
                    coord_origin=bbox.coord_origin,
                )
            )

        return ro_elements

    def _add_child_elements(
        self, element: BasePageElement, doc_item: NodeItem, doc: DoclingDocument
    ) -> None:
        for child in element.cluster.children:
            bbox = child.bbox.to_bottom_left_origin(doc.pages[element.page_no].size.height)
            text = " ".join(
                [
                    cell.text.replace("\x02", "-").strip()
                    for cell in child.cells
                    if cell.text and cell.text.strip()
                ]
            )

            prov = ProvenanceItem(
                page_no=element.page_no,
                charspan=(0, len(text)),
                bbox=bbox,
            )

            if child.label == DocItemLabel.LIST_ITEM:
                list_item = doc.add_list_item(parent=doc_item, text=text, prov=prov)
                self.list_item_processor.process_list_item(list_item)
            elif child.label == DocItemLabel.SECTION_HEADER:
                doc.add_heading(parent=doc_item, text=text, prov=prov)
            else:
                doc.add_text(parent=doc_item, label=child.label, text=text, prov=prov)

    def _create_rich_cell_group(
        self, element: BasePageElement, doc: DoclingDocument, table_item: NodeItem
    ) -> RefItem:
        group_name = f"rich_cell_group_{len(doc.tables)}_0_0"
        group = doc.add_group(
            label=GroupLabel.UNSPECIFIED,
            name=group_name,
            parent=table_item,
        )
        self._add_child_elements(element, group, doc)
        return group.get_ref()

    def _add_caption_or_footnote(
        self, elem: TextElement, doc: DoclingDocument, parent: NodeItem, page_height: float
    ) -> NodeItem:
        prov = ProvenanceItem(
            page_no=elem.page_no,
            charspan=(0, len(elem.text or "")),
            bbox=elem.cluster.bbox.to_bottom_left_origin(page_height),
        )
        return doc.add_text(
            label=elem.label,
            text=elem.text or "",
            prov=prov,
            parent=parent,
        )

    def _handle_text_element(
        self,
        element: TextElement,
        doc: DoclingDocument,
        current_list: NodeItem | None,
        page_height: float,
    ) -> tuple[NodeItem, NodeItem | None]:
        text = element.text or ""
        prov = ProvenanceItem(
            page_no=element.page_no,
            charspan=(0, len(text)),
            bbox=element.cluster.bbox.to_bottom_left_origin(page_height),
        )

        if element.label == DocItemLabel.LIST_ITEM:
            if current_list is None:
                current_list = doc.add_group(label=GroupLabel.LIST, name="list")
            item = doc.add_list_item(
                text=text, enumerated=False, prov=prov, parent=current_list
            )
            self.list_item_processor.process_list_item(item)
            return item, current_list

        if element.label == DocItemLabel.SECTION_HEADER:
            return doc.add_heading(text=text, prov=prov), None

        if element.label == DocItemLabel.FORMULA:
            return (
                doc.add_text(label=DocItemLabel.FORMULA, text="", orig=text, prov=prov),
                None,
            )

        content_layer = ContentLayer.BODY
        if element.label in {DocItemLabel.PAGE_HEADER, DocItemLabel.PAGE_FOOTER}:
            content_layer = ContentLayer.FURNITURE

        item = doc.add_text(
            label=element.label,
            text=text,
            prov=prov,
            content_layer=content_layer,
        )
        return item, None

    @staticmethod
    def _merge_elements(
        merged_elem: TextElement, new_item: NodeItem, page_height: float
    ) -> None:
        assert merged_elem.label == new_item.label, "Merged labels must match."
        merged_text = merged_elem.text or ""
        new_text = getattr(new_item, "text", "") or ""

        prov = ProvenanceItem(
            page_no=merged_elem.page_no,
            charspan=(len(new_text) + 1, len(new_text) + 1 + len(merged_text)),
            bbox=merged_elem.cluster.bbox.to_bottom_left_origin(page_height),
        )

        new_item.text = f"{new_text} {merged_text}".strip()
        if hasattr(new_item, "orig") and isinstance(new_item.orig, str):
            new_item.orig = f"{new_item.orig} {merged_text}".strip()
        if hasattr(new_item, "prov") and isinstance(new_item.prov, list):
            new_item.prov.append(prov)

    def _readingorder_elements_to_docling_doc(
        self,
        ctx: _FileReadingOrderContext,
        ro_elements: list[Any],
        el_to_captions_mapping: dict[int, list[int]],
        el_to_footnotes_mapping: dict[int, list[int]],
        el_merges_mapping: dict[int, list[int]],
    ) -> DoclingDocument:
        id_to_elem = {
            RefItem(cref=f"#/{elem.page_no}/{elem.cluster.id}").cref: elem
            for elem in ctx.assembled.elements
        }
        cid_to_rel = {rel.cid: rel for rel in ro_elements}

        origin = DocumentOrigin(
            mimetype="application/pdf",
            filename=ctx.file_name,
            binary_hash=ctx.document_hash,
        )
        doc = DoclingDocument(name=Path(ctx.file_name).stem, origin=origin)

        for page in ctx.pages:
            if page.size is None:
                raise ValueError(f"Page size missing for page_no={page.page_no}.")
            doc.add_page(page_no=page.page_no, size=page.size)

        if not ro_elements:
            return doc

        skippable_cids = {
            cid
            for mapping in (
                el_to_captions_mapping,
                el_to_footnotes_mapping,
                el_merges_mapping,
            )
            for cid_list in mapping.values()
            for cid in cid_list
        }
        page_map = {page.page_no: page for page in ctx.pages}
        current_list: NodeItem | None = None

        for rel in ro_elements:
            if rel.cid in skippable_cids:
                continue

            element = id_to_elem[rel.ref.cref]
            page = page_map[element.page_no]
            assert page.size is not None
            page_height = page.size.height

            if isinstance(element, TextElement):
                if element.label == DocItemLabel.CODE:
                    text = element.text or ""
                    prov = ProvenanceItem(
                        page_no=element.page_no,
                        charspan=(0, len(text)),
                        bbox=element.cluster.bbox.to_bottom_left_origin(page_height),
                    )
                    code_item = doc.add_code(text=text, prov=prov)

                    for caption_cid in el_to_captions_mapping.get(rel.cid, []):
                        caption_elem = id_to_elem[cid_to_rel[caption_cid].ref.cref]
                        caption_item = self._add_caption_or_footnote(
                            caption_elem, doc, code_item, page_height
                        )
                        code_item.captions.append(caption_item.get_ref())

                    for footnote_cid in el_to_footnotes_mapping.get(rel.cid, []):
                        footnote_elem = id_to_elem[cid_to_rel[footnote_cid].ref.cref]
                        footnote_item = self._add_caption_or_footnote(
                            footnote_elem, doc, code_item, page_height
                        )
                        code_item.footnotes.append(footnote_item.get_ref())
                else:
                    new_item, current_list = self._handle_text_element(
                        element, doc, current_list, page_height
                    )
                    for merged_cid in el_merges_mapping.get(rel.cid, []):
                        merged_elem = id_to_elem[cid_to_rel[merged_cid].ref.cref]
                        self._merge_elements(merged_elem, new_item, page_height)

            elif isinstance(element, Table):
                if element.num_rows == 0 and element.num_cols == 0:
                    if element.cluster.children:
                        tbl_data = TableData(num_rows=1, num_cols=1, table_cells=[])
                    else:
                        tbl_data = TableData(num_rows=0, num_cols=0, table_cells=[])
                else:
                    tbl_data = TableData(
                        num_rows=element.num_rows,
                        num_cols=element.num_cols,
                        table_cells=element.table_cells,
                    )

                prov = ProvenanceItem(
                    page_no=element.page_no,
                    charspan=(0, 0),
                    bbox=element.cluster.bbox.to_bottom_left_origin(page_height),
                )
                table_item = doc.add_table(
                    data=tbl_data,
                    prov=prov,
                    label=element.cluster.label,
                )

                for caption_cid in el_to_captions_mapping.get(rel.cid, []):
                    caption_elem = id_to_elem[cid_to_rel[caption_cid].ref.cref]
                    caption_item = self._add_caption_or_footnote(
                        caption_elem, doc, table_item, page_height
                    )
                    table_item.captions.append(caption_item.get_ref())

                for footnote_cid in el_to_footnotes_mapping.get(rel.cid, []):
                    footnote_elem = id_to_elem[cid_to_rel[footnote_cid].ref.cref]
                    footnote_item = self._add_caption_or_footnote(
                        footnote_elem, doc, table_item, page_height
                    )
                    table_item.footnotes.append(footnote_item.get_ref())

                if (
                    element.num_rows == 0
                    and element.num_cols == 0
                    and element.cluster.children
                ):
                    rich_cell_ref = self._create_rich_cell_group(element, doc, table_item)
                    rich_cell = RichTableCell(
                        text="",
                        row_span=1,
                        col_span=1,
                        start_row_offset_idx=0,
                        end_row_offset_idx=1,
                        start_col_offset_idx=0,
                        end_col_offset_idx=1,
                        column_header=False,
                        row_header=False,
                        ref=rich_cell_ref,
                    )
                    doc.add_table_cell(table_item=table_item, cell=rich_cell)

            elif isinstance(element, FigureElement):
                prov = ProvenanceItem(
                    page_no=element.page_no,
                    charspan=(0, 0),
                    bbox=element.cluster.bbox.to_bottom_left_origin(page_height),
                )
                picture_item = doc.add_picture(prov=prov)

                for caption_cid in el_to_captions_mapping.get(rel.cid, []):
                    caption_elem = id_to_elem[cid_to_rel[caption_cid].ref.cref]
                    caption_item = self._add_caption_or_footnote(
                        caption_elem, doc, picture_item, page_height
                    )
                    picture_item.captions.append(caption_item.get_ref())

                for footnote_cid in el_to_footnotes_mapping.get(rel.cid, []):
                    footnote_elem = id_to_elem[cid_to_rel[footnote_cid].ref.cref]
                    footnote_item = self._add_caption_or_footnote(
                        footnote_elem, doc, picture_item, page_height
                    )
                    picture_item.footnotes.append(footnote_item.get_ref())

                self._add_child_elements(element, picture_item, doc)

            elif isinstance(element, ContainerElement):
                group_label = GroupLabel.UNSPECIFIED
                if element.label == DocItemLabel.FORM:
                    group_label = GroupLabel.FORM_AREA
                elif element.label == DocItemLabel.KEY_VALUE_REGION:
                    group_label = GroupLabel.KEY_VALUE_AREA
                container_group = doc.add_group(label=group_label)
                self._add_child_elements(element, container_group, doc)

        return doc

    def _add_page_markdown(
        self, processed_df: pd.DataFrame, documents: dict[str, DoclingDocument]
    ) -> pd.DataFrame:
        page_markdown: dict[tuple[str, int], str | None] = {}

        for file_name, file_df in processed_df.groupby("file_name", sort=False):
            file_name_str = str(file_name)
            document = documents.get(file_name_str)
            for page_no in file_df["page"].unique():
                page_key = self._row_page_key(file_name_str, page_no)
                markdown: str | None = None

                if document is not None:
                    try:
                        exported = document.export_to_markdown(page_no=int(page_no)).strip()
                        markdown = exported if exported else None
                    except Exception:
                        markdown = None

                page_markdown[page_key] = markdown

        output_df = processed_df.copy()
        output_df["page_markdown"] = output_df.apply(
            lambda row: page_markdown.get(
                self._row_page_key(row["file_name"], row["page"]), None
            ),
            axis=1,
        )
        return output_df

    @log_function_calls(logger)
    def resolve(self, assembled_df: pd.DataFrame) -> tuple[dict[str, DoclingDocument], pd.DataFrame]:
        """Resolve reading order and return (documents, dataframe with page_markdown)."""
        try:
            required_columns = {"file_name", "docling_page_obj"}
            missing_columns = required_columns - set(assembled_df.columns)
            if missing_columns:
                missing_str = ", ".join(sorted(missing_columns))
                raise ValueError(f"Input DataFrame is missing required columns: {missing_str}")

            documents: dict[str, DoclingDocument] = {}
            for file_name, file_df in assembled_df.groupby("file_name", sort=False):
                pages = self._collect_pages(file_df)
                context = self._build_file_context(file_name=file_name, pages=pages)

                ro_elements = self._assembled_to_readingorder_elements(context)
                if ro_elements:
                    sorted_elements = self.ro_model.predict_reading_order(
                        page_elements=ro_elements
                    )
                    el_to_captions_mapping = self.ro_model.predict_to_captions(
                        sorted_elements=sorted_elements
                    )
                    el_to_footnotes_mapping = self.ro_model.predict_to_footnotes(
                        sorted_elements=sorted_elements
                    )
                    el_merges_mapping = self.ro_model.predict_merges(
                        sorted_elements=sorted_elements
                    )
                else:
                    sorted_elements = []
                    el_to_captions_mapping = {}
                    el_to_footnotes_mapping = {}
                    el_merges_mapping = {}

                documents[file_name] = self._readingorder_elements_to_docling_doc(
                    context,
                    sorted_elements,
                    el_to_captions_mapping,
                    el_to_footnotes_mapping,
                    el_merges_mapping,
                )

            output_df = self._add_page_markdown(assembled_df, documents)
            return documents, output_df
        except Exception as exc:
            logger.error(f"Error during reading order resolution: {exc}")
            raise
