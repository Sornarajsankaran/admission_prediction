#!/usr/bin/env python3
"""
raster_pool.py — Persistent, all-core PDF rasterization with a batched generator API.

Input:  a list of PDF file paths.
Output: batches of rendered pages, streamed while all cores stay busy.

    pool = RasterPool()                      # create ONCE per process
    for batch in pool.iter_batches(pdf_paths, batch_size=32, dpi=144):
        for page in batch:
            page.pdf_path, page.page_no, page.image  # np.uint8 (H, W, 3)

Key properties:
- multiprocessing (spawn) -> CUDA-safe, true all-core parallelism
- workers are warm and reused across calls; each keeps an LRU of open Documents
- tasks are submitted lazily via a generator -> constant memory even for
  corpora with 100k+ pages (but see the iter_batches note: finished results
  buffer in the parent if the consumer is slower than the pool; iter_tasks
  windows submission so parent RAM stays bounded regardless of consumer speed)
- results stream back unordered by default (max throughput); ordered=True
  available when sequence matters
"""

from __future__ import annotations

import queue
import time
from collections import OrderedDict
from dataclasses import dataclass
from multiprocessing import get_context
from pathlib import Path
from typing import Iterable, Iterator

import numpy as np
import pymupdf  # pip install pymupdf

# ----------------------------------------------------------------------------
# Worker side (runs in each spawned process)
# ----------------------------------------------------------------------------

_DOC_CACHE_MAX = 8  # open Documents kept per worker (LRU)
_doc_cache: "OrderedDict[str, pymupdf.Document]" = OrderedDict()


def _init_worker() -> None:
    global _doc_cache
    _doc_cache = OrderedDict()


def _get_doc(path: str) -> pymupdf.Document:
    doc = _doc_cache.get(path)
    if doc is not None:
        _doc_cache.move_to_end(path)
        return doc
    doc = pymupdf.open(path)
    _doc_cache[path] = doc
    if len(_doc_cache) > _DOC_CACHE_MAX:
        _, old = _doc_cache.popitem(last=False)
        old.close()
    return doc


def _render(args: tuple) -> tuple:
    """(path, page_no, dpi, encode, max_px) -> (path, page_no, payload) or error."""
    path, page_no, dpi, encode, max_px = args
    try:
        doc = _get_doc(path)
        page = doc[page_no]
        zoom = dpi / 72.0
        if max_px:
            # scanned PDFs often declare pixel-sized page boxes; cap the render
            # area so one huge page can't explode downstream (VLM token) cost
            px = page.rect.width * page.rect.height * zoom * zoom
            if px > max_px:
                zoom *= (max_px / px) ** 0.5
        pix = page.get_pixmap(matrix=pymupdf.Matrix(zoom, zoom), alpha=False)
        if encode == "jpg":
            payload = ("jpg", pix.tobytes("jpg", jpg_quality=85))
        else:  # raw RGB bytes; rebuilt into np array on the parent side
            payload = ("raw", (pix.height, pix.width, bytes(pix.samples)))
        return (path, page_no, payload, None)
    except Exception as e:  # never let one bad page kill the pool
        return (path, page_no, None, f"{type(e).__name__}: {e}")


# ----------------------------------------------------------------------------
# Parent side
# ----------------------------------------------------------------------------

@dataclass
class RenderedPage:
    pdf_path: str
    page_no: int
    image: np.ndarray | None      # (H, W, 3) uint8 when encode="raw"
    jpg: bytes | None             # encoded bytes when encode="jpg"
    error: str | None = None

    @property
    def ok(self) -> bool:
        return self.error is None


def _to_page(result: tuple) -> RenderedPage:
    path, page_no, payload, err = result
    if err is not None:
        return RenderedPage(path, page_no, None, None, err)
    kind, data = payload
    if kind == "jpg":
        return RenderedPage(path, page_no, None, data)
    h, w, raw = data
    img = np.frombuffer(raw, dtype=np.uint8).reshape(h, w, 3)
    return RenderedPage(path, page_no, img, None)


class RasterPool:
    """Persistent all-core rasterization pool. Create once, reuse everywhere."""

    def __init__(self, workers: int | None = None, ctx: str = "spawn"):
        mp = get_context(ctx)  # spawn = safe next to CUDA/vLLM
        self.workers = workers or mp.cpu_count()
        self.pool = mp.Pool(self.workers, initializer=_init_worker)

    # -- the main API ---------------------------------------------------------

    def iter_batches(
        self,
        pdf_paths: Iterable[str | Path],
        batch_size: int = 32,
        dpi: int = 144,
        encode: str = "raw",          # "raw" -> np arrays | "jpg" -> bytes
        ordered: bool = False,        # True preserves (pdf, page) order
        chunksize: int = 4,
        max_pixels: int | None = None,  # downscale renders above this area
    ) -> Iterator[list[RenderedPage]]:
        """
        Yield lists of RenderedPage of length batch_size (last may be short).

        Tasks are generated lazily, so memory stays flat regardless of corpus
        size. Unordered mode yields whichever pages finish first — fastest and
        the right default for training data. Ordered mode is for consumers
        that need document order (e.g. sequential inference over a report).

        NOTE: imap buffers every finished page in parent RAM if the consumer
        iterates slower than the pool renders. Fine when the consumer keeps
        up (or the corpus is small); for slow consumers use iter_tasks.
        """
        def task_gen():
            for p in pdf_paths:
                p = str(p)
                try:
                    with pymupdf.open(p) as d:
                        n = d.page_count
                except Exception as e:
                    yield None, RenderedPage(p, -1, None, None, f"open failed: {e}")
                    continue
                for i in range(n):
                    yield (p, i, dpi, encode, max_pixels), None

        # split error sentinels from real tasks while staying lazy
        errors: list[RenderedPage] = []

        def clean_tasks():
            for task, err in task_gen():
                if err is not None:
                    errors.append(err)
                    continue
                yield task

        mapper = self.pool.imap if ordered else self.pool.imap_unordered
        results = mapper(_render, clean_tasks(), chunksize=chunksize)

        batch: list[RenderedPage] = []
        for res in results:
            batch.append(_to_page(res))
            if len(batch) >= batch_size:
                yield batch
                batch = []
        # surface unopenable files at the end instead of raising mid-stream
        batch.extend(errors)
        if batch:
            yield batch

    def iter_tasks(
        self,
        tasks: Iterable[tuple[str | Path, int]],
        batch_size: int = 32,
        dpi: int = 144,
        encode: str = "raw",
        max_pixels: int | None = None,
        window: int = 256,
    ) -> Iterator[list[RenderedPage]]:
        """
        Like iter_batches, but renders exactly the given (pdf_path, page_no)
        pairs — for resume-style workloads that must skip already-done pages.

        Submission is windowed: at most `window` pages are in flight or
        finished-but-unconsumed at any moment. imap would render at full CPU
        speed and buffer every finished page in parent RAM whenever the
        consumer is slower than the pool (e.g. GPU-bound inference) — over a
        large corpus that grows unbounded and OOMs the parent. The window
        propagates the consumer's backpressure to the pool, keeping
        parent-side RAM at O(window) pages forever. Results are unordered.
        """
        pending: "queue.Queue[tuple]" = queue.Queue()
        it = iter(tasks)
        outstanding = 0
        exhausted = False
        batch: list[RenderedPage] = []
        while True:
            while not exhausted and outstanding < window:
                try:
                    path, page_no = next(it)
                except StopIteration:
                    exhausted = True
                    break
                self.pool.apply_async(
                    _render,
                    ((str(path), int(page_no), dpi, encode, max_pixels),),
                    callback=pending.put,
                )
                outstanding += 1
            if outstanding == 0:
                break
            batch.append(_to_page(pending.get()))
            outstanding -= 1
            if len(batch) >= batch_size:
                yield batch
                batch = []
        if batch:
            yield batch

    def render_async(self, path: str, page_no: int, dpi: int = 144,
                     encode: str = "raw", max_pixels: int | None = None):
        """Single-page, non-blocking (for inference): .get(timeout=...) later."""
        ar = self.pool.apply_async(
            _render, ((str(path), page_no, dpi, encode, max_pixels),))

        class _Fut:
            def get(_s, timeout=None):
                return _to_page(ar.get(timeout))
        return _Fut()

    def close(self) -> None:
        self.pool.close()
        self.pool.join()

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        self.close()


# ----------------------------------------------------------------------------
# Demo / benchmark
# ----------------------------------------------------------------------------

if __name__ == "__main__":
    import argparse

    ap = argparse.ArgumentParser(description="RasterPool throughput benchmark")
    ap.add_argument("inputs", nargs="+", help="PDF files or directories")
    ap.add_argument("--batch-size", type=int, default=32)
    ap.add_argument("--dpi", type=int, default=144)
    ap.add_argument("--encode", choices=["raw", "jpg"], default="jpg")
    ap.add_argument("--workers", type=int, default=None)
    args = ap.parse_args()

    paths: list[Path] = []
    for inp in args.inputs:
        p = Path(inp)
        paths.extend(sorted(p.rglob("*.pdf")) if p.is_dir() else [p])

    t0 = time.perf_counter()
    done = failed = 0
    with RasterPool(workers=args.workers) as pool:
        for batch in pool.iter_batches(
            paths, batch_size=args.batch_size, dpi=args.dpi, encode=args.encode
        ):
            for page in batch:
                done += page.ok
                failed += not page.ok
            rate = done / (time.perf_counter() - t0)
            print(f"\r{done} pages | {rate:6.1f} pages/sec | {failed} failed",
                  end="", flush=True)
    print(f"\nTotal: {done} pages in {time.perf_counter() - t0:.1f}s")