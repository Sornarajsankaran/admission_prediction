"""Stock vLLM ModernBERT cross-encoder throughput on exact tokenized pairs.

Run each scheduler configuration in a fresh process. Timings include vLLM input
processing, scheduling, GPU inference, and CPU output delivery, but exclude
checkpoint loading, initialization/compilation, tokenization and prompt assembly.
This benchmark performs full bidirectional cross encoding, without Variant B.
"""

import argparse
import importlib.metadata
import json
import os
from pathlib import Path
import statistics
import time

os.environ.setdefault("OMP_NUM_THREADS", "8")
os.environ.setdefault("TOKENIZERS_PARALLELISM", "false")
os.environ.setdefault("VLLM_WORKER_MULTIPROC_METHOD", "spawn")
os.environ.setdefault("VLLM_ENABLE_V1_MULTIPROCESSING", "0")


def find_tensor(data, names):
    for name in names:
        if name in data:
            return data[name]
    raise KeyError(f"None of {names} found; keys={list(data)}")


def make_prompts(path, num_pairs):
    import torch

    data = torch.load(path, map_location="cpu", weights_only=False)
    queries = find_tensor(data, ["query_ids", "queries", "query_input_ids"])
    docs = find_tensor(data, ["doc_input_ids", "doc_ids", "docs", "document_ids", "chunk_ids"])
    qlens = find_tensor(data, ["query_lengths", "query_lens", "q_lengths"])
    dlens = data.get("doc_lengths", data.get("doc_lens"))
    if dlens is None:
        dlens = [docs.shape[1]] * len(docs)
    qlists = [queries[i, :int(qlens[i])].tolist() for i in range(len(queries))]
    dlists = [docs[i, :int(dlens[i])].tolist() for i in range(len(docs))]
    maximum = len(qlists) * len(dlists)
    if num_pairs > maximum:
        raise ValueError(f"Requested {num_pairs} pairs, dataset contains {maximum}")
    prompts = []
    samples = []
    for pair_id in range(num_pairs):
        doc_id, query_id = divmod(pair_id, len(qlists))
        ids = qlists[query_id] + dlists[doc_id]
        prompts.append({"prompt_token_ids": ids})
        if pair_id < 50:
            samples.append({"pair_id": pair_id, "doc_id": doc_id,
                            "query_id": query_id, "length": len(ids)})
    return prompts, samples


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--model", default="models/benchmark-cls")
    parser.add_argument("--data", default="data/tokenized.pt")
    parser.add_argument("--pairs", type=int, default=10000)
    parser.add_argument("--max-num-batched-tokens", type=int, default=32768)
    parser.add_argument("--max-num-seqs", type=int, default=128)
    parser.add_argument("--dtype", default="bfloat16")
    parser.add_argument("--warmup-pairs", type=int, default=512)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--compiled", action="store_true")
    parser.add_argument("--output", default="results/vllm.jsonl")
    args = parser.parse_args()

    import torch
    torch.set_num_threads(8)
    from vllm import LLM, PoolingParams
    from vllm.config import PoolerConfig

    t0 = time.perf_counter()
    prompts, samples = make_prompts(args.data, args.pairs)
    preparation_s = time.perf_counter() - t0
    max_length = max(len(p["prompt_token_ids"]) for p in prompts)
    kwargs = {}
    if not args.compiled:
        kwargs["compilation_config"] = 0
    t0 = time.perf_counter()
    llm = LLM(
        model=args.model,
        runner="pooling",
        dtype=args.dtype,
        hf_overrides={"head_dtype": "model"},
        skip_tokenizer_init=False,
        max_model_len=max_length,
        max_num_batched_tokens=args.max_num_batched_tokens,
        max_num_seqs=args.max_num_seqs,
        enable_prefix_caching=False,
        enable_chunked_prefill=False,
        enforce_eager=not args.compiled,
        pooler_config=PoolerConfig(task="classify", use_activation=False),
        gpu_memory_utilization=0.9,
        seed=17,
        disable_log_stats=True,
        **kwargs,
    )
    initialization_s = time.perf_counter() - t0
    pp = PoolingParams(task="classify", use_activation=False)
    warmup = prompts[:min(args.warmup_pairs, len(prompts))]
    llm.classify(warmup, pooling_params=pp, use_tqdm=False)
    durations = []
    values = None
    for repeat in range(args.repeats):
        t0 = time.perf_counter()
        outputs = llm.classify(prompts, pooling_params=pp, use_tqdm=False)
        seconds = time.perf_counter() - t0
        if len(outputs) != len(prompts):
            raise RuntimeError("vLLM output count mismatch")
        errors = [o.error for o in outputs if o.error is not None]
        if errors:
            raise RuntimeError(f"vLLM request errors: {errors[:3]}")
        durations.append(seconds)
        values = [o.outputs.probs for o in outputs[:len(samples)]]
        print(json.dumps({"repeat": repeat, "seconds": seconds,
                          "pairs_per_second": len(prompts)/seconds}), flush=True)
        del outputs
    for sample, logits in zip(samples, values):
        sample["logits"] = logits
    Path("results").mkdir(exist_ok=True)
    Path("results/vllm_logits.json").write_text(json.dumps({
        "logits": values, "dtype": args.dtype, "samples": samples,
        "use_activation": False,
    }, indent=2))
    median = statistics.median(durations)
    record = {
        "experiment": "vllm_stock_cross_encoder",
        "measurement": "pretokenized_offline_api_wall_clock",
        "num_pairs": len(prompts),
        "num_documents": (len(prompts) + 49) // 50,
        "num_queries": 50,
        "dtype": args.dtype,
        "head_dtype": args.dtype,
        "compiled": args.compiled,
        "max_num_batched_tokens": args.max_num_batched_tokens,
        "max_num_seqs": args.max_num_seqs,
        "max_sequence_length": max_length,
        "seconds": durations,
        "median_seconds": median,
        "pairs_per_second": len(prompts) / median,
        "best_pairs_per_second": len(prompts) / min(durations),
        "input_preparation_seconds": preparation_s,
        "initialization_seconds": initialization_s,
        "warmup_pairs": len(warmup),
        "sample_outputs": samples,
        "versions": {k: importlib.metadata.version(k)
                     for k in ["vllm", "torch", "transformers"]},
    }
    Path(args.output).parent.mkdir(parents=True, exist_ok=True)
    with open(args.output, "a") as f:
        f.write(json.dumps(record) + "\n")
    print(json.dumps({k:v for k,v in record.items() if k != "sample_outputs"}), flush=True)


if __name__ == "__main__":
    main()
