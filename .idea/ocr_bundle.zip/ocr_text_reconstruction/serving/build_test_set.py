"""
Build an OCR test set from PDFs in the model's input format.
============================================================

Runs RapidOCR (PP-OCR detection + recognition on ONNX Runtime) over rasterized PDF
pages and writes one parquet row per page with the same columns the training data
uses (see scripts_v0.1/data.py):

    file_name : PDF filename (under --pdf-dir)
    page      : 1-based page number
    ocr_bbox  : (N, 4) float32 x1,y1,x2,y2 normalized to [0, 1], flattened
    ocr_text  : list[str], aligned with ocr_bbox
    ocr_score : list[float], recognizer confidence

Runs in the ``ocr-tools`` venv (kept apart from the vLLM venv so onnxruntime /
opencv versions never collide):

    /workspace/envs/ocr-tools/bin/python serving/build_test_set.py \
        --pdf-dir /workspace/datasets/ocr_bench/pdfs \
        --out /workspace/datasets/ocr_bench/test_pages.parquet --max-pages 400
"""

from __future__ import annotations

import os

# One ORT/OpenMP thread pool per worker process. Left at the default, every worker
# spins up a pool sized to the whole machine and a single page takes minutes.
_THREADS = os.environ.setdefault("OCR_THREADS_PER_WORKER", "4")
os.environ.setdefault("OMP_NUM_THREADS", _THREADS)

import glob
import random
import time
from concurrent.futures import ProcessPoolExecutor, as_completed
from pathlib import Path

import click
import numpy as np
import pandas as pd
import pymupdf

_ENGINE = None


def _engine():
    global _ENGINE
    if _ENGINE is None:
        import cv2
        from rapidocr import RapidOCR

        cv2.setNumThreads(1)
        n = int(_THREADS)
        _ENGINE = RapidOCR(params={
            "EngineConfig.onnxruntime.intra_op_num_threads": n,
            "EngineConfig.onnxruntime.inter_op_num_threads": 1,
            "Global.log_level": "warning",
        })
    return _ENGINE


def ocr_page(pdf_path: str, page_no: int, zoom: float) -> dict:
    """OCR one page (1-based ``page_no``) -> a parquet row."""
    doc = pymupdf.open(pdf_path)
    pix = doc[page_no - 1].get_pixmap(matrix=pymupdf.Matrix(zoom, zoom), alpha=False)
    img = np.frombuffer(pix.samples, np.uint8).reshape(pix.height, pix.width, 3)

    t0 = time.perf_counter()
    res = _engine()(img)
    elapsed = time.perf_counter() - t0

    if res.boxes is None or len(res.boxes) == 0:
        boxes = np.zeros((0, 4), np.float32)
        texts, scores = [], []
    else:
        quads = np.asarray(res.boxes, np.float32)                    # (N, 4, 2) pixel quads
        xyxy = np.concatenate([quads.min(1), quads.max(1)], axis=1)  # axis-aligned hull
        xyxy /= np.array([pix.width, pix.height, pix.width, pix.height], np.float32)
        boxes = np.clip(xyxy, 0.0, 1.0)
        texts, scores = list(res.txts), [float(s) for s in res.scores]

    return {
        "file_name": Path(pdf_path).name,
        "page": page_no,
        "ocr_bbox": boxes.reshape(-1).tolist(),
        "ocr_text": texts,
        "ocr_score": scores,
        "num_boxes": len(texts),
        "ocr_seconds": elapsed,
    }


@click.command()
@click.option("--pdf-dir", required=True, type=click.Path(exists=True, file_okay=False))
@click.option("--out", required=True, type=click.Path(dir_okay=False))
@click.option("--max-pages", default=400, show_default=True, help="pages sampled across all PDFs")
@click.option("--zoom", default=2.0, show_default=True, help="rasterization scale (2.0 ~= 144 dpi)")
@click.option("--workers", default=24, show_default=True)
@click.option("--seed", default=0, show_default=True)
def main(pdf_dir, out, max_pages, zoom, workers, seed):
    pages = []
    for pdf in sorted(glob.glob(os.path.join(pdf_dir, "*.pdf"))):
        with pymupdf.open(pdf) as doc:
            pages += [(pdf, i + 1) for i in range(len(doc))]
    random.Random(seed).shuffle(pages)
    pages = pages[:max_pages]
    print(f"OCR {len(pages)} pages with {workers} workers x {_THREADS} threads")

    rows, t0 = [], time.perf_counter()
    with ProcessPoolExecutor(max_workers=workers) as pool:
        futures = [pool.submit(ocr_page, pdf, p, zoom) for pdf, p in pages]
        for i, fut in enumerate(as_completed(futures), 1):
            rows.append(fut.result())
            if i % 25 == 0 or i == len(futures):
                print(f"  {i}/{len(futures)}  {time.perf_counter() - t0:6.1f}s")

    df = pd.DataFrame(rows).sort_values(["file_name", "page"]).reset_index(drop=True)
    df.to_parquet(out, index=False)
    n = df["num_boxes"]
    print(f"wrote {out}: {len(df)} pages | boxes/page min/median/p90/max = "
          f"{n.min()}/{int(n.median())}/{int(n.quantile(0.9))}/{n.max()} | "
          f"ocr s/page median {df['ocr_seconds'].median():.2f}")


if __name__ == "__main__":
    main()
