"""
VRAM usage profiler for GRPO training.

Measures peak GPU memory at each phase of a train step:
  1. Model weights (policy + reference)
  2. Pixel values buffer (B=32 images)
  3. encode_boxes (frozen backbone, no grad)
  4. sample_decode — KV cache grows to L tokens
  5. Policy forward + backward (AR decoder gradients)
  6. Reference forward (no grad)
  7. Optimizer state (AdamW — estimated, not measured live)

Usage:
    python benchmark_vram.py --device cuda
"""

from __future__ import annotations

import json
import sys
from pathlib import Path

import click

import torch

REPO = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(REPO / "scripts"))

from modeling_ocr_reconstruction import OcrReconstructionConfig, OcrTextReconstructionModel
from transformers import RTDetrV2Config, RTDetrV2Model

_HERON_CFG  = REPO / "layout_heron" / "heron_config.json"
_HERON_SKIP = {"architectures", "model_type", "torch_dtype", "transformers_version",
               "id2label", "label2id"}


def gb(n_bytes: int) -> str:
    return f"{n_bytes / 1e9:.3f} GB"


def peak_since(baseline_bytes: int) -> int:
    return torch.cuda.max_memory_allocated() - baseline_bytes


def build_model(device):
    with open(_HERON_CFG) as f:
        hcfg = json.load(f)
    rt_cfg = RTDetrV2Config(**{k: v for k, v in hcfg.items() if k not in _HERON_SKIP})
    rt     = RTDetrV2Model(rt_cfg)
    cfg    = OcrReconstructionConfig(d_model=rt_cfg.d_model)
    model  = OcrTextReconstructionModel(cfg, rtdetr=rt).to(device)
    return model


def make_batch(B, N, device):
    raw = torch.rand(B, N, 4, device=device)
    x1, y1 = torch.min(raw[..., 0], raw[..., 2]), torch.min(raw[..., 1], raw[..., 3])
    x2, y2 = torch.max(raw[..., 0], raw[..., 2]), torch.max(raw[..., 1], raw[..., 3])
    boxes = torch.stack([x1, y1, x2, y2], dim=-1)
    return {
        "pixel_values": torch.rand(B, 3, 640, 640, device=device),
        "ocr_boxes":    boxes,
        "box_mask":     torch.ones(B, N, dtype=torch.bool, device=device),
    }


def profile(device_str: str):
    device = torch.device(device_str)
    B = 32  # P=4 × K=8

    print(f"\n{'='*70}")
    print(f"GRPO VRAM Profile  |  device={device}  |  B={B} (P=4 × K=8)")
    print(f"{'='*70}")

    # ── Phase 0: GPU baseline ─────────────────────────────────────────────────
    torch.cuda.reset_peak_memory_stats(device)
    base = torch.cuda.memory_allocated(device)
    total_vram = torch.cuda.get_device_properties(device).total_memory
    print(f"\nGPU total VRAM : {gb(total_vram)}")
    print(f"Baseline (empty): {gb(base)}")

    # ── Phase 1: model weights (single copy = policy model) ──────────────────
    model = build_model(device)
    model.freeze_rtdetr()          # backbone frozen for RL
    after_model = torch.cuda.memory_allocated(device)
    model_bytes = after_model - base
    print(f"\n[1] Policy model weights    : {gb(model_bytes)}")

    # Reference model is an identical copy (kept in eval, no grad)
    ref_model = build_model(device).eval()
    for p in ref_model.parameters():
        p.requires_grad_(False)
    after_ref = torch.cuda.memory_allocated(device)
    ref_bytes = after_ref - after_model
    print(f"[2] Reference model weights : {gb(ref_bytes)}")
    print(f"    Both models together    : {gb(after_ref - base)}")

    for N in [73, 443]:
        for L in [512, 1024, 2048]:
            print(f"\n{'─'*70}")
            print(f"  N={N} boxes/page   max_new_tokens={L}")
            print(f"{'─'*70}")

            batch = make_batch(B, N, device)
            pv    = batch["pixel_values"]
            ob    = batch["ocr_boxes"]
            bm    = batch["box_mask"]

            mem_after_models = torch.cuda.memory_allocated(device)

            # ── pixel values ──────────────────────────────────────────────
            pv_bytes = pv.element_size() * pv.numel()
            print(f"  [3] Pixel values (B={B}×3×640×640)  : {gb(pv_bytes)}")

            # ── encode_boxes (frozen, no grad) ────────────────────────────
            torch.cuda.reset_peak_memory_stats(device)
            with torch.no_grad():
                h_box = model.encode_boxes(pv, ob, box_mask=bm)
            enc_peak = peak_since(mem_after_models)
            enc_after = torch.cuda.memory_allocated(device) - mem_after_models
            print(f"  [4] encode_boxes  peak activation  : {gb(enc_peak)}"
                  f"   (h_box retained: {gb(h_box.element_size()*h_box.numel())})")

            # ── sample_decode: KV cache fills up ──────────────────────────
            torch.cuda.reset_peak_memory_stats(device)
            before_decode = torch.cuda.memory_allocated(device)
            with torch.no_grad():
                seqs, old_lp, valid = model.sample_decode(
                    pv, ob, box_mask=bm, max_new_tokens=L, temperature=1.0
                )
            decode_peak = peak_since(before_decode)
            # KV cache theoretical size at final step
            d = model.config.d_model
            n_layers = model.config.num_markdown_layers
            actual_L = seqs.size(1) - 1   # actual generated length
            kv_self_bytes  = n_layers * 2 * B * actual_L * d * 4  # fp32, self K+V
            kv_cross_bytes = n_layers * 2 * B * N * d * 4         # fp32, cross K+V
            print(f"  [5] sample_decode (L={actual_L:4d}) peak  : {gb(decode_peak)}")
            print(f"       └─ KV cache self  (theoretical) : {gb(kv_self_bytes)}")
            print(f"       └─ KV cache cross (theoretical) : {gb(kv_cross_bytes)}")

            # ── policy forward + backward ─────────────────────────────────
            # Simulates what GRPO does: forward on sampled sequences, backprop
            # through the AR decoder (backbone is frozen → no grad through it)
            torch.cuda.reset_peak_memory_stats(device)
            before_fwdbwd = torch.cuda.memory_allocated(device)
            model.train()
            # With frozen backbone, encode_boxes runs in no_grad
            with torch.no_grad():
                h_box_fwd = model.encode_boxes(pv, ob, box_mask=bm)
            # Only AR decoder runs with grad
            T_in  = seqs[:, :-1]
            T_out = seqs[:, 1:]
            tok_emb = model._embed_tokens(T_in, h_box_fwd)
            T = T_in.size(1)
            x = tok_emb + model.pos_embedding[:, :T]
            causal = torch.triu(torch.full((T, T), float("-inf"), device=device), diagonal=1)
            mem_pad = (~bm)
            hidden = model.markdown_decoder(tgt=x, memory=h_box_fwd,
                                            tgt_mask=causal,
                                            memory_key_padding_mask=mem_pad)
            hidden = model.decoder_norm(hidden)
            logits, _, _ = model._compute_logits(hidden, h_box_fwd, bm)
            # Policy loss (simplified cross-entropy as proxy for GRPO loss)
            loss = torch.nn.functional.cross_entropy(
                logits.reshape(-1, logits.size(-1)),
                T_out.reshape(-1).clamp(0, logits.size(-1) - 1),
            )
            fwdbwd_peak_before_bwd = torch.cuda.max_memory_allocated(device) - before_fwdbwd
            loss.backward()
            fwdbwd_peak = peak_since(before_fwdbwd)
            print(f"  [6] policy fwd (T={T}) peak          : {gb(fwdbwd_peak_before_bwd)}")
            print(f"  [6] policy fwd+bwd peak              : {gb(fwdbwd_peak)}")
            model.zero_grad(set_to_none=True)

            # ── reference forward (no grad) ───────────────────────────────
            torch.cuda.reset_peak_memory_stats(device)
            before_ref = torch.cuda.memory_allocated(device)
            with torch.no_grad():
                ref_out = ref_model.forward(pv, ob, decoder_input_ids=T_in, box_mask=bm)
            ref_peak = peak_since(before_ref)
            print(f"  [7] ref model fwd (no grad) peak     : {gb(ref_peak)}")

            # ── total live after one full step ────────────────────────────
            # AdamW optimizer: 2 tensors per trainable param (m + v), fp32
            trainable_bytes = sum(
                p.numel() * p.element_size()
                for p in model.parameters() if p.requires_grad
            )
            adam_bytes = 2 * trainable_bytes  # m and v in fp32
            print(f"\n  [8] AdamW state (est, 2×trainable)  : {gb(adam_bytes)}")

            # ── grand total estimate ──────────────────────────────────────
            # Worst case: both models + pixel buffer + peak of fwd+bwd + adam
            grand = (after_ref - base) + pv_bytes + fwdbwd_peak + adam_bytes
            print(f"\n  *** Estimated peak VRAM (training) :")
            print(f"      Both models    : {gb(after_ref - base)}")
            print(f"      Pixel buffer   : {gb(pv_bytes)}")
            print(f"      Fwd+bwd peak   : {gb(fwdbwd_peak)}")
            print(f"      AdamW state    : {gb(adam_bytes)}")
            print(f"      ─────────────────────────────────")
            print(f"      TOTAL ESTIMATE : {gb(grand)}  "
                  f"(L40s has {gb(total_vram)} → "
                  f"{'OK' if grand < total_vram * 0.9 else 'TIGHT'} "
                  f"[{100*grand/total_vram:.0f}% of VRAM])")

            # Cleanup
            del seqs, old_lp, valid, h_box, h_box_fwd
            del tok_emb, x, hidden, logits, loss, ref_out
            torch.cuda.empty_cache()
            model.eval()


@click.command(context_settings={"show_default": True})
@click.option("--device", default="cuda", help="Compute device.")
def main(device):
    profile(device)


if __name__ == "__main__":
    main()
