"""HF-style config for the vLLM port of ``OcrTwoStageModel``.

Token id layout of the single decoder stream (one vLLM request per page):

    [0, M)                     markdown specials (vocab.json order; bos=0, eos=1, pad=2)
    M                          EMIT_NEXT          (formatter: place the cursor block)
    M + 1                      ORD_BOS            (decoder prompt)
    M + 2                      FMT_BOS            (forced once the order is complete)
    M + 3                      GAP                (forced filler, see below)
    M + 4 + b, b < max_boxes   BOX_b              (order decoder: box b is next)

A page with K boxes decodes as

    ORD_BOS  BOX_o0 ... BOX_o{K-1}  GAP ... GAP  FMT_BOS  f_1 ... f_T(=eos)
    '--------- order stage ---------------------' '---- formatter stage -----'

GAP tokens pad the order stage so FMT_BOS lands on a KV-cache block boundary; the
formatter's self-attention then reads only its own blocks (see model.py).
"""

from __future__ import annotations

from transformers import PretrainedConfig


class OcrTwoStageConfig(PretrainedConfig):
    model_type = "ocr_twostage"

    def __init__(
        self,
        d_model: int = 256,
        num_decoder_layers: int = 6,
        decoder_attention_heads: int = 8,
        decoder_ffn_dim: int = 2048,
        content_mlp_hidden_dim: int = 512,
        content_mlp_num_layers: int = 3,
        num_special_tokens: int = 69,
        max_boxes: int = 1024,
        stage_max_positions: int = 2048,
        max_format_tokens: int = 2048,
        rtdetr_config: dict | None = None,
        encoder_dtype: str = "float32",
        encoder_max_batch: int = 8,
        compile_encoder: bool = True,
        compile_decoder: bool = True,
        encoder_channels_last: bool = True,
        **kwargs,
    ):
        self.d_model = d_model
        self.num_decoder_layers = num_decoder_layers
        self.decoder_attention_heads = decoder_attention_heads
        self.decoder_ffn_dim = decoder_ffn_dim
        self.content_mlp_hidden_dim = content_mlp_hidden_dim
        self.content_mlp_num_layers = content_mlp_num_layers
        self.num_special_tokens = num_special_tokens
        self.max_boxes = max_boxes
        # size of each decoder's learned positional table (reference max_position_embeddings)
        self.stage_max_positions = stage_max_positions
        self.max_format_tokens = max_format_tokens
        self.rtdetr_config = rtdetr_config or {}
        # dtype the RT-DETR encoder runs in ("float32" | "bfloat16" | "float16"); the
        # decoders always run in the model dtype.
        self.encoder_dtype = encoder_dtype
        # page images per RT-DETR forward: bounds activation memory, and 8 measured faster
        # per page than 16 or 32 on L40S (1.38 vs 1.58 / 1.69 ms, bf16, channels_last)
        self.encoder_max_batch = encoder_max_batch
        # torch.compile the encoder's image backbone (static shape, compiled at startup)
        self.compile_encoder = compile_encoder
        # torch.compile the decoder's dense (non-attention) pieces to fuse small kernels
        self.compile_decoder = compile_decoder
        # channels_last convs: faster, but fp32 results differ from the NCHW reference in
        # the last bits (turn off for bit-exact parity tests)
        self.encoder_channels_last = encoder_channels_last

        # vLLM reads these generic names.
        kwargs.setdefault("is_encoder_decoder", True)
        kwargs.setdefault("vocab_size", num_special_tokens + 4 + max_boxes)
        kwargs.setdefault("hidden_size", d_model)
        # vLLM attention backends size per-group decode workspaces from the model-level
        # head count / head size, so these must be the maxima over ALL attention layers
        # (all of this model's layers use the decoder's heads x head_dim).
        kwargs.setdefault("num_attention_heads", decoder_attention_heads)
        kwargs.setdefault("num_key_value_heads", decoder_attention_heads)
        kwargs.setdefault("head_dim", d_model // decoder_attention_heads)
        kwargs.setdefault("num_hidden_layers", num_decoder_layers)
        kwargs.setdefault("bos_token_id", num_special_tokens + 1)
        kwargs.setdefault("eos_token_id", 1)
        kwargs.setdefault("pad_token_id", 2)
        kwargs.setdefault("decoder_start_token_id", num_special_tokens + 1)
        # longest decoder stream: ORD_BOS + K boxes + GAPs (< one KV block) + FMT_BOS +
        # formatter tokens. vLLM
        # derives max_model_len from max_position_embeddings, so it names the stream.
        kwargs.setdefault("max_position_embeddings", max_boxes + 2 + max_format_tokens + 64)
        # longest encoder "sequence" (one row per OCR box); vLLM sizes cross-attention
        # CUDA graphs from this
        kwargs.setdefault("max_source_positions", max_boxes)
        super().__init__(**kwargs)

    # ---- token id helpers ----
    @property
    def emit_id(self) -> int:
        return self.num_special_tokens

    @property
    def ord_bos_id(self) -> int:
        return self.num_special_tokens + 1

    @property
    def fmt_bos_id(self) -> int:
        return self.num_special_tokens + 2

    @property
    def gap_id(self) -> int:
        return self.num_special_tokens + 3

    @property
    def box0_id(self) -> int:
        return self.num_special_tokens + 4
