"""CPU-only tests for OCR-dataframe parsing and markdown decoding."""

import json

import numpy as np
import pandas as pd
import pytest

from ocr_vllm.decode import DEFAULT_VOCAB, MarkdownDecoder
from ocr_vllm.inputs import build_jobs, parse_line_cords, parse_lines

# model-compact special ids (vocab.json ids start at 10000)
TOK = {t: i - 10000 for t, i in json.loads(DEFAULT_VOCAB.read_text())["tokens"].items()}


def test_line_cords_reordered_to_xyxy():
    # Textract layout is x1,x2,y1,y2
    boxes = parse_line_cords("0.12,0.34,0.88,0.93|0.02,0.1,0.2,0.4")
    np.testing.assert_allclose(boxes, [[0.12, 0.88, 0.34, 0.93], [0.02, 0.2, 0.1, 0.4]], rtol=1e-6)


def test_line_cords_swapped_corners_and_clipping():
    boxes = parse_line_cords("0.5,0.1,0.9,0.2|-0.01,1.2,0.3,0.4")
    np.testing.assert_allclose(boxes, [[0.1, 0.2, 0.5, 0.9], [0.0, 0.3, 1.0, 0.4]], rtol=1e-6)


def test_line_cords_bad_and_empty():
    assert parse_line_cords("").shape == (0, 4)
    assert parse_line_cords(None).shape == (0, 4)
    with pytest.raises(ValueError):
        parse_line_cords("0.1,0.2,0.3")


def test_lines_tabs_become_spaces():
    assert parse_lines("Total\tAmount\tDue\n$\t12.00") == ["Total Amount Due", "$ 12.00"]
    assert parse_lines("") == [] and parse_lines(None) == []


def test_build_jobs_statuses(tmp_path):
    import pymupdf

    doc = pymupdf.open()
    doc.new_page()
    doc.save(tmp_path / "a.pdf")
    df = pd.DataFrame([
        {"file_name": "a.pdf", "page": 1, "content": "x\ty\nz", "line_cords": "0,1,0,0.1|0,1,0.2,0.3"},
        {"file_name": "a.pdf", "page": 2, "content": "x", "line_cords": "0,1,0,0.1|0,1,0.2,0.3"},
        {"file_name": "missing.pdf", "page": 1, "content": "x", "line_cords": "0,1,0,0.1"},
        {"file_name": "a", "page": 3, "content": "", "line_cords": ""},
        {"file_name": "a.pdf", "page": 4, "content": "x", "line_cords": "0,1,0"},
        {"file_name": "a.pdf", "page": 1, "content": "x", "line_cords": "0,1,0,0.1"},
    ])
    jobs = build_jobs(df, tmp_path, max_boxes=1024)
    assert [j.status for j in jobs] == ["ok", "line_box_mismatch", "missing_pdf", "no_lines",
                                        "bad_cords", "duplicate_row"]
    assert jobs[0].lines == ["x y", "z"]


def test_decode_emit_follows_reading_order():
    dec = MarkdownDecoder()
    tok, emit = TOK, dec.num_special
    lines = ["Title", "first para", "second para"]
    ids = [tok["#"], tok[" "], emit, tok["\n"], emit, tok["\n"], emit, tok["<eos>"]]
    assert dec.decode([0, 2, 1], ids, lines) == "# Title\nsecond para\nfirst para"


def test_decode_table_spans():
    dec = MarkdownDecoder()
    tok, emit = TOK, dec.num_special
    ids = [tok["<TABLE>"], tok["<TR>"], tok["<TD>"], tok["<COLSPAN>"], tok["<COLSPAN>"], emit,
           tok["</TD>"], tok["</TR>"], tok["</TABLE>"], tok["<eos>"]]
    assert dec.decode([0], ids, ["cell"]) == '<table><tr><td colspan="2">cell</td></tr></table>'


def test_rasterizer_shape_and_page_bounds(tmp_path):
    import pymupdf

    from ocr_vllm.inputs import PageRasterizer

    doc = pymupdf.open()
    doc.new_page().insert_text((72, 72), "hello")
    doc.save(tmp_path / "one.pdf")
    raster = PageRasterizer()
    img = raster(str(tmp_path / "one.pdf"), 0)
    assert img.shape == (3, 640, 640) and img.dtype == np.uint8
    for bad in (-1, 1):                      # -1 must not wrap to the last page
        with pytest.raises(IndexError):
            raster(str(tmp_path / "one.pdf"), bad)
