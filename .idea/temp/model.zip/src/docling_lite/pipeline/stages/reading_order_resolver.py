import hashlib
from dataclasses import dataclass, field
from pathlib import Path

import pandas as pd
from docling.datamodel.base_models import (
    AssembledUnit,
    BasePageElement,
    ContainerElement,
    FigureElement,
    Page,
    Table,
    TextElement,
)
from docling_core.types.doc import (
    DocItemLabel,
    DoclingDocument,
    DocumentOrigin,
    GroupLabel,
    NodeItem,
    ProvenanceItem,
    RefItem,
    RichTableCell,
    TableData,
)
from docling_core.types.doc.document import ContentLayer
from docling_ibm_models.list_item_normalizer.list_marker_processor import (
    ListItemMarkerProcessor,
)
from docling_ibm_models.reading_order.reading_order_rb import (
    PageElement as ReadingOrderPageElement,
    ReadingOrderPredictor,
)
from pydantic import BaseModel, ConfigDict

from docling_lite.core.config import READING_ORDER_CONFIG
from docling_lite.core.logging import log_function_calls, logger


EMPTY_CHARSPAN: tuple[int, int] = (0, 0)


@dataclass
class _FileReadingOrderContext:
    file_name: str
    document_hash: str
    pages: list[Page]
    assembled: AssembledUnit


@dataclass
class _RelationshipMappings:
    captions: dict[int, list[int]] = field(default_factory=dict)
    footnotes: dict[int, list[int]] = field(default_factory=dict)
    merges: dict[int, list[int]] = field(default_factory=dict)

    def skippable_cids(self) -> set[int]:
        return {
            cid
            for mapping in (self.captions, self.footnotes, self.merges)
            for cid_list in mapping.values()
            for cid in cid_list
        }


@dataclass
class _BuildContext:
    doc: DoclingDocument
    page_map: dict[int, Page]
    id_to_elem: dict[str, BasePageElement]
    cid_to_rel: dict[int, ReadingOrderPageElement]
    mappings: _RelationshipMappings
    current_list: NodeItem | None = None

    def page_height(self, page_no: int) -> float:
        page = self.page_map[page_no]
        assert page.size is not None
        return page.size.height

    def element_for_cid(self, cid: int) -> BasePageElement:
        return self.id_to_elem[self.cid_to_rel[cid].ref.cref]


class ReadingOrderResolverOptions(BaseModel):
    model_config = ConfigDict(protected_namespaces=())
    list_item_infer_enumerated: bool = True


class ReadingOrderResolver:
    def __init__(self, options: ReadingOrderResolverOptions | None = None):
        self.options = options or self._build_options_from_config()
        self.ro_model = ReadingOrderPredictor()
        self.list_item_processor = ListItemMarkerProcessor(
            infer_enumerated=self.options.list_item_infer_enumerated
        )

    @staticmethod
    def _build_options_from_config() -> ReadingOrderResolverOptions:
        cfg = READING_ORDER_CONFIG
        return ReadingOrderResolverOptions(
            list_item_infer_enumerated=bool(
                cfg.get("list_item_infer_enumerated", True)
            )
        )

    # ── Input handling ────────────────────────────────────────────────

    @staticmethod
    def _validate_input(df: pd.DataFrame) -> None:
        required = {"file_name", "docling_page_obj"}
        missing = required - set(df.columns)
        if missing:
            raise ValueError(
                "Input DataFrame is missing required columns: "
                + ", ".join(sorted(missing))
            )

    @staticmethod
    def _collect_pages(file_df: pd.DataFrame) -> list[Page]:
        page_by_no: dict[int, Page] = {}
        for page in file_df["docling_page_obj"]:
            if not isinstance(page, Page):
                raise TypeError("Each 'docling_page_obj' entry must be a docling Page.")
            page_by_no.setdefault(page.page_no, page)
        return [page_by_no[page_no] for page_no in sorted(page_by_no)]

    @staticmethod
    def _build_file_context(
        file_name: str, pages: list[Page]
    ) -> _FileReadingOrderContext:
        elements, headers, body = [], [], []
        signature_parts: list[str] = []

        for page in pages:
            assembled = page.assembled or AssembledUnit()
            elements.extend(assembled.elements)
            headers.extend(assembled.headers)
            body.extend(assembled.body)
            signature_parts.append(
                f"{page.page_no}:{len(assembled.elements)}:"
                f"{len(assembled.headers)}:{len(assembled.body)}"
            )

        signature = f"{file_name}|{'|'.join(signature_parts)}"
        document_hash = hashlib.sha256(signature.encode("utf-8")).hexdigest()
        return _FileReadingOrderContext(
            file_name=file_name,
            document_hash=document_hash,
            pages=pages,
            assembled=AssembledUnit(elements=elements, headers=headers, body=body),
        )

    # ── Reading-order element preparation & prediction ────────────────

    @staticmethod
    def _assembled_to_readingorder_elements(
        ctx: _FileReadingOrderContext,
    ) -> list[ReadingOrderPageElement]:
        page_map = {page.page_no: page for page in ctx.pages}
        ro_elements: list[ReadingOrderPageElement] = []

        for element in ctx.assembled.elements:
            page = page_map.get(element.page_no)
            if page is None or page.size is None:
                raise ValueError(
                    f"Page metadata missing for element page_no={element.page_no}."
                )

            bbox = element.cluster.bbox.to_bottom_left_origin(page.size.height)
            ro_elements.append(
                ReadingOrderPageElement(
                    cid=len(ro_elements),
                    ref=RefItem(cref=f"#/{element.page_no}/{element.cluster.id}"),
                    text=element.text or "",
                    page_no=element.page_no,
                    page_size=page.size,
                    label=element.label,
                    l=bbox.l,
                    r=bbox.r,
                    b=bbox.b,
                    t=bbox.t,
                    coord_origin=bbox.coord_origin,
                )
            )
        return ro_elements

    def _predict_relationships(
        self, ro_elements: list[ReadingOrderPageElement]
    ) -> tuple[list[ReadingOrderPageElement], _RelationshipMappings]:
        if not ro_elements:
            return [], _RelationshipMappings()

        sorted_elements = self.ro_model.predict_reading_order(
            page_elements=ro_elements
        )
        return sorted_elements, _RelationshipMappings(
            captions=self.ro_model.predict_to_captions(
                sorted_elements=sorted_elements
            ),
            footnotes=self.ro_model.predict_to_footnotes(
                sorted_elements=sorted_elements
            ),
            merges=self.ro_model.predict_merges(sorted_elements=sorted_elements),
        )

    # ── Small builders (prov, captions/footnotes, child elements) ─────

    @staticmethod
    def _make_prov(
        element: BasePageElement,
        page_height: float,
        charspan: tuple[int, int] | None = None,
    ) -> ProvenanceItem:
        if charspan is None:
            text = getattr(element, "text", "") or ""
            charspan = (0, len(text))
        return ProvenanceItem(
            page_no=element.page_no,
            charspan=charspan,
            bbox=element.cluster.bbox.to_bottom_left_origin(page_height),
        )

    def _add_caption_or_footnote(
        self, elem: TextElement, parent: NodeItem, ctx: _BuildContext
    ) -> NodeItem:
        page_height = ctx.page_height(elem.page_no)
        return ctx.doc.add_text(
            label=elem.label,
            text=elem.text or "",
            prov=self._make_prov(elem, page_height),
            parent=parent,
        )

    def _attach_captions_and_footnotes(
        self, item: NodeItem, rel_cid: int, ctx: _BuildContext
    ) -> None:
        for cid in ctx.mappings.captions.get(rel_cid, []):
            caption_elem = ctx.element_for_cid(cid)
            caption_item = self._add_caption_or_footnote(caption_elem, item, ctx)
            item.captions.append(caption_item.get_ref())

        for cid in ctx.mappings.footnotes.get(rel_cid, []):
            footnote_elem = ctx.element_for_cid(cid)
            footnote_item = self._add_caption_or_footnote(footnote_elem, item, ctx)
            item.footnotes.append(footnote_item.get_ref())

    def _add_child_elements(
        self, element: BasePageElement, parent: NodeItem, doc: DoclingDocument
    ) -> None:
        page_height = doc.pages[element.page_no].size.height
        for child in element.cluster.children:
            bbox = child.bbox.to_bottom_left_origin(page_height)
            text = " ".join(
                cell.text.replace("\x02", "-").strip()
                for cell in child.cells
                if cell.text and cell.text.strip()
            )
            prov = ProvenanceItem(
                page_no=element.page_no,
                charspan=(0, len(text)),
                bbox=bbox,
            )

            if child.label == DocItemLabel.LIST_ITEM:
                list_item = doc.add_list_item(parent=parent, text=text, prov=prov)
                self.list_item_processor.process_list_item(list_item)
            elif child.label == DocItemLabel.SECTION_HEADER:
                doc.add_heading(parent=parent, text=text, prov=prov)
            else:
                doc.add_text(parent=parent, label=child.label, text=text, prov=prov)

    # ── Per-element-type handlers ─────────────────────────────────────

    def _build_code(
        self,
        rel: ReadingOrderPageElement,
        element: TextElement,
        ctx: _BuildContext,
    ) -> None:
        page_height = ctx.page_height(element.page_no)
        code_item = ctx.doc.add_code(
            text=element.text or "",
            prov=self._make_prov(element, page_height),
        )
        self._attach_captions_and_footnotes(code_item, rel.cid, ctx)

    def _build_text(
        self,
        rel: ReadingOrderPageElement,
        element: TextElement,
        ctx: _BuildContext,
    ) -> None:
        page_height = ctx.page_height(element.page_no)
        text = element.text or ""
        prov = self._make_prov(element, page_height)
        doc = ctx.doc

        if element.label == DocItemLabel.LIST_ITEM:
            if ctx.current_list is None:
                ctx.current_list = doc.add_group(label=GroupLabel.LIST, name="list")
            new_item = doc.add_list_item(
                text=text, enumerated=False, prov=prov, parent=ctx.current_list
            )
            self.list_item_processor.process_list_item(new_item)
        elif element.label == DocItemLabel.SECTION_HEADER:
            new_item = doc.add_heading(text=text, prov=prov)
            ctx.current_list = None
        elif element.label == DocItemLabel.FORMULA:
            new_item = doc.add_text(
                label=DocItemLabel.FORMULA, text="", orig=text, prov=prov
            )
            ctx.current_list = None
        else:
            content_layer = (
                ContentLayer.FURNITURE
                if element.label in {DocItemLabel.PAGE_HEADER, DocItemLabel.PAGE_FOOTER}
                else ContentLayer.BODY
            )
            new_item = doc.add_text(
                label=element.label,
                text=text,
                prov=prov,
                content_layer=content_layer,
            )
            ctx.current_list = None

        for merged_cid in ctx.mappings.merges.get(rel.cid, []):
            merged_elem = ctx.element_for_cid(merged_cid)
            self._merge_elements(merged_elem, new_item, page_height)

    @staticmethod
    def _merge_elements(
        merged_elem: TextElement, new_item: NodeItem, page_height: float
    ) -> None:
        assert merged_elem.label == new_item.label, "Merged labels must match."
        merged_text = merged_elem.text or ""
        new_text = getattr(new_item, "text", "") or ""

        prov = ProvenanceItem(
            page_no=merged_elem.page_no,
            charspan=(len(new_text) + 1, len(new_text) + 1 + len(merged_text)),
            bbox=merged_elem.cluster.bbox.to_bottom_left_origin(page_height),
        )
        new_item.text = f"{new_text} {merged_text}".strip()
        if hasattr(new_item, "orig") and isinstance(new_item.orig, str):
            new_item.orig = f"{new_item.orig} {merged_text}".strip()
        if hasattr(new_item, "prov") and isinstance(new_item.prov, list):
            new_item.prov.append(prov)

    def _build_table(
        self,
        rel: ReadingOrderPageElement,
        element: Table,
        ctx: _BuildContext,
    ) -> None:
        page_height = ctx.page_height(element.page_no)
        is_empty_shape = element.num_rows == 0 and element.num_cols == 0
        has_children = bool(element.cluster.children)

        table_item = ctx.doc.add_table(
            data=self._build_table_data(element, is_empty_shape, has_children),
            prov=self._make_prov(element, page_height, charspan=EMPTY_CHARSPAN),
            label=element.cluster.label,
        )

        self._attach_captions_and_footnotes(table_item, rel.cid, ctx)

        if is_empty_shape and has_children:
            rich_cell_ref = self._create_rich_cell_group(element, table_item, ctx.doc)
            ctx.doc.add_table_cell(
                table_item=table_item,
                cell=RichTableCell(
                    text="",
                    row_span=1,
                    col_span=1,
                    start_row_offset_idx=0,
                    end_row_offset_idx=1,
                    start_col_offset_idx=0,
                    end_col_offset_idx=1,
                    column_header=False,
                    row_header=False,
                    ref=rich_cell_ref,
                ),
            )

    @staticmethod
    def _build_table_data(
        element: Table, is_empty_shape: bool, has_children: bool
    ) -> TableData:
        if is_empty_shape:
            dim = 1 if has_children else 0
            return TableData(num_rows=dim, num_cols=dim, table_cells=[])
        return TableData(
            num_rows=element.num_rows,
            num_cols=element.num_cols,
            table_cells=element.table_cells,
        )

    def _create_rich_cell_group(
        self, element: BasePageElement, table_item: NodeItem, doc: DoclingDocument
    ) -> RefItem:
        group = doc.add_group(
            label=GroupLabel.UNSPECIFIED,
            name=f"rich_cell_group_{len(doc.tables)}_0_0",
            parent=table_item,
        )
        self._add_child_elements(element, group, doc)
        return group.get_ref()

    def _build_figure(
        self,
        rel: ReadingOrderPageElement,
        element: FigureElement,
        ctx: _BuildContext,
    ) -> None:
        page_height = ctx.page_height(element.page_no)
        picture_item = ctx.doc.add_picture(
            prov=self._make_prov(element, page_height, charspan=EMPTY_CHARSPAN),
        )
        self._attach_captions_and_footnotes(picture_item, rel.cid, ctx)
        self._add_child_elements(element, picture_item, ctx.doc)

    def _build_container(
        self,
        rel: ReadingOrderPageElement,
        element: ContainerElement,
        ctx: _BuildContext,
    ) -> None:
        if element.label == DocItemLabel.FORM:
            group_label = GroupLabel.FORM_AREA
        elif element.label == DocItemLabel.KEY_VALUE_REGION:
            group_label = GroupLabel.KEY_VALUE_AREA
        else:
            group_label = GroupLabel.UNSPECIFIED

        container_group = ctx.doc.add_group(label=group_label)
        self._add_child_elements(element, container_group, ctx.doc)

    def _dispatch(
        self,
        rel: ReadingOrderPageElement,
        element: BasePageElement,
        ctx: _BuildContext,
    ) -> None:
        if isinstance(element, TextElement):
            if element.label == DocItemLabel.CODE:
                self._build_code(rel, element, ctx)
            else:
                self._build_text(rel, element, ctx)
        elif isinstance(element, Table):
            self._build_table(rel, element, ctx)
        elif isinstance(element, FigureElement):
            self._build_figure(rel, element, ctx)
        elif isinstance(element, ContainerElement):
            self._build_container(rel, element, ctx)

    # ── Document construction ─────────────────────────────────────────

    def _build_document(
        self,
        file_ctx: _FileReadingOrderContext,
        ro_elements: list[ReadingOrderPageElement],
        mappings: _RelationshipMappings,
    ) -> DoclingDocument:
        origin = DocumentOrigin(
            mimetype="application/pdf",
            filename=file_ctx.file_name,
            binary_hash=file_ctx.document_hash,
        )
        doc = DoclingDocument(name=Path(file_ctx.file_name).stem, origin=origin)

        for page in file_ctx.pages:
            if page.size is None:
                raise ValueError(f"Page size missing for page_no={page.page_no}.")
            doc.add_page(page_no=page.page_no, size=page.size)

        if not ro_elements:
            return doc

        id_to_elem = {
            RefItem(cref=f"#/{elem.page_no}/{elem.cluster.id}").cref: elem
            for elem in file_ctx.assembled.elements
        }
        build_ctx = _BuildContext(
            doc=doc,
            page_map={page.page_no: page for page in file_ctx.pages},
            id_to_elem=id_to_elem,
            cid_to_rel={rel.cid: rel for rel in ro_elements},
            mappings=mappings,
        )
        skippable_cids = mappings.skippable_cids()

        for rel in ro_elements:
            if rel.cid in skippable_cids:
                continue
            element = id_to_elem[rel.ref.cref]
            self._dispatch(rel, element, build_ctx)

        return doc

    # ── Public entry point ────────────────────────────────────────────

    @log_function_calls(logger)
    def resolve(self, assembled_df: pd.DataFrame) -> dict[str, DoclingDocument]:
        """Resolve reading order for each file and return file_name → DoclingDocument."""
        self._validate_input(assembled_df)

        documents: dict[str, DoclingDocument] = {}
        for file_name, file_df in assembled_df.groupby("file_name", sort=False):
            file_name_str = str(file_name)
            pages = self._collect_pages(file_df)
            file_ctx = self._build_file_context(file_name=file_name_str, pages=pages)

            ro_elements = self._assembled_to_readingorder_elements(file_ctx)
            sorted_elements, mappings = self._predict_relationships(ro_elements)

            documents[file_name_str] = self._build_document(
                file_ctx, sorted_elements, mappings
            )

        return documents
