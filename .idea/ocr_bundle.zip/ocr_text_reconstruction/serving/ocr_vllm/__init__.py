"""vLLM plugin: registers the OCR two-stage model (entry point ``vllm.general_plugins``)."""

ARCH = "OcrTwoStageForConditionalGeneration"


# Thread pools that must stay at one thread. Containers often get a CPU *quota* far below
# the visible core count (15 cores of 128 here); several engine processes each spinning up
# machine-sized pools (OpenMP, BLAS, blake3/rayon for multimodal hashing) exceed it in
# bursts, and cgroup throttling then pauses every thread for the rest of the 100 ms period.
# Measured: 3 engines 41 -> 63 pages/s once these were pinned.
SINGLE_THREAD_ENV = ("OMP_NUM_THREADS", "MKL_NUM_THREADS", "OPENBLAS_NUM_THREADS",
                     "NUMEXPR_NUM_THREADS", "RAYON_NUM_THREADS")


def register() -> None:
    import os

    for var in SINGLE_THREAD_ENV:
        os.environ.setdefault(var, "1")
    os.environ.setdefault("TORCHINDUCTOR_COMPILE_THREADS", "4")

    import torch

    torch.set_num_threads(1)

    # Full-fp32 dot products in vLLM's Triton attention kernels (default is TF32, ~5e-4
    # relative error), so fp32 serving matches the PyTorch reference. No effect on bf16
    # inputs. Must be set before any Triton kernel is compiled.
    os.environ.setdefault("TRITON_F32_DEFAULT", "ieee")
    if os.environ.get("OCR_VLLM_STRICT_FP32") == "1":
        # parity testing: no TF32 anywhere (PyTorch enables it for cuDNN convs by default)
        torch.backends.cudnn.allow_tf32 = False
        torch.backends.cuda.matmul.allow_tf32 = False

    from transformers import AutoConfig
    from vllm import ModelRegistry

    from .config import OcrTwoStageConfig

    AutoConfig.register(OcrTwoStageConfig.model_type, OcrTwoStageConfig, exist_ok=True)
    if ARCH not in ModelRegistry.get_supported_archs():
        ModelRegistry.register_model(ARCH, f"ocr_vllm.model:{ARCH}")

