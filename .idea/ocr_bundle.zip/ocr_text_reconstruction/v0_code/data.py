"""
Data pipeline for the OCR Text Reconstruction model.
=====================================================

Source: parquet files with columns
    file_name              : PDF filename (under PDF_DIR)
    page                   : 1-based page number  (page = doc[page - 1])
    ocr_bbox               : np.ndarray (N, 4)  x1,y1,x2,y2  ALREADY normalized to [0, 1]
    encoded_ouput_ids_raw  : list[int]  target sequence in the GLOBAL tokenizer scheme
                             (box id = ocr index in [0, 9999]; special = 10000..10016)

Per-row processing (see the conversation / plan.md):

  1. Drop <unk> (global id 10003) from the sequence entirely.
  2. Compaction: keep only OCR boxes actually referenced in the sequence, renumber
     the survivors contiguously, and rewrite the box pointer ids to match. This
     avoids training the model to "skip" boxes that were only lost to matching
     failures (v1 = order+format every box it is given).
  3. Global -> model-compact id remap (padding-independent):
         special g  ->  g - 10000        (in [0, 17))
         box     i  ->  17 + new_index    (M = num_special_tokens = 17)
  4. Teacher forcing: decoder_input_ids = ids[:-1], labels = ids[1:].
  5. Drop the row if it has no referenced boxes, or if the (post-shift) length
     exceeds ``max_len`` (default 2048).

The model's ``H_box[i]`` corresponds to ``ocr_bbox[i]`` (confirmed: row order ==
ocr id order), which is what makes the pointer ids meaningful.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

import numpy as np
import torch
from torch.utils.data import Dataset

# --------------------------------------------------------------------------- #
# Constants (must match CustomTokenizerV3 and OcrReconstructionConfig)
# --------------------------------------------------------------------------- #
NUM_SPECIAL_TOKENS = 17       # M  (global ids 10000..10016)
GLOBAL_SPECIAL_BASE = 10000   # specials start here in the tokenizer scheme
UNK_GLOBAL_ID = 10003         # <unk>  -> dropped from labels
PAD_MODEL_ID = 2              # <pad>  in model-compact space (10002 - 10000)
IGNORE_INDEX = -100
MAX_BOXES = GLOBAL_SPECIAL_BASE  # box ids must stay below the special range


# --------------------------------------------------------------------------- #
# Core id transform (pure python, PDF-free, unit-testable)
# --------------------------------------------------------------------------- #
@dataclass
class BuiltExample:
    present: list[int]            # original box ids kept, ascending (len K)
    decoder_input_ids: list[int]  # model-compact ids, len T
    labels: list[int]             # model-compact ids, len T


def build_example(
    num_boxes: int,
    raw_ids,
    max_len: int = 2048,
    num_special: int = NUM_SPECIAL_TOKENS,
    base: int = GLOBAL_SPECIAL_BASE,
    unk_id: int = UNK_GLOBAL_ID,
) -> tuple[Optional[BuiltExample], str]:
    """Apply drop-unk -> compaction -> global->model remap -> shift.

    Returns ``(BuiltExample | None, reason)``. ``reason`` is ``"ok"`` for a valid
    example, otherwise a short tag explaining why the row was dropped.
    """
    # 1. drop <unk>
    ids = [int(t) for t in raw_ids if int(t) != unk_id]

    # 2. boxes actually referenced
    present = sorted({t for t in ids if t < base})
    if not present:
        return None, "no_boxes"
    if present[-1] >= num_boxes:
        return None, "box_id_out_of_range"
    if present[-1] >= MAX_BOXES:
        return None, "box_id_collides_with_specials"

    old_to_new = {old: i for i, old in enumerate(present)}

    # 3. global -> model-compact ids
    model_ids: list[int] = []
    for t in ids:
        if t < base:
            model_ids.append(num_special + old_to_new[t])  # box -> M + new_index
        else:
            s = t - base                                    # special -> g - base
            if not (0 <= s < num_special):
                return None, "special_id_out_of_range"
            model_ids.append(s)

    if len(model_ids) < 2:
        return None, "too_short"
    if len(model_ids) - 1 > max_len:  # length after the teacher-forcing shift
        return None, "too_long"

    # 4. teacher forcing shift
    return (
        BuiltExample(
            present=present,
            decoder_input_ids=model_ids[:-1],
            labels=model_ids[1:],
        ),
        "ok",
    )


def model_ids_to_global_ids(
    model_ids,
    num_special: int = NUM_SPECIAL_TOKENS,
    base: int = GLOBAL_SPECIAL_BASE,
) -> list[int]:
    """Inverse remap (model-compact -> global tokenizer scheme) for decoding/eval.

    NOTE: box ids returned are the *compacted* indices, so to recover text you
    must index into the compacted box/line list (the one aligned with the boxes
    actually fed to the model), not the original full OCR list.
    """
    out = []
    for m in model_ids:
        m = int(m)
        out.append((m + base) if m < num_special else (m - num_special))
    return out


# model-compact special id -> display string (mirrors CustomTokenizerV3.SPECIAL_TOKENS,
# offset by GLOBAL_SPECIAL_BASE). Kept here so previews need no tokenizer import.
SPECIAL_ID_TO_STR = {
    0: "<bos>", 1: "<eos>", 2: "<pad>", 3: "<unk>", 4: "\n", 5: " ",
    6: "###", 7: "##", 8: "#", 9: "**", 10: "*", 11: "|",
    12: "---", 13: "--", 14: ":", 15: ".", 16: ",",
}


def render_sequence(model_ids, num_special: int = NUM_SPECIAL_TOKENS, stop_at_eos: bool = True) -> str:
    """Human-readable preview of a model-compact id sequence: special tokens become
    their markdown strings, box pointers become ``[BOX_k]`` placeholders. Text is
    not recoverable here (OCR strings are not in the training data)."""
    parts = []
    for m in model_ids:
        m = int(m)
        if m < num_special:
            if stop_at_eos and m == 1:  # <eos>
                break
            if m in (0, 2):  # skip <bos>/<pad> in the preview
                continue
            parts.append(SPECIAL_ID_TO_STR.get(m, f"<s{m}>"))
        else:
            parts.append(f"[BOX_{m - num_special}]")
    return "".join(parts)


# --------------------------------------------------------------------------- #
# PDF rasterization (lazy fitz/PIL imports so the transforms above stay light)
# --------------------------------------------------------------------------- #
def rasterize_page(page, zoom: float = 2.0):
    """Render a PyMuPDF page to a PIL RGB image. ``zoom`` ~= dpi/72 (2.0 ~= 144 dpi).
    Box coords are already normalized to [0, 1], so ``zoom`` only affects sharpness."""
    import fitz  # noqa: F401  (PyMuPDF) -- imported lazily
    from PIL import Image

    matrix = fitz.Matrix(zoom, zoom)
    pix = page.get_pixmap(matrix=matrix, alpha=False)
    return Image.frombytes("RGB", (pix.width, pix.height), pix.samples)


def load_image_processor(name_or_path: str = "docling-project/docling-layout-heron"):
    """Convenience loader for the RT-DETR image processor (resize 640, rescale)."""
    from transformers import RTDetrImageProcessor

    return RTDetrImageProcessor.from_pretrained(name_or_path)


# --------------------------------------------------------------------------- #
# Dataset
# --------------------------------------------------------------------------- #
class OcrReconstructionDataset(Dataset):
    """Map-style dataset over a parquet file + a directory of source PDFs.

    Invalid rows (no referenced boxes, out-of-range ids, over-length) are filtered
    out at construction time, so ``__len__`` and indexing only ever see valid rows.
    """

    def __init__(
        self,
        parquet_path: str,
        pdf_dir: str,
        image_processor,
        max_len: int = 2048,
        zoom: float = 2.0,
        file_name_column: str = "file_name",
        page_column: str = "page",
        bbox_column: str = "ocr_bbox",
        output_ids_column: str = "encoded_ouput_ids_raw",
        verbose: bool = True,
    ):
        import pandas as pd
        from pathlib import Path

        _p = str(parquet_path)
        self.df = pd.read_pickle(_p) if _p.endswith((".pkl", ".pickle")) else pd.read_parquet(_p)
        self.pdf_dir = Path(pdf_dir)
        self.image_processor = image_processor
        self.max_len = max_len
        self.zoom = zoom
        self.cols = dict(
            file_name=file_name_column,
            page=page_column,
            bbox=bbox_column,
            output_ids=output_ids_column,
        )
        missing = [c for c in self.cols.values() if c not in self.df.columns]
        if missing:
            raise KeyError(
                f"Missing columns {missing}. Available: {list(self.df.columns)}"
            )

        self._doc_cache: dict[str, object] = {}  # per-worker fitz.Document cache
        self.samples: list[tuple[int, BuiltExample]] = []
        self._build_index(verbose)

    def _build_index(self, verbose: bool):
        from collections import Counter

        reasons = Counter()
        lengths, unk_dropped, total_tokens = [], 0, 0
        bbox_col, out_col = self.cols["bbox"], self.cols["output_ids"]

        for df_idx in range(len(self.df)):
            row = self.df.iloc[df_idx]
            raw = list(row[out_col])
            total_tokens += len(raw)
            unk_dropped += sum(1 for t in raw if int(t) == UNK_GLOBAL_ID)
            num_boxes = int(np.asarray(row[bbox_col]).reshape(-1, 4).shape[0])

            built, reason = build_example(num_boxes, raw, max_len=self.max_len)
            reasons[reason] += 1
            if built is not None:
                self.samples.append((df_idx, built))
                lengths.append(len(built.decoder_input_ids))

        if verbose:
            kept = len(self.samples)
            print(f"[OcrReconstructionDataset] kept {kept}/{len(self.df)} rows")
            print(f"  drop reasons: {dict(reasons)}")
            unk_pct = 100.0 * unk_dropped / max(total_tokens, 1)
            print(f"  <unk> dropped: {unk_dropped} tokens ({unk_pct:.2f}% of all tokens)")
            if lengths:
                arr = np.array(lengths)
                pct = np.percentile(arr, [50, 90, 99]).astype(int)
                print(f"  seq len  min/median/p90/p99/max = "
                      f"{arr.min()}/{pct[0]}/{pct[1]}/{pct[2]}/{arr.max()}")

    def __len__(self):
        return len(self.samples)

    def _get_doc(self, file_name: str):
        doc = self._doc_cache.get(file_name)
        if doc is None:
            import fitz

            doc = fitz.open(self.pdf_dir / file_name)
            self._doc_cache[file_name] = doc
        return doc

    def __getitem__(self, idx: int):
        df_idx, built = self.samples[idx]
        row = self.df.iloc[df_idx]

        # image: open PDF (cached) -> rasterize -> RT-DETR preprocessing
        doc = self._get_doc(str(row[self.cols["file_name"]]))
        page = doc[int(row[self.cols["page"]]) - 1]
        image = rasterize_page(page, zoom=self.zoom)
        pixel_values = self.image_processor(images=image, return_tensors="pt")["pixel_values"][0]

        # boxes, compacted to the referenced set, aligned with the pointer ids
        boxes = np.asarray(row[self.cols["bbox"]], dtype=np.float32).reshape(-1, 4)[built.present]

        return {
            "pixel_values": pixel_values,                                   # (3, 640, 640)
            "ocr_boxes": torch.from_numpy(boxes),                           # (K, 4) xyxy in [0,1]
            "decoder_input_ids": torch.tensor(built.decoder_input_ids, dtype=torch.long),  # (T,)
            "labels": torch.tensor(built.labels, dtype=torch.long),         # (T,)
        }


# --------------------------------------------------------------------------- #
# Collate: pad variable N (boxes) and T (sequence)
# --------------------------------------------------------------------------- #
def collate_fn(batch, pad_id: int = PAD_MODEL_ID, ignore_index: int = IGNORE_INDEX):
    B = len(batch)
    pixel_values = torch.stack([b["pixel_values"] for b in batch])  # (B, 3, 640, 640)

    Ks = [b["ocr_boxes"].shape[0] for b in batch]
    Ts = [b["decoder_input_ids"].shape[0] for b in batch]
    max_K, max_T = max(Ks), max(Ts)

    ocr_boxes = torch.zeros(B, max_K, 4, dtype=torch.float32)
    box_mask = torch.zeros(B, max_K, dtype=torch.bool)
    decoder_input_ids = torch.full((B, max_T), pad_id, dtype=torch.long)
    labels = torch.full((B, max_T), ignore_index, dtype=torch.long)

    for i, b in enumerate(batch):
        k, t = Ks[i], Ts[i]
        ocr_boxes[i, :k] = b["ocr_boxes"]
        box_mask[i, :k] = True
        decoder_input_ids[i, :t] = b["decoder_input_ids"]
        labels[i, :t] = b["labels"]

    return {
        "pixel_values": pixel_values,
        "ocr_boxes": ocr_boxes,
        "box_mask": box_mask,
        "decoder_input_ids": decoder_input_ids,
        "labels": labels,
    }


# --------------------------------------------------------------------------- #
# RL (GRPO) dataset: feed ALL boxes, no compaction, no targets
# --------------------------------------------------------------------------- #
class RLDataset(Dataset):
    """Map-style dataset for GRPO / RL fine-tuning.

    Unlike :class:`OcrReconstructionDataset` (which compacts to the *matched*
    boxes and builds teacher-forcing targets), this feeds **every** OCR box for
    the page -- the same distribution the model sees at inference -- and returns
    **no targets**. The reward (coverage / duplicates) is computed from the
    model's own rollout, so no gold markdown is needed here.

    Rows are filtered only by box count: pages with fewer than ``min_boxes`` are
    useless, and ``max_boxes`` caps rollout length / memory during training.
    """

    def __init__(
        self,
        parquet_path: str,
        pdf_dir: str,
        image_processor,
        zoom: float = 2.0,
        min_boxes: int = 1,
        max_boxes: Optional[int] = None,
        file_name_column: str = "file_name",
        page_column: str = "page",
        bbox_column: str = "ocr_bbox",
        verbose: bool = True,
    ):
        import pandas as pd
        from pathlib import Path

        _p = str(parquet_path)
        self.df = pd.read_pickle(_p) if _p.endswith((".pkl", ".pickle")) else pd.read_parquet(_p)
        self.pdf_dir = Path(pdf_dir)
        self.image_processor = image_processor
        self.zoom = zoom
        self.cols = dict(file_name=file_name_column, page=page_column, bbox=bbox_column)
        missing = [c for c in self.cols.values() if c not in self.df.columns]
        if missing:
            raise KeyError(f"Missing columns {missing}. Available: {list(self.df.columns)}")

        self._doc_cache: dict[str, object] = {}  # per-worker fitz.Document cache
        self.samples: list[int] = []             # kept df indices
        self._build_index(min_boxes, max_boxes, verbose)

    def _build_index(self, min_boxes: int, max_boxes: Optional[int], verbose: bool):
        from collections import Counter

        reasons = Counter()
        bbox_col = self.cols["bbox"]
        box_counts = []
        for df_idx in range(len(self.df)):
            row = self.df.iloc[df_idx]
            n = int(np.asarray(row[bbox_col]).reshape(-1, 4).shape[0])
            if n < min_boxes:
                reasons["too_few_boxes"] += 1
                continue
            if max_boxes is not None and n > max_boxes:
                reasons["too_many_boxes"] += 1
                continue
            self.samples.append(df_idx)
            box_counts.append(n)

        if verbose:
            print(f"[RLDataset] kept {len(self.samples)}/{len(self.df)} rows")
            if reasons:
                print(f"  drop reasons: {dict(reasons)}")
            if box_counts:
                arr = np.array(box_counts)
                pct = np.percentile(arr, [50, 90, 99]).astype(int)
                print(f"  boxes/page  min/median/p90/p99/max = "
                      f"{arr.min()}/{pct[0]}/{pct[1]}/{pct[2]}/{arr.max()}")

    def __len__(self):
        return len(self.samples)

    def _get_doc(self, file_name: str):
        doc = self._doc_cache.get(file_name)
        if doc is None:
            import fitz

            doc = fitz.open(self.pdf_dir / file_name)
            self._doc_cache[file_name] = doc
        return doc

    def __getitem__(self, idx: int):
        df_idx = self.samples[idx]
        row = self.df.iloc[df_idx]

        doc = self._get_doc(str(row[self.cols["file_name"]]))
        page = doc[int(row[self.cols["page"]]) - 1]
        image = rasterize_page(page, zoom=self.zoom)
        pixel_values = self.image_processor(images=image, return_tensors="pt")["pixel_values"][0]

        # ALL boxes (no [built.present] compaction): the inference distribution
        boxes = np.asarray(row[self.cols["bbox"]], dtype=np.float32).reshape(-1, 4)

        return {
            "pixel_values": pixel_values,                 # (3, 640, 640)
            "ocr_boxes": torch.from_numpy(boxes),         # (N, 4) xyxy in [0, 1]
            "num_boxes": boxes.shape[0],                  # int N
            "df_idx": df_idx,                             # for monitoring / gold join
        }


def rl_collate_fn(batch):
    """Pad variable N (boxes) across a batch of pages. No sequence padding -- the
    decoder sequence is produced by sampling, not supplied here."""
    B = len(batch)
    pixel_values = torch.stack([b["pixel_values"] for b in batch])
    Ns = [b["ocr_boxes"].shape[0] for b in batch]
    max_N = max(Ns)

    ocr_boxes = torch.zeros(B, max_N, 4, dtype=torch.float32)
    box_mask = torch.zeros(B, max_N, dtype=torch.bool)
    for i, b in enumerate(batch):
        n = Ns[i]
        ocr_boxes[i, :n] = b["ocr_boxes"]
        box_mask[i, :n] = True

    return {
        "pixel_values": pixel_values,                              # (B, 3, 640, 640)
        "ocr_boxes": ocr_boxes,                                    # (B, max_N, 4)
        "box_mask": box_mask,                                      # (B, max_N)
        "num_boxes": torch.tensor(Ns, dtype=torch.long),           # (B,)
        "df_idx": torch.tensor([b["df_idx"] for b in batch], dtype=torch.long),
    }


# --------------------------------------------------------------------------- #
# Self-test for the pure data logic (no PDF / model needed)
# --------------------------------------------------------------------------- #
if __name__ == "__main__":
    M, BASE = NUM_SPECIAL_TOKENS, GLOBAL_SPECIAL_BASE
    BOS, EOS, HASH, NL = 10000, 10001, 10008, 10004

    # 500 boxes, output references {3, 7, 499}; contains an <unk> to be dropped
    raw = [BOS, 3, HASH, 7, UNK_GLOBAL_ID, NL, 499, EOS]
    built, reason = build_example(num_boxes=500, raw_ids=raw, max_len=2048)
    assert reason == "ok", reason
    assert built.present == [3, 7, 499]
    # full sequence (model-compact): bos=0, box3->M+0, '#'=8, box7->M+1, '\n'=4, box499->M+2, eos=1
    expected_full = [0, M + 0, 8, M + 1, 4, M + 2, 1]
    assert built.decoder_input_ids == expected_full[:-1], built.decoder_input_ids
    assert built.labels == expected_full[1:], built.labels
    assert model_ids_to_global_ids(expected_full) == [BOS, 0, HASH, 1, NL, 2, EOS]

    # drop conditions
    assert build_example(500, [BOS, EOS])[1] == "no_boxes"
    assert build_example(2, [BOS, 5, EOS])[1] == "box_id_out_of_range"
    assert build_example(500, [BOS] + [3, NL] * 2000 + [EOS], max_len=64)[1] == "too_long"

    # collate shapes (synthetic, skip image with a dummy tensor)
    def item(K, ids):
        b, _ = build_example(K, ids)
        return {
            "pixel_values": torch.zeros(3, 640, 640),
            "ocr_boxes": torch.rand(len(b.present), 4),
            "decoder_input_ids": torch.tensor(b.decoder_input_ids),
            "labels": torch.tensor(b.labels),
        }

    batch = [item(500, raw), item(10, [BOS, 0, NL, 5, HASH, 9, EOS])]
    out = collate_fn(batch)
    assert out["ocr_boxes"].shape == (2, 3, 4), out["ocr_boxes"].shape
    assert out["box_mask"].tolist() == [[True, True, True], [True, True, True]]
    assert out["decoder_input_ids"].shape == out["labels"].shape
    print("data.py self-test OK")
    print("collate keys:", {k: tuple(v.shape) for k, v in out.items()})
