import subprocess,json,sys
from pathlib import Path
py=str(Path.cwd()/'.venv/bin/python')
def run(name,*args):
 print('RUN',name,flush=True)
 with open('results/'+name+'.log','w') as f:
  r=subprocess.run([py,*args],stdout=f,stderr=subprocess.STDOUT)
 if r.returncode: print('FAILED',name,flush=True)
 return r.returncode
run('validate_final','validate.py','--dtypes','fp32','bf16','fp16')
run('hf_eager','bench_hf.py','--batch-sizes','16','32','64','128','256')
run('hf_graph','bench_hf.py','--batch-sizes','16','32','64','128','256','--cuda-graph','--output','results/hf_graph.json')
for tokens,seq in [(4096,32),(8192,64),(16384,64)]:
 for compiled in [False,True]:
  run(f'vllm_{tokens}_{compiled}','bench_vllm.py','--pairs','10000','--max-num-batched-tokens',str(tokens),'--max-num-seqs',str(seq),'--repeats','2',*(['--compiled'] if compiled else []))
rows=[json.loads(x) for x in open('results/vllm.jsonl')]
rows=[x for x in rows if not x.get('pilot_only') and x.get('head_dtype')=='bfloat16']
best=max(rows,key=lambda x:x['pairs_per_second'])
run('vllm_full','bench_vllm.py','--pairs','250000','--max-num-batched-tokens',str(best['max_num_batched_tokens']),'--max-num-seqs',str(best['max_num_seqs']),'--repeats','2',*(['--compiled'] if best['compiled'] else []))
rows=[json.loads(x) for x in open('results/vllm_custom.jsonl')]
best=max((x for x in rows if x['mode']!='hot'),key=lambda x:x['pairs_per_second'])
config={k:best[k] for k in ['mode','tile','compile_parts']};config.update(graph=best['cuda_graph'],full_docs=5000,repeats=7,iters=5,save_scores='results/full_scores.pt')
Path('best_config.json').write_text(json.dumps([config]*3))
run('custom_full','bench_vllm_custom.py','--configs-json','best_config.json')
print('DONE',flush=True)
