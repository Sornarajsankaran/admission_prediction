from __future__ import annotations

from typing import Optional

import torch
import torch.nn as nn
from transformers import AutoModelForCausalLM


class Qwen3Reranker(nn.Module):
    def __init__(self, config):
        super().__init__()
        model_cfg = config["model"]
        attn_impl = "flash_attention_2" if model_cfg.get("use_flash_attention", False) else "sdpa"
        self.model = AutoModelForCausalLM.from_pretrained(
            model_cfg["hugging_face_card"],
            attn_implementation=attn_impl,
            torch_dtype=torch.bfloat16,
        )
        self.token_true_id = config["token_true_id"]
        self.token_false_id = config["token_false_id"]

    def forward(
        self,
        input_ids: torch.Tensor,
        attention_mask: Optional[torch.Tensor] = None,
        **_: torch.Tensor,
    ) -> torch.Tensor:
        logits = self.model(input_ids=input_ids, attention_mask=attention_mask).logits[:, -1, :]

        true_vec = logits[:, self.token_true_id]
        false_vec = logits[:, self.token_false_id]

        out = torch.stack([false_vec, true_vec], dim=1)
        return out
