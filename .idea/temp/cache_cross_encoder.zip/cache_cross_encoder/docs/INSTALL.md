# Installation and migration

## Tested environment

Linux x86_64, Python 3.12.14, NVIDIA L40S, driver 595.91.07, PyTorch 2.14.0+cu130,
vLLM 0.33.0, Transformers 5.20.2, Triton 3.8.0. `requirements.lock.txt` records the
entire installed Python environment. These pinned versions are the reproduction
target; they are not a promise of compatibility with older CUDA drivers or GPUs.
A CUDA-capable GPU and a driver compatible with the supplied CUDA 13 wheel runtime
are required. The code uses FlashAttention 2 and Triton for FP16/BF16 inference.

## Copy and install

Copy the directory with its models, results and subdirectories, then enter it:

```bash
cd /path/to/cached_cross_encoder_codex
bash setup.sh
```

`setup.sh` uses `uv` if installed, otherwise `python3.12 -m venv` and pip. Python
3.12 must be available for the pip path. With uv, its Python download may require
network access. Install downloads several GB of CUDA/runtime dependencies; allow
adequate disk space beyond the approximately 1.2 GB model/data handoff directory.
No separate system CUDA toolkit was needed for the original wheel installation.

Do not copy the source machine's `.venv` or compiled GPU cache. They contain local
paths and hardware/version-dependent binaries. Compile/autotune happens on the
first execution and is excluded from the published steady-state measurements.

## Offline target machine

The model files are self-contained. Package installation is a separate concern.
If the target has no internet, prepare a wheelhouse on a compatible Linux x86_64
machine using Python 3.12, before copying the directory:

```bash
python3.12 -m pip download -r requirements.lock.txt --dest wheelhouse
```

If a dependency is only available as a source distribution, build its wheel on the
compatible staging machine with `pip wheel` rather than expecting an air-gapped
machine to fetch build dependencies. Then on the target:

```bash
python3.12 -m venv .venv
.venv/bin/python -m pip install --no-index --find-links wheelhouse -r requirements.lock.txt
export HF_HUB_OFFLINE=1 TRANSFORMERS_OFFLINE=1
```

A wheelhouse is not bundled in this handoff. The directory contains everything
specific to this experiment, but installing Python packages still requires either
network access or a separately prepared compatible wheelhouse.

## Smoke check

```bash
.venv/bin/python -c 'import torch,vllm; print(torch.__version__,vllm.__version__); print(torch.cuda.get_device_name())'
.venv/bin/python bench_vllm_custom.py --mode joint --tile 1 --repeats 2 --output runs/smoke.jsonl
```

For numerical validation of the bundled model and dataset:

```bash
.venv/bin/python validate.py --dtypes fp32 bf16 fp16 --output runs/correctness.json
```

Create `runs/` first for `validate.py`. Its fixed sample indices belong to the bundled
synthetic dataset; use a separate representative validation set for real records.
The original absolute paths inside archived result JSON/logs describe the source
machine. They are provenance strings, not input dependencies.

## Transfer integrity

`MANIFEST.sha256` contains hashes for packaged files. From the package root, run:

```bash
sha256sum -c MANIFEST.sha256
```

Changes made after transfer, such as new outputs or edited configuration, are not
part of the original manifest. Newly created files are not covered by it.
