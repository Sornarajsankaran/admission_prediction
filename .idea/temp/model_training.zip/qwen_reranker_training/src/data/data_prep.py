from iterstrat.ml_stratifiers import MultilabelStratifiedShuffleSplit
import pandas as pd
from src.data.data_utils import load_raw_dataframe, clean_dataframe , dump_splits_with_metadata


def stratified_split(df: pd.DataFrame, val_size: float, test_size: float, stratified_cols: list):
    """
    Perform multi-column stratified train/val/test split.

    Parameters:
        df (pd.DataFrame): Input dataframe.
        val_size (float): Fraction for validation split (e.g., 0.1).
        test_size (float): Fraction for test split (e.g., 0.1).
        stratified_cols (list): Columns to use for stratification.

    Returns:
        train_df, val_df, test_df (pd.DataFrame)
    """
    # --- Prepare multilabel stratification targets ---
    y = df[stratified_cols].astype(str).apply(lambda x: '_'.join(x), axis=1)  # combine into single label
    y = pd.get_dummies(y)  # one-hot encode for iterative stratifier

    # --- First split: train + val/test ---
    msss1 = MultilabelStratifiedShuffleSplit(n_splits=1, test_size=(val_size + test_size), random_state=42)
    train_idx, valtest_idx = next(msss1.split(df, y))

    train_df = df.iloc[train_idx].reset_index(drop=True)
    valtest_df = df.iloc[valtest_idx].reset_index(drop=True)

    # --- Second split: val / test ---
    msss2 = MultilabelStratifiedShuffleSplit(
        n_splits=1,
        test_size=test_size / (val_size + test_size),
        random_state=42
    )
    val_idx, test_idx = next(msss2.split(valtest_df, y.iloc[valtest_idx]))

    val_df = valtest_df.iloc[val_idx].reset_index(drop=True)
    test_df = valtest_df.iloc[test_idx].reset_index(drop=True)

    return train_df, val_df, test_df


def build_stratified_splits(config):
    raw_data_path = config['data']['raw_data_path']
    df = clean_dataframe(load_raw_dataframe(raw_data_path))

    stratified_cols = config['data']['stratified_columns']
    train_df, val_df, test_df = stratified_split(
        df,
        val_size=config['data']['val_size'],
        test_size=config['data']['test_size'],
        stratified_cols=stratified_cols
    )
    processed_data_dir = config['data']['processed_data_dir']
    dump_splits_with_metadata(processed_data_dir, train_df, val_df, test_df , stratified_cols)
    

   
    

    

