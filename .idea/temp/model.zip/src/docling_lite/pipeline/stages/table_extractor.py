import gc
import torch
import torch.nn.functional as F
import pandas as pd
from itertools import groupby, islice
from tqdm import tqdm
from typing import Any, Iterator
from PIL import Image
from transformers import AutoTokenizer
from torchvision.transforms import functional as TF

from docling_ibm_models.tableformer_v2 import TableFormerV2
from docling.datamodel.base_models import Table, TableStructurePrediction
from docling_core.types.doc import BoundingBox, TableCell

from docling_lite.core.config import (
    OTSL_CELL_TOKENS,
    OTSL_SKIP_TOKENS,
    TABLE_LABELS,
    TABLE_MODEL_CONFIG,
)
from docling_lite.core.logging import log_function_calls, logger


class TableExtractor:
    def __init__(
        self,
        model_name_or_path: str,
        table_batch_size: int = 8,
        device: str = "cuda",
        is_mixed_precision: bool = False,
    ):
        self.model_name_or_path = model_name_or_path
        self.batch_size = int(table_batch_size)
        self.device = torch.device(device)
        self.is_mixed_precision = is_mixed_precision

        self.image_size = int(TABLE_MODEL_CONFIG["image_size"])
        self.max_length = int(TABLE_MODEL_CONFIG["max_length"])

        self.model = None
        self.tokenizer = None
        self.image_mean = None
        self.image_std = None

    @log_function_calls(logger)
    def _load_model_files(self):
        logger.info(
            f"Loading table extraction model: {self.model_name_or_path} on device: {self.device}"
        )

        self.tokenizer = AutoTokenizer.from_pretrained(self.model_name_or_path)
        self.model = (
            TableFormerV2.from_pretrained(self.model_name_or_path)
            .to(self.device)
            .eval()
        )
        self.image_mean = torch.tensor(
            TABLE_MODEL_CONFIG["mean"],
            dtype=torch.float32,
            device=self.device,
        ).view(1, 3, 1, 1)
        self.image_std = torch.tensor(
            TABLE_MODEL_CONFIG["std"],
            dtype=torch.float32,
            device=self.device,
        ).view(1, 3, 1, 1)

    def _collect_table_tasks(self, layout_df: pd.DataFrame) -> list[dict[str, Any]]:
        tasks: list[dict[str, Any]] = []
        for _, row in layout_df.iterrows():
            page_obj = row["docling_page_obj"]
            clusters = getattr(page_obj.predictions.layout, "clusters", [])
            for cluster in clusters:
                if cluster.label not in TABLE_LABELS:
                    continue
                tasks.append(
                    {
                        "file_name": row["file_name"],
                        "page": row["page"],
                        "image_path": row["image_path"],
                        "image_width": int(row["image_width"]),
                        "image_height": int(row["image_height"]),
                        "page_width_pt": float(row["page_width_pt"]),
                        "page_height_pt": float(row["page_height_pt"]),
                        "docling_page_obj": page_obj,
                        "table_cluster": cluster,
                    }
                )
        return tasks

    def _crop_table_image(self, task: dict[str, Any]) -> Image.Image:
        x0, y0, x1, y1 = task["table_cluster"].bbox.as_tuple()
        scale_x = task["image_width"] / task["page_width_pt"]
        scale_y = task["image_height"] / task["page_height_pt"]
        crop_box = (
            int(round(x0 * scale_x)),
            int(round(y0 * scale_y)),
            int(round(x1 * scale_x)),
            int(round(y1 * scale_y)),
        )
        with Image.open(task["image_path"]) as page_image:
            return page_image.convert("RGB").crop(crop_box)

    def _preprocess_table_images(self, images: list[Image.Image]) -> torch.Tensor:
        if self.image_mean is None or self.image_std is None:
            raise RuntimeError("Image normalization tensors are not initialized.")

        tensors = []
        for image in images:
            tensor = TF.pil_to_tensor(image).to(
                device=self.device,
                dtype=torch.float32,
            )
            tensor = tensor.div(255.0).unsqueeze(0)
            tensor = F.interpolate(
                tensor,
                size=(self.image_size, self.image_size),
                mode="bilinear",
                align_corners=False,
                antialias=True,
            )
            tensors.append(tensor)

        batch = torch.cat(tensors, dim=0)
        return (batch - self.image_mean) / self.image_std

    def _iter_batches(
        self,
        tasks: list[dict[str, Any]],
    ) -> Iterator[torch.Tensor]:
        if self.batch_size <= 0:
            raise ValueError("batch_size must be > 0")

        tasks_iter = iter(tasks)
        while batch := list(islice(tasks_iter, self.batch_size)):
            images = [self._crop_table_image(task) for task in batch]
            yield self._preprocess_table_images(images)

    def _predict_batch(self, image_tensors: torch.Tensor) -> list[dict[str, Any]]:
        if image_tensors.device != self.device:
            image_tensors = image_tensors.to(self.device)

        with torch.inference_mode():
            if self.is_mixed_precision and self.device.type == "cuda":
                with torch.autocast(device_type="cuda", dtype=torch.bfloat16):
                    batch_output = self.generate(image_tensors)
            else:
                batch_output = self.generate(image_tensors)

        return self._split_batch_output(batch_output, batch_size=image_tensors.shape[0])

    def generate(self, images: torch.Tensor) -> dict[str, Any]:
        # Replaces TableFormerV2.generate to fix a batched-inference bug:
        # the upstream loop only stops when *every* sample emits <end>, so
        # short samples keep accumulating stale tokens. The original code
        # then collects cell-token positions across the whole sequence
        # (stale ones included), and bbox_head's intra-sample self-attention
        # mixes those embeddings with the real ones — corrupting bbox values
        # for the valid cells. Here we stop position collection at each
        # sample's own <end>; encoder/decoder stay batched.
        model = self.model
        eos_id = self.tokenizer.eos_token_id
        bos_id = self.tokenizer.bos_token_id
        device = images.device
        batch_size = images.size(0)

        encoder_outputs = model.encode_images(images)

        generated_ids = torch.full(
            (batch_size, 1), bos_id, dtype=torch.long, device=device
        )
        current_input, past_key_values = generated_ids, None

        for _ in range(self.max_length):
            outputs = model.forward(
                input_ids=current_input,
                attention_mask=None,
                encoder_outputs=encoder_outputs,
                past_key_values=past_key_values,
                use_cache=True,
                return_dict=True,
            )
            next_token = outputs.logits[:, -1, :].argmax(dim=-1, keepdim=True)
            generated_ids = torch.cat([generated_ids, next_token], dim=1)
            past_key_values = outputs.past_key_values
            current_input = next_token
            if torch.all(next_token == eos_id):
                break

        hidden_states = model.forward(
            input_ids=generated_ids,
            attention_mask=torch.ones_like(generated_ids),
            encoder_outputs=encoder_outputs,
            past_key_values=None,
            use_cache=False,
            return_dict=True,
        ).hidden_states

        cell_set = set(model.data_cells)
        positions_per_sample = [
            self._cell_positions_until_end(generated_ids[b].tolist(), cell_set, eos_id)
            for b in range(batch_size)
        ]
        max_cells = max((len(p) for p in positions_per_sample), default=0)

        pred_bboxes: torch.Tensor | None = None
        if max_cells > 0:
            pred_bboxes = torch.zeros(batch_size, max_cells, 4, device=device)
            spatial_size = encoder_outputs.get("spatial_size")
            for b, positions in enumerate(positions_per_sample):
                if not positions:
                    continue
                bboxes = model.bbox_head(
                    hidden_states[b, positions, :],
                    encoder_outputs["last_hidden_state"][b : b + 1],
                    torch.zeros(len(positions), dtype=torch.long, device=device),
                    spatial_size=spatial_size,
                )
                pred_bboxes[b, : len(bboxes)] = bboxes

        return {"generated_ids": generated_ids, "predicted_bboxes": pred_bboxes}

    @staticmethod
    def _cell_positions_until_end(
        token_ids: list[int], cell_set: set[int], eos_id: int
    ) -> list[int]:
        positions: list[int] = []
        for pos, tok in enumerate(token_ids):
            if tok == eos_id:
                break
            if tok in cell_set:
                positions.append(pos)
        return positions

    @staticmethod
    def _split_batch_output(
        batch_output: dict[str, Any], batch_size: int
    ) -> list[dict[str, Any]]:
        outputs: list[dict[str, Any]] = []
        for i in range(batch_size):
            sample: dict[str, Any] = {}
            for key, value in batch_output.items():
                if isinstance(value, torch.Tensor):
                    sample[key] = value[i : i + 1].cpu()
                elif isinstance(value, (list, tuple)):
                    sample[key] = value[i]
                else:
                    sample[key] = value
            outputs.append(sample)
        return outputs

    @staticmethod
    def _decode_otsl_sequence(tokenizer, token_ids: torch.Tensor) -> list[str]:
        # Stop at <end>: in batched generation the AR loop continues past a
        # short sample's own <end>, leaving stale nl/cell tokens in the tail
        # that would otherwise materialize as phantom (empty) rows.
        tags: list[str] = []
        for tid in token_ids.tolist():
            token = tokenizer.decode([tid]).strip()
            if token == "<end>":
                break
            if token in OTSL_SKIP_TOKENS:
                continue
            if token.startswith("<") and token.endswith(">"):
                token = token[1:-1]
            tags.append(token)
        return tags

    @staticmethod
    def _valid_bbox_mask(pred_bboxes: torch.Tensor) -> torch.Tensor:
        return pred_bboxes[pred_bboxes.sum(dim=-1) > 0]

    @staticmethod
    def _build_table_cells(
        otsl_seq: list[str],
        bboxes: torch.Tensor,
        table_bbox: tuple[float, float, float, float],
    ) -> tuple[list[dict[str, Any]], int, int]:
        rows = [
            list(group)
            for is_nl, group in groupby(otsl_seq, lambda token: token == "nl")
            if not is_nl
        ]
        if not rows:
            return [], 0, 0

        num_rows = len(rows)
        num_cols = max(len(row) for row in rows)
        grid = [row + [""] * (num_cols - len(row)) for row in rows]

        table_cells: list[dict[str, Any]] = []
        bbox_idx = 0
        t_x1, t_y1, t_x2, t_y2 = table_bbox
        t_w = t_x2 - t_x1
        t_h = t_y2 - t_y1

        for row_idx, row in enumerate(grid):
            for col_idx, tag in enumerate(row):
                if tag not in OTSL_CELL_TOKENS:
                    continue

                cell_bbox = None
                if bbox_idx < bboxes.shape[0]:
                    bbox = bboxes[bbox_idx].tolist()
                    cell_bbox = {
                        "l": t_x1 + bbox[0] * t_w,
                        "t": t_y1 + bbox[1] * t_h,
                        "r": t_x1 + bbox[2] * t_w,
                        "b": t_y1 + bbox[3] * t_h,
                    }
                    bbox_idx += 1

                colspan = 1
                for c in range(col_idx + 1, num_cols):
                    if grid[row_idx][c] == "lcel":
                        colspan += 1
                    else:
                        break

                rowspan = 1
                for r in range(row_idx + 1, num_rows):
                    if grid[r][col_idx] == "ucel":
                        rowspan += 1
                    else:
                        break

                table_cells.append(
                    {
                        "bbox": cell_bbox,
                        "row_span": rowspan,
                        "col_span": colspan,
                        "start_row_offset_idx": row_idx,
                        "end_row_offset_idx": row_idx + rowspan,
                        "start_col_offset_idx": col_idx,
                        "end_col_offset_idx": col_idx + colspan,
                        "text": "",
                        "column_header": tag == "ched",
                        "row_header": tag == "rhed",
                        "row_section": tag == "srow",
                    }
                )

        return table_cells, num_rows, num_cols

    @staticmethod
    def _centroid_distance(bbox_a: BoundingBox, bbox_b: BoundingBox) -> float:
        ax = (bbox_a.l + bbox_a.r) / 2.0
        ay = (bbox_a.t + bbox_a.b) / 2.0
        bx = (bbox_b.l + bbox_b.r) / 2.0
        by = (bbox_b.t + bbox_b.b) / 2.0
        return ((ax - bx) ** 2 + (ay - by) ** 2) ** 0.5

    @staticmethod
    def _reflow_cell_text(ocr_cells: list[Any]) -> str:
        entries = []
        for cell in ocr_cells:
            text = (cell.text or "").strip()
            if not text:
                continue
            bbox = cell.rect.to_bounding_box()
            entries.append((text, bbox))
        if not entries:
            return ""

        heights = sorted(bbox.b - bbox.t for _, bbox in entries if bbox.b > bbox.t)
        median_h = heights[len(heights) // 2] if heights else 0.0
        y_tol = max(median_h * 0.5, 1e-6)

        entries.sort(key=lambda e: (e[1].t + e[1].b) / 2.0)

        bands: list[dict[str, Any]] = []
        for text, bbox in entries:
            y_center = (bbox.t + bbox.b) / 2.0
            if bands and abs(y_center - bands[-1]["y"]) <= y_tol:
                band = bands[-1]
                band["items"].append((text, bbox))
                band["y"] = sum(
                    (b.t + b.b) / 2.0 for _, b in band["items"]
                ) / len(band["items"])
            else:
                bands.append({"y": y_center, "items": [(text, bbox)]})

        lines: list[str] = []
        for band in bands:
            band["items"].sort(key=lambda ib: ib[1].l)
            line = " ".join(text for text, _ in band["items"])
            if line:
                lines.append(line)
        return "\n".join(lines)

    @classmethod
    def _assign_ocr_to_predicted_cells(
        cls,
        cell_data: list[dict[str, Any]],
        table_cluster: Any,
    ) -> None:
        target_idxs = [i for i, cell in enumerate(cell_data) if cell.get("bbox") is not None]
        if not target_idxs:
            return

        target_bboxes = {
            i: BoundingBox.model_validate(cell_data[i]["bbox"]) for i in target_idxs
        }
        buckets: dict[int, list[Any]] = {i: [] for i in target_idxs}

        for tc in table_cluster.cells or []:
            if not (tc.text and tc.text.strip()):
                continue
            tc_bbox = tc.rect.to_bounding_box()
            if tc_bbox.area() <= 0:
                continue

            best_overlap = 0.0
            best_idx = None
            for i in target_idxs:
                pbbox = target_bboxes[i]
                if tc_bbox.get_intersection_bbox(pbbox) is None:
                    continue
                overlap = tc_bbox.intersection_over_self(pbbox)
                if overlap > best_overlap:
                    best_overlap = overlap
                    best_idx = i

            if best_idx is None:
                best_dist = float("inf")
                for i in target_idxs:
                    dist = cls._centroid_distance(tc_bbox, target_bboxes[i])
                    if dist < best_dist:
                        best_dist = dist
                        best_idx = i

            if best_idx is not None:
                buckets[best_idx].append(tc)

        for i, bucket in buckets.items():
            text = cls._reflow_cell_text(bucket)
            if text:
                cell_data[i]["text"] = text

    def _build_table_from_output(
        self,
        task: dict[str, Any],
        output: dict[str, Any],
    ) -> Table:
        token_ids = output["generated_ids"].squeeze()
        otsl_seq = self._decode_otsl_sequence(self.tokenizer, token_ids)

        pred_bboxes = output.get("predicted_bboxes")
        if pred_bboxes is not None:
            pred_bboxes = pred_bboxes[0]
            pred_bboxes = self._valid_bbox_mask(pred_bboxes)
        else:
            pred_bboxes = torch.empty((0, 4))

        table_cluster = task["table_cluster"]
        cell_data, num_rows, num_cols = self._build_table_cells(
            otsl_seq=otsl_seq,
            bboxes=pred_bboxes,
            table_bbox=table_cluster.bbox.as_tuple(),
        )

        self._assign_ocr_to_predicted_cells(cell_data, table_cluster)

        table_cells: list[TableCell] = []
        for element in cell_data:
            if element["bbox"] is not None:
                bbox = BoundingBox.model_validate(element["bbox"])
                element["bbox"] = bbox.model_dump()
            table_cells.append(TableCell.model_validate(element))

        return Table(
            otsl_seq=otsl_seq,
            table_cells=table_cells,
            num_rows=num_rows,
            num_cols=num_cols,
            id=table_cluster.id,
            page_no=task["page"],
            cluster=table_cluster,
            label=table_cluster.label,
            text="",
        )

    @staticmethod
    def _attach_table_to_page(task: dict[str, Any], table: Table) -> None:
        page_obj = task["docling_page_obj"]
        if page_obj.predictions.tablestructure is None:
            page_obj.predictions.tablestructure = TableStructurePrediction()
        page_obj.predictions.tablestructure.table_map[table.id] = table

    @log_function_calls(logger)
    def extract_tables(self, layout_df: pd.DataFrame) -> pd.DataFrame:
        try:
            self._load_model_files()

            table_results = layout_df.copy()
            tasks = self._collect_table_tasks(table_results)
            if not tasks:
                logger.info("No table clusters found. Skipping table extraction.")
                return table_results

            total_batches = (len(tasks) + self.batch_size - 1) // self.batch_size
            logger.info(
                f"Extracting {len(tasks)} tables in {total_batches} batch(es) "
                f"(batch_size={self.batch_size}, device={self.device})"
            )

            outputs = []
            batches = self._iter_batches(tasks)
            for batch_tensors in tqdm(
                batches,
                desc="Extracting tables",
                unit="batch",
                total=total_batches,
            ):
                outputs.extend(self._predict_batch(batch_tensors))

            for task, output in zip(tasks, outputs):
                table = self._build_table_from_output(task, output)
                self._attach_table_to_page(task, table)

            logger.info(f"Attached {len(tasks)} table prediction(s) to pages.")
            return table_results
        finally:
            self._unload_model()

    @log_function_calls(logger)
    def _unload_model(self):
        if self.model is None:
            logger.warning("Unload called before loading. Skipping.")
            return

        logger.info("Unloading model and releasing resources.")

        self.model = None
        self.tokenizer = None
        self.image_mean = None
        self.image_std = None

        gc.collect()

        if self.device.type == "cuda" and torch.cuda.is_available():
            torch.cuda.synchronize(device=self.device)
            torch.cuda.empty_cache()
            logger.info("CUDA cache cleared.")
