﻿# Qwen3 Reranker Training

End-to-end pipeline for training a yes/no reranker on top of Qwen-3 style causal language models. The repository includes data preprocessing utilities, a token-aware dataset/collator, a Qwen-based binary head, trainer with mixed-precision support, MLflow logging, and a CLI for building splits + running experiments.

---

## 1. Environment & Dependencies

```bash
python -m venv .venv
. .venv/Scripts/activate    # PowerShell on Windows
pip install -r requirements.txt
```

Key libraries: PyTorch, Transformers, Accelerate, pandas/pyarrow, scikit-learn, MLflow, matplotlib, tqdm.

---

## 2. Repository Layout

```
data/
  raw/data.parquet                # source file (provided by you)
  processed/
    train_df.parquet
    val_df.parquet
    test_df.parquet
    metadata.json
notebook/00_quick_eda.ipynb       # simple inspection of processed splits
src/
  data_utils.py                   # read/normalize/split/write data
  dataset.py                      # CustomDataset + collate_fn/prompting
  model.py                        # Qwen3Reranker module
  trainer.py                      # Trainer + MLflow logging/metrics
  train.py                        # CLI entry point
  utils.py                        # logging, seeding, metrics, token ids, device helpers
requirements.txt
README.md
```

---

## 3. Data Pipeline

### Source Expectations
- `data/raw/data.parquet` with columns `{id, condition, indicator, category, instruction, query, doc, label}`.
- Labels accept `"yes"/"no"` (any casing), `"true"/"false"`, `1/0`.

### Build Processed Splits

```bash
python -m src.train --build-splits --seed 42
```

Options:
- `--stratify-include-label`: append `|label` to each `condition|indicator|category` key when splitting.
- `--train-ratio/--val-ratio/--test-ratio`: default 0.8/0.1/0.1; must sum to 1.0.
- `--seed`: drives shuffling, stratification, and grouped fallback.

Behavior:
1. Read parquet, validate schema, normalize labels.
2. Create `strata_key` as described above.
3. Stratified split via scikit-learn; if any strata vanish, log a warning and fall back to grouped shuffle.
4. Write `{train,val,test}_df.parquet`.
5. Emit `metadata.json` with row counts, class distributions, unique column counts, stratification settings, seed, ratios, SHA256 of raw file, plus preview of strata keys.

---

## 4. Dataset, Tokenization, and Prompting

`CustomDataset` (in `src/dataset.py`) receives a processed DataFrame and an `instruction_prompt`. Each sample is formatted as:

```
<Instruct>{instruction_prompt}
<Query>: {query}
<Document>: {doc}
```

At collate time:
- Fixed system/user prefix and assistant suffix wrap every sample.
- Tokenization happens without special tokens, then prefix/suffix token ids are prepended/appended.
- Batches are padded/truncated to `--max-length`, producing `input_ids`, `attention_mask`, and target tensors on the active device.

Tokenizer uses the same `hf_model_card` as the model. If no pad token exists, we reuse `eos_token_id`.

### Token ID Resolution
`utils.get_token_ids` determines the vocab ids for `"yes"` and `"no"`:
1. Encode token without specials; accept if single id.
2. Retry with a leading space.
3. Otherwise use the last id and log the decision.

Override with CLI flags `--token-true-id` and `--token-false-id` when you know the exact ids.

---

## 5. Model & Loss

`Qwen3Reranker` subclasses `nn.Module` but simply wraps `AutoModelForCausalLM`. During the forward pass we:
1. Run the Causal LM (FlashAttention 2 requested; HF will fall back if unsupported) with bf16 weights.
2. Extract the final-token logits for `[false, true]` positions, using the resolved token ids.
3. Return stacked logits shaped `[batch, 2]`.

Loss: `logit_diff = logits[:,1] - logits[:,0]`, then `torch.nn.BCEWithLogitsLoss(logit_diff, targets)`. This creates the desired binary classifier while benefiting from the LM’s language modeling head.

---

## 6. Trainer & Metrics

Defined in `src/trainer.py`:
- Mixed-precision: uses bf16 `autocast` on GPUs that support it; otherwise FP16 autocast + GradScaler. CPU runs stay in FP32.
- Gradient accumulation (`--grad-accum-steps`), optional gradient clipping (`--max-grad-norm`), linear warmup schedule (when `--warmup-ratio > 0`).
- Metrics per epoch: loss, accuracy, F1 (binary), AUROC. If a split has a single class, AUROC is recorded as NaN and a warning is logged.
- Predictions are `sigmoid(logit_diff) >= 0.5`.
- Checkpointing: `outputs/last_model.pt` always updated, `outputs/best_model.pt` saved when validation AUROC improves, tie-breaking via F1 then loss.
- After training, `training_summary.json` and `confusion_matrix.png` (validation best) are written; both become MLflow artifacts when tracking is enabled.

Resume training via `--resume path/to/last_model.pt` (loads model weights, optimizer state, and epoch).

---

## 7. Training CLI (`src/train.py`)

### Common Command
```bash
python -m src.train \
  --hf-model-card Qwen/Qwen2.5-7B-Instruct \
  --instruction-prompt "Judge relevance for retrieval reranking (yes/no)." \
  --batch-size 2 \
  --epochs 3 \
  --lr 2e-5 \
  --weight-decay 0.01 \
  --max-length 2048 \
  --mlflow-tracking-uri http://localhost:5000 \
  --mlflow-experiment qwen3-reranker
```

Key flags:
- **Data**: `--build-splits`, `--train`, `--train/val/test-ratio`, `--stratify-include-label`, `--seed`.
- **Model/Training**: `--hf-model-card`, `--instruction-prompt`, `--batch-size`, `--num-workers`, `--max-length`, `--epochs`, `--lr`, `--weight-decay`, `--grad-accum-steps`, `--max-grad-norm`, `--warmup-ratio`, `--token-true-id`, `--token-false-id`, `--output-dir`, `--resume`.
- **Logging**: `--mlflow-tracking-uri`, `--mlflow-experiment`.

Default behavior (no flags) assumes processed splits already exist in `data/processed/`.

---

## 8. Device & Precision Handling

`utils.detect_device`:
- Prefers CUDA when available, checks compute capability to decide bf16 support (cap ≥ 8 → bf16; otherwise fallback to fp32 with a warning).
- CPU-only systems run FP32.

During training:
- Inputs are moved to the detected device automatically.
- If bf16 is unavailable, checkpoints remain fp32-compatible, and GradScaler handles FP16 autocast when CUDA exists but lacks bf16.

---

## 9. MLflow Integration

Enabled when both URI and experiment are provided:
1. `train.py` opens a run (`mlflow.start_run`), logs all CLI args plus derived metadata (token ids, vocab size, device, dtype).
2. Each epoch logs `train_*` and `val_*` metrics.
3. At the end, MLflow receives `metadata.json`, `training_summary.json`, and `confusion_matrix.png`, along with `best_*` metrics.

Skip MLflow flags to run offline; logs remain in stdout and the `outputs/` directory.

---

## 10. Outputs & Artifacts

| Location | Contents |
|----------|----------|
| `data/processed/` | `{train,val,test}_df.parquet`, `metadata.json` |
| `outputs/` | `best_model.pt`, `last_model.pt`, `training_summary.json`, `confusion_matrix.png` |
| MLflow run (optional) | All params, per-epoch metrics, best metrics, metadata file, training summary, confusion matrix |

`outputs/best_model.pt` can be reloaded via:

```python
from pathlib import Path
import torch
from src.model import Qwen3Reranker

model = Qwen3Reranker("Qwen/Qwen2.5-7B-Instruct", token_true_id, token_false_id)
state_dict = torch.load(Path("outputs/best_model.pt"), map_location="cpu")
model.load_state_dict(state_dict)
```

---

## 11. Notebook & Exploratory Analysis

`notebook/00_quick_eda.ipynb` demonstrates how to load the processed splits, preview rows, and visualize label distribution. Use it to sanity-check the preprocessing output before launching large training jobs.

---

## 12. Development Tips

- Run `python -m pyflakes src` to lint; the project currently passes.
- Keep `data/raw/data.parquet` under version control ignore rules if it contains sensitive data.
- For rapid experiments on GPUs with limited memory, adjust `--batch-size`, enable gradient accumulation, and shorten `--max-length`.
- If you need custom prompts or multi-class targets, extend `dataset.py`/`utils.compute_metrics` accordingly—everything is modular.

Happy reranking! Let me know if you need additional guidance or integrations.
