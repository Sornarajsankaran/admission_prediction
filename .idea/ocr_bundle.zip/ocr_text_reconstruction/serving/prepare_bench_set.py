"""
Pre-rasterize benchmark workloads so every backend is timed on identical inputs
(and PDF rendering stays out of the model timing).

  w300 : pages with 200-450 OCR boxes, resampled (denser pages weighted up) to --n pages
         averaging --target-mean boxes -- the ~300 boxes/page production profile. Every
         sample gets a tiny box jitter so no cache can reuse another page's encoder output.
  mix  : every OCR'd page with 1..1024 boxes, as-is (natural distribution).

Output: a torch file with a list of {"pixels": uint8 (3,640,640), "boxes": float (K,4),
"file_name", "page"}.
"""

from __future__ import annotations

import click
import numpy as np
import torch

from common import attach_pixels, load_pages
from engine import to_uint8


@click.command()
@click.option("--workload", type=click.Choice(["w300", "mix"]), required=True)
@click.option("--n", default=512, show_default=True, help="w300: number of pages after replication")
@click.option("--out", required=True)
@click.option("--target-mean", default=300.0, show_default=True, help="w300: mean boxes/page")
@click.option("--seed", default=0, show_default=True)
def main(workload, n, out, target_mean, seed):
    if workload == "w300":
        base = load_pages(min_boxes=200, max_boxes=450)
    else:
        base = load_pages(min_boxes=1, max_boxes=1024)
    attach_pixels(base)
    rng = np.random.default_rng(seed)
    order = list(range(len(base)))
    if workload == "w300":
        # sample pages with weight exp(beta * K), beta bisected so the mean K hits the target
        ks = np.array([len(p["boxes"]) for p in base], np.float64)
        lo, hi = -0.1, 0.1
        for _ in range(60):
            beta = (lo + hi) / 2
            w = np.exp(beta * (ks - ks.mean()))
            lo, hi = (beta, hi) if (w * ks).sum() / w.sum() < target_mean else (lo, beta)
        order = list(rng.choice(len(base), size=n, p=w / w.sum()))
    items = []
    for i, j in enumerate(order):
        p = base[j]
        boxes = p["boxes"].copy()
        if workload == "w300":
            boxes = np.clip(boxes + rng.uniform(-1e-4, 1e-4, boxes.shape).astype(np.float32), 0, 1)
        items.append({"pixels": to_uint8(p["pixel_values"]), "boxes": torch.from_numpy(boxes),
                      "file_name": p["file_name"], "page": p["page"]})
    torch.save(items, out)
    k = np.array([len(it["boxes"]) for it in items])
    print(f"{workload}: {len(items)} pages ({len(base)} unique) | boxes/page mean {k.mean():.0f} "
          f"median {np.median(k):.0f} min {k.min()} max {k.max()} -> {out}")


if __name__ == "__main__":
    main()
