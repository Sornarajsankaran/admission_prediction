import fitz


def configure_mupdf_diagnostics(display: bool = False) -> None:
    fitz.TOOLS.mupdf_display_errors(display)
    fitz.TOOLS.mupdf_display_warnings(display)
    fitz.TOOLS.reset_mupdf_warnings()
