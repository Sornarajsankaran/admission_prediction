"""Inputs: the Textract OCR dataframe and the page images.

OCR dataframe (parquet / pickle / csv / jsonl), one row per page:

    file_name   PDF file name (matched against pdf-dir by relative path or base name)
    page        page number (1-based by default, like the training data)
    content     page text: lines separated by '\\n', words within a line by '\\t'
    line_cords  one box per line, separated by '|'; each box "x1,x2,y1,y2" normalized to
                [0, 1] (note the order), converted here to (x1, y1, x2, y2)

Line i of ``content`` belongs to box i of ``line_cords``; the model's box pointers index
this list, exactly as the training data's ``ocr_bbox`` rows followed the OCR line order.
"""

from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path

import numpy as np

HERON_DIR = Path(__file__).with_name("assets") / "heron"
REQUIRED_COLUMNS = ("file_name", "page", "content", "line_cords")


@dataclass
class PageJob:
    idx: int                      # row position, used as the request id
    file_name: str
    page: int                     # as given in the dataframe
    pdf_path: str | None
    lines: list[str] = field(default_factory=list)
    boxes: np.ndarray | None = None
    status: str = "ok"            # ok | missing_pdf | line_box_mismatch | no_lines | bad_cords |
                                  # too_many_boxes | duplicate_row


# --------------------------------------------------------------------------- #
# Parsing
# --------------------------------------------------------------------------- #
def parse_lines(content) -> list[str]:
    if content is None or (isinstance(content, float) and np.isnan(content)):
        return []
    text = str(content)
    if not text:
        return []
    return [line.replace("\t", " ") for line in text.split("\n")]


def parse_line_cords(cords) -> np.ndarray:
    """ "x1,x2,y1,y2|x1,x2,y1,y2|..." -> (N, 4) float32 xyxy, corners ordered, in [0, 1]."""
    if cords is None or (isinstance(cords, float) and np.isnan(cords)) or not str(cords).strip():
        return np.zeros((0, 4), np.float32)
    rows = []
    for part in str(cords).split("|"):
        vals = [float(v) for v in part.split(",")]
        if len(vals) != 4:
            raise ValueError(f"bad bbox {part!r}: expected 4 numbers x1,x2,y1,y2")
        x1, x2, y1, y2 = vals
        rows.append((min(x1, x2), min(y1, y2), max(x1, x2), max(y1, y2)))
    return np.clip(np.asarray(rows, np.float32), 0.0, 1.0)


def read_ocr_df(path: str | os.PathLike):
    import pandas as pd

    p = str(path)
    if p.endswith((".parquet", ".pq")):
        df = pd.read_parquet(p)
    elif p.endswith((".pkl", ".pickle")):
        df = pd.read_pickle(p)
    elif p.endswith(".csv"):
        df = pd.read_csv(p)
    elif p.endswith((".jsonl", ".json")):
        df = pd.read_json(p, lines=p.endswith(".jsonl"))
    else:
        raise ValueError(f"unsupported OCR dataframe format: {p} (parquet / pkl / csv / jsonl)")
    missing = [c for c in REQUIRED_COLUMNS if c not in df.columns]
    if missing:
        raise ValueError(f"OCR dataframe is missing columns {missing}; has {list(df.columns)}")
    return df


def index_pdfs(pdf_dir: str | os.PathLike) -> dict[str, str]:
    """relative path and base name -> absolute path, for every *.pdf under pdf_dir."""
    root = Path(pdf_dir)
    index: dict[str, str] = {}
    by_name: dict[str, list[str]] = {}
    for p in root.rglob("*"):
        if p.is_file() and p.suffix.lower() == ".pdf":
            index[str(p.relative_to(root))] = str(p)
            by_name.setdefault(p.name, []).append(str(p))
    for name, paths in by_name.items():
        if len(paths) == 1:
            index.setdefault(name, paths[0])
    return index


def build_jobs(df, pdf_dir, max_boxes: int) -> list[PageJob]:
    pdfs = index_pdfs(pdf_dir)
    jobs, seen = [], set()
    for i, row in enumerate(df.itertuples(index=False)):
        name = str(row.file_name)
        pdf = pdfs.get(name) or pdfs.get(Path(name).name) or pdfs.get(name + ".pdf")
        job = PageJob(i, name, int(row.page), pdf)
        if (name, job.page) in seen:              # one output file per page: first row wins
            job.status = "duplicate_row"
            jobs.append(job)
            continue
        seen.add((name, job.page))
        if pdf is None:
            job.status = "missing_pdf"
        else:
            try:
                job.lines = parse_lines(row.content)
                job.boxes = parse_line_cords(row.line_cords)
            except ValueError:
                job.status = "bad_cords"
            else:
                if len(job.lines) != len(job.boxes):
                    job.status = "line_box_mismatch"
                elif len(job.boxes) == 0:
                    job.status = "no_lines"
                elif len(job.boxes) > max_boxes:
                    job.status = "too_many_boxes"
        jobs.append(job)
    return jobs


# --------------------------------------------------------------------------- #
# Page images (same preprocessing as training: PyMuPDF raster -> Heron processor)
# --------------------------------------------------------------------------- #
class PageRasterizer:
    """Per-process: PDF handle cache + Heron image processor -> uint8 (3, 640, 640).

    The Heron processor only resizes and rescales (no normalization), so
    round(pixel_values * 255) is the exact resized image -- 4x smaller to ship."""

    def __init__(self, zoom: float = 2.0, max_open: int = 32):
        from transformers import AutoImageProcessor

        self.zoom = zoom
        self.processor = AutoImageProcessor.from_pretrained(str(HERON_DIR), use_fast=True)
        self.max_open = max_open
        self._docs: dict[str, object] = {}

    def _doc(self, path: str):
        import pymupdf

        doc = self._docs.pop(path, None)
        if doc is None:
            doc = pymupdf.open(path)
            if len(self._docs) >= self.max_open:
                old = next(iter(self._docs))
                self._docs.pop(old).close()
        self._docs[path] = doc                                      # most recent last
        return doc

    def __call__(self, pdf_path: str, page_index: int) -> np.ndarray:
        import pymupdf
        import torch
        from PIL import Image

        doc = self._doc(pdf_path)
        if not 0 <= page_index < len(doc):          # negative indices would wrap silently
            raise IndexError(f"page index {page_index} outside 0..{len(doc) - 1}")
        page = doc[page_index]
        pix = page.get_pixmap(matrix=pymupdf.Matrix(self.zoom, self.zoom), alpha=False)
        image = Image.frombytes("RGB", (pix.width, pix.height), pix.samples)
        pv = self.processor(images=image, return_tensors="pt")["pixel_values"][0]
        return (pv * 255.0).round_().clamp_(0, 255).to(torch.uint8).numpy()
