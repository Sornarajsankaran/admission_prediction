"""General utility helpers for the Qwen reranker project."""
from __future__ import annotations

import json
import logging
import random
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, Optional, Sequence, Tuple

import numpy as np
import torch
from matplotlib import pyplot as plt
from sklearn.metrics import (ConfusionMatrixDisplay, accuracy_score,
                             f1_score, roc_auc_score)

LOGGER_NAME = "qwen_reranker"


def get_logger(name: Optional[str] = None) -> logging.Logger:
    """Return a module-level logger with consistent formatting."""
    logger = logging.getLogger(name or LOGGER_NAME)
    if not logger.handlers:
        handler = logging.StreamHandler()
        formatter = logging.Formatter(
            "%(asctime)s | %(levelname)s | %(name)s | %(message)s"
        )
        handler.setFormatter(formatter)
        logger.addHandler(handler)
        logger.setLevel(logging.INFO)
    return logger


def set_seed(seed: int) -> None:
    """Seed Python, NumPy, and PyTorch for reproducibility."""
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


@dataclass
class DeviceConfig:
    device: torch.device
    dtype: torch.dtype
    bf16: bool


def detect_device() -> DeviceConfig:
    """Detect the best available device and dtype configuration."""
    logger = get_logger(__name__)
    if torch.cuda.is_available():
        capability = torch.cuda.get_device_capability()
        bf16_possible = capability[0] >= 8
        dtype = torch.bfloat16 if bf16_possible else torch.float32
        device = torch.device("cuda")
        if bf16_possible:
            logger.info("Using CUDA device with bfloat16 precision")
        else:
            logger.warning(
                "CUDA device lacks native bfloat16 support; falling back to float32"
            )
        return DeviceConfig(device=device, dtype=dtype, bf16=bf16_possible)
    logger.warning("CUDA unavailable; using CPU float32")
    return DeviceConfig(device=torch.device("cpu"), dtype=torch.float32, bf16=False)


def calculate_sha256(path: Path) -> str:
    import hashlib

    hasher = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(8192), b""):
            hasher.update(chunk)
    return hasher.hexdigest()


def ensure_dir(path) -> None:
    path = Path(path)  
    path.mkdir(parents=True, exist_ok=True)


def save_json(data: Dict[str, Any], path: Path) -> None:
    path.write_text(json.dumps(data, indent=2))


MetricTuple = Tuple[np.ndarray, np.ndarray]


def compute_metrics(logit_diff: Sequence[float], targets: Sequence[int]) -> Dict[str, float]:
    y_true = np.asarray(targets)
    y_score = np.asarray(logit_diff)
    preds = (1.0 / (1.0 + np.exp(-y_score))) >= 0.5
    metrics = {
        "accuracy": float(accuracy_score(y_true, preds)),
        "f1": float(f1_score(y_true, preds, zero_division=0)),
    }
    unique = np.unique(y_true)
    if unique.size < 2:
        get_logger(__name__).warning("Cannot compute AUROC with a single class")
        metrics["auroc"] = float("nan")
    else:
        try:
            metrics["auroc"] = float(roc_auc_score(y_true, y_score))
        except ValueError:
            metrics["auroc"] = float("nan")
    return metrics


def confusion_matrix_figure(y_true: Sequence[int], y_pred: Sequence[int], path: Path) -> None:
    fig, ax = plt.subplots(figsize=(4, 4))
    ConfusionMatrixDisplay.from_predictions(y_true, y_pred, ax=ax, cmap="Blues")
    fig.tight_layout()
    fig.savefig(path)
    plt.close(fig)


def get_token_ids(
    tokenizer,
    true_token: str = "yes",
    false_token: str = "no",
    override_true: Optional[int] = None,
    override_false: Optional[int] = None,
) -> Tuple[int, int]:
    logger = get_logger(__name__)
    if override_true is not None and override_false is not None:
        logger.info("Using user-provided token ids: true=%s false=%s", override_true, override_false)
        return override_true, override_false

    def resolve(token: str) -> int:
        enc = tokenizer.encode(token, add_special_tokens=False)
        if len(enc) == 1:
            return enc[0]
        enc = tokenizer.encode(" " + token, add_special_tokens=False)
        if len(enc) == 1:
            return enc[0]
        logger.warning(
            "Token '%s' maps to %d ids; using the last id %d", token, len(enc), enc[-1]
        )
        return enc[-1]

    true_id = resolve(true_token)
    false_id = resolve(false_token)
    logger.info("Resolved token ids: '%s'=%s, '%s'=%s", true_token, true_id, false_token, false_id)
    return true_id, false_id


class AverageMeter:
    """Utility to keep running averages."""

    def __init__(self) -> None:
        self.total = 0.0
        self.count = 0

    def update(self, value: float, n: int = 1) -> None:
        self.total += value * n
        self.count += n

    @property
    def average(self) -> float:
        return self.total / max(self.count, 1)
