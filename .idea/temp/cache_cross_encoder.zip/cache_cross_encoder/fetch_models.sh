#!/usr/bin/env bash
# Re-download the public checkpoints at the exact revisions used in the benchmarks.
# Run from the handoff directory after `bash setup.sh`. models/benchmark-cls is
# NOT on Hugging Face (it was built locally) and must be copied with the package.
# google/embeddinggemma-2 may be gated: accept its license on huggingface.co and
# run `.venv/bin/hf auth login` (or set HF_TOKEN) first if the download is refused.
set -euo pipefail
cd "$(dirname "$0")"
PY=${PY:-.venv/bin/python}
"$PY" - <<'EOF'
from huggingface_hub import snapshot_download
snapshot_download("google/embeddinggemma-2",
                  revision="f9972ac22e696a105c482202646979e33e4b5a1e",
                  local_dir="models/embeddinggemma-2")
snapshot_download("thomas-sounack/BioClinical-ModernBERT-base",
                  revision="c3648aa87af95837c809e6f0c5f85d08160db437",
                  local_dir="models/bioclinical-base",
                  allow_patterns=["*.json", "*.safetensors", "*.txt", "README.md"])
EOF
echo "Verifying checksums..."
sha256sum -c --quiet MANIFEST.sha256 && echo "All files match MANIFEST.sha256"
