"""
Convert an ``OcrTwoStageModel`` checkpoint into a vLLM model directory.
======================================================================

Input: a ``torch.save``'d dict with ``state_dict`` (+ ``config``) of the reference
``OcrTwoStageModel`` (scripts_v0.1). Output: ``config.json`` + ``model.safetensors``
whose tensor names match ``ocr_vllm.model.OcrTwoStageForConditionalGeneration``.

    python serving/convert_checkpoint.py --ckpt model.pt --out /workspace/models/ocr_vllm
"""

from __future__ import annotations

import json
import re
from pathlib import Path

import click
import torch
from safetensors.torch import save_file

from ocr_vllm.config import OcrTwoStageConfig

# nn.TransformerDecoderLayer -> ocr_vllm DecoderLayer
_LAYER_RENAMES = {
    "self_attn.in_proj_weight": "qkv.weight",
    "self_attn.in_proj_bias": "qkv.bias",
    "self_attn.out_proj.weight": "self_out.weight",
    "self_attn.out_proj.bias": "self_out.bias",
    "multihead_attn.out_proj.weight": "cross_out.weight",
    "multihead_attn.out_proj.bias": "cross_out.bias",
}


def _convert_layers(sd: dict, src: str, dst: str, d: int, out: dict) -> None:
    pat = re.compile(rf"^{re.escape(src)}\.(\d+)\.(.+)$")
    for name, w in sd.items():
        m = pat.match(name)
        if not m:
            continue
        i, rest = m.groups()
        base = f"{dst}.{i}."
        if rest in _LAYER_RENAMES:
            out[base + _LAYER_RENAMES[rest]] = w
        elif rest.startswith("multihead_attn.in_proj_"):
            kind = rest.rsplit("_", 1)[1]                      # weight | bias
            out[base + f"cross_q.{kind}"] = w[:d]
            out[base + f"cross_kv.{kind}"] = w[d:]
        else:                                                  # linear1/2, norm1/2/3
            out[base + rest] = w


def convert_state_dict(sd: dict, d: int) -> dict:
    out = {}
    for name, w in sd.items():
        if name.startswith("order.rtdetr."):
            out["encoder." + name[len("order."):]] = w
        elif name.startswith(("order.box_content_mlp.", "order.box_input_norm.")):
            out["encoder." + name[len("order."):]] = w
    out["order_bos"] = sd["order.order_bos"].reshape(1, d)
    out["order.pos_embedding"] = sd["order.pos_embedding"]
    out["order.norm.weight"] = sd["order.decoder_norm.weight"]
    out["order.norm.bias"] = sd["order.decoder_norm.bias"]
    out["pointer_key_proj.weight"] = sd["order.pointer_key_proj.weight"]
    _convert_layers(sd, "order.order_decoder.layers", "order.layers", d, out)

    out["formatter.pos_embedding"] = sd["formatter.pos_embedding"]
    out["formatter.norm.weight"] = sd["formatter.decoder_norm.weight"]
    out["formatter.norm.bias"] = sd["formatter.decoder_norm.bias"]
    out["token_embedding.weight"] = sd["formatter.token_embedding.weight"]
    out["cursor_done"] = sd["formatter.cursor_done"].reshape(1, d)
    out["head.weight"] = sd["formatter.head.weight"]
    out["head.bias"] = sd["formatter.head.bias"]
    _convert_layers(sd, "formatter.markdown_decoder.layers", "formatter.layers", d, out)
    # everything except the RT-DETR box encoder lives under the ``decoder`` module
    out = {(k if k.startswith("encoder.") else "decoder." + k): v for k, v in out.items()}
    return {k: v.detach().contiguous().clone() for k, v in out.items()}


@click.command()
@click.option("--ckpt", required=True, type=click.Path(exists=True, dir_okay=False))
@click.option("--out", required=True, type=click.Path(file_okay=False))
@click.option("--max-boxes", default=1024, show_default=True)
@click.option("--max-format-tokens", default=2048, show_default=True)
@click.option("--encoder-dtype", default="float32", show_default=True,
              type=click.Choice(["float32", "bfloat16", "float16"]))
def main(ckpt, out, max_boxes, max_format_tokens, encoder_dtype):
    from transformers import AutoConfig

    blob = torch.load(ckpt, map_location="cpu", weights_only=False)
    ref_cfg = blob["config"]
    rtdetr_cfg = AutoConfig.from_pretrained(ref_cfg["backbone_name_or_path"]).to_dict()
    d = ref_cfg["d_model"]

    cfg = OcrTwoStageConfig(
        d_model=d,
        num_decoder_layers=ref_cfg["num_markdown_layers"],
        decoder_attention_heads=ref_cfg["markdown_attention_heads"],
        decoder_ffn_dim=ref_cfg["markdown_ffn_dim"],
        content_mlp_hidden_dim=ref_cfg["content_mlp_hidden_dim"],
        content_mlp_num_layers=ref_cfg["content_mlp_num_layers"],
        num_special_tokens=ref_cfg["num_special_tokens"],
        stage_max_positions=ref_cfg["max_position_embeddings"],
        max_boxes=max_boxes,
        max_format_tokens=max_format_tokens,
        rtdetr_config=rtdetr_cfg,
        encoder_dtype=encoder_dtype,
        architectures=["OcrTwoStageForConditionalGeneration"],
        torch_dtype="float32",
    )
    out = Path(out)
    out.mkdir(parents=True, exist_ok=True)
    cfg.save_pretrained(out)
    # vLLM reads eos/bos from generation_config.json when there is no tokenizer
    (out / "generation_config.json").write_text(json.dumps(
        {"bos_token_id": cfg.ord_bos_id, "eos_token_id": cfg.eos_token_id,
         "decoder_start_token_id": cfg.ord_bos_id, "pad_token_id": cfg.pad_token_id}, indent=2))
    tensors = convert_state_dict(blob["state_dict"], d)
    save_file(tensors, out / "model.safetensors")
    print(f"wrote {out}: {len(tensors)} tensors, "
          f"{sum(t.numel() for t in tensors.values()) / 1e6:.1f}M params")


if __name__ == "__main__":
    main()
