"""Custom kernels that read per-page state straight from vLLM's paged KV caches.

vLLM gives a model no per-request memory other than attention KV caches, so this
model keeps its per-page state in two write-only cache layers and reads them here
through the layers' block tables:

  * box_store layer (cross, one row per box): K = pointer_key_proj(H_box[j]),
    V = box_input_norm(H_box[j]).
  * state layer (self, one row per decoded position): V[..., :4] =
        (box_id // 32, box_id % 32, is_box, is_emit)
    -- small integers, exact in bf16.

``pointer_scores``  -> exact q . key_j / sqrt(d) with placed boxes and j >= K at -inf.
``page_cursor``     -> formatter cursor (#EMIT inputs so far) and the box id of the
                       block at that cursor, i.e. the box placed at order step `cursor`.
``gather_box_rows`` -> box_input_norm(H_box[b]) for one box per request.

Both assume one query token per request per step, which always holds for this model
(the decoder prompt is a single token; chunked prefill is off for encoder-decoder).
Rows past the batch's request count (CUDA-graph padding) produce harmless defaults.
"""

from __future__ import annotations

import torch
import triton
import triton.language as tl

STATE_BOX_HI, STATE_BOX_LO, STATE_IS_BOX, STATE_IS_EMIT = 0, 1, 2, 3
# the same channel indices as Triton compile-time constants
_HI, _LO, _IS_BOX, _IS_EMIT = (tl.constexpr(STATE_BOX_HI), tl.constexpr(STATE_BOX_LO),
                               tl.constexpr(STATE_IS_BOX), tl.constexpr(STATE_IS_EMIT))


@triton.jit
def _pointer_scores_kernel(
    q_ptr, ptr_kv, ptr_bt, ptr_lens, st_kv, st_bt, st_lens, out_ptr,
    num_reqs, scale,
    stride_q, ptr_s_block, ptr_s_pos, ptr_s_bt,
    st_s_block, st_s_pos, st_s_bt, stride_out,
    PTR_BS: tl.constexpr, ST_BS: tl.constexpr, HEAD_DIM: tl.constexpr,
    BLOCK_N: tl.constexpr, BLOCK_P: tl.constexpr,
):
    row = tl.program_id(0)
    nb = tl.program_id(1)
    offs_n = nb * BLOCK_N + tl.arange(0, BLOCK_N)
    valid_row = row < num_reqs
    n_keys = tl.load(ptr_lens + row, mask=valid_row, other=0)
    mask_n = offs_n < n_keys

    # ---- scores q . k_j ----
    blocks = tl.load(ptr_bt + row * ptr_s_bt + offs_n // PTR_BS, mask=mask_n, other=0)
    offs_d = tl.arange(0, HEAD_DIM)
    k = tl.load(ptr_kv + blocks.to(tl.int64)[:, None] * ptr_s_block
                + (offs_n % PTR_BS)[:, None] * ptr_s_pos + offs_d[None, :],
                mask=mask_n[:, None], other=0.0).to(tl.float32)
    q = tl.load(q_ptr + row * stride_q + offs_d).to(tl.float32)
    s = tl.sum(k * q[None, :], axis=1) * scale

    # ---- boxes already placed: every BOX input in positions [0, min(len, K + 1)) ----
    n_pos = tl.load(st_lens + row, mask=valid_row, other=0)
    n_pos = tl.minimum(n_pos, n_keys + 1)
    used = tl.zeros([BLOCK_N], dtype=tl.int32)
    for p0 in range(0, n_pos, BLOCK_P):
        offs_p = p0 + tl.arange(0, BLOCK_P)
        mask_p = offs_p < n_pos
        pb = tl.load(st_bt + row * st_s_bt + offs_p // ST_BS, mask=mask_p, other=0).to(tl.int64)
        base = st_kv + pb * st_s_block + (offs_p % ST_BS) * st_s_pos
        hi = tl.load(base + _HI, mask=mask_p, other=0.0).to(tl.float32)
        lo = tl.load(base + _LO, mask=mask_p, other=0.0).to(tl.float32)
        is_box = tl.load(base + _IS_BOX, mask=mask_p, other=0.0).to(tl.float32)
        box = (hi * 32.0 + lo).to(tl.int32)
        box = tl.where(is_box > 0.5, box, -1)
        hit = (box[:, None] == offs_n[None, :]).to(tl.int32)
        used = tl.maximum(used, tl.max(hit, axis=0))

    s = tl.where(mask_n & (used == 0), s, float("-inf"))
    tl.store(out_ptr + row * stride_out + offs_n, s)


@triton.jit
def _page_cursor_kernel(
    st_kv, st_bt, st_lens, cursor_ptr, box_ptr,
    num_reqs, st_s_block, st_s_pos, st_s_bt,
    ST_BS: tl.constexpr, BLOCK_P: tl.constexpr,
):
    row = tl.program_id(0)
    valid_row = row < num_reqs
    n_pos = tl.load(st_lens + row, mask=valid_row, other=0)
    count = tl.zeros([BLOCK_P], dtype=tl.float32)
    for p0 in range(0, n_pos, BLOCK_P):
        offs_p = p0 + tl.arange(0, BLOCK_P)
        mask_p = offs_p < n_pos
        pb = tl.load(st_bt + row * st_s_bt + offs_p // ST_BS, mask=mask_p, other=0).to(tl.int64)
        count += tl.load(st_kv + pb * st_s_block + (offs_p % ST_BS) * st_s_pos + _IS_EMIT,
                         mask=mask_p, other=0.0).to(tl.float32)
    cursor = tl.sum(count, axis=0).to(tl.int32)
    # order step c was placed by the BOX input at position c + 1
    hp = cursor + 1
    ok = valid_row & (hp < n_pos)
    pb = tl.load(st_bt + row * st_s_bt + hp // ST_BS, mask=ok, other=0).to(tl.int64)
    base = st_kv + pb * st_s_block + (hp % ST_BS) * st_s_pos
    hi = tl.load(base + _HI, mask=ok, other=0.0).to(tl.float32)
    lo = tl.load(base + _LO, mask=ok, other=0.0).to(tl.float32)
    tl.store(cursor_ptr + row, cursor)
    tl.store(box_ptr + row, (hi * 32.0 + lo).to(tl.int32))


def _v_view(kv_cache: torch.Tensor) -> torch.Tensor:
    """(num_blocks, 2, block_size, heads, hd) -> the V half, for base-pointer math."""
    return kv_cache[:, 1]


def pointer_scores(q, ptr_kv, ptr_bt, ptr_lens, st_kv, st_bt, st_lens, max_keys: int, scale: float):
    """q (T, D) -> (T, max_keys) fp32 scores; -inf for j >= K and for placed boxes."""
    T, D = q.shape
    out = torch.empty(T, max_keys, device=q.device, dtype=torch.float32)
    BLOCK_N = 64
    st_v = _v_view(st_kv)
    _pointer_scores_kernel[(T, max_keys // BLOCK_N)](
        q, ptr_kv, ptr_bt, ptr_lens, st_v, st_bt, st_lens, out,
        ptr_bt.shape[0], scale,
        q.stride(0), ptr_kv.stride(0), ptr_kv.stride(2), ptr_bt.stride(0),
        st_v.stride(0), st_v.stride(1), st_bt.stride(0), out.stride(0),
        PTR_BS=ptr_kv.shape[2], ST_BS=st_kv.shape[2], HEAD_DIM=D,
        BLOCK_N=BLOCK_N, BLOCK_P=128,
    )
    return out


def page_cursor(T: int, st_kv, st_bt, st_lens):
    """-> (cursor (T,) int32, box id at the cursor (T,) int32)."""
    cursor = torch.empty(T, device=st_kv.device, dtype=torch.int32)
    box = torch.empty(T, device=st_kv.device, dtype=torch.int32)
    st_v = _v_view(st_kv)
    _page_cursor_kernel[(T,)](
        st_v, st_bt, st_lens, cursor, box,
        st_bt.shape[0], st_v.stride(0), st_v.stride(1), st_bt.stride(0),
        ST_BS=st_kv.shape[2], BLOCK_P=256,
    )
    return cursor, box


def gather_box_rows(kv_cache: torch.Tensor, block_table: torch.Tensor, box: torch.Tensor) -> torch.Tensor:
    """V row of box ``box[t]`` of request t from a cross-attention cache -> (T, heads*hd).
    One direct read instead of an attention pass over all of the page's boxes."""
    T = box.shape[0]
    R = block_table.shape[0]
    bs = kv_cache.shape[2]
    rows = torch.arange(T, device=box.device).clamp(max=R - 1)
    blocks = block_table[rows, (box // bs).clamp(max=block_table.shape[1] - 1)].long()
    return kv_cache[blocks, 1, box % bs].reshape(T, -1)
