# Development and troubleshooting

## 1. Working on the code

```bash
python -m venv venv && . venv/bin/activate
pip install vllm==0.23.0 -r requirements.txt
pip install -e .                               # registers the vLLM plugin entry point
pytest -q tests                                # CPU unit tests
```

The package layout is in [architecture.md](architecture.md) §12. The plugin is found by
vLLM through the `vllm.general_plugins` entry point in `pyproject.toml`, so the package
must be *installed* (editable is fine), not merely on `PYTHONPATH`, for vLLM's worker
processes to see it.

Useful switches:

| Setting | Effect |
|---|---|
| `VLLM_ENABLE_V1_MULTIPROCESSING=0` | run vLLM's engine core in-process, so stack traces and debuggers work (vLLM hides child errors) |
| `OCR_VLLM_STRICT_FP32=1` + an fp32 model dir with `compile_decoder`, `compile_encoder` and `encoder_channels_last` set to `false` in `config.json` | bit-level parity mode (see [validation.md](validation.md)) |
| `--engines 1 --limit 20` | the fastest end-to-end loop |
| `make_llm(..., enforce_eager=True)` | no CUDA graphs or compile; easier to debug |

Model directory config flags (`config.json` of a converted model):

| key | default | meaning |
|---|---|---|
| `encoder_max_batch` | 8 | images per RT-DETR forward (8 measured fastest) |
| `compile_encoder` | true | `torch.compile` the encoder halves |
| `compile_decoder` | true | `torch.compile` the stacked dense decoder parts and logits assembly |
| `encoder_channels_last` | true | channels-last convolutions |
| `max_boxes` | 1024 | largest page; must be a multiple of 64 and ≤ 1024 (box ids are two base-32 digits in the state cache) |
| `stage_max_positions` | from checkpoint | per-stage positional table; the formatter emits at most this − 1 tokens |

## 2. Common changes

**A new checkpoint with the same architecture:** nothing to change; point `MODEL` at it.
Conversion is automatic and cached.

**Different decoder depth, width or FFN size:** inferred from the weights automatically.
The **number of decoder attention heads** cannot be inferred; pass `--decoder-heads`.
`d_model / heads` must be 32 or more (vLLM Triton attention head-size limit).

**A changed markdown vocab (`vocab.json`):**
1. Replace `src/ocr_vllm/assets/vocab.json`.
2. Keep `<bos>`, `<eos>`, `<pad>` at ids 10000–10002 (the model relies on 0/1/2).
3. Rebuild.

`num_special_tokens` is read from the checkpoint's `token_embedding` (rows − 1) and must
equal the vocab's span.

**Another RT-DETR / Heron variant:** replace `src/ocr_vllm/assets/heron/config.json` and
`preprocessor_config.json`. The converter checks that `d_model` matches the checkpoint.

**Upgrading vLLM.** The plugin depends on vLLM 0.23 internals:
- `Attention.impl.do_kv_cache_update(layer, key, value, kv_cache, slot_mapping)`;
- the Triton attention metadata fields `seq_lens`, `block_table` and `slot_mapping`, and
  the KV cache layout `(num_blocks, 2, block_size, heads, head_dim)`;
- cross-attention metadata `seq_lens` = encoder length;
- the per-layer metadata dict in the forward context (used by `restrict_attention`);
- `EncDecMultiModalProcessor`, `DictEmbeddingItems` and `SupportsMultiModal`
  (`_mark_tower_model` / `_mark_language_model`);
- encoder-decoder CUDA-graph behaviour (`max_source_positions`).

vLLM ≥ 0.24 also requires transformers 5, while the RT-DETR self-attention patch in
`encoder.py` was validated on 4.57.6. After an upgrade, re-run the strict parity test and
the throughput benchmark before trusting it.

## 3. Troubleshooting

| Symptom | Cause / fix |
|---|---|
| Log: `nvidia-cuda-mps-control not found` or `could not start CUDA MPS` | the container lacks the driver utilities; ensure `NVIDIA_DRIVER_CAPABILITIES=compute,utility` (set in the image) and the NVIDIA runtime. Throughput drops a lot without MPS; `--engines 1` is then the honest setting |
| `engine N failed: ... Free memory on device ... less than desired GPU memory utilization` | another process uses the GPU, or `--gpu-memory` is too high; lower it or free the GPU |
| An engine fails with CUDA OOM during a run | lower `--max-seqs`, or use fewer `--engines` |
| Steady-state pages/s far below [performance.md](performance.md) | check `/sys/fs/cgroup/cpu.stat` throttling, `--preprocess-workers`, and whether MPS started |
| Startup takes minutes | normal on a cold cache (compile + CUDA-graph capture, engines one after another); keep `CACHE_DIR` |
| Many `line_box_mismatch` | the `content` line count ≠ the `line_cords` box count; check for trailing `\n` or `\|`, or a different export format |
| Many `page_out_of_range` | the `page` column is 0-based; use `--page-base 0` |
| Many `missing_pdf` | `file_name` doesn't match paths under `pdf-dir` (matched by relative path, base name, base name + `.pdf`) |
| `unsupported OCR dataframe format` | save as `.parquet`, `.pkl`, `.csv` or `.jsonl` |
| `checkpoint is missing N params` at engine start | the checkpoint doesn't match the architecture (e.g. wrong stage file); check which of `--model`, `--order-ckpt` and `--formatter-ckpt` got which file |
| `unrecognised checkpoint` from the converter | not a v0.1 two-stage, order or formatter state dict |
| Markdown looks wrong but pages are `ok` | re-run a few pages with `--dtype float32`; if that helps, bf16 affects this model's decisions ([validation.md](validation.md) §5) |
| `docker: ... unshare: operation not permitted` | you are inside an unprivileged container; Docker needs a real host (see [validation.md](validation.md) §4) |

## 4. Lessons worth keeping

- **Profile before optimizing.** Every large win (the 16 ms pointer call, 29 KV groups,
  CPU throttling, encoder chunk size) came from a measurement, not a hunch. Two plausible
  optimizations (stacking the decoder GEMMs, compile tuning for the image backbone) barely
  moved the numbers.
- **GPU utilization is a weak signal.** nvidia-smi reported 80–98% busy while small
  kernels left most of the GPU idle.
- **Check the CPU quota, not the core count,** on any shared or cloud host.
- **Verify a divergence before calling it numerics:** teacher-force the served sequence
  through the reference and measure the reference's margin at the divergent step.
