import pandas as pd

from docling_lite.core.datamodels import TextractBBox
from docling_lite.core.logging import log_function_calls, logger
from docling.datamodel.base_models import Page
from docling_core.types.doc import BoundingBox, CoordOrigin, Size
from docling_core.types.doc.page import (
    BoundingRectangle,
    PdfPageBoundaryType,
    PdfPageGeometry,
    SegmentedPdfPage,
    TextCell,
)
from docling_lite.core.config import (
    COORDS_SEPARATOR,
    LINE_SEPARATOR,
    WORD_SEPARATOR,
)


class Preprocessor:
    @staticmethod
    def _get_page_geometry(page_size: Size) -> PdfPageGeometry:
        page_bbox = BoundingBox.from_tuple(
            coord=(0.0, 0.0, float(page_size.width), float(page_size.height)),
            origin=CoordOrigin.BOTTOMLEFT,
        )
        page_rect = BoundingRectangle.from_bounding_box(page_bbox)
        return PdfPageGeometry(
            angle=0.0,
            rect=page_rect,
            boundary_type=PdfPageBoundaryType.CROP_BOX,
            art_bbox=page_bbox,
            bleed_bbox=page_bbox,
            crop_bbox=page_bbox,
            media_bbox=page_bbox,
            trim_bbox=page_bbox,
        )

    @staticmethod
    def _build_line_cells(lines, line_coords, page_size):
        return [
            TextCell(
                text=line,
                orig=line,
                rect=TextractBBox.from_string(coord, page_size),
                from_ocr=True,
                index=index,
            )
            for index, (line, coord) in enumerate(zip(lines, line_coords))
        ]

    @classmethod
    def _build_docling_page(
        cls, page_no, page_width_pt, page_height_pt, lines, line_coords
    ) -> Page:
        page_size = Size(width=float(page_width_pt), height=float(page_height_pt))
        line_cells = cls._build_line_cells(lines, line_coords, page_size.as_tuple())

        ocr_page = SegmentedPdfPage(
            dimension=cls._get_page_geometry(page_size),
            textline_cells=line_cells,
            word_cells=[],
            char_cells=[],
        )
        return Page(page_no=int(page_no), size=page_size, parsed_page=ocr_page)

    @classmethod
    @log_function_calls(logger)
    def preprocess(cls, joined_df: pd.DataFrame) -> pd.DataFrame:
        try:
            df = joined_df.copy()
            df["lines"] = (
                df["content"]
                .astype(str)
                .str.replace(WORD_SEPARATOR, " ", regex=False)
                .str.split(LINE_SEPARATOR)
            )
            df["line_coords"] = (
                df["line_cord"].astype(str).str.split(COORDS_SEPARATOR, regex=False)
            )

            df["docling_page_obj"] = [
                cls._build_docling_page(page, pw, ph, lines, coords)
                for page, pw, ph, lines, coords in zip(
                    df["page"],
                    df["page_width_pt"],
                    df["page_height_pt"],
                    df["lines"],
                    df["line_coords"],
                )
            ]

            return df[
                [
                    "file_name",
                    "page",
                    "content",
                    "line_cord",
                    "word_cord",
                    "image_path",
                    "image_width",
                    "image_height",
                    "page_width_pt",
                    "page_height_pt",
                    "docling_page_obj",
                ]
            ]

        except Exception as e:
            logger.error(f"Error during preprocessing: {e}")
            raise
