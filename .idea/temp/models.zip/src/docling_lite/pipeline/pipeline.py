from docling_lite.core.datamodels import JobConfig
from docling_lite.core.logging import logger, log_function_calls
from docling_lite.pipeline.stages.dataloader import DataLoader
from docling_lite.pipeline.stages.layout_detector import LayoutDetector
from docling_lite.pipeline.stages.page_assembler import PageAssembly
from docling_lite.pipeline.stages.preprocessor import Preprocessor
from docling_lite.pipeline.stages.reading_order_resolver import ReadingOrderResolver
from docling_lite.pipeline.stages.result_writing import ResultWriter
from docling_lite.pipeline.stages.table_extractor import TableExtractor


class ProcessingPipeline:
    def __init__(self, config: JobConfig):
        self.config = config

        self.layout_detector = LayoutDetector(
            model_name_or_path=config.layout_model_name_or_path,
            is_mixed_precision=config.dtype.is_mixed_precision,
            device=config.device.torch_device,
            layout_batch_size=config.layout_batch_size,
        )
        self.table_extractor = TableExtractor(
            model_name_or_path=config.table_model_name_or_path,
            device=config.device.torch_device,
            table_batch_size=config.table_batch_size,
        )
        self.assembly = PageAssembly()
        self.reading_order_resolver = ReadingOrderResolver()
        self.result_writer = ResultWriter(
            output_dir=config.output_dir,
            batch_name=config.batch_name,
        )

    @log_function_calls(logger)
    def run(self) -> bool:
        pdfs = None

        try:
            # Load data files and preprocess
            ocr_df, pdfs = DataLoader.load(
                self.config.ocr_df_path,
                self.config.pdf_dir,
            )
            processed_df = Preprocessor.preprocess(ocr_df, pdfs)

            # Layout detection
            layout_results = self.layout_detector.detect_layout(processed_df)
        
            # Table structure extraction
            table_structure_results = self.table_extractor.extract_tables(layout_results)

            # Page assembly and reading order
            assembled_df = self.assembly.assemble_pages(table_structure_results)
            docling_documents, results_df = self.reading_order_resolver.resolve(assembled_df)

            self.result_writer.save_results(
                documents=docling_documents,
                processed_df=results_df,
            )

            return True

        except Exception as exc:
            logger.exception(f"Pipeline failed: {exc}")
            return False

        finally:
            if pdfs is not None:
                for pdf_file in pdfs.values():
                    try:
                        pdf_file.close()
                    except Exception as exc:
                        logger.warning(f"Failed to close PDF handle: {exc}")
