"""
Generator for the TWO-STAGE OCR Text Reconstruction architecture diagram
(OcrTwoStageModel: shared RT-DETR box encoder -> order decoder + EMIT_NEXT formatter).

Emits an editable Excalidraw scene (.excalidraw, hand-drawn look, fully editable)
plus a crisp preview SVG for QA. Same primitives / palette as build_diagram.py.
"""
import json, random, html

random.seed(11)
TS = 1710000000000

BLACK="#1e1e1e"; BROWN="#846358"; GRAY="#e9ecef"; GREEN="#b2f2bb"; PINK="#ffc9c9"
YELLOW="#ffec99"; ORANGE="#ffd8a8"; BLUE="#a5d8ff"; LGREEN="#ebfbee"; LPINK="#fff0f6"
TAN="#f8f1ee"; WHITE="#ffffff"; TRANS="transparent"; ORANGETXT="#f08c00"; BLUETXT="#1971c2"

shapes = []
def _id(): return "".join(random.choice("abcdefghijklmnopqrstuvwxyz0123456789") for _ in range(16))

def rect(x,y,w,h,fill=GRAY,stroke=BLACK,rounded=True,sw=2,dashed=False):
    s=dict(kind="rect",x=x,y=y,w=w,h=h,fill=fill,stroke=stroke,rounded=rounded,sw=sw,dashed=dashed,id=_id())
    shapes.append(s); return s
def line(x1,y1,x2,y2,stroke=BROWN,sw=1):
    shapes.append(dict(kind="line",x1=x1,y1=y1,x2=x2,y2=y2,stroke=stroke,sw=sw,id=_id()))
def text(t,cx,cy,size=20,color=BLACK,align="center"):
    shapes.append(dict(kind="text",t=t,cx=cx,cy=cy,size=size,color=color,align=align,id=_id()))
def arrow(pts,stroke=BLACK,sw=2,dashed=False,head_end=True,head_start=False):
    shapes.append(dict(kind="arrow",pts=pts,stroke=stroke,sw=sw,dashed=dashed,head_end=head_end,head_start=head_start,id=_id()))
def grid(x,y,w,h,rows,cols,fill,stroke=BLACK,cell=BROWN):
    r0=rect(x,y,w,h,fill=fill,stroke=stroke,rounded=False,sw=2)
    for r in range(1,rows): line(x,y+h*r/rows,x+w,y+h*r/rows,stroke=cell,sw=1)
    for c in range(1,cols): line(x+w*c/cols,y,x+w*c/cols,y+h,stroke=cell,sw=1)
    return r0
def cells(x,y,w,h,n,cell=BROWN):
    for c in range(1,n): line(x+w*c/n,y,x+w*c/n,y+h,stroke=cell,sw=1)
def stack(x,y,w,h,n=3,off=8,fill=BLUE):
    for i in range(n-1,-1,-1): rect(x+i*off,y+i*off,w,h,fill=fill,stroke=BLACK,rounded=False,sw=2)

def top(s):   return (s["x"]+s["w"]/2, s["y"])
def bot(s):   return (s["x"]+s["w"]/2, s["y"]+s["h"])
def left(s):  return (s["x"], s["y"]+s["h"]/2)
def right(s): return (s["x"]+s["w"], s["y"]+s["h"]/2)
def ctr(s):   return (s["x"]+s["w"]/2, s["y"]+s["h"]/2)

# ============================================================= LAYOUT
A = arrow

# --------- title + inference note ---------
text("OCR Text Reconstruction  —  Two-Stage Model", 900, 26, size=30)
text("shared RT-DETR box encoder  →  reading-order decoder  +  EMIT_NEXT markdown formatter", 900, 62, size=18, color=BROWN)

# =============================== SHARED ENCODER (left) ===============================
rect(40, 895, 445, 615, fill=TRANS, stroke=BROWN, rounded=True, sw=2, dashed=True)
text("Shared RT-DETR-v2 Box Encoder  (runs once)", 262, 921, size=18, color=BROWN)

page = rect(180, 1380, 185, 90, fill=WHITE, rounded=False)
text("PAGE IMAGE", *ctr(page), size=18)
backbone = rect(155, 1235, 235, 95, fill=GRAY); text("Conv Backbone\n(ResNet)", *ctr(backbone), size=18)
encoder  = rect(155, 1090, 235, 95, fill=GRAY); text("Hybrid Encoder\n(multi-scale)", *ctr(encoder), size=18)
stack(405, 1095, 55, 55); text("memory", 448, 1180, size=13)
decoder  = rect(120, 940, 300, 105, fill=GRAY)
text("Deformable Decoder", 270, 972, size=18)
text("queries = content MLP(4->d) + ref points", 270, 1002, size=12)
ocr = grid(30, 1235, 105, 95, 5, 3, PINK)
text("OCR boxes\n(N, 4)", 82, 1370, size=14)
hbox = grid(150, 745, 240, 96, 4, 6, GREEN)
text("H_box", 270, 723, size=20)
text("(N, d_model)", 270, 863, size=15)

# encoder arrows
A([top(page), (270,1330)])
A([top(backbone), bot(encoder)])
A([(390,1137),(432,1112)])            # encoder -> memory
A([(438,1095),(360,1045)])            # memory -> decoder
A([top(encoder), bot(decoder)])
A([right(ocr), (120,1000)])           # ocr boxes -> decoder (queries)
A([top(decoder), (270,841)])          # decoder -> H_box

# =============================== STAGE 1 : ORDER DECODER (middle) ===============================
rect(560, 300, 470, 990, fill=TRANS, stroke=BROWN, rounded=True, sw=2, dashed=True)
text("Stage 1  —  Reading-Order Decoder", 795, 326, size=19, color=BROWN)

s1_in  = rect(650, 1180, 290, 78, fill=LGREEN)
text("input:  BOS  /  H_box[ pi(t-1) ]", 795, 1210, size=15)
text("(previously selected box)", 795, 1234, size=12)
s1_dec = rect(635, 950, 320, 170, fill=GRAY)
text("Order Decoder\n(6 layers)\ncausal self-attn + cross-attn", *ctr(s1_dec), size=17)
s1_ptr = rect(635, 760, 320, 120, fill=GRAY)
text("Pointer Head", 795, 792, size=17)
text("score = q . proj(H_box)", 795, 820, size=13)
text("mask: already-used + padded boxes", 795, 848, size=12)
s1_out = rect(600, 600, 390, 96, fill=BLUE, rounded=False); cells(600,600,390,96,7)
text("reading order  pi = (b1, b2, b3, ...)", 795, 636, size=15)
text("K steps  •  valid permutation by construction", 795, 664, size=12)
text("argmax -> next box", 690, 580, size=13, color=BLUETXT)

A([top(s1_in), bot(s1_dec)])
A([top(s1_dec), bot(s1_ptr)])
A([top(s1_ptr), bot(s1_out)])
# stage-1 autoregressive feedback (left side); arrowhead back into the input is self-explanatory
A([left(s1_out), (560,648),(560,1219),left(s1_in)], dashed=True, sw=2, stroke=BROWN)

# =============================== STAGE 2 : MARKDOWN FORMATTER (right) ===============================
rect(1110, 300, 560, 990, fill=TRANS, stroke=BROWN, rounded=True, sw=2, dashed=True)
text("Stage 2  —  Markdown Formatter  (EMIT_NEXT)", 1390, 326, size=19, color=BROWN)

s2_in  = rect(1230, 1180, 320, 78, fill=YELLOW, rounded=False)
text("decoder_input_ids", 1390, 1208, size=15)
text("vocab = { M specials ,  EMIT_NEXT }", 1390, 1234, size=13)
s2_emb = rect(1180, 990, 420, 130, fill=GRAY)
text("Token Embedding  +  positional", 1390, 1022, size=16)
text("+  cursor hint  H_ord[cursor]", 1390, 1052, size=14)
text("(block about to be placed; cursor_done when all placed)", 1390, 1080, size=11)
s2_dec = rect(1210, 790, 360, 150, fill=GRAY)
text("Markdown Decoder\n(6 layers)\ncausal self-attn + cross-attn", *ctr(s2_dec), size=17)
s2_head = rect(1195, 620, 390, 120, fill=GRAY)
text("Head  Linear(d -> M+1)", 1390, 652, size=16)
text("+ structural EMIT / EOS mask:", 1390, 680, size=12)
text("EMIT_NEXT off when cursor>=K   •   EOS off until then", 1390, 704, size=11)
s2_log = rect(1215, 500, 350, 54, fill=YELLOW, rounded=False); cells(1215,500,350,54,7)
rect(1215+350*6/7, 500, 350/7, 54, fill=GREEN, rounded=False, sw=2)  # last cell = EMIT_NEXT
text("logits  (1, M+1)", 1390, 480, size=14)
s2_out = rect(1200, 390, 380, 66, fill=LGREEN)
text("token:  special  or  EMIT_NEXT", 1390, 414, size=14)
text("EMIT_NEXT places block, cursor++", 1390, 438, size=12)

A([top(s2_in), bot(s2_emb)])
A([top(s2_emb), bot(s2_dec)])
A([top(s2_dec), bot(s2_head)])
A([top(s2_head), bot(s2_log)])
A([top(s2_log), bot(s2_out)])
# stage-2 autoregressive feedback (right side)
A([right(s2_out), (1640,423),(1640,1219),right(s2_in)], dashed=True, sw=2, stroke=BROWN)
text("emit token\n-> next input", 1690, 830, size=12, color=BROWN, align="center")

# =============================== H_box -> both decoders (shared memory) ===============================
A([right(hbox), (635, 1035)])                         # H_box -> order decoder (K,V)
text("K, V", 452, 858, size=14)
# shared H_box "bus": up out of the encoder, across the empty band, down stage-2's left margin
A([(270, 743), (270, 468), (1155, 468), (1155, 1090)], head_end=False, sw=2)
text("shared H_box  ->  K,V  +  cursor hint", 618, 452, size=13)
A([(1155, 865), (1210, 865)]); text("K, V", 1180, 850, size=12)          # -> markdown decoder
A([(1155, 1075), (1180, 1075)]); text("H_box", 1122, 1058, size=11)      # -> cursor hint

# =============================== inter-stage: reading order -> formatter cursor ===============================
A([(990, 648), (1050, 648), (1050, 1010), (1180, 1010)], stroke=BLUETXT, sw=3)
text("reading order pi", 1066, 706, size=15, color=BLUETXT, align="left")
text("drives cursor + H_ord", 1066, 730, size=12, color=BLUETXT, align="left")

# =============================== joint loss (top) ===============================
loss = rect(700, 150, 700, 96, fill=TAN)
text("Joint training loss", 1050, 180, size=18)
text("L = w_order · L_order  +  w_format · L_format", 1050, 210, size=16)
text("(both losses backprop into the one shared H_box)", 1050, 234, size=12, color=BROWN)
A([(795, 600), (795, 246)], dashed=True, sw=1, stroke=BROWN)              # L_order
text("L_order", 806, 434, size=12, color=BROWN, align="left")
A([(1195, 660), (1175, 660), (1175, 246)], dashed=True, sw=1, stroke=BROWN)  # L_format
text("L_format", 1185, 434, size=12, color=BROWN, align="left")

# inference note
text("End-to-end inference:   Order Decoder  ->  predicted pi  ->  Formatter  ->  markdown", 1000, 100, size=15, color=BLUETXT)

# ============================================================= EMITTERS (shared with build_diagram.py)
def est_w(t,size): return max(len(l) for l in t.split("\n"))*size*0.55
def est_h(t,size): return len(t.split("\n"))*size*1.25
def base(el):
    el.update(dict(angle=0,opacity=100,groupIds=[],frameId=None,seed=random.randint(1,2**31),
        version=1,versionNonce=random.randint(1,2**31),isDeleted=False,boundElements=None,
        updated=TS,link=None,locked=False)); return el
def to_excalidraw():
    els=[]
    for s in shapes:
        k=s["kind"]
        if k=="rect":
            e=base(dict(id=s["id"],type="rectangle",x=s["x"],y=s["y"],width=s["w"],height=s["h"],
                strokeColor=s["stroke"] if s["sw"] else "transparent",backgroundColor=s["fill"],fillStyle="solid",
                strokeWidth=s["sw"] or 1,strokeStyle="dashed" if s["dashed"] else "solid",roughness=1,
                roundness={"type":3} if s["rounded"] else None)); els.append(e)
        elif k=="line":
            els.append(base(dict(id=s["id"],type="line",x=s["x1"],y=s["y1"],width=s["x2"]-s["x1"],height=s["y2"]-s["y1"],
                strokeColor=s["stroke"],backgroundColor="transparent",fillStyle="solid",strokeWidth=s["sw"],
                strokeStyle="solid",roughness=0,roundness=None,points=[[0,0],[s["x2"]-s["x1"],s["y2"]-s["y1"]]],
                lastCommittedPoint=None,startBinding=None,endBinding=None,startArrowhead=None,endArrowhead=None)))
        elif k=="arrow":
            p=s["pts"]; x0,y0=p[0]; rel=[[a-x0,b-y0] for a,b in p]
            xs=[q[0] for q in rel]; ys=[q[1] for q in rel]
            els.append(base(dict(id=s["id"],type="arrow",x=x0,y=y0,width=max(xs)-min(xs),height=max(ys)-min(ys),
                strokeColor=s["stroke"],backgroundColor="transparent",fillStyle="solid",strokeWidth=s["sw"],
                strokeStyle="dashed" if s["dashed"] else "solid",roughness=1,roundness={"type":2},points=rel,
                lastCommittedPoint=None,startBinding=None,endBinding=None,
                startArrowhead="arrow" if s["head_start"] else None,endArrowhead="arrow" if s["head_end"] else None)))
        elif k=="text":
            w=est_w(s["t"],s["size"]); h=est_h(s["t"],s["size"])
            x=s["cx"] if s["align"]=="left" else s["cx"]-w/2; y=s["cy"]-h/2
            els.append(base(dict(id=s["id"],type="text",x=x,y=y,width=w,height=h,strokeColor=s["color"],
                backgroundColor="transparent",fillStyle="solid",strokeWidth=1,strokeStyle="solid",roughness=1,
                roundness=None,text=s["t"],fontSize=s["size"],fontFamily=1,textAlign=s["align"],
                verticalAlign="top",containerId=None,originalText=s["t"],autoResize=True,lineHeight=1.25)))
    return dict(type="excalidraw",version=2,source="https://excalidraw.com",elements=els,
        appState=dict(gridSize=None,viewBackgroundColor="#ffffff"),files={})

def to_svg():
    W,H=1900,1560
    o=[f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="-20 -20 {W} {H}" width="{W}" height="{H}" font-family="Segoe UI, sans-serif">',
       f'<rect x="-20" y="-20" width="{W}" height="{H}" fill="#fff"/>',
       '<defs><marker id="ah" markerWidth="10" markerHeight="10" refX="8" refY="3" orient="auto" markerUnits="strokeWidth"><path d="M0,0 L8,3 L0,6 z" fill="#1e1e1e"/></marker>'
       '<marker id="ahb" markerWidth="10" markerHeight="10" refX="8" refY="3" orient="auto" markerUnits="strokeWidth"><path d="M0,0 L8,3 L0,6 z" fill="#846358"/></marker>'
       '<marker id="ahc" markerWidth="10" markerHeight="10" refX="8" refY="3" orient="auto" markerUnits="strokeWidth"><path d="M0,0 L8,3 L0,6 z" fill="#1971c2"/></marker></defs>']
    for s in shapes:
        k=s["kind"]
        if k=="rect":
            rx=12 if s["rounded"] else 0; fill="none" if s["fill"]==TRANS else s["fill"]
            stroke="none" if s["sw"]==0 else s["stroke"]; dash=' stroke-dasharray="8 6"' if s["dashed"] else ""
            o.append(f'<rect x="{s["x"]}" y="{s["y"]}" width="{s["w"]}" height="{s["h"]}" rx="{rx}" fill="{fill}" stroke="{stroke}" stroke-width="{s["sw"]}"{dash}/>')
        elif k=="line":
            o.append(f'<line x1="{s["x1"]}" y1="{s["y1"]}" x2="{s["x2"]}" y2="{s["y2"]}" stroke="{s["stroke"]}" stroke-width="{s["sw"]}"/>')
        elif k=="arrow":
            d="M "+" L ".join(f"{x},{y}" for x,y in s["pts"]); dash=' stroke-dasharray="9 6"' if s["dashed"] else ""
            mk={"#846358":"ahb","#1971c2":"ahc"}.get(s["stroke"],"ah"); end=f' marker-end="url(#{mk})"' if s["head_end"] else ""
            o.append(f'<path d="{d}" fill="none" stroke="{s["stroke"]}" stroke-width="{s["sw"]}"{dash}{end}/>')
        elif k=="text":
            anc={"center":"middle","left":"start"}[s["align"]]; ls=s["t"].split("\n"); n=len(ls)
            for i,ln in enumerate(ls):
                yy=s["cy"]-(n-1)*s["size"]*0.6+i*s["size"]*1.2+s["size"]*0.35
                o.append(f'<text x="{s["cx"]}" y="{yy}" font-size="{s["size"]}" fill="{s["color"]}" text-anchor="{anc}">{html.escape(ln)}</text>')
    o.append("</svg>"); return "\n".join(o)

if __name__=="__main__":
    import sys
    d=sys.argv[1] if len(sys.argv)>1 else "."
    json.dump(to_excalidraw(), open(d+"/ocr_reconstruction_two_stage_model_architecture.excalidraw","w",encoding="utf-8"), indent=2)
    open(d+"/preview_twostage.svg","w",encoding="utf-8").write(to_svg())
    print("wrote two-stage excalidraw + preview;  #elements =", len(shapes))
