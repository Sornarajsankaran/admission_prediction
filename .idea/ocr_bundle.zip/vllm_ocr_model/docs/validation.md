# Validation

## 1. Test setup (no trained weights were available)

The trained checkpoints live on another machine, so everything here used a **stand-in
checkpoint** built by `serving/build_checkpoint.py` in the development repo
(`ocr_text_reconstruction/`, not shipped with this package):
- the real pretrained Heron RT-DETR encoder;
- randomly initialised order and formatter decoders, adjusted to behave like a trained
  model where it matters for serving:
  - the pointer key projection and formatter head are scaled up until the median top-2
    logit gap is 3 nats. Fresh random decoders are nearly flat, and every fp rounding
    would flip their argmax;
  - the EMIT_NEXT bias is calibrated to ~2.5 formatter tokens per box, and EOS is biased
    so decoding stops once all blocks are placed. This gives realistic decode lengths.

Test pages came from 12 public PDFs (arXiv papers, IRS forms/instructions, Census and
Federal Reserve reports):
- for model tests, 600 pages OCR'd with RapidOCR (PP-OCRv6, line-level boxes);
- for runner tests, a Textract-layout dataframe built from the PDFs' text layers
  (`tools/pdf_text_to_ocr_df.py`).

**What this can and cannot show:** it validates that the port computes *the same
function* as the PyTorch model, and how fast. It cannot show output quality, or how bf16
affects the trained model's decisions. Those need the real checkpoint (§5).

## 2. Model parity with the PyTorch reference

Method: the same weights in both implementations, compared token for token, with the
reference being `OcrTwoStageModel.generate_end_to_end` (greedy).

**Strict mode** (`OCR_VLLM_STRICT_FP32=1`, fp32, TF32 off everywhere, batch size 1, no
channels-last/compile, 12 dense pages with 200–400 lines):

| Stage of development | Order exact | Formatter exact |
|---|---:|---:|
| After each major refactor (pointer kernel, state kernels, GAP alignment, box_store) | 12/12 | 12/12 |
| Final code (stacked batched-GEMM decoders) | 11/12 | 12/12 |

The single mismatch diverges at step 147 of 389, where the reference's top two
candidates differ by **0.0004 nats on logits of about 1,000** (4 × 10⁻⁷ relative). That is
floating-point summation order in the stacked matmuls and layer norm, not logic; the
stand-in checkpoint's ×890 logit scaling magnifies such ties. Every divergence found
during development was checked the same way, by teacher-forcing the vLLM sequence
through the reference and measuring the reference's own margin at the divergent step.
All were near-ties.

**Default mode** (bf16 or fp32 with TF32, batched): the outputs diverge more, *and so do
the reference's own outputs* between its fp32 and bf16 runs (64 pages; edit similarity,
1.0 = identical; measured mid-development, after the GAP-alignment step):

| Compared with reference fp32 | Order exact | Order similarity | Formatter similarity |
|---|---:|---:|---:|
| Reference bf16 autocast | 0% | 0.13 | 0.89 |
| vLLM fp32 (batched) | 14% | 0.89 | 0.996 |
| vLLM bf16 | 0% | 0.11 | 0.85 |

The bf16 drift is the same size in both implementations, so it comes from the
stand-in model's sensitivity, not from the port. A trained model with learned margins
should drift far less. **This must be re-measured with the trained checkpoint.**

## 3. Markdown decoding

`MarkdownDecoder` (`decode.py`) re-implements the training tokenizer's
`CustomTokenizer.decode`. Checked on real model outputs: token ids saved with
`--save-tokens --save-order`, converted to the tokenizer's global id scheme and decoded by
both: **2,796 / 2,796 pages identical**. Unit tests cover EMIT placement in reading order
and colspan/rowspan folding.

## 4. The runner and the package

| Test | Result |
|---|---|
| CPU unit tests (`tests/test_inputs.py`: `line_cords` reordering, clipping, tab handling, statuses, duplicate rows, render bounds, decoding) | 8 passed; they also run during `docker build` |
| A fresh venv installed exactly like the image (vllm 0.23.0 → `requirements.txt` → package, no-deps) | tests pass; package assets present |
| End to end, 738 rows (12 PDFs), offline, cold cache | 699 ok, 39 skipped with statuses, exit 0 |
| End to end, 5,904 rows (distinct pages), 4 engines + MPS | 5,592 ok, 312 skipped, exit 0, no CPU throttling, ~60–70 pages/s steady state |
| Self-test flow (text-layer df → 1 engine → summary check), 20 pages | 20/20 ok |
| Makefile | `make -n` expands to the intended `docker build` / `docker run` commands and mounts |

Bugs found and fixed by these runs:
- engine processes must not be daemonic, because vLLM spawns its own engine-core process;
- exit could hang on undelivered queue items;
- a stale MPS pipe was mistaken for a live daemon;
- negative page indices wrapped to the last page;
- duplicate rows overwrote each other's markdown.

**Not tested: the Docker image itself.** The development machine is an unprivileged
container, and `dockerd` there fails with `unshare: operation not permitted`. Instead, the
base image's config and build history were read from the registry: system Python 3.12,
packages installed with `uv pip install --system`, `NVIDIA_DRIVER_CAPABILITIES` already
`compute,utility`, entrypoint `vllm serve` (replaced). `make selftest` is the first real
test of the Docker build, GPU passthrough and MPS inside the container.

## 5. Checklist with the trained checkpoint

1. `make selftest PDF_DIR=<a few PDFs> MODEL=<checkpoint>`: the plumbing works on the host.
2. Run a few hundred real pages (with real Textract output) with `--dtype float32` and with
   the default bf16. Compare `results.parquet` markdown, e.g. edit similarity per page,
   and read a sample of the differences. If bf16 changes decisions noticeably, run with
   `--dtype float32` (slower; see [performance.md](performance.md)).
3. Compare against the PyTorch pipeline on the same pages. The quickest route is the
   reference's `generate_end_to_end` over a small batch, then decoding with
   `CustomTokenizer.decode`. Expect identical output except at near-ties.
4. Check skip statuses in `summary.json`. Many `line_box_mismatch` rows mean the export
   and the assumed format disagree (see [usage.md](usage.md) §4.2).
5. Check `pages_per_s_all_engines` on a few thousand pages to confirm throughput on that
   GPU and CPU budget.
