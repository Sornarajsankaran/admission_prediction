"""vLLM engine construction and request / response helpers."""

from __future__ import annotations

import numpy as np
import torch

from .config import OcrTwoStageConfig


def make_llm(model_dir: str, *, max_num_seqs: int = 160, gpu_memory_utilization: float = 0.21,
             block_size: int = 32, max_num_batched_tokens: int = 32768, dtype: str | None = None,
             enforce_eager: bool = False, **kwargs):
    """Offline vLLM engine for a converted model directory (see convert.py)."""
    from vllm import LLM

    if dtype is None:
        # the model directory decides; vLLM's "auto" would downcast fp32 checkpoints
        cfg = OcrTwoStageConfig.from_pretrained(model_dir)
        dtype = str(getattr(cfg, "dtype", None) or cfg.torch_dtype).replace("torch.", "")
    return LLM(
        model=model_dir,
        skip_tokenizer_init=True,
        dtype=dtype,
        attention_backend="TRITON_ATTN",
        enable_prefix_caching=False,
        limit_mm_per_prompt={"image": 1},
        # pages arrive as {pixel_values, ocr_boxes} tensor dicts
        enable_mm_embeds=True,
        max_num_seqs=max_num_seqs,
        max_num_batched_tokens=max_num_batched_tokens,
        gpu_memory_utilization=gpu_memory_utilization,
        block_size=block_size,
        enforce_eager=enforce_eager,
        compilation_config=None if enforce_eager else {"cudagraph_mode": "FULL_DECODE_ONLY"},
        disable_log_stats=True,
        **kwargs,
    )


def page_request(pixels_u8, boxes, cfg: OcrTwoStageConfig) -> dict:
    """pixels_u8: (3, 640, 640) uint8 (Heron-preprocessed page); boxes: (K, 4) xyxy in [0, 1]."""
    pixels = torch.as_tensor(np.ascontiguousarray(pixels_u8))
    boxes = torch.as_tensor(np.asarray(boxes, np.float32)).reshape(1, -1, 4)
    k = boxes.shape[1]
    if not 0 < k <= cfg.max_boxes:
        raise ValueError(f"page has {k} boxes; supported range is 1..{cfg.max_boxes}")
    return {
        "prompt_token_ids": [cfg.ord_bos_id],
        "multi_modal_data": {"image": {"pixel_values": pixels.reshape(1, 3, *pixels.shape[-2:]),
                                       "ocr_boxes": boxes}},
    }


def sampling_params(cfg: OcrTwoStageConfig, num_boxes: int):
    """Greedy; the stream is K+1 order tokens, < 64 GAP tokens, then formatter tokens."""
    from vllm import SamplingParams
    from vllm.sampling_params import RequestOutputKind

    return SamplingParams(temperature=0.0, max_tokens=num_boxes + 64 + 1 + cfg.max_format_tokens,
                          stop_token_ids=[cfg.eos_token_id], detokenize=False,
                          output_kind=RequestOutputKind.FINAL_ONLY)


def split_output(token_ids, cfg: OcrTwoStageConfig):
    """Generated ids -> (reading order as box indices, formatter ids in the model-compact
    scheme: specials [0, M) and EMIT_NEXT = M, ending with EOS unless capped)."""
    ids = [t for t in token_ids if t != cfg.gap_id]
    if cfg.fmt_bos_id in ids:
        cut = ids.index(cfg.fmt_bos_id)
        order_ids, fmt = ids[:cut], ids[cut + 1:]
    else:
        order_ids, fmt = ids, []
    return [t - cfg.box0_id for t in order_ids], fmt
