# Exact document caching for masked ModernBERT

## Scope and assumptions

The public checkpoint is a masked-language model, not the user's fine-tuned ranker. Its configuration has 22 layers, hidden width 768, 12 attention heads, head width 64, 1152 intermediate units, global attention every third layer, a 128-token local window, and `classifier_pooling="mean"`. The global and local rotary bases differ. A deterministic classification head enables performance comparisons, not validation of the user's trained ranking quality. Preserve the trained pooling operation and mask; introducing CLS pooling is a separately labelled change if that is not what was trained.

Configuration source: https://huggingface.co/thomas-sounack/BioClinical-ModernBERT-base/blob/main/config.json

Implementation reference: https://github.com/huggingface/transformers/blob/main/src/transformers/models/modernbert/modeling_modernbert.py

## Exactness argument

Let `d_l` be all document hidden states entering layer `l`, and `u_l^(r)` the query hidden states for query `r`. With document-to-query attention prohibited in every layer, the document recurrence is `d_(l+1)=F_l(d_l)`. Layer normalization and the feed-forward network act independently on tokens. Therefore document keys and values `K_l^d,V_l^d` depend on document tokens and model parameters only. They can be reused by every query, provided tokenization, positional semantics, local masks, weights and precision match. Cache layer-input projected keys and values, not the final document embedding; each layer requires its own keys and values.

The query recurrence remains a cross encoder: each query token attends to its own query plus the document at each applicable layer. Query states become document-dependent after layer zero and cannot generally be shared across different documents. Different queries must not attend to each other. Putting all 50 queries into one ordinary bidirectional sequence silently changes the model.

The exact allowed-edge mask is the original layer mask intersected with `not(document_receiver and query_sender)`. If the user's training instead replaced every local mask with a global asymmetric mask, that is a different model and must be benchmarked separately.

## One coordinate system removes query-length-dependent cache keys

For a query segment of true length `q`, conventional positions are `query: 0..q-1`, `document: q..q+d-1`. Shift *both* segments by `-q`: `query: -q..-1`, `document: 0..d-1`. RoPE dot products depend on position differences, so this shift preserves attention scores mathematically. Use the layer's own rotary base. Local attention also depends only on position differences and is unchanged. This gives every document a reusable rotary-encoded key at the same coordinate, regardless of query length.

Negative positions are legitimate inputs to cosine/sine but may not be accepted by an existing position-cache indexing API. Compute the trigonometric factors or extend the cache explicitly; do not accidentally use Python's negative indexing into an ordinary positive-position table. RoPE invariance is mathematical, with small finite-precision deviations possible. This reasoning assumes standard RoPE, no absolute learned position embedding and no sequence-length-dependent rotary scaling. Verify the concrete executor rather than interpreting the stale config string `position_embedding_type="absolute"` literally.

For ragged/padded queries, each real query token `i` has position `i-q_r`, and only `i<q_r` is valid. A padded bucket size must not substitute for `q_r`. Tag and separator token ownership must be specified consistently: every query-specific token belongs to the query segment; cached document tokens include all invariant document tags/separators that the baseline uses.

## Local attention detail

A local ModernBERT layer with `local_attention=128` allows distance at most 64 in the referenced implementation. For query token `i` at position `i-q`, a document token `j` is visible iff `abs(j-(i-q))<=64`. Thus only the early document region is directly accessible from query tokens in local layers, while global layers provide unrestricted query-to-document paths. With queries shorter than 64 tokens all query-to-query edges are local-valid, but this shortcut must not be used for longer queries. Check the installed executor for inclusive window convention before comparing kernels.

## Memory and scheduling

Full BF16 per-layer document KV costs `layers * 2 * document_tokens * hidden_size * 2` bytes. At 22 layers, 256 tokens and hidden width 768 this is 17,301,504 bytes = 16.5 MiB per document, 80.57 GiB for 5000 chunks, before model, queries and temporary buffers. Tags/separators increase the figure. Keeping all full caches for even one MR does not fit a 48 GB L40S. Because query coordinates are always negative, local layers need only document positions 0..63 in the reusable query cache. The 8 global and 14 local layers then require `(8*d+14*64)*768*2*2` bytes per document: 8.625 MiB at d=256, or 42.11 GiB for 5000 documents. This is still tight on the GPU after weights, activations and graph pools; tiling is preferable.

Process a block of documents and all 50 associated queries, then discard those documents' KV. This yields the same computational reuse without requiring the complete MR cache. There are two exact schedules:

1. **Persistent block cache:** run document-only inference, save each layer's KV for the block, run batched queries against it, then free/reuse the block. Useful for independently arriving queries; measure cache construction and lookup separately and combined.
2. **Layerwise shared-document execution:** hold the block's document states and all query states. For each layer compute document KV once, query projections for all queries, run independent query-to-query-and-document attention, update the document once and queries individually, then release that layer's KV. This is the preferable throughput schedule when all 50 queries are already known. It avoids all-layers cache memory and can combine document and query token projections into large GEMMs while retaining separate attention masks.

Do not mistake an already-warm cache benchmark for MR completion throughput. Report both `query evaluations / query seconds` and `query evaluations / (document preparation + query seconds)` and include host/tokenization scheduling overhead in an explicit end-to-end measurement. Query-document evaluations per second is an unambiguous unit; unique document chunks per second is that number divided by the query count.

## Packed-query attention strategies

A naive implementation repeats document KV 50 times and concatenates each query's KV with the document. It is correct but creates unnecessary reads, writes and memory allocations. A segmented shared-document kernel instead reads query-specific K/V and shared document K/V directly; query group id determines the private query block and document id determines the shared block. A single softmax must span both sources. Computing query and document softmaxes separately and adding outputs is incorrect unless log-sum-exp normalization is used to combine them.

A practical Triton layout uses query tensors `[documents,queries,query_tokens,heads,head_dim]` and document tensors `[documents,document_tokens,heads,head_dim]`. Each program handles one document, query, head and block of query rows. It loops over its private query keys and shared document keys with online softmax. It avoids replicated KV and supports the exact local window. Different programs still read the same document KV; L2 reuse helps, but a more elaborate kernel could process several query groups per program to improve reuse at possible occupancy cost.

Other experiments worth measuring:

- Sweep document block size and query grouping size; large enough GEMMs matter more than minimizing each tensor.
- BF16 FlashAttention/SDPA baseline with actual prompt lengths, not an unfused eager baseline only.
- CUDA graph capture for stable shapes; include a streaming multi-block run to expose host launch overhead.
- Compile pointwise rotary, normalization and GELU-gating paths; avoid recompilation in timing.
- Remove needless token expansion and CPU/GPU copies, pretokenize once, and bucket real lengths.
- Fuse document and query linear/MLP operations layerwise if separate small document GEMMs underutilize the GPU.
- FP8 cache or projection quantization only as a separate approximation with its own accuracy comparison.

## Last layer and pooling

For CLS pooling, the last layer needs output attention, output projection, MLP and final norm only for the CLS receiver. It still needs keys and values from **all** final-layer query inputs and document inputs. Since the final layer has no later consumers, unused last-layer document outputs can also be skipped. Preserve the query-side final residual at CLS. This is exact when the classification head consumes only CLS; it is not an exact optimization for mean pooling.

For mean pooling, compute every query output. The document's final normalized output sum and token count are cacheable, so the mean can be assembled as `(sum(query_final) + sum(document_final)) / (q + d)`. Include the original attention mask in the denominator and apply the head **after** forming the mean, as the original model does. Summing post-head outputs would generally be wrong.

## Validation needed before throughput claims

Validate the custom full-attention baseline against the installed HF/vLLM model; validate cached execution against the full asymmetric-mask reference, not against the original bidirectional model. Include variable query lengths, nonzero document offsets, local boundaries at distance 64/65, masked padding, several document lengths and both global/local layers. Compare FP32 for semantic errors and BF16 with numerical tolerances for kernel arithmetic differences. Comparing synthetic random-head scores alone does not establish downstream medical ranking quality.

Estimate the projection/MLP token-work speedup ceiling as `R*(q+d)/(d+R*q)`. With `R=50,d=256,q=40` this is 6.56x. Attention, cache traffic, different kernels and launch overhead change the actual result. The true maximum is hardware/workload dependent; the experiments establish the best measured configuration, not an absolute maximum.
