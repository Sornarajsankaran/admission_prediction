"""
Shared helpers for the serving work: model construction, test-page loading.

The reference model is ``scripts_v0.1.modeling_ocr_reconstruction.OcrTwoStageModel``.
No trained checkpoint is available here, so we build one with:

  * the pretrained Heron RT-DETR-v2 encoder (real weights -> real encoder cost), and
  * randomly initialised order / markdown decoders.

Random decoders decode for exactly K order steps (the pointer mask forces a full
permutation) but the formatter's length is arbitrary: EOS is masked until K
EMIT_NEXTs are placed, and with random logits EMIT_NEXT wins about 1/69 of steps,
so every page would run to ``max_new_tokens``. ``calibrate_emit_bias`` fixes that by
biasing the EMIT_NEXT logit until greedy decoding places a block about every
``tokens_per_block`` tokens, which gives realistic formatter lengths (~K * 2.5). The
calibrated weights are saved once and shared by every backend, so all backends
decode the same token sequences and can be checked against each other.
"""

from __future__ import annotations

import os
import sys
from pathlib import Path

import numpy as np
import torch

REPO = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(REPO / "scripts_v0.1"))

from modeling_ocr_reconstruction import OcrReconstructionConfig, OcrTwoStageModel  # noqa: E402

os.environ.setdefault("HF_HOME", "/workspace/models/hf")

HERON = "docling-project/docling-layout-heron"
DEFAULT_CKPT = Path("/workspace/models/ocr_twostage_random/model.pt")
DEFAULT_PAGES = Path("/workspace/datasets/ocr_bench/test_pages.parquet")
PDF_DIR = Path("/workspace/datasets/ocr_bench/pdfs")


def build_random_model(seed: int = 0) -> OcrTwoStageModel:
    torch.manual_seed(seed)
    cfg = OcrReconstructionConfig(backbone_name_or_path=HERON)
    return OcrTwoStageModel(cfg)


def save_checkpoint(model: OcrTwoStageModel, path: Path = DEFAULT_CKPT, **meta) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    torch.save({"state_dict": model.state_dict(), "config": vars(model.config), "meta": meta}, path)


def load_model(path: Path = DEFAULT_CKPT, device: str = "cuda") -> OcrTwoStageModel:
    ckpt = torch.load(path, map_location="cpu", weights_only=False)
    model = OcrTwoStageModel(OcrReconstructionConfig(**ckpt["config"]))
    model.load_state_dict(ckpt["state_dict"])
    return model.to(device).eval()


# --------------------------------------------------------------------------- #
# Test pages
# --------------------------------------------------------------------------- #
def load_pages(path: Path = DEFAULT_PAGES, min_boxes: int = 1, max_boxes: int | None = None):
    """Parquet rows from ``build_test_set.py`` -> list of dicts with (N, 4) boxes."""
    import pandas as pd

    df = pd.read_parquet(path)
    df = df[df["num_boxes"] >= min_boxes]
    if max_boxes is not None:
        df = df[df["num_boxes"] <= max_boxes]
    pages = []
    for row in df.itertuples():
        pages.append({
            "file_name": row.file_name,
            "page": int(row.page),
            "boxes": np.asarray(row.ocr_bbox, np.float32).reshape(-1, 4),
            "texts": list(row.ocr_text),
        })
    return pages


def rasterize(file_name: str, page: int, zoom: float = 2.0, pdf_dir: Path = PDF_DIR):
    """Same rasterization as training (data.rasterize_page) -> PIL RGB image."""
    import pymupdf
    from PIL import Image

    with pymupdf.open(pdf_dir / file_name) as doc:
        pix = doc[page - 1].get_pixmap(matrix=pymupdf.Matrix(zoom, zoom), alpha=False)
        return Image.frombytes("RGB", (pix.width, pix.height), pix.samples)


def load_image_processor():
    from transformers import AutoImageProcessor

    return AutoImageProcessor.from_pretrained(HERON, use_fast=True)


def attach_pixels(pages, processor=None, zoom: float = 2.0):
    """Rasterize + preprocess every page once (kept out of the timed region)."""
    processor = processor or load_image_processor()
    for p in pages:
        img = rasterize(p["file_name"], p["page"], zoom)
        p["pixel_values"] = processor(images=img, return_tensors="pt")["pixel_values"][0]
    return pages


def collate(pages, device="cuda"):
    """Pad a list of pages into the batch tensors ``generate_end_to_end`` expects."""
    B = len(pages)
    K = max(len(p["boxes"]) for p in pages)
    boxes = torch.zeros(B, K, 4)
    mask = torch.zeros(B, K, dtype=torch.bool)
    for i, p in enumerate(pages):
        k = len(p["boxes"])
        boxes[i, :k] = torch.from_numpy(p["boxes"])
        mask[i, :k] = True
    pixels = torch.stack([p["pixel_values"] for p in pages])
    return pixels.to(device), boxes.to(device), mask.to(device)


# --------------------------------------------------------------------------- #
# Output-length calibration for random decoders
# --------------------------------------------------------------------------- #
@torch.no_grad()
def predicted_orders(model: OcrTwoStageModel, pages) -> list[torch.Tensor]:
    """The order decoder's own greedy order for each page (what the formatter sees
    at inference)."""
    out = []
    for p in pages:
        pixels, boxes, mask = collate([p])
        order, _ = model.order.generate_order(pixels, boxes, box_mask=mask)
        out.append(order[0])
    return out


@torch.no_grad()
def formatter_emit_rate(model: OcrTwoStageModel, pages, orders, max_new_tokens: int = 2047) -> float:
    """Blocks placed per formatter token under greedy decoding, given each page's order."""
    fmt = model.formatter
    emits = total = 0
    for i in range(0, len(pages), 8):
        pixels, boxes, mask = collate(pages[i:i + 8])
        order = torch.zeros(boxes.shape[:2], dtype=torch.long, device=boxes.device)
        for j, o in enumerate(orders[i:i + 8]):
            order[j, : len(o)] = o
        seq = fmt.generate_markdown(pixels, boxes, order, box_mask=mask, max_new_tokens=max_new_tokens)
        body = seq[:, 1:]
        emits += int((body == fmt.emit_next_id).sum())
        total += int((body != fmt.config.pad_token_id).sum())
    return emits / max(total, 1)


@torch.no_grad()
def calibrate_emit_bias(model: OcrTwoStageModel, pages, tokens_per_block: float = 2.5,
                        iters: int = 14, lo: float = -5.0, hi: float = 10.0) -> float:
    """Bisect ``formatter.head.bias[EMIT_NEXT]`` so greedy end-to-end decoding emits one
    block per ``tokens_per_block`` formatter tokens on ``pages``. Returns the offset."""
    head = model.formatter.head
    emit = model.formatter.emit_next_id
    orders = predicted_orders(model, pages)
    target = 1.0 / tokens_per_block
    base = head.bias[emit].item()
    for _ in range(iters):
        mid = (lo + hi) / 2
        head.bias[emit] = base + mid
        rate = formatter_emit_rate(model, pages, orders)
        print(f"  emit bias {mid:+.3f} -> {1 / max(rate, 1e-9):.2f} tokens/block")
        if rate < target:
            lo = mid
        else:
            hi = mid
    head.bias[emit] = base + (lo + hi) / 2
    return (lo + hi) / 2
