"""Measured cached-ModernBERT experiments; usable inside LLM.apply_model."""
import argparse
import json
import os
import statistics
import time
from pathlib import Path
import torch
from cached_model import CachedModernBert

ROOT=Path(__file__).resolve().parent


def timed(fn, repeats=5, iters=1):
    gpu=[]; wall=[]
    for _ in range(repeats):
        torch.cuda.synchronize()
        a,b=torch.cuda.Event(enable_timing=True),torch.cuda.Event(enable_timing=True)
        t=time.perf_counter();a.record()
        for _ in range(iters):
            out=fn()
        b.record();b.synchronize()
        wall.append((time.perf_counter()-t)/iters)
        gpu.append(a.elapsed_time(b)/1000/iters)
    return {"seconds":statistics.median(wall),"gpu_seconds":statistics.median(gpu),
            "wall_samples_s":wall,"gpu_samples_s":gpu},out


def make_graph(fn):
    stream=torch.cuda.Stream()
    stream.wait_stream(torch.cuda.current_stream())
    with torch.cuda.stream(stream):
        for _ in range(3): out=fn()
    torch.cuda.current_stream().wait_stream(stream)
    graph=torch.cuda.CUDAGraph()
    with torch.cuda.graph(graph):
        out=fn()
    def replay():
        graph.replay()
        return out
    return replay,graph


@torch.inference_mode()
def benchmark(model,args):
    torch.set_num_threads(8)
    torch.backends.cuda.matmul.allow_tf32=True
    data=torch.load(ROOT/"data/tokenized.pt",weights_only=True)
    qlen=data["query_lengths"][:args.queries].cuda()
    qwidth=args.qwidth or int(qlen.max())
    qids=data["query_input_ids"][:args.queries,:qwidth].cuda()
    dids=data["doc_input_ids"][:args.tile].cuda()
    dlen=data["doc_lengths"][:args.tile].cuda()
    if args.doc_backend=="flash" and not bool((dlen==dids.shape[1]).all()):
        raise ValueError("Flash document path requires equal unpadded lengths")
    runner=CachedModernBert(model,backend=args.backend,compile_parts=args.compile_parts,
        trim_local=not args.no_trim_local,last_cls=not args.no_last_cls,doc_backend=args.doc_backend)
    meta=runner.metadata(qids,qlen,dids,dlen)
    cache=None
    build_stats=None
    if args.mode=="hot":
        cache=runner.build_cache(dids,meta)
        build_stats,_=timed(lambda:runner.build_cache(dids,meta),3)
        fn=lambda:runner.query_cached(qids,cache,meta)
    elif args.mode=="cache":
        def fn():
            c=runner.build_cache(dids,meta)
            return runner.query_cached(qids,c,meta)
    elif args.mode=="joint":
        runner.prepare_joint_metadata(meta)
        fn=lambda:runner.stream_joint(qids,dids,meta)
    else:
        fn=lambda:runner.stream(qids,dids,meta)
    t=time.perf_counter()
    for _ in range(3): fn()
    torch.cuda.synchronize()
    warm_s=time.perf_counter()-t
    graph=None
    if args.graph:
        fn,graph=make_graph(fn)
    torch.cuda.reset_peak_memory_stats()
    result,out=timed(fn,args.repeats,args.iters)
    result.update({"dtype":str(model.classifier.weight.dtype),"mode":args.mode,"backend":args.backend,"doc_backend":args.doc_backend,
        "tile":args.tile,"queries":args.queries,"query_width":qwidth,"doc_width":dids.shape[1],
        "compile_parts":args.compile_parts,"cuda_graph":args.graph,
        "trim_local":not args.no_trim_local,"last_cls":not args.no_last_cls,
        "warmup_seconds":warm_s,"pairs_per_second":args.tile*args.queries/result["seconds"],
        "peak_allocated_gib":torch.cuda.max_memory_allocated()/2**30,
        "peak_reserved_gib":torch.cuda.max_memory_reserved()/2**30,
        "sample_logits":out[:2,:5].float().cpu().tolist(),"build_cache":build_stats,
        "executor":getattr(args,"executor","huggingface_weights_custom_executor")})
    if args.full_docs:
        if args.mode=="hot":
            raise ValueError("hot cache timing cannot represent unseen documents; use cache or stream")
        # Include CPU->GPU token transfers and GPU->CPU score transfers. Handle
        # final short tile by masked duplicate padding, discard duplicate scores.
        source=data["doc_input_ids"][:args.full_docs].pin_memory()
        scores=torch.empty(args.full_docs,args.queries,dtype=torch.float32,pin_memory=True)
        torch.cuda.synchronize(); start=time.perf_counter()
        for i in range(0,args.full_docs,args.tile):
            n=min(args.tile,args.full_docs-i)
            dids[:n].copy_(source[i:i+n],non_blocking=True)
            out=fn()
            scores[i:i+n].copy_(out[:n],non_blocking=True)
        torch.cuda.synchronize(); elapsed=time.perf_counter()-start
        result["full_workload"]={"documents":args.full_docs,"pairs":args.full_docs*args.queries,
           "seconds":elapsed,"pairs_per_second":args.full_docs*args.queries/elapsed,
           "includes":"token H2D, document encoding/cache, all query layers, classifier, score D2H",
           "excludes":"model load, warmup/compile/capture, dataset generation/tokenization",
           "score_checksum":scores.double().sum().item(),"finite":bool(scores.isfinite().all())}
        if getattr(args,"save_scores",None):
            torch.save(scores.cpu(),args.save_scores)
    return result


def parser():
    p=argparse.ArgumentParser()
    p.add_argument("--model",default=str(ROOT/"models/benchmark-cls"))
    p.add_argument("--dtype", choices=["bfloat16","float16"], default="bfloat16")
    p.add_argument("--mode",choices=["stream","joint","cache","hot"],default="stream")
    p.add_argument("--backend",choices=["triton","sdpa"],default="triton")
    p.add_argument("--doc-backend",choices=["flash","sdpa"],default="flash")
    p.add_argument("--tile",type=int,default=8)
    p.add_argument("--queries",type=int,default=50)
    p.add_argument("--qwidth",type=int,default=0)
    p.add_argument("--compile-parts",action="store_true")
    p.add_argument("--graph",action="store_true")
    p.add_argument("--no-trim-local",action="store_true")
    p.add_argument("--no-last-cls",action="store_true")
    p.add_argument("--repeats",type=int,default=5)
    p.add_argument("--iters",type=int,default=1)
    p.add_argument("--full-docs",type=int,default=0)
    p.add_argument("--output",default=str(ROOT/"results/cached.jsonl"))
    p.add_argument("--save-scores")
    return p


def main():
    args=parser().parse_args()
    from transformers import AutoModelForSequenceClassification
    model=AutoModelForSequenceClassification.from_pretrained(args.model,dtype=getattr(torch,args.dtype),
            attn_implementation="sdpa").cuda().eval()
    result=benchmark(model,args)
    with open(args.output,"a") as f: f.write(json.dumps(result)+"\n")
    print(json.dumps(result,indent=2))

if __name__=="__main__": main()
