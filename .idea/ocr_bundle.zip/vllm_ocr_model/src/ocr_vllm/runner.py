"""
ocr-vllm-run: PDFs + Textract OCR dataframe -> markdown, at full GPU throughput.
===============================================================================

Process layout (all started here; spawn start method):

  preprocess workers (CPU, --preprocess-workers)   PDF page -> Heron 640x640 uint8 image
          |  page queue (bounded)
  engine processes (GPU, --engines)                 one vLLM engine each, pages admitted in waves
          |  result queue
  main process                                      markdown files, results.jsonl, results.parquet

Several engines share the GPU through CUDA MPS (started here when --engines > 1): each
engine's host-side scheduling overhead is hidden behind the others' GPU work. Pages are
admitted to an engine ``--wave`` at a time because vLLM runs a step with CUDA graphs only
when no page in it is starting.
"""

from __future__ import annotations

import argparse
import json
import multiprocessing as mp
import os
import queue
import shutil
import subprocess
import sys
import threading
import time
import traceback
from collections import Counter
from pathlib import Path


def log(msg: str) -> None:
    print(f"[ocr-vllm {time.strftime('%H:%M:%S')}] {msg}", file=sys.stderr, flush=True)


def cpu_quota() -> float:
    """CPUs this container may use (cgroup quota), not the host's core count."""
    try:
        quota, period = Path("/sys/fs/cgroup/cpu.max").read_text().split()
        if quota != "max":
            return int(quota) / int(period)
    except (OSError, ValueError):
        pass
    try:
        return float(len(os.sched_getaffinity(0)))
    except AttributeError:
        return float(os.cpu_count() or 1)


# --------------------------------------------------------------------------- #
# CUDA MPS
# --------------------------------------------------------------------------- #
class MpsDaemon:
    """Starts nvidia-cuda-mps-control for this run (and stops it) unless one is running."""

    def __init__(self, pipe_dir="/tmp/nvidia-mps", log_dir="/tmp/nvidia-mps-log"):
        self.pipe_dir, self.log_dir = pipe_dir, log_dir
        self.started = False

    def start(self) -> bool:
        binary = shutil.which("nvidia-cuda-mps-control")
        if binary is None:
            log("WARNING: nvidia-cuda-mps-control not found; engines will time-slice the GPU "
                "(run the container with NVIDIA_DRIVER_CAPABILITIES=compute,utility)")
            return False
        os.makedirs(self.pipe_dir, exist_ok=True)
        os.makedirs(self.log_dir, exist_ok=True)
        os.environ["CUDA_MPS_PIPE_DIRECTORY"] = self.pipe_dir
        os.environ["CUDA_MPS_LOG_DIRECTORY"] = self.log_dir
        if Path(self.pipe_dir, "control").exists():
            # a live daemon answers on its pipe; a crashed/stopped one leaves stale files
            try:
                alive = subprocess.run([binary], input=b"get_server_list\n", env=os.environ,
                                       capture_output=True, timeout=10).returncode == 0
            except subprocess.TimeoutExpired:
                alive = False
            if alive:
                log("CUDA MPS already running; reusing it")
                return True
            for f in Path(self.pipe_dir).iterdir():
                f.unlink(missing_ok=True)
        rc = subprocess.run([binary, "-d"], env=os.environ).returncode
        if rc != 0:
            log(f"WARNING: could not start CUDA MPS (rc={rc}); engines will time-slice the GPU")
            os.environ.pop("CUDA_MPS_PIPE_DIRECTORY")
            os.environ.pop("CUDA_MPS_LOG_DIRECTORY")
            return False
        self.started = True
        log("CUDA MPS daemon started")
        return True

    def stop(self) -> None:
        if self.started:
            subprocess.run(["nvidia-cuda-mps-control"], input=b"quit\n", env=os.environ)
            self.started = False
            log("CUDA MPS daemon stopped")


# --------------------------------------------------------------------------- #
# Worker processes
# --------------------------------------------------------------------------- #
def preprocess_worker(job_q, page_q, result_q, zoom: float):
    from .inputs import PageRasterizer

    raster = PageRasterizer(zoom=zoom)
    while True:
        job = job_q.get()
        if job is None:
            return
        idx, pdf_path, page_index, boxes = job
        try:
            pixels = raster(pdf_path, page_index)
        except IndexError:
            result_q.put(("page", idx, "page_out_of_range", None, None, 0, None))
            continue
        except Exception as e:                                          # noqa: BLE001
            result_q.put(("page", idx, "render_error", None, None, 0, repr(e)))
            continue
        page_q.put((idx, pixels, boxes))


def engine_worker(eid: int, model_dir: str, opts: dict, page_q, result_q, prev_ready, ready):
    try:
        if prev_ready is not None:
            prev_ready.wait()                  # start engines one at a time (memory profiling)
        from .config import OcrTwoStageConfig
        from .engine import make_llm, page_request, sampling_params, split_output

        cfg = OcrTwoStageConfig.from_pretrained(model_dir)
        llm = make_llm(model_dir, max_num_seqs=opts["max_seqs"], block_size=opts["block_size"],
                       gpu_memory_utilization=opts["gpu_mem"], dtype=opts["dtype"])
        engine = llm.llm_engine
    except Exception:                                                   # noqa: BLE001
        result_q.put(("engine_error", eid, traceback.format_exc()))
        if ready is not None:
            ready.set()
        return
    result_q.put(("ready", eid))
    if ready is not None:
        ready.set()

    max_seqs, wave = opts["max_seqs"], opts["wave"]
    in_flight: set[str] = set()
    input_done = False
    while True:
        free = max_seqs - len(in_flight)
        if not input_done and (not in_flight or free >= wave):
            added = 0
            while added < free:
                try:
                    item = page_q.get(block=(not in_flight and added == 0), timeout=1.0)
                except queue.Empty:
                    break
                if item is None:
                    input_done = True
                    break
                idx, pixels, boxes = item
                rid = str(idx)
                try:
                    engine.add_request(rid, page_request(pixels, boxes, cfg),
                                       sampling_params(cfg, len(boxes)))
                except Exception as e:                                  # noqa: BLE001
                    result_q.put(("page", idx, "engine_error", None, None, 0, repr(e)))
                    continue
                in_flight.add(rid)
                added += 1
        if not in_flight:
            if input_done:
                break
            continue
        for out in engine.step():
            if out.finished:
                in_flight.discard(out.request_id)
                ids = list(out.outputs[0].token_ids)
                order, fmt = split_output(ids, cfg)
                result_q.put(("page", int(out.request_id), "ok", order, fmt, len(ids), None))
    result_q.put(("engine_done", eid))


# --------------------------------------------------------------------------- #
# Main
# --------------------------------------------------------------------------- #
def resolve_model(a) -> str:
    from .convert import cached_convert, is_model_dir

    if a.model and is_model_dir(a.model):
        return a.model
    t = time.time()
    out = cached_convert(a.cache_dir, model=a.model, order=a.order_ckpt, formatter=a.formatter_ckpt,
                         encoder_from=a.encoder_from, dtype=a.dtype, decoder_heads=a.decoder_heads,
                         max_boxes=a.max_boxes)
    log(f"model ready: {out} ({time.time() - t:.1f}s)")
    return str(out)


def parse_args(argv=None):
    ap = argparse.ArgumentParser(prog="ocr-vllm-run", description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    io = ap.add_argument_group("inputs / outputs")
    io.add_argument("--pdf-dir", required=True, help="directory with the PDFs (searched recursively)")
    io.add_argument("--ocr-df", required=True,
                    help="Textract OCR dataframe (.parquet/.pkl/.csv/.jsonl) with columns "
                         "file_name, page, content, line_cords")
    io.add_argument("--out-dir", required=True, help="where markdown + results are written")
    io.add_argument("--page-base", type=int, default=1, choices=[0, 1],
                    help="numbering of the dataframe's page column (default 1-based)")
    io.add_argument("--save-order", action="store_true",
                    help="also store each page's predicted reading order in results.jsonl")
    io.add_argument("--save-tokens", action="store_true",
                    help="also store each page's raw formatter token ids in results.jsonl")
    io.add_argument("--limit", type=int, default=None, help="only the first N dataframe rows")

    m = ap.add_argument_group("model")
    m.add_argument("--model", help="combined two-stage checkpoint (stage 3), or a converted model dir")
    m.add_argument("--order-ckpt", help="order-model checkpoint (with --formatter-ckpt)")
    m.add_argument("--formatter-ckpt", help="formatter checkpoint, e.g. the GRPO stage-4 best.pt")
    m.add_argument("--encoder-from", choices=["order", "formatter"], default="order",
                   help="which checkpoint supplies the shared RT-DETR encoder")
    m.add_argument("--dtype", choices=["bfloat16", "float32"], default="bfloat16")
    m.add_argument("--decoder-heads", type=int, default=8)
    m.add_argument("--max-boxes", type=int, default=1024, help="pages with more OCR lines are skipped")
    m.add_argument("--cache-dir", default=os.environ.get("OCR_VLLM_CACHE", "/cache"),
                   help="converted model + compile caches")

    r = ap.add_argument_group("throughput (defaults: tuned on 1x L40S 48GB)")
    r.add_argument("--engines", type=int, default=4, help="vLLM engines sharing the GPU")
    r.add_argument("--max-seqs", type=int, default=160, help="pages in flight per engine")
    r.add_argument("--wave", type=int, default=40, help="pages admitted to an engine at a time")
    r.add_argument("--block-size", type=int, default=32, help="KV cache block size")
    r.add_argument("--gpu-memory", type=float, default=0.86, help="GPU memory fraction, all engines")
    r.add_argument("--preprocess-workers", type=int, default=0,
                   help="PDF rasterization processes (0 = from the CPU quota)")
    r.add_argument("--raster-zoom", type=float, default=2.0, help="PDF render scale (training: 2.0)")
    r.add_argument("--mps", choices=["auto", "on", "off"], default="auto")
    a = ap.parse_args(argv)
    if not (a.model or (a.order_ckpt and a.formatter_ckpt)):
        ap.error("give --model, or --order-ckpt and --formatter-ckpt")
    return a


def main(argv=None) -> int:
    a = parse_args(argv)
    out_dir = Path(a.out_dir)
    (out_dir / "markdown").mkdir(parents=True, exist_ok=True)
    os.environ.setdefault("TORCHINDUCTOR_CACHE_DIR", str(Path(a.cache_dir) / "inductor"))
    os.environ.setdefault("VLLM_CACHE_ROOT", str(Path(a.cache_dir) / "vllm"))

    # ---- inputs ----
    from .decode import MarkdownDecoder
    from .inputs import build_jobs, read_ocr_df

    df = read_ocr_df(a.ocr_df)
    if a.limit:
        df = df.iloc[: a.limit]
    jobs = build_jobs(df, a.pdf_dir, a.max_boxes)
    todo = [j for j in jobs if j.status == "ok"]
    log(f"{len(jobs)} pages in the OCR dataframe; {len(todo)} to run "
        f"({dict(Counter(j.status for j in jobs if j.status != 'ok')) or 'no skips'})")

    model_dir = resolve_model(a)
    decoder = MarkdownDecoder()

    # ---- processes ----
    quota = cpu_quota()
    n_pre = a.preprocess_workers or max(2, min(8, int(quota) - 2 * a.engines - 1))
    log(f"CPU quota {quota:.1f} -> {n_pre} preprocess workers; {a.engines} engine(s)")
    mps = MpsDaemon()
    if a.mps == "on" or (a.mps == "auto" and a.engines > 1):
        mps.start()

    ctx = mp.get_context("spawn")
    job_q = ctx.Queue()
    page_q = ctx.Queue(maxsize=max(64, a.engines * a.wave * 2))
    result_q = ctx.Queue()
    opts = dict(max_seqs=a.max_seqs, wave=a.wave, block_size=a.block_size, dtype=a.dtype,
                gpu_mem=a.gpu_memory / a.engines)
    events = [ctx.Event() for _ in range(a.engines)]
    # not daemonic: each engine spawns vLLM's own engine-core process
    engines = [ctx.Process(target=engine_worker, name=f"engine{i}",
                           args=(i, model_dir, opts, page_q, result_q,
                                 events[i - 1] if i else None, events[i]))
               for i in range(a.engines)]
    pre = [ctx.Process(target=preprocess_worker, name=f"pre{i}", daemon=True,
                       args=(job_q, page_q, result_q, a.raster_zoom)) for i in range(n_pre)]
    for p in engines + pre:
        p.start()
    for j in todo:
        job_q.put((j.idx, j.pdf_path, j.page - a.page_base, j.boxes))
    for _ in pre:
        job_q.put(None)

    def close_input():
        for p in pre:
            p.join()
        for _ in engines:
            page_q.put(None)
    threading.Thread(target=close_input, daemon=True).start()

    # ---- results ----
    by_idx = {j.idx: j for j in jobs}
    markdown: dict[int, str] = {}
    statuses: dict[int, str] = {j.idx: j.status for j in jobs if j.status != "ok"}
    results_f = open(out_dir / "results.jsonl", "w", encoding="utf-8")

    def record(job, status, md=None, order=None, n_tokens=0, error=None, fmt=None):
        statuses[job.idx] = status
        rec = {"file_name": job.file_name, "page": job.page, "status": status,
               "num_lines": len(job.lines)}
        if md is not None:
            rel = Path(job.file_name).with_suffix("") / f"page_{job.page:04d}.md"
            path = out_dir / "markdown" / rel
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(md, encoding="utf-8")
            markdown[job.idx] = md
            rec.update(markdown_path=str(Path("markdown") / rel), num_tokens=n_tokens)
        if order is not None and a.save_order:
            rec["reading_order"] = order
        if fmt is not None and a.save_tokens:
            rec["formatter_ids"] = fmt
        if error:
            rec["error"] = error
        results_f.write(json.dumps(rec, ensure_ascii=False) + "\n")

    for j in jobs:
        if j.status != "ok":
            record(j, j.status)

    pending, ready, alive = len(todo), 0, a.engines
    t_start = t_last = t_all_ready = None
    done = done_at_all_ready = 0
    try:
        while pending > 0 and alive > 0:
            try:
                msg = result_q.get(timeout=5.0)
            except queue.Empty:
                if not any(p.is_alive() for p in engines):
                    log("ERROR: all engine processes exited")
                    break
                continue
            kind = msg[0]
            if kind == "ready":
                ready += 1
                log(f"engine {msg[1]} ready ({ready}/{a.engines})")
                if t_start is None:
                    t_start = t_last = time.time()
                if ready == a.engines:
                    t_all_ready, done_at_all_ready = time.time(), done
            elif kind == "engine_error":
                alive -= 1
                log(f"ERROR: engine {msg[1]} failed:\n{msg[2]}")
            elif kind == "engine_done":
                alive -= 1
            elif kind == "page":
                _, idx, status, order, fmt, n_tokens, error = msg
                job = by_idx[idx]
                md = decoder.decode(order, fmt, job.lines) if status == "ok" else None
                record(job, status, md, order, n_tokens, error, fmt)
                pending -= 1
                done += 1
                if time.time() - (t_last or 0) > 10:
                    t_last = time.time()
                    el = t_last - (t_start or t_last)
                    log(f"{done}/{len(todo)} pages" + (f", {done / el:.1f} pages/s" if el > 0 else ""))
    finally:
        results_f.close()
        for p in engines:
            p.join(timeout=60)
            if p.is_alive():
                p.terminate()
        for p in pre:
            if p.is_alive():
                p.terminate()
        # undelivered items (e.g. after an engine failure) must not block interpreter exit
        for q in (job_q, page_q):
            q.cancel_join_thread()
        mps.stop()

    elapsed = time.time() - (t_start or time.time())
    for j in todo:
        if j.idx not in statuses:
            statuses[j.idx] = "not_processed"
    counts = Counter(statuses.values())
    summary = {"pages_total": len(jobs), "status_counts": dict(counts),
               "seconds_since_first_engine_ready": round(elapsed, 1),
               "pages_per_s": round(counts.get("ok", 0) / elapsed, 2) if elapsed > 0 else None,
               "engines": a.engines, "engines_ready": ready, "model_dir": model_dir}
    if t_all_ready is not None and time.time() - t_all_ready > 0:
        # steady state: every engine up (startup is sequential, so early pages see fewer)
        summary["pages_per_s_all_engines"] = round(
            (done - done_at_all_ready) / (time.time() - t_all_ready), 2)
    (out_dir / "summary.json").write_text(json.dumps(summary, indent=2))

    import pandas as pd
    pd.DataFrame([{"file_name": j.file_name, "page": j.page, "status": statuses[j.idx],
                   "markdown": markdown.get(j.idx)} for j in jobs]).to_parquet(out_dir / "results.parquet")
    log(f"done: {json.dumps(summary)}")
    return 0 if counts.get("not_processed", 0) == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
