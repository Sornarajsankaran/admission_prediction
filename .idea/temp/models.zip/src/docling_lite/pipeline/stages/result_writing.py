from pathlib import Path

import pandas as pd
from docling_core.types.doc import DoclingDocument
from docling_lite.core.config import (
    COLUMNS_TO_SAVE,
    DOCLING_DOCUMENT_FILE_TYPE,
    RESULTS_DF_FILE_TYPE,
)
from docling_lite.core.logging import log_function_calls, logger


class ResultWriter:
    def __init__(self, output_dir: Path, batch_name: str ):
        self.output_dir = Path(output_dir)
        self.batch_name = batch_name
        self.df_file_type = RESULTS_DF_FILE_TYPE
        self.docling_document_file_type = DOCLING_DOCUMENT_FILE_TYPE
        self.results_columns_to_save = COLUMNS_TO_SAVE

        self.docs_dir = self.output_dir / f"{self.batch_name}_docling_documents"
        self.processed_df_path = (
            self.output_dir
            / f"{self.batch_name}_docling_lite_results.{RESULTS_DF_FILE_TYPE}"
        )

        self.output_dir.mkdir(parents=True, exist_ok=True)
        self.docs_dir.mkdir(parents=True, exist_ok=True)

    def _save_documents(self, documents: dict[str, DoclingDocument]) -> None:
        for file_name, document in documents.items():
            safe_name = Path(file_name).name
            out_path = self.docs_dir / f"{safe_name}.{self.docling_document_file_type}"
            
            if self.docling_document_file_type == "json":
                document.save_as_json(out_path)
            elif self.docling_document_file_type == "yaml":
                document.save_as_yaml(out_path)
            else:
                raise ValueError(f"Unsupported document file type '{self.docling_document_file_type}'.")
            
            logger.info(f"Saved DoclingDocument for '{file_name}' to {out_path}")

    def _save_processed_df(self, processed_df: pd.DataFrame) -> None:
        missing_columns = [
            column
            for column in self.results_columns_to_save
            if column not in processed_df.columns
        ]
        if missing_columns:
            raise KeyError(
                "Processed dataframe is missing required columns: "
                + ", ".join(missing_columns)
            )

        output_df = processed_df.loc[:, self.results_columns_to_save].copy()

        if self.df_file_type == "parquet":
            output_df.to_parquet(self.processed_df_path, index=False)
        elif self.df_file_type == "csv":
            output_df.to_csv(self.processed_df_path, index=False)
        elif self.df_file_type == "pkl":
            output_df.to_pickle(self.processed_df_path)
        else:
            raise ValueError(
                f"Unsupported dataframe file type '{self.df_file_type}'."
            )
        logger.info(f"Saved processed dataframe to {self.processed_df_path}")

    @log_function_calls(logger)
    def save_results(self, documents: dict[str, DoclingDocument], processed_df: pd.DataFrame) -> None:
        self._save_documents(documents)
        self._save_processed_df(processed_df)
