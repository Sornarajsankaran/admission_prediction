"""
Debug the markdown formatter's free-running decode (logit inspector).
=====================================================================

Pulls ONE real sample from a MarkdownDataset and runs the formatter's KV-cached
decode with per-step instrumentation (``OcrMarkdownFormatterModel.debug_generate``),
printing at every step the cursor, the chosen token, and the post-mask probabilities
of the tokens that matter for the known failure modes -- EMIT_NEXT, EOS, and space (id 5,
the token that "continuous spaces" collapses onto) -- plus the top-k.

It runs the decode under the GOLD reading order and, if an ``--order-ckpt`` is given,
ALSO under the order decoder's PREDICTED order. That is the decisive experiment for a
repetition loop:

    * loops under BOTH gold and predicted order  -> a formatter free-running attractor (H1).
    * clean under gold, loops under predicted     -> the loop is triggered by an upstream
                                                     ORDER error putting the formatter OOD (H2).

Example (GPU box):

    python debug_formatter.py \
        --formatter-ckpt ./runs/grpo_fmt/best.pt \
        --order-ckpt     ./runs/joint/best.pt \
        --test-parquet /data/test.parquet --pdf-dir /data/pdfs \
        --index 0 --max-new-tokens 1600
"""

from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

import click
import torch

import data
from infer import _load_state, _strip_prefix
from modeling_ocr_reconstruction import (
    OcrReconstructionConfig, OcrOrderingModel, OcrMarkdownFormatterModel)

EMIT = data.EMIT_NEXT_MODEL_ID
EOS = 1
SPACE = 5

# printable token labels (whitespace made visible)
_DISP = dict(data.SPECIAL_ID_TO_STR)
_DISP[4] = "\\n"
_DISP[5] = "SP"       # space (ASCII-safe marker for the console)


def tok_str(i: int) -> str:
    i = int(i)
    return "EMIT" if i == EMIT else _DISP.get(i, f"<s{i}>")


# --------------------------------------------------------------------------- #
# loading (formatter required; order optional)
# --------------------------------------------------------------------------- #
def _load_formatter(ckpt, cfg, device):
    m = OcrMarkdownFormatterModel(cfg).to(device).eval()
    info = m.load_state_dict(_strip_prefix(_load_state(ckpt, device), "formatter"), strict=False)
    print(f"formatter load: missing {len(info.missing_keys)}, unexpected {len(info.unexpected_keys)}")
    return m


def _load_order(ckpt, cfg, device):
    m = OcrOrderingModel(cfg).to(device).eval()
    info = m.load_state_dict(_strip_prefix(_load_state(ckpt, device), "order"), strict=False)
    print(f"order     load: missing {len(info.missing_keys)}, unexpected {len(info.unexpected_keys)}")
    return m


# --------------------------------------------------------------------------- #
# analysis / printing
# --------------------------------------------------------------------------- #
def _probs(rec_logits, temperature):
    return torch.softmax(rec_logits[0].float() / temperature, dim=-1)      # (V,)


def _longest_run(ids):
    """(token_id, run_length, start_index) of the longest consecutive-equal run in ids."""
    best_id, best_len, best_start = None, 0, 0
    i = 0
    while i < len(ids):
        j = i
        while j < len(ids) and ids[j] == ids[i]:
            j += 1
        if j - i > best_len:
            best_id, best_len, best_start = ids[i], j - i, i
        i = j
    return best_id, best_len, best_start


def analyse(label, seq, records, K, temperature, head, window):
    chosen = seq[0, 1:].tolist()                                            # decision at step t -> chosen[t]
    if EOS in chosen:
        end = chosen.index(EOS) + 1                                         # include the EOS
    else:
        end = len(chosen)
    hit_eos = EOS in chosen

    def row(t):
        p = _probs(records[t]["logits"], temperature)
        cur = int(records[t]["cursor"][0])
        ch = chosen[t]
        topk = torch.topk(p, k=min(5, p.numel()))
        tops = " ".join(f"{tok_str(int(i))}:{float(v):.3f}" for v, i in zip(topk.values, topk.indices))
        return (f"  t={t:<4d} cur={cur}/{K}  chose {tok_str(ch):<5} | "
                f"EMIT={float(p[EMIT]):.3f} EOS={float(p[EOS]):.3f} sp={float(p[SPACE]):.3f} | {tops}")

    print(f"\n===== {label} =====  K={K}  gen_len={end}  hit_eos={hit_eos}  (temp={temperature})")
    print("  preview:", repr(data.render_sequence(seq[0].tolist())[:160]))

    n = min(end, len(records))
    run_id, run_len, run_start = _longest_run(chosen[:end])

    # head rows
    for t in range(min(head, n)):
        print(row(t))

    # collapse window: rows around the start of the longest run (if it's past the head)
    if run_len >= 8 and run_start >= head:
        lo = max(head, run_start - 3)
        hi = min(n, run_start + window)
        print(f"  ... [collapse window @ longest run of {tok_str(run_id)} x{run_len}] ...")
        for t in range(lo, hi):
            print(row(t))

    # summary
    if run_len >= 8:
        w = range(run_start, min(run_start + run_len, len(records)))
        mp_emit = sum(float(_probs(records[t]["logits"], temperature)[EMIT]) for t in w) / max(len(w), 1)
        mp_eos = sum(float(_probs(records[t]["logits"], temperature)[EOS]) for t in w) / max(len(w), 1)
        cur_stuck = int(records[run_start]["cursor"][0])
        print(f"  >> LONGEST RUN: {tok_str(run_id)} x{run_len} from t={run_start}, "
              f"cursor STUCK at {cur_stuck}/{K}; over the run mean P(EMIT)={mp_emit:.4f} P(EOS)={mp_eos:.4f}")
        if not hit_eos:
            print(f"  >> never emitted EOS: cursor never reached K -> forced to keep emitting to max_new_tokens")
    else:
        print(f"  >> no degenerate run (longest consecutive token = {tok_str(run_id)} x{run_len})")


# --------------------------------------------------------------------------- #
# CLI
# --------------------------------------------------------------------------- #
@click.command(context_settings={"show_default": True})
@click.option("--formatter-ckpt", required=True, type=click.Path(exists=True),
              help="Phase-4 formatter (GRPO) or a Phase-3 two-stage dump")
@click.option("--order-ckpt", type=click.Path(exists=True), default=None,
              help="optional: also run the formatter under this order model's PREDICTED order")
@click.option("--test-parquet", required=True, type=click.Path(exists=True))
@click.option("--pdf-dir", required=True, type=click.Path(exists=True))
@click.option("--index", type=int, default=0, help="dataset sample index to debug")
@click.option("--backbone", default="docling-project/docling-layout-heron")
@click.option("--max-len", type=int, default=2048)
@click.option("--max-new-tokens", type=int, default=1600)
@click.option("--sample/--no-sample", default=False, help="sample instead of greedy (diagnose greedy first)")
@click.option("--temperature", type=float, default=1.0, help="temperature for the reported probs / sampling")
@click.option("--head", type=int, default=40, help="print this many steps from the start")
@click.option("--window", type=int, default=12, help="print this many steps at the collapse point")
@click.option("--dump", type=click.Path(), default=None, help="torch.save {seq, records} here for offline analysis")
@click.option("--device", default="cuda" if torch.cuda.is_available() else "cpu")
def main(formatter_ckpt, order_ckpt, test_parquet, pdf_dir, index, backbone, max_len,
         max_new_tokens, sample, temperature, head, window, dump, device):
    device = torch.device(device)
    if max_new_tokens > 2048:
        print(f"WARNING: --max-new-tokens {max_new_tokens} exceeds max_position_embeddings (2048); "
              f"generation will fail at the position-embedding lookup. Clamp it to <= 2048.")

    cfg = OcrReconstructionConfig(backbone_name_or_path=backbone)
    formatter = _load_formatter(formatter_ckpt, cfg, device)
    order_model = _load_order(order_ckpt, cfg, device) if order_ckpt else None

    image_processor = data.load_image_processor(backbone)
    ds = data.MarkdownDataset(test_parquet, pdf_dir, image_processor, max_len=max_len)
    if not (0 <= index < len(ds)):
        raise click.UsageError(f"--index {index} out of range (dataset has {len(ds)} samples)")
    batch = data.md_collate_fn([ds[index]])
    batch = {k: v.to(device) for k, v in batch.items()}
    pv, ob, bm = batch["pixel_values"], batch["ocr_boxes"], batch["box_mask"]
    K = int(bm.sum())

    dumps = {}

    # ---- GOLD order ----
    gold_order = batch["order"]
    seq_g, rec_g = formatter.debug_generate(pv, ob, gold_order, box_mask=bm,
                                            max_new_tokens=max_new_tokens, sample=sample,
                                            temperature=temperature)
    analyse("GOLD order", seq_g, rec_g, K, temperature, head, window)
    dumps["gold"] = {"seq": seq_g.cpu(), "records": [{k: v.cpu() for k, v in r.items()} for r in rec_g],
                     "order": gold_order.cpu()}

    # ---- PREDICTED order (optional) ----
    if order_model is not None:
        pred_order, n_real = order_model.generate_order(pv, ob, box_mask=bm, boxes_are_xyxy=True)
        agree = int((pred_order[0, :K] == gold_order[0, :K]).sum())
        print(f"\n[order] predicted vs gold: {agree}/{K} positions match "
              f"({'IDENTICAL' if agree == K else 'DIFFERS -> tests H2'})")
        seq_p, rec_p = formatter.debug_generate(pv, ob, pred_order, box_mask=bm,
                                                max_new_tokens=max_new_tokens, sample=sample,
                                                temperature=temperature)
        analyse("PREDICTED order", seq_p, rec_p, K, temperature, head, window)
        dumps["pred"] = {"seq": seq_p.cpu(), "records": [{k: v.cpu() for k, v in r.items()} for r in rec_p],
                         "order": pred_order.cpu()}

    if dump:
        torch.save(dumps, dump)
        print(f"\nsaved raw logits/records -> {dump}")


if __name__ == "__main__":
    main()
