#!/usr/bin/env python3
"""Create deterministic small CSV inputs demonstrating V0.2 inputs; no dependencies."""
import csv
import json
from pathlib import Path

OUT = Path(__file__).resolve().parent

DOCUMENTS = [
    (
        "AUD101", "alpha.pdf", 12,
        {
            "code_resolver": {"DRG code assignment": {0: 3, 4: 2}},
            "signs_and_symptoms": {
                "fever": {0: 3, 1: 2, 3: 1},
                "numbness": {},
            },
            "therapeutic_treatment": {"antibiotic": {2: 3, 8: 1}},
            "diagnostic_procedure": {"biopsy": {}},
            "clinical_evaluation": {"risk": {7: 2}},
        },
    ),
    (
        "AUD202", "beta.pdf", 8,
        {
            "code_resolver": {"procedure code": {}},
            "signs_and_symptoms": {"pain": {0: 1, 3: 2}},
            "therapeutic_treatment": {"steroid": {}},
            "diagnostic_procedure": {"MRI": {5: 3}},
            "clinical_evaluation": {"abnormal lab": {1: 2}},
        },
    ),
]
GRADE_NAME = ["not_relevant", "less_relevant", "relevant", "highly_relevant"]


def write(name, rows, headers):
    with (OUT / name).open("w", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, headers)
        writer.writeheader()
        for row in rows:
            writer.writerow({k: json.dumps(v, sort_keys=True) if isinstance(v, dict) else v for k, v in row.items()})


def main():
    ground, pred_a, pred_b = [], [], []
    for audit, pdf, n, queries in DOCUMENTS:
        for chunk_idx in range(n):
            cid = f"{audit}:{pdf}:{1+chunk_idx//4}:{chunk_idx%4}"
            gt = {}
            scores_a, scores_b = {}, {}
            binary_a, binary_b = {}, {}
            for category, mapping in queries.items():
                gt[category], scores_a[category], scores_b[category] = {}, {}, {}
                binary_a[category], binary_b[category] = {}, {}
                for query, positives in mapping.items():
                    grade = positives.get(chunk_idx, 0)
                    gt[category][query] = GRADE_NAME[grade]
                    # This synthetic example is NOT a calibrated similarity model.
                    # A few deliberate false positives and false negatives for tests.
                    noise = (chunk_idx * 7 + len(query) * 3) % 11
                    a_score = round((0.20 + 0.20 * grade) + noise / 150, 5)
                    b_score = round((0.32 + 0.13 * grade) + (10-noise) / 45, 5)
                    a_binary = int(a_score >= 0.39)
                    b_binary = int(b_score >= 0.55)
                    # Some no-positive query false alarms are deliberately injected.
                    if grade == 0 and chunk_idx == 2 and len(query) % 2 == 0:
                        a_score, a_binary = 0.74, 1
                    if grade == 0 and chunk_idx == 1 and len(query) % 3 == 0:
                        b_score, b_binary = 0.77, 1
                    scores_a[category][query] = a_score
                    scores_b[category][query] = b_score
                    binary_a[category][query] = a_binary
                    binary_b[category][query] = b_binary
            ground.append({"chunk_id": cid, "labels": gt})
            pred_a.append({"chunk_id": cid, "labels": scores_a, "binary_predictions": binary_a})
            pred_b.append({"chunk_id": cid, "labels": scores_b, "binary_predictions": binary_b})
    write("ground_truth_V0.1.csv", ground, ("chunk_id", "labels"))
    write("predictions_model_A_V0.2.csv", pred_a, ("chunk_id", "labels", "binary_predictions"))
    write("predictions_model_B_V0.2.csv", pred_b, ("chunk_id", "labels", "binary_predictions"))
    print("Created examples: 2 PDFs, 20 chunks, 11 query instances, 4 no-positive queries")


if __name__ == "__main__":
    main()
