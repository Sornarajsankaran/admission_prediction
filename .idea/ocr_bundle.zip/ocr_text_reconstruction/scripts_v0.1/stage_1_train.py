"""
Stage-1 training script: reading-order model (class-based).
==========================================================

Trains :class:`OcrOrderingModel` to predict the reading-order permutation of a
page's OCR boxes. Target order comes from ``data.build_order_example`` (the same
``encoded_ouput_ids_raw`` used for SFT -- no new data).

`Stage1Trainer` owns the loop:
    train_epoch   grad-accum + AMP + clip + schedule, periodic eval
    eval_epoch    teacher-forced next-position accuracy  +  FREE-RUNNING reading-
                  order metrics (pairwise / exact / adjacency) vs. gold AND vs. a
                  geometric top-left baseline (the go/no-go reference)
    train_model / eval_model   outer loop + checkpoint best (by free-running pairwise)

Headline metric: free-running ``pairwise`` (= (Kendall-tau + 1)/2). The feasibility
verdict is whether the learned model BEATS the top-left baseline on pairwise/exact.

Real run (GPU box):

    python stage_1_train.py \
        --train-parquet /data/train.parquet --test-parquet /data/test.parquet \
        --pdf-dir /data/pdfs --output-dir ./runs/order_v1 \
        --epochs 20 --batch-size 8 --grad-accum 2 --lr 3e-4 --backbone-lr 3e-5 \
        --eval-steps 1000 --num-eval-samples 16

CPU smoke test (no parquet / PDFs / GPU):

    python stage_1_train.py --smoke
"""

from __future__ import annotations

import json
import os
import sys
import time
from pathlib import Path
from types import SimpleNamespace

sys.path.insert(0, str(Path(__file__).resolve().parent))

import click
import numpy as np
import torch
from torch.utils.data import DataLoader, Dataset

import data
from modeling_ocr_reconstruction import OcrReconstructionConfig, OcrOrderingModel
from train import build_optimizer, build_scheduler, _init_from_checkpoint


# --------------------------------------------------------------------------- #
# Reading-order metrics (free-running eval)
# --------------------------------------------------------------------------- #
def reading_order_metrics(pred: list[int], gold: list[int]) -> dict:
    """All three headline metrics for one page. ``pred`` and ``gold`` are both
    permutations of ``range(K)``.

      pairwise  : fraction of box pairs in the correct relative order = (tau+1)/2
      exact     : 1.0 iff the whole permutation matches
      adjacency : fraction of consecutive gold pairs kept consecutive-and-ordered
    """
    K = len(gold)
    if K <= 1:
        return {"pairwise": 1.0, "exact": 1.0, "adjacency": 1.0}
    pred_pos = {b: i for i, b in enumerate(pred)}
    gold_pos = {b: i for i, b in enumerate(gold)}

    conc = tot = 0
    for a_i in range(K):
        for b_i in range(a_i + 1, K):
            a, b = gold[a_i], gold[b_i]
            tot += 1
            if (gold_pos[a] - gold_pos[b]) * (pred_pos[a] - pred_pos[b]) > 0:
                conc += 1
    pairwise = conc / tot

    exact = 1.0 if pred == gold else 0.0

    adj = sum(1 for t in range(K - 1) if pred_pos[gold[t + 1]] == pred_pos[gold[t]] + 1)
    adjacency = adj / (K - 1)
    return {"pairwise": pairwise, "exact": exact, "adjacency": adjacency}


def topleft_order(boxes) -> list[int]:
    """Weak raster baseline: sort top-to-bottom then left-to-right (by y1, x1).
    ``boxes`` is (K, 4) xyxy. Kept as a second reference -- it interleaves columns
    on multi-column pages, so it is easy to beat and not a meaningful bar alone."""
    b = boxes.tolist() if hasattr(boxes, "tolist") else boxes
    return sorted(range(len(b)), key=lambda i: (b[i][1], b[i][0]))


def _first_gap(intervals):
    """First (smallest-coordinate) whitespace gap in a union of 1-D intervals
    ``(lo, hi)``. Returns ``(gap_size, split_point)``; ``(0.0, None)`` if the
    intervals all overlap into a single span."""
    events = sorted(intervals, key=lambda p: p[0])
    cover_hi = events[0][1]
    for lo, hi in events[1:]:
        if lo > cover_hi:
            return lo - cover_hi, (cover_hi + lo) / 2
        cover_hi = max(cover_hi, hi)
    return 0.0, None


def xycut_order(boxes) -> list[int]:
    """Column-aware XY-cut reading order (the meaningful baseline). Recursively:
    if the boxes split into columns (a vertical whitespace gutter exists), peel the
    LEFT-most column and recurse; otherwise peel the TOP-most horizontal band and
    recurse. Columns-first means a full-width header (no vertical gutter) is peeled
    before the body, then the body splits into columns and each is read fully --
    unlike a raster sort. ``boxes`` is (K, 4) xyxy."""
    b = boxes.tolist() if hasattr(boxes, "tolist") else [list(x) for x in boxes]

    def rec(ids):
        if len(ids) <= 1:
            return list(ids)
        # columns first: if a vertical gutter exists, split left / right there
        x_gap, x_split = _first_gap([(b[i][0], b[i][2]) for i in ids])
        if x_gap > 0.0:
            left = [i for i in ids if (b[i][0] + b[i][2]) / 2 < x_split]
            right = [i for i in ids if (b[i][0] + b[i][2]) / 2 >= x_split]
            return rec(left) + rec(right)
        # else peel the top-most horizontal band
        y_gap, y_split = _first_gap([(b[i][1], b[i][3]) for i in ids])
        if y_gap > 0.0:
            top = [i for i in ids if (b[i][1] + b[i][3]) / 2 < y_split]
            bot = [i for i in ids if (b[i][1] + b[i][3]) / 2 >= y_split]
            return rec(top) + rec(bot)
        return sorted(ids, key=lambda i: (b[i][1], b[i][0]))  # no gaps -> raster

    return rec(list(range(len(b))))


# difficulty buckets by boxes/page (K) -- the go/no-go signal lives in the hard buckets
_BUCKETS = [(2, 4), (5, 9), (10, 19), (20, None)]
BUCKET_LABELS = ["2-4", "5-9", "10-19", "20+"]


def bucket_label(k: int) -> str:
    for (lo, hi), lbl in zip(_BUCKETS, BUCKET_LABELS):
        if k >= lo and (hi is None or k <= hi):
            return lbl
    return BUCKET_LABELS[0]


# --------------------------------------------------------------------------- #
# Synthetic dataset for --smoke
# --------------------------------------------------------------------------- #
class _SyntheticOrderingDataset(Dataset):
    def __init__(self, n: int = 32, seed: int = 0):
        self.n, self.rng = n, torch.Generator().manual_seed(seed)

    def __len__(self):
        return self.n

    def __getitem__(self, idx):
        k = int(torch.randint(2, 7, (1,), generator=self.rng).item())
        return {
            "pixel_values": torch.rand(3, 640, 640, generator=self.rng),
            "ocr_boxes": torch.rand(k, 4, generator=self.rng).sort(-1).values,
            "order": torch.randperm(k, generator=self.rng),
        }


# --------------------------------------------------------------------------- #
# Construction helpers
# --------------------------------------------------------------------------- #
def build_model(args, device):
    if args.smoke:
        from transformers import RTDetrV2Config, RTDetrV2Model

        rt = RTDetrV2Model(RTDetrV2Config(
            d_model=64, encoder_hidden_dim=64, decoder_in_channels=[64, 64, 64],
            encoder_ffn_dim=128, decoder_ffn_dim=128, decoder_layers=2,
            encoder_layers=1, num_denoising=0))
        cfg = OcrReconstructionConfig(d_model=64, num_markdown_layers=2,
                                      markdown_attention_heads=8, markdown_ffn_dim=128,
                                      content_mlp_hidden_dim=64, dropout=args.dropout)
        model = OcrOrderingModel(cfg, rtdetr=rt, strict_transformers_version=False)
    else:
        cfg = OcrReconstructionConfig(backbone_name_or_path=args.backbone, dropout=args.dropout)
        model = OcrOrderingModel(cfg)

    if args.freeze_rtdetr:
        model.freeze_rtdetr(freeze_decoder=True)
    return model.to(device), cfg


def build_dataloaders(args):
    if args.smoke:
        train_ds, val_ds = _SyntheticOrderingDataset(32, seed=0), _SyntheticOrderingDataset(8, seed=1)
    else:
        image_processor = data.load_image_processor(args.backbone)
        train_ds = data.OrderingDataset(args.train_parquet, args.pdf_dir, image_processor,
                                        min_boxes=args.min_boxes, max_boxes=args.max_boxes)
        val_ds = (data.OrderingDataset(args.test_parquet, args.pdf_dir, image_processor,
                                       min_boxes=args.min_boxes, max_boxes=args.max_boxes)
                  if args.test_parquet else None)

    train_loader = DataLoader(train_ds, batch_size=args.batch_size, shuffle=True,
                              collate_fn=data.order_collate_fn,
                              pin_memory=not args.smoke, drop_last=True,
                              **data.make_loader_kwargs(args.num_workers))
    val_loader = (DataLoader(val_ds, batch_size=args.batch_size, shuffle=False,
                             collate_fn=data.order_collate_fn,
                             **data.make_loader_kwargs(args.num_workers))
                  if val_ds is not None else None)
    return train_loader, val_loader


# --------------------------------------------------------------------------- #
# Trainer
# --------------------------------------------------------------------------- #
class Stage1Trainer:
    def __init__(self, model, train_loader, val_loader, model_cfg, args, device):
        self.model = model
        self.train_loader = train_loader
        self.val_loader = val_loader
        self.cfg = model_cfg
        self.args = args
        self.device = device

        self.steps_per_epoch = max(1, len(train_loader) // args.grad_accum)
        self.total_steps = self.steps_per_epoch * args.epochs
        self.optimizer = build_optimizer(model, args)
        self.scheduler = build_scheduler(self.optimizer, args, self.total_steps)
        self.use_amp = device.type == "cuda" and not args.no_amp
        self.scaler = torch.amp.GradScaler("cuda", enabled=self.use_amp)
        self.freeze_rtdetr_eval = args.freeze_rtdetr and args.freeze_rtdetr_eval

        self.step, self.start_epoch, self.best = 0, 0, -1.0  # best = max free-running pairwise
        self.sample_dir = os.path.join(args.output_dir, "samples")
        os.makedirs(self.sample_dir, exist_ok=True)
        if args.resume:
            self._load(args.resume)

    # ---- utilities -------------------------------------------------------- #
    def _autocast(self):
        return torch.amp.autocast(device_type=self.device.type, enabled=self.use_amp)

    def _to_device(self, batch):
        return {k: v.to(self.device, non_blocking=True) for k, v in batch.items()}

    def _trainable(self):
        return (p for p in self.model.parameters() if p.requires_grad)

    def _set_train_mode(self):
        self.model.train()
        if self.freeze_rtdetr_eval:
            self.model.rtdetr.eval()

    # ---- training --------------------------------------------------------- #
    def train_epoch(self, epoch):
        self._set_train_mode()
        self.optimizer.zero_grad(set_to_none=True)
        running, t0 = 0.0, time.time()

        for i, batch in enumerate(self.train_loader):
            batch = self._to_device(batch)
            with self._autocast():
                out = self.model(**batch)
                loss = out.loss / self.args.grad_accum
            self.scaler.scale(loss).backward()
            running += float(out.loss.detach())

            if (i + 1) % self.args.grad_accum != 0:
                continue

            self.scaler.unscale_(self.optimizer)
            torch.nn.utils.clip_grad_norm_(self._trainable(), self.args.grad_clip)
            self.scaler.step(self.optimizer)
            self.scaler.update()
            self.scheduler.step()
            self.optimizer.zero_grad(set_to_none=True)
            self.step += 1

            if self.step % self.args.log_every == 0:
                avg = running / (self.args.grad_accum * self.args.log_every)
                ips = self.args.grad_accum * self.args.log_every / (time.time() - t0)
                print(f"epoch {epoch} step {self.step}/{self.total_steps} "
                      f"loss {avg:.4f} lr {self.scheduler.get_last_lr()[0]:.2e} {ips:.1f} it/s")
                running, t0 = 0.0, time.time()

            if (self.val_loader is not None and self.args.eval_steps
                    and self.step % self.args.eval_steps == 0):
                m = self.eval_epoch(tag=f"step{self.step}")
                self._print_eval(m)
                self._maybe_save_best(m["pairwise"], epoch)

    @torch.no_grad()
    def eval_epoch(self, tag):
        self.model.eval()
        metrics = self._teacher_forced_metrics()
        metrics.update(self._free_running_metrics(tag))
        self._set_train_mode()
        return metrics

    @torch.no_grad()
    def _teacher_forced_metrics(self):
        tot_loss = tot = correct = 0
        for batch in self.val_loader:
            batch = self._to_device(batch)
            with self._autocast():
                out = self.model(**batch)
            order = batch["order"]
            valid = order != data.IGNORE_INDEX
            n = int(valid.sum())
            tot_loss += float(out.loss) * n
            pred = out.logits.argmax(-1)
            correct += int(((pred == order) & valid).sum())
            tot += n
        return {"loss": tot_loss / max(tot, 1), "next_pos_acc": correct / max(tot, 1)}

    @torch.no_grad()
    def _free_running_metrics(self, tag):
        keys = ("pairwise", "exact", "adjacency")
        agg = {k: 0.0 for k in keys}   # model (free-running)
        base = {k: 0.0 for k in keys}  # top-left raster (weak reference)
        xy = {k: 0.0 for k in keys}    # XY-cut column-aware (the real bar)
        wins = losses = n_pages = 0
        buckets = {lbl: [0, 0.0, 0.0] for lbl in BUCKET_LABELS}  # [n, model_pw, xy_pw]
        records, n_store = [], self.args.num_eval_samples

        for batch in self.val_loader:
            batch = self._to_device(batch)
            pred_order, n_real = self.model.generate_order(
                pixel_values=batch["pixel_values"], ocr_boxes=batch["ocr_boxes"],
                box_mask=batch["box_mask"])
            for b in range(pred_order.size(0)):
                k = int(n_real[b])
                gold = batch["order"][b, :k].tolist()
                pred = pred_order[b, :k].tolist()
                boxes_k = batch["ocr_boxes"][b, :k]
                tl_pred, xy_pred = topleft_order(boxes_k), xycut_order(boxes_k)

                mp = reading_order_metrics(pred, gold)
                mtl = reading_order_metrics(tl_pred, gold)
                mxy = reading_order_metrics(xy_pred, gold)
                for key in keys:
                    agg[key] += mp[key]
                    base[key] += mtl[key]
                    xy[key] += mxy[key]
                wins += int(mp["pairwise"] > mxy["pairwise"])   # win/lose vs the real bar
                losses += int(mp["pairwise"] < mxy["pairwise"])
                lbl = bucket_label(k)
                buckets[lbl][0] += 1
                buckets[lbl][1] += mp["pairwise"]
                buckets[lbl][2] += mxy["pairwise"]
                n_pages += 1
                if len(records) < n_store:
                    records.append({"tag": tag, "step": self.step, "K": k, "gold": gold,
                                    "pred": pred, "topleft": tl_pred, "xycut": xy_pred})

        path = os.path.join(self.sample_dir, f"{tag}.jsonl")
        with open(path, "w", encoding="utf-8") as f:
            for r in records:
                f.write(json.dumps(r) + "\n")

        d = max(n_pages, 1)
        out = {k: agg[k] / d for k in keys}
        out.update({f"base_{k}": base[k] / d for k in keys})
        out.update({f"xy_{k}": xy[k] / d for k in keys})
        out["win_rate"] = wins / d
        out["lose_rate"] = losses / d
        out["buckets"] = [(lbl, n, pw / max(n, 1), xpw / max(n, 1))
                          for lbl, (n, pw, xpw) in buckets.items() if n > 0]
        return out

    def _print_eval(self, m):
        print(f"[eval@{self.step}] loss {m['loss']:.4f} next_pos_acc {m['next_pos_acc']:.3f}")
        print(f"  FREE  pairwise {m['pairwise']:.3f} exact {m['exact']:.3f} adj {m['adjacency']:.3f}")
        print(f"  XYCUT pairwise {m['xy_pairwise']:.3f} exact {m['xy_exact']:.3f} "
              f"adj {m['xy_adjacency']:.3f}   (raster pairwise {m['base_pairwise']:.3f})")
        print(f"  win vs xycut {m['win_rate']:.3f}   lose {m['lose_rate']:.3f}")
        for lbl, n, pw, xpw in m.get("buckets", []):
            flag = "  <-- model wins" if pw > xpw else ("  <-- model loses" if pw < xpw else "")
            print(f"    K {lbl:>5}: n={n:<5} FREE {pw:.3f}  XY {xpw:.3f}{flag}")

    def train_model(self):
        n_train = sum(p.numel() for p in self.model.parameters() if p.requires_grad)
        n_total = sum(p.numel() for p in self.model.parameters())
        print(f"trainable {n_train/1e6:.2f}M / {n_total/1e6:.2f}M | "
              f"steps/epoch {self.steps_per_epoch} | total {self.total_steps}")

        for epoch in range(self.start_epoch, self.args.epochs):
            self.train_epoch(epoch)
            if self.val_loader is not None:
                m = self.eval_epoch(tag=f"epoch{epoch}")
                self._print_eval(m)
                self._maybe_save_best(m["pairwise"], epoch)
            self._save(os.path.join(self.args.output_dir, "last.pt"), epoch + 1)
        print("done.")

    @torch.no_grad()
    def eval_model(self, ckpt=None):
        if ckpt:
            self._load(ckpt)
        if self.val_loader is None:
            raise ValueError("eval_model requires a validation loader")
        m = self.eval_epoch(tag="eval_model")
        self._print_eval(m)
        return m

    # ---- checkpointing ---------------------------------------------------- #
    def _maybe_save_best(self, pairwise, epoch):
        if pairwise > self.best:
            self.best = pairwise
            self._save(os.path.join(self.args.output_dir, "best.pt"), epoch + 1)
            print(f"  saved best (pairwise {self.best:.4f})")

    def _save(self, path, epoch):
        os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
        torch.save({"model": self.model.state_dict(), "optimizer": self.optimizer.state_dict(),
                    "scheduler": self.scheduler.state_dict(), "scaler": self.scaler.state_dict(),
                    "step": self.step, "epoch": epoch, "best": self.best}, path)

    def _load(self, path):
        ck = torch.load(path, map_location=self.device)
        self.model.load_state_dict(ck["model"])
        self.optimizer.load_state_dict(ck["optimizer"])
        self.scheduler.load_state_dict(ck["scheduler"])
        self.scaler.load_state_dict(ck["scaler"])
        self.step, self.start_epoch, self.best = ck["step"], ck["epoch"], ck["best"]
        print(f"resumed from {path} @ step {self.step}, epoch {self.start_epoch}")


# --------------------------------------------------------------------------- #
# CLI (click)
# --------------------------------------------------------------------------- #
@click.command(context_settings={"show_default": True})
# data
@click.option("--train-parquet", type=click.Path(), default=None)
@click.option("--test-parquet", type=click.Path(), default=None)
@click.option("--pdf-dir", type=click.Path(), default=None)
@click.option("--backbone", default="docling-project/docling-layout-heron")
@click.option("--min-boxes", type=int, default=2, help="drop pages with < this many matched boxes")
@click.option("--max-boxes", type=int, default=None, help="drop pages with > this many matched boxes")
# optim
@click.option("--epochs", type=int, default=20)
@click.option("--batch-size", type=int, default=8)
@click.option("--grad-accum", type=int, default=2)
@click.option("--lr", type=float, default=3e-4, help="LR for new modules")
@click.option("--backbone-lr", type=float, default=3e-5, help="LR for pretrained rt-detr")
@click.option("--weight-decay", type=float, default=0.01)
@click.option("--warmup-steps", type=int, default=500)
@click.option("--min-lr-ratio", type=float, default=0.05)
@click.option("--grad-clip", type=float, default=1.0)
@click.option("--dropout", type=float, default=0.1)
# runtime
@click.option("--freeze-rtdetr", is_flag=True, help="train only new modules")
@click.option("--freeze-rtdetr-eval", is_flag=True, help="also put a frozen rt-detr in eval mode")
@click.option("--num-workers", type=int, default=8)
@click.option("--device", default="cuda" if torch.cuda.is_available() else "cpu")
@click.option("--no-amp", is_flag=True)
@click.option("--seed", type=int, default=42)
@click.option("--output-dir", type=click.Path(), default="./runs/order_v1")
@click.option("--resume", type=click.Path(), default=None, help="resume FULL training state")
@click.option("--init-from", type=click.Path(), default=None, help="load ONLY model weights")
@click.option("--eval-only", is_flag=True)
@click.option("--log-every", type=int, default=20)
# eval
@click.option("--eval-steps", type=int, default=0, help="eval every N optimizer steps (0 = epoch end only)")
@click.option("--num-eval-samples", type=int, default=16, help="how many pred/gold orders to store each eval")
# smoke
@click.option("--smoke", is_flag=True, help="tiny random model + synthetic permutations; CPU loop test")
def main(**kwargs):
    args = SimpleNamespace(**kwargs)

    if args.smoke:
        args.epochs = 2 if args.epochs == 20 else args.epochs
        args.batch_size, args.grad_accum, args.num_workers = 2, 2, 0
        args.warmup_steps, args.log_every = 2, 1
        args.eval_steps, args.num_eval_samples = 4, 4
        args.output_dir = "./runs/order_smoke"
    elif not args.eval_only and not (args.train_parquet and args.pdf_dir):
        raise click.UsageError("--train-parquet and --pdf-dir are required (or use --smoke)")
    if args.init_from and args.resume:
        raise click.UsageError("--init-from and --resume are mutually exclusive")

    torch.manual_seed(args.seed)
    device = torch.device(args.device)
    print(f"device={device}  smoke={args.smoke}")

    model, cfg = build_model(args, device)
    if args.init_from:
        _init_from_checkpoint(model, args.init_from, device)
    train_loader, val_loader = build_dataloaders(args)
    trainer = Stage1Trainer(model, train_loader, val_loader, cfg, args, device)

    if args.eval_only:
        trainer.eval_model(ckpt=args.resume)
    else:
        trainer.train_model()


if __name__ == "__main__":
    main()
