"""
Stage-4 training: GRPO on the markdown formatter's free-running structural stream.
==================================================================================

Phase 4 of the two-stage plan. Stages 1-2 showed order is solved and the stage handoff
is ~free; the binding constraint is the formatter's teacher-forcing -> free-running
collapse. GRPO attacks exactly that by training the formatter against its OWN sampled
rollouts with a sequence-level reward.

Setup (format-decoder only):
  * standalone ``OcrMarkdownFormatterModel``; the shared box encoder is FROZEN.
  * order is GOLD (from the data), not predicted -- order is already solved and the reward
    reference (the gold structural stream) is only valid under gold order, so this keeps the
    reward a pure formatting signal.
  * every rollout is a valid, complete, correctly-ordered K-block sequence by construction
    (EMIT_NEXT masked at cursor==K, EOS masked until cursor==K), so the reward never has to
    police coverage/order -- it only measures formatting.

One GRPO step:
  1. take P pages, encode ONCE (frozen), replicate H_box / order / mask G times  -> P*G rollouts
  2. KV-cached multinomial ``_ar_generate`` each rollout (records old log-probs)
  3. reward = token-id edit-similarity of the rollout stream vs the gold stream
  4. group-normalize rewards within each page's G samples                          -> advantages
  5. recompute masked log-probs with grad (policy) and without (frozen reference)
  6. loss = clipped surrogate + kl_beta * KL(policy || reference)

The policy is kept in eval() throughout (dropout off) so sampled and recomputed log-probs
match -- the importance ratio starts at ~1.

Real run (GPU box; --init-from a Phase-2 or Phase-3 formatter checkpoint):

    python stage_4_train.py \
        --train-parquet /data/train.parquet --test-parquet /data/test.parquet --pdf-dir /data/pdfs \
        --init-from ./runs/md_frozen/best.pt --output-dir ./runs/grpo_fmt \
        --pages-per-step 4 --group-size 8 --kl-beta 0.02 --lr 2e-6 \
        --steps 2000 --eval-every 100 --max-eval-samples 256

CPU smoke:  python stage_4_train.py --smoke
"""

from __future__ import annotations

import os
import sys
import time
from collections import defaultdict
from pathlib import Path
from types import SimpleNamespace

sys.path.insert(0, str(Path(__file__).resolve().parent))

import click
import torch
from loguru import logger
from torch.utils.data import DataLoader

import data
from modeling_ocr_reconstruction import OcrReconstructionConfig, OcrMarkdownFormatterModel
from stage_2_train import edit_similarity, _clean_generated, _clean_labels, _SyntheticMarkdownDataset


# --------------------------------------------------------------------------- #
# GRPO math (module-level, unit-testable)
# --------------------------------------------------------------------------- #
def group_advantages(rewards: torch.Tensor, group_size: int, eps: float = 1e-6) -> torch.Tensor:
    """Group-relative advantages: normalize each page's G rewards to mean 0 / std 1.
    A group whose G rewards are all equal yields zero advantage (nothing to learn)."""
    r = rewards.view(-1, group_size)
    adv = (r - r.mean(dim=1, keepdim=True)) / (r.std(dim=1, keepdim=True) + eps)
    return adv.reshape(-1)


# --------------------------------------------------------------------------- #
# Construction
# --------------------------------------------------------------------------- #
def _load_weights(model, path, device):
    ck = torch.load(path, map_location=device)
    state = ck["model"] if isinstance(ck, dict) and "model" in ck else ck
    # A Phase-3 OcrTwoStageModel dump stores the formatter under 'formatter.*' (with the tied
    # encoder); a Phase-2 standalone formatter dump already matches. Strip if it's two-stage.
    if any(k.startswith("formatter.") for k in state):
        state = {k[len("formatter."):]: v for k, v in state.items() if k.startswith("formatter.")}
        logger.info("init-from: two-stage dump detected -> using its 'formatter.*' sub-state")
    info = model.load_state_dict(state, strict=False)
    logger.info(f"init-from {path}: loaded weights "
                f"(missing {len(info.missing_keys)}, unexpected {len(info.unexpected_keys)})")
    if info.missing_keys:
        logger.warning(f"  {len(info.missing_keys)} missing (fresh-init) e.g. {info.missing_keys[:4]}")


def build_model(args, device):
    if args.smoke:
        from transformers import RTDetrV2Config, RTDetrV2Model

        rt = RTDetrV2Model(RTDetrV2Config(
            d_model=64, encoder_hidden_dim=64, decoder_in_channels=[64, 64, 64],
            encoder_ffn_dim=128, decoder_ffn_dim=128, decoder_layers=2,
            encoder_layers=1, num_denoising=0))
        cfg = OcrReconstructionConfig(d_model=64, num_markdown_layers=2, markdown_attention_heads=8,
                                      markdown_ffn_dim=128, content_mlp_hidden_dim=64, dropout=args.dropout)
        model = OcrMarkdownFormatterModel(cfg, rtdetr=rt, strict_transformers_version=False)
    else:
        cfg = OcrReconstructionConfig(backbone_name_or_path=args.backbone, dropout=args.dropout)
        model = OcrMarkdownFormatterModel(cfg)
        if args.init_from:
            _load_weights(model, args.init_from, device)

    model.freeze_box_encoder()          # Phase 4: encoder always frozen (format-decoder only)
    return model.to(device), cfg


def build_reference(policy, cfg, device):
    """Frozen snapshot of the init formatter -- the KL leash. Shares the frozen encoder by
    reference (no RT-DETR duplication); only the decoder-side weights are a separate snapshot,
    held at init so the leash measures drift from the starting policy."""
    ref = OcrMarkdownFormatterModel(cfg, rtdetr=policy.rtdetr, strict_transformers_version=False)
    ref.box_content_mlp = policy.box_content_mlp        # shared frozen encoder
    ref.box_input_norm = policy.box_input_norm
    ref.load_state_dict(policy.state_dict())            # decoder-side <- policy(init); encoder no-op
    ref.to(device).eval()
    for p in ref.parameters():
        p.requires_grad_(False)
    return ref


def build_optimizer(model, args):
    """Single LR tier: the encoder is frozen, so only the decoder-side modules train."""
    def no_decay(name, p):
        return (p.ndim <= 1 or "norm" in name.lower() or "embedding" in name.lower()
                or name.endswith("pos_embedding") or name.endswith("cursor_done"))

    decay, nodecay = [], []
    for name, p in model.named_parameters():
        if not p.requires_grad:
            continue
        (nodecay if no_decay(name, p) else decay).append(p)
    groups = [{"params": decay, "weight_decay": args.weight_decay},
              {"params": nodecay, "weight_decay": 0.0}]
    return torch.optim.AdamW([g for g in groups if g["params"]], lr=args.lr, betas=(0.9, 0.999), eps=1e-8)


def build_dataloaders(args):
    if args.smoke:
        train_ds = _SyntheticMarkdownDataset(24, seed=0)
        val_ds = _SyntheticMarkdownDataset(8, seed=1)
    else:
        image_processor = data.load_image_processor(args.backbone)
        train_ds = data.MarkdownDataset(args.train_parquet, args.pdf_dir, image_processor,
                                        max_len=args.max_len, max_boxes=args.max_boxes)
        val_ds = (data.MarkdownDataset(args.test_parquet, args.pdf_dir, image_processor,
                                       max_len=args.max_len, max_boxes=args.max_boxes)
                  if args.test_parquet else None)

    train_loader = DataLoader(train_ds, batch_size=args.pages_per_step, shuffle=True,
                              collate_fn=data.md_collate_fn,
                              pin_memory=not args.smoke, drop_last=True,
                              **data.make_loader_kwargs(args.num_workers))
    val_loader = (DataLoader(val_ds, batch_size=args.eval_batch_size, shuffle=False,
                             collate_fn=data.md_collate_fn,
                             **data.make_loader_kwargs(args.num_workers))
                  if val_ds is not None else None)
    return train_loader, val_loader


# --------------------------------------------------------------------------- #
# Trainer
# --------------------------------------------------------------------------- #
class Stage4GRPOTrainer:
    def __init__(self, policy, reference, train_loader, val_loader, model_cfg, args, device):
        self.policy = policy
        self.reference = reference
        self.train_loader = train_loader
        self.val_loader = val_loader
        self.cfg = model_cfg
        self.args = args
        self.device = device
        self.optimizer = build_optimizer(policy, args)
        self.step = 0
        self.best = -1.0
        os.makedirs(args.output_dir, exist_ok=True)

    def _to_device(self, batch):
        return {k: v.to(self.device, non_blocking=True) for k, v in batch.items()}

    def _infinite(self):
        while True:
            for batch in self.train_loader:
                yield batch

    # ---- one GRPO micro-batch -------------------------------------------- #
    def train_step(self, batch, scale: float):
        args, G, cfg = self.args, self.args.group_size, self.cfg
        batch = self._to_device(batch)
        pv, ob = batch["pixel_values"], batch["ocr_boxes"]
        order, bm, labels = batch["order"], batch["box_mask"], batch["labels"]
        B = pv.size(0)

        # 1. encode ONCE (frozen), replicate H_box / order / mask into G rollouts per page
        with torch.no_grad():
            H = self.policy.encode_boxes(pv, ob, box_mask=bm)
        Hb = H.repeat_interleave(G, dim=0)
        order_g = order.repeat_interleave(G, dim=0)
        bm_g = bm.repeat_interleave(G, dim=0)

        # 2. KV-cached multinomial rollout (no grad); old_logprobs under the temp-1 policy
        with torch.no_grad():
            seq, old_lp, valid = self.policy._ar_generate(
                Hb, order_g, bm_g, max_new_tokens=args.max_new_tokens,
                sample=True, temperature=args.temperature)

        # 3. reward = edit-similarity of the rollout stream vs the gold structural stream
        gold = [_clean_labels(labels[b].tolist(), cfg.eos_token_id, data.IGNORE_INDEX) for b in range(B)]
        rewards = torch.empty(B * G, device=self.device)
        for i in range(B * G):
            gen_ids = _clean_generated(seq[i].tolist(), cfg.bos_token_id, cfg.eos_token_id, cfg.pad_token_id)
            rewards[i] = edit_similarity(gen_ids, gold[i // G])
        adv = group_advantages(rewards, G).unsqueeze(1)                      # (B*G, 1)

        # 4. masked log-probs: policy (grad) + reference (no grad), both eval-mode
        new_lp = self.policy.token_logprobs(Hb, seq, order_g, bm_g)          # (B*G, S-1)
        with torch.no_grad():
            ref_lp = self.reference.token_logprobs(Hb, seq, order_g, bm_g)
        old = old_lp[:, 1:]
        vmask = valid[:, 1:].float()

        # 5. clipped surrogate (ratio ~= 1 at init -> proper group-baseline PG)
        ratio = torch.exp(new_lp - old)
        surrogate = -torch.min(ratio * adv,
                               torch.clamp(ratio, 1 - args.clip_eps, 1 + args.clip_eps) * adv)

        # 6. KL(policy || reference), k3 estimator (>= 0) -- the leash
        r = ref_lp - new_lp
        kl = torch.exp(r) - r - 1.0

        loss_tok = surrogate + args.kl_beta * kl
        denom = vmask.sum().clamp(min=1.0)
        loss = (loss_tok * vmask).sum() / denom

        (loss * scale).backward()

        return {
            "loss": float(loss.detach()),
            "reward": float(rewards.mean()),
            "adv_std": float(rewards.view(B, G).std(dim=1).mean()),
            "kl": float((kl.detach() * vmask).sum() / denom),
            "ratio": float((ratio.detach() * vmask).sum() / denom),
            "gen_len": float(vmask.sum(1).mean()),
        }

    # ---- loop ------------------------------------------------------------- #
    def train_model(self):
        self.policy.eval()          # dropout off: sampled & recomputed log-probs stay aligned
        self.reference.eval()
        n_train = sum(p.numel() for p in self.policy.parameters() if p.requires_grad)
        n_total = sum(p.numel() for p in self.policy.parameters())
        logger.info(f"trainable {n_train / 1e6:.2f}M / {n_total / 1e6:.2f}M | "
                    f"pages/step {self.args.pages_per_step} x G {self.args.group_size} = "
                    f"{self.args.pages_per_step * self.args.group_size} rollouts/micro-batch | "
                    f"grad-accum {self.args.grad_accum} | total steps {self.args.steps}")

        data_iter = self._infinite()
        self.optimizer.zero_grad(set_to_none=True)
        agg, micro = defaultdict(float), 0
        t0 = t_start = time.time()

        while self.step < self.args.steps:
            stats = self.train_step(next(data_iter), scale=1.0 / self.args.grad_accum)
            for k, v in stats.items():
                agg[k] += v
            micro += 1
            if micro % self.args.grad_accum:
                continue

            torch.nn.utils.clip_grad_norm_(
                (p for p in self.policy.parameters() if p.requires_grad), self.args.grad_clip)
            self.optimizer.step()
            self.optimizer.zero_grad(set_to_none=True)
            self.step += 1

            if self.step % self.args.log_every == 0:
                n = self.args.grad_accum * self.args.log_every
                now = time.time()
                ips = n / (now - t0)
                eta_s = (now - t_start) / self.step * (self.args.steps - self.step)
                logger.info(
                    f"step {self.step}/{self.args.steps} | loss {agg['loss'] / n:+.4f} | "
                    f"reward {agg['reward'] / n:.4f} | adv_std {agg['adv_std'] / n:.4f} | "
                    f"kl {agg['kl'] / n:.4f} | ratio {agg['ratio'] / n:.3f} | "
                    f"len {agg['gen_len'] / n:.0f} | {ips:.2f} it/s | "
                    f"ETA {time.strftime('%H:%M:%S', time.gmtime(eta_s))}")
                agg, t0 = defaultdict(float), now

            if (self.val_loader is not None and self.args.eval_every
                    and self.step % self.args.eval_every == 0):
                self._eval_and_save()

        if self.val_loader is not None:
            self._eval_and_save()
        self._save(os.path.join(self.args.output_dir, "last.pt"))
        total = time.strftime("%H:%M:%S", time.gmtime(time.time() - t_start))
        logger.info(f"training complete -- {self.step} steps in {total} | best gold_edit_sim {self.best:.4f}")

    def _eval_and_save(self):
        m = self.evaluate()
        logger.info(f"[eval@{self.step}] gold_edit_sim {m['gold_edit_sim']:.4f} (n={m['n']})")
        if m["gold_edit_sim"] > self.best:
            self.best = m["gold_edit_sim"]
            self._save(os.path.join(self.args.output_dir, "best.pt"))
            logger.info(f"  saved best (gold_edit_sim {self.best:.4f})")

    @torch.no_grad()
    def evaluate(self):
        """Greedy free-running gold_edit_sim -- the metric Phase 4 optimizes."""
        self.policy.eval()
        sims, n, cap = [], 0, self.args.max_eval_samples
        for batch in self.val_loader:
            batch = self._to_device(batch)
            gen = self.policy.generate_markdown(
                batch["pixel_values"], batch["ocr_boxes"], batch["order"],
                box_mask=batch["box_mask"], max_new_tokens=self.args.max_new_tokens)
            for b in range(gen.size(0)):
                gold = _clean_labels(batch["labels"][b].tolist(), self.cfg.eos_token_id, data.IGNORE_INDEX)
                pred = _clean_generated(gen[b].tolist(), self.cfg.bos_token_id,
                                        self.cfg.eos_token_id, self.cfg.pad_token_id)
                sims.append(edit_similarity(pred, gold))
                n += 1
            if cap and n >= cap:
                break
        return {"gold_edit_sim": sum(sims) / max(len(sims), 1), "n": len(sims)}

    def _save(self, path):
        torch.save({"model": self.policy.state_dict(), "step": self.step, "best": self.best}, path)
        logger.info(f"saved checkpoint -> {path}")


# --------------------------------------------------------------------------- #
# CLI
# --------------------------------------------------------------------------- #
@click.command(context_settings={"show_default": True})
# data
@click.option("--train-parquet", type=click.Path(), default=None)
@click.option("--test-parquet", type=click.Path(), default=None, help="eval set for gold_edit_sim")
@click.option("--pdf-dir", type=click.Path(), default=None)
@click.option("--backbone", default="docling-project/docling-layout-heron")
@click.option("--max-len", type=int, default=2048)
@click.option("--max-boxes", type=int, default=None, help="drop pages with more boxes (caps rollout cost)")
# init
@click.option("--init-from", type=click.Path(), default=None,
              help="formatter checkpoint (Phase-2 or Phase-3) to start GRPO from (REQUIRED unless --smoke)")
# GRPO
@click.option("--pages-per-step", type=int, default=4, help="P: distinct pages per micro-batch")
@click.option("--group-size", type=int, default=8, help="G: rollouts sampled per page")
@click.option("--temperature", type=float, default=1.0)
@click.option("--kl-beta", type=float, default=0.02, help="strength of the KL leash to the init formatter")
@click.option("--clip-eps", type=float, default=0.2)
@click.option("--max-new-tokens", type=int, default=768)
# optim
@click.option("--lr", type=float, default=2e-6)
@click.option("--weight-decay", type=float, default=0.0)
@click.option("--grad-accum", type=int, default=1)
@click.option("--grad-clip", type=float, default=1.0)
@click.option("--dropout", type=float, default=0.1)
@click.option("--steps", type=int, default=2000, help="total optimizer steps")
# runtime
@click.option("--num-workers", type=int, default=8)
@click.option("--device", default="cuda" if torch.cuda.is_available() else "cpu")
@click.option("--seed", type=int, default=42)
@click.option("--output-dir", type=click.Path(), default="./runs/grpo_fmt")
@click.option("--log-every", type=int, default=10)
@click.option("--eval-every", type=int, default=100, help="gold_edit_sim eval every N steps (0 = off)")
@click.option("--eval-batch-size", type=int, default=8)
@click.option("--max-eval-samples", type=int, default=256, help="cap eval to the first N test samples")
@click.option("--smoke", is_flag=True)
def main(**kwargs):
    args = SimpleNamespace(**kwargs)

    if args.smoke:
        args.device = "cpu"
        args.steps = 3
        args.pages_per_step, args.group_size, args.grad_accum = 2, 4, 1
        args.max_new_tokens, args.num_workers = 24, 0
        args.log_every, args.eval_every, args.eval_batch_size = 1, 2, 4
        args.max_eval_samples = 8
        args.output_dir = "./runs/grpo_fmt_smoke"
    elif not args.init_from:
        raise click.UsageError("--init-from (a formatter checkpoint) is required, or use --smoke")
    elif not (args.train_parquet and args.pdf_dir):
        raise click.UsageError("--train-parquet and --pdf-dir are required (or use --smoke)")

    os.makedirs(args.output_dir, exist_ok=True)
    log_path = os.path.join(args.output_dir, "train.log")
    logger.remove()
    logger.add(sys.stderr, format="<green>{time:YYYY-MM-DD HH:mm:ss}</green> | <level>{level: <8}</level> | {message}")
    logger.add(log_path, format="{time:YYYY-MM-DD HH:mm:ss} | {level: <8} | {message}",
               rotation="50 MB", encoding="utf-8")
    logger.info(f"logging to {log_path} | device={args.device} smoke={args.smoke}")

    torch.manual_seed(args.seed)
    device = torch.device(args.device)

    policy, cfg = build_model(args, device)
    reference = build_reference(policy, cfg, device)
    train_loader, val_loader = build_dataloaders(args)

    trainer = Stage4GRPOTrainer(policy, reference, train_loader, val_loader, cfg, args, device)
    trainer.train_model()


if __name__ == "__main__":
    main()
