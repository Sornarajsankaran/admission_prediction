"""
Test: the RT-DETR-v2 decoder query self-attention must NOT let real OCR-box
queries attend to padded queries.

Core invariant being checked
----------------------------
``H_box`` for a page's real boxes must be *identical* whether or not the page is
padded with extra (degenerate) boxes -- padding is an artifact of ragged
batching and must be invisible to real boxes.

The test is self-validating: it also shows that with the mask DISABLED
(``box_mask=None``, the old behavior) the real boxes' H_box is contaminated by
the padding. So a pass proves the mask is both correct *and* necessary.

Runs on CPU with a tiny, randomly-initialized RT-DETR-v2 (no checkpoint
download). Run directly::

    python tests/test_box_self_attention_mask.py

or under pytest (``test_*`` function is discoverable).
"""

from __future__ import annotations

import sys
from pathlib import Path

import torch

# ---- locate repo root ---------------------------------------------------
_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(_ROOT / "scripts"))

from transformers import RTDetrV2Config, RTDetrV2Model  # noqa: E402

from modeling_ocr_reconstruction import (  # noqa: E402
    OcrReconstructionConfig,
    OcrTextReconstructionModel,
)


def _build_tiny_model(seed: int = 0) -> OcrTextReconstructionModel:
    """A small, random-weight model -- enough to exercise encode_boxes on CPU."""
    torch.manual_seed(seed)

    # Shrink RT-DETR-v2 so the backbone/encoder/decoder are cheap. hidden_sizes'
    # last three entries must equal encoder_in_channels (backbone out channels).
    backbone_cfg = {
        "model_type": "rt_detr_resnet",
        "depths": [1, 1, 1, 1],
        "embedding_size": 16,
        "hidden_sizes": [32, 64, 128, 256],
        "layer_type": "bottleneck",
        "out_features": ["stage2", "stage3", "stage4"],
    }
    rt_cfg = RTDetrV2Config(
        d_model=64,
        encoder_hidden_dim=64,
        decoder_in_channels=[64, 64, 64],
        encoder_in_channels=[64, 128, 256],
        feat_strides=[8, 16, 32],
        num_feature_levels=3,
        decoder_layers=3,
        decoder_attention_heads=8,
        decoder_ffn_dim=128,
        decoder_n_points=4,
        num_queries=30,
        num_denoising=0,
        num_labels=2,
        backbone_config=backbone_cfg,
    )
    rtdetr = RTDetrV2Model(rt_cfg)
    # Mirror production: no box refinement, reference points pinned to OCR boxes.
    rtdetr.decoder.bbox_embed = None
    rtdetr.decoder.class_embed = None

    cfg = OcrReconstructionConfig(
        d_model=64,
        content_mlp_hidden_dim=64,
        num_markdown_layers=2,
        markdown_attention_heads=8,
        markdown_ffn_dim=128,
    )
    # opt out of the version guard: this test is exactly what you run on a *new*
    # transformers version to decide whether the pin can be bumped.
    model = OcrTextReconstructionModel(cfg, rtdetr=rtdetr, strict_transformers_version=False)
    model.eval()  # dropout off -> deterministic, comparable outputs
    return model


def _random_boxes(n: int, seed: int) -> torch.Tensor:
    """n valid xyxy boxes in [0, 1] (x1<x2, y1<y2)."""
    g = torch.Generator().manual_seed(seed)
    xy1 = torch.rand(n, 2, generator=g) * 0.5
    wh = torch.rand(n, 2, generator=g) * 0.5 + 0.01
    return torch.cat([xy1, xy1 + wh], dim=-1)  # (n, 4)


@torch.no_grad()
def test_padding_does_not_contaminate_h_box():
    model = _build_tiny_model()

    n_real, n_pad = 5, 12
    img = torch.randn(1, 3, 64, 64)
    real_boxes = _random_boxes(n_real, seed=1)

    # --- reference: n real boxes, NO padding -------------------------------- #
    h_ref = model.encode_boxes(
        img, real_boxes.unsqueeze(0),
        box_mask=torch.ones(1, n_real, dtype=torch.bool),
    )[0, :n_real]  # (n_real, d)

    # --- padded batch (real boxes + degenerate zero boxes, as collate_fn) --- #
    padded_boxes = torch.zeros(1, n_real + n_pad, 4)
    padded_boxes[0, :n_real] = real_boxes
    box_mask = torch.zeros(1, n_real + n_pad, dtype=torch.bool)
    box_mask[0, :n_real] = True

    # fixed path: mask on -> padding invisible to real boxes
    h_masked = model.encode_boxes(img, padded_boxes, box_mask=box_mask)[0, :n_real]
    # buggy path: no self-attn mask -> real boxes attend to padding
    h_unmasked = model.encode_boxes(img, padded_boxes, box_mask=None)[0, :n_real]

    fixed_diff = (h_masked - h_ref).abs().max().item()
    bug_diff = (h_unmasked - h_ref).abs().max().item()

    print(f"[masked]   max|H_padded - H_ref| = {fixed_diff:.3e}  (want ~0)")
    print(f"[unmasked] max|H_padded - H_ref| = {bug_diff:.3e}  (want >> 0)")

    # 1. The fix: masked H_box for real boxes matches the no-padding reference.
    assert fixed_diff < 1e-4, (
        f"padding still leaks into real boxes with the mask on: {fixed_diff:.3e}"
    )
    # 2. Sensitivity: without the mask, padding demonstrably contaminates H_box,
    #    proving the mask is doing real work (and the test would catch a regression).
    assert bug_diff > 1e-3, (
        f"unmasked run should be contaminated but wasn't ({bug_diff:.3e}); "
        "test cannot prove the mask matters"
    )
    print("PASS: padding is invisible to real boxes iff the self-attention mask is applied.")


@torch.no_grad()
def test_patched_self_attn_matches_stock_when_unmasked():
    """The patched SDPA self-attention must reproduce HF's stock attention math
    exactly when no mask is applied -- otherwise a transformers upgrade that
    changes RT-DETR's self-attention could silently diverge from our reimpl."""
    model = _build_tiny_model()
    mha = model.rtdetr.decoder.layers[0].self_attn  # .forward is our patch

    B, T, d = 2, 9, mha.num_heads * mha.head_dim
    torch.manual_seed(7)
    hidden = torch.randn(B, T, d)
    pos = torch.randn(B, T, d)

    patched, _ = mha(hidden, attention_mask=None, position_embeddings=pos)
    # call the un-patched class method directly to get the stock result
    stock, _ = type(mha).forward(mha, hidden, attention_mask=None, position_embeddings=pos)

    diff = (patched - stock).abs().max().item()
    print(f"[equivalence] max|patched - stock| = {diff:.3e}  (want ~0)")
    assert diff < 1e-5, f"patched self-attention diverged from stock: {diff:.3e}"
    print("PASS: patched self-attention matches HF stock math (mask=None).")


if __name__ == "__main__":
    test_padding_does_not_contaminate_h_box()
    test_patched_self_attn_matches_stock_when_unmasked()
