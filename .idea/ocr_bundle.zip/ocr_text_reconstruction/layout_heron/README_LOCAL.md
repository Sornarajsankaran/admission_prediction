# Layout Heron Local Architecture Copy

This directory contains a local copy of the PyTorch architecture code used by
`docling-project/docling-layout-heron`.

The Heron Hugging Face model config declares:

- `architectures`: `RTDetrV2ForObjectDetection`
- `model_type`: `rt_detr_v2`
- backbone `model_type`: `rt_detr_resnet`
- `num_queries`: `300`
- `decoder_layers`: `6`
- layout labels: `17`

## Files

- `heron_config.json` - downloaded model config from Hugging Face.
- `preprocessor_config.json` - downloaded image processor config from Hugging Face.
- `HERON_MODEL_CARD.md` - downloaded Hugging Face model card.
- `modeling_rt_detr_v2.py` - full generated Transformers PyTorch implementation.
- `configuration_rt_detr_v2.py` - RT-DETRv2 config class.
- `modular_rt_detr_v2.py` - shorter modular source used to generate the full model file.
- `modeling_rt_detr_resnet.py` - ResNet backbone implementation used by the Heron config.
- `configuration_rt_detr_resnet.py` - ResNet backbone config class.
- `image_processing_rt_detr.py` - image preprocessing and detection post-processing.

## Good Entry Points

- `modeling_rt_detr_v2.py:1810` - `RTDetrV2ForObjectDetection`
- `modeling_rt_detr_v2.py:1367` - `RTDetrV2Model`
- `modeling_rt_detr_v2.py:1045` - `RTDetrV2HybridEncoder`
- `modeling_rt_detr_v2.py:563` - `RTDetrV2Decoder`
- `modeling_rt_detr_v2.py:346` - `RTDetrV2DecoderLayer`
- `modeling_rt_detr_resnet.py:325` - `RTDetrResNetBackbone`

## Notes

These files were copied from the installed local `transformers==4.57.6`
package. The copied code is for exploration; importing these files directly as a
standalone package will need their relative `transformers` imports adjusted or
the code moved into a package layout matching Transformers.
