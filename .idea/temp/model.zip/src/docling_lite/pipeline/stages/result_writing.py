from pathlib import Path

import pandas as pd
from docling_core.types.doc import DocItem, DoclingDocument

from docling_lite.core.config import (
    COLUMNS_TO_SAVE,
    DOCLING_DOCUMENT_FILE_TYPE,
    EXPORT_MARKDOWN_FILES,
    MARKDOWN_CONTENT_LAYERS,
    PAGE_MARKDOWN_PLACEHOLDER,
    RESULTS_DF_FILE_TYPE,
)
from docling_lite.core.logging import log_function_calls, logger


class ResultWriter:
    def __init__(self, output_dir: Path, batch_name: str):
        self.output_dir = Path(output_dir)
        self.batch_name = batch_name
        self.df_file_type = RESULTS_DF_FILE_TYPE
        self.docling_document_file_type = DOCLING_DOCUMENT_FILE_TYPE
        self.results_columns_to_save = COLUMNS_TO_SAVE
        self.export_markdown_files = EXPORT_MARKDOWN_FILES
        self.page_break_placeholder = PAGE_MARKDOWN_PLACEHOLDER
        self.markdown_content_layers = MARKDOWN_CONTENT_LAYERS

        self.docs_dir = self.output_dir / f"{self.batch_name}_docling_documents"
        self.markdown_dir = self.output_dir / f"{self.batch_name}_markdown"
        self.processed_df_path = (
            self.output_dir
            / f"{self.batch_name}_docling_lite_results.{RESULTS_DF_FILE_TYPE}"
        )

        self.output_dir.mkdir(parents=True, exist_ok=True)
        self.docs_dir.mkdir(parents=True, exist_ok=True)
        if self.export_markdown_files:
            self.markdown_dir.mkdir(parents=True, exist_ok=True)

    def _save_documents(self, documents: dict[str, DoclingDocument]) -> None:
        for file_name, document in documents.items():
            safe_name = Path(file_name).name
            out_path = self.docs_dir / f"{safe_name}.{self.docling_document_file_type}"

            if self.docling_document_file_type == "json":
                document.save_as_json(out_path)
            elif self.docling_document_file_type == "yaml":
                document.save_as_yaml(out_path)
            else:
                raise ValueError(
                    f"Unsupported document file type '{self.docling_document_file_type}'."
                )

            logger.info(f"Saved DoclingDocument for '{file_name}' to {out_path}")

    def _save_processed_df(self, processed_df: pd.DataFrame) -> None:
        missing_columns = [
            column
            for column in self.results_columns_to_save
            if column not in processed_df.columns
        ]
        if missing_columns:
            raise KeyError(
                "Processed dataframe is missing required columns: "
                + ", ".join(missing_columns)
            )

        output_df = processed_df.loc[:, self.results_columns_to_save].copy()

        if self.df_file_type == "parquet":
            output_df.to_parquet(self.processed_df_path, index=False)
        elif self.df_file_type == "csv":
            output_df.to_csv(self.processed_df_path, index=False)
        elif self.df_file_type == "pkl":
            output_df.to_pickle(self.processed_df_path)
        else:
            raise ValueError(
                f"Unsupported dataframe file type '{self.df_file_type}'."
            )
        logger.info(f"Saved processed dataframe to {self.processed_df_path}")

    # ── Page-level markdown ───────────────────────────────────────────

    def _markdown_for_doc(
        self, doc: DoclingDocument
    ) -> tuple[dict[int, str], str]:
        """Export the full document once, split by the page-break placeholder,
        and return both the per-page map and the full clean markdown.

        Page breaks are only emitted between pages that contain content in the
        configured layers (matching docling's export behavior), so we walk the
        doc in the same order to pair each chunk with its page_no. The full
        markdown is reconstructed by rejoining the stripped chunks so the
        output has no leftover placeholder artifacts.
        """
        full_md = doc.export_to_markdown(
            page_break_placeholder=self.page_break_placeholder,
            included_content_layers=self.markdown_content_layers,
        )
        chunks = [chunk.strip() for chunk in full_md.split(self.page_break_placeholder)]

        pages_in_order: list[int] = []
        prev: int | None = None
        for item, _lvl in doc.iterate_items(
            with_groups=False,
            included_content_layers=self.markdown_content_layers,
        ):
            if isinstance(item, DocItem) and item.prov:
                page_no = item.prov[0].page_no
                if prev is None or page_no > prev:
                    pages_in_order.append(page_no)
                    prev = page_no

        if len(chunks) != len(pages_in_order) and pages_in_order:
            logger.warning(
                f"Markdown chunk/page mismatch for '{doc.name}': "
                f"{len(chunks)} chunks vs {len(pages_in_order)} content-bearing pages. "
                "Pairing by order; trailing unmatched entries will be dropped."
            )

        page_markdown: dict[int, str] = {page_no: "" for page_no in doc.pages.keys()}
        for page_no, chunk in zip(pages_in_order, chunks):
            page_markdown[page_no] = chunk

        full_markdown = "\n\n".join(chunk for chunk in chunks if chunk)
        return page_markdown, full_markdown

    def _build_markdown_maps(
        self, documents: dict[str, DoclingDocument]
    ) -> tuple[dict[tuple[str, int], str], dict[str, str]]:
        page_markdown: dict[tuple[str, int], str] = {}
        document_markdown: dict[str, str] = {}
        for file_name, document in documents.items():
            per_page, full_md = self._markdown_for_doc(document)
            for page_no, markdown in per_page.items():
                page_markdown[(file_name, int(page_no))] = markdown
            document_markdown[file_name] = full_md
        return page_markdown, document_markdown

    @staticmethod
    def _add_page_markdown_column(
        processed_df: pd.DataFrame,
        page_markdown: dict[tuple[str, int], str],
    ) -> pd.DataFrame:
        output_df = processed_df.copy()
        keys = zip(
            output_df["file_name"].astype(str),
            output_df["page"].astype(int),
        )
        output_df["page_markdown"] = [page_markdown.get(key) for key in keys]
        return output_df

    def _save_document_markdown_files(
        self, document_markdown: dict[str, str]
    ) -> None:
        written = 0
        for file_name, markdown in document_markdown.items():
            if not markdown:
                continue
            out_path = self.markdown_dir / f"{Path(file_name).stem}.md"
            out_path.write_text(markdown, encoding="utf-8")
            written += 1
        logger.info(
            f"Saved {written} document markdown file(s) to {self.markdown_dir}"
        )

    @log_function_calls(logger)
    def save_results(
        self,
        documents: dict[str, DoclingDocument],
        processed_df: pd.DataFrame,
    ) -> None:
        self._save_documents(documents)

        page_markdown, document_markdown = self._build_markdown_maps(documents)
        enriched_df = self._add_page_markdown_column(processed_df, page_markdown)
        self._save_processed_df(enriched_df)

        if self.export_markdown_files:
            self._save_document_markdown_files(document_markdown)
