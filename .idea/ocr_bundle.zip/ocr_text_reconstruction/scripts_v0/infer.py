"""
Inference for the two-stage OCR text reconstruction (order decoder + markdown formatter).
=========================================================================================

Given a page image + its OCR boxes/texts, reconstruct the Markdown in two stages:

    1. OcrOrderingModel.generate_order  -> a reading-order permutation over the boxes.
    2. OcrMarkdownFormatterModel.generate_markdown(order) -> a structural token stream over
       the fixed vocab {17 specials, EMIT_NEXT}. Each EMIT_NEXT places the NEXT box in
       reading order; every other id is a literal markdown token (data.SPECIAL_ID_TO_STR).

Rendering splices the real OCR text back in: the k-th EMIT_NEXT -> ocr_texts[order[k]].
Coverage and reading order are structural (exactly one EMIT_NEXT per box, in order), so
every box you pass appears exactly once.

Checkpoints (each may be a standalone dump OR an OcrTwoStageModel/Phase-3 dump):
    --order-ckpt     : Phase-1 OcrOrderingModel, or a two-stage dump (uses its ``order.*``).
    --formatter-ckpt : Phase-4 OcrMarkdownFormatterModel (GRPO), or a two-stage dump
                       (uses its ``formatter.*``); Phase-4 is the intended one.

IMPORTANT: at inference there is NO box compaction. Feed every OCR box you have, in the
SAME order as ocr_texts, boxes normalized to [0, 1] xyxy (exactly as training data was).
The predicted order and every EMIT_NEXT index directly into that list.
"""

from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

import click
import torch

import data
from modeling_ocr_reconstruction import (
    OcrReconstructionConfig, OcrOrderingModel, OcrMarkdownFormatterModel)


# --------------------------------------------------------------------------- #
# Checkpoint loading (handles standalone and two-stage/Phase-3 dumps)
# --------------------------------------------------------------------------- #
def _load_state(path, device):
    ck = torch.load(path, map_location=device)
    return ck["model"] if isinstance(ck, dict) and "model" in ck else ck


def _strip_prefix(state, prefix):
    """Return the sub-state under ``prefix.`` (stripped) if this is an OcrTwoStageModel dump;
    otherwise return it unchanged (already a standalone checkpoint). The two-stage dump carries
    the tied encoder under BOTH prefixes, so ``formatter.*`` / ``order.*`` are each complete."""
    p = prefix + "."
    if any(k.startswith(p) for k in state):
        return {k[len(p):]: v for k, v in state.items() if k.startswith(p)}
    return state


def load_models(order_ckpt, formatter_ckpt, device,
                backbone: str = "docling-project/docling-layout-heron"):
    """Build the order decoder + markdown formatter and load their weights."""
    cfg = OcrReconstructionConfig(backbone_name_or_path=backbone)
    order = OcrOrderingModel(cfg).to(device).eval()
    formatter = OcrMarkdownFormatterModel(cfg).to(device).eval()

    oi = order.load_state_dict(_strip_prefix(_load_state(order_ckpt, device), "order"), strict=False)
    fi = formatter.load_state_dict(_strip_prefix(_load_state(formatter_ckpt, device), "formatter"), strict=False)
    print(f"order     load: missing {len(oi.missing_keys)}, unexpected {len(oi.unexpected_keys)}")
    print(f"formatter load: missing {len(fi.missing_keys)}, unexpected {len(fi.unexpected_keys)}")
    return order, formatter, cfg


# --------------------------------------------------------------------------- #
# Rendering: structural stream + reading order + OCR texts -> markdown
# --------------------------------------------------------------------------- #
def decode_to_markdown(struct_ids, pred_order, ocr_texts,
                       num_special: int = data.NUM_SPECIAL_TOKENS) -> str:
    """Render the formatter's structural id stream to Markdown text.

    Args:
        struct_ids: model-compact ids over {specials, EMIT_NEXT(=num_special)}.
        pred_order: predicted reading-order permutation (indices into ``ocr_texts``); the
                    k-th EMIT_NEXT resolves to ``ocr_texts[pred_order[k]]``.
        ocr_texts:  the OCR line strings, SAME order as the boxes fed to the model.
    Stops at <eos>; skips <bos>/<pad>.
    """
    emit = num_special
    out, cursor = [], 0
    for m in struct_ids:
        m = int(m)
        if m == 1:               # <eos>
            break
        if m in (0, 2):          # <bos>, <pad>
            continue
        if m == emit:            # place the next box in reading order
            if cursor < len(pred_order):
                idx = int(pred_order[cursor])
                if 0 <= idx < len(ocr_texts):
                    out.append(ocr_texts[idx])
            cursor += 1
        else:                    # literal markdown token
            out.append(data.SPECIAL_ID_TO_STR.get(m, ""))
    return "".join(out)


def _pad_boxes(boxes_list, device):
    """Pad a list of ``(N_i, 4)`` box arrays (N may differ per page) to a single
    ``(B, maxN, 4)`` tensor + a ``(B, maxN)`` bool mask (True for real boxes).
    Mirrors ``data.md_collate_fn`` so batched inference matches training exactly."""
    tensors = [torch.as_tensor(b, dtype=torch.float32) for b in boxes_list]
    counts = [t.size(0) for t in tensors]
    max_n = max(counts) if counts else 0
    boxes = torch.zeros(len(tensors), max_n, 4, dtype=torch.float32)
    box_mask = torch.zeros(len(tensors), max_n, dtype=torch.bool)
    for i, (t, n) in enumerate(zip(tensors, counts)):
        boxes[i, :n] = t
        box_mask[i, :n] = True
    return boxes.to(device), box_mask.to(device)


@torch.no_grad()
def reconstruct_batch(order_model, formatter, images, ocr_boxes_list, ocr_texts_list,
                      image_processor, device, max_new_tokens: int = 1024,
                      sample: bool = False, temperature: float = 1.0):
    """Reconstruct Markdown for a BATCH of pages in one forward pass.

    All three inputs are parallel lists, one entry per page:
        images:          list of PIL.Image (pages).
        ocr_boxes_list:  list of ``(N_i, 4)`` arrays, x1,y1,x2,y2 normalized to [0,1]
                         (the box count N_i may differ per page -- padded internally).
        ocr_texts_list:  list of N_i-length string lists, SAME order as that page's boxes.
        sample:          if True, draw the structural stream by multinomial sampling at
                         ``temperature`` (KV-cached ``sample_markdown``) instead of greedy
                         argmax. Coverage/order remain structural either way (exactly one
                         EMIT_NEXT per box, in reading order), so sampling only varies the
                         formatting tokens -- every box is still placed exactly once.
        temperature:     softmax temperature for sampling (ignored when ``sample=False``).
    Returns a list of Markdown strings, one per page.
    """
    pixel_values = image_processor(images=list(images), return_tensors="pt")["pixel_values"].to(device)
    boxes, box_mask = _pad_boxes(ocr_boxes_list, device)                     # (B,maxN,4), (B,maxN)

    # stage 1: reading order over each page's boxes (padding ignored via box_mask)
    pred_order, n_real = order_model.generate_order(
        pixel_values=pixel_values, ocr_boxes=boxes, box_mask=box_mask, boxes_are_xyxy=True)

    # stage 2: structural markdown stream conditioned on that order (greedy or sampled)
    if sample:
        struct_ids, _, _ = formatter.sample_markdown(
            pixel_values=pixel_values, ocr_boxes=boxes, order=pred_order,
            box_mask=box_mask, boxes_are_xyxy=True, max_new_tokens=max_new_tokens,
            temperature=temperature)
    else:
        struct_ids = formatter.generate_markdown(
            pixel_values=pixel_values, ocr_boxes=boxes, order=pred_order,
            box_mask=box_mask, boxes_are_xyxy=True, max_new_tokens=max_new_tokens)

    out = []
    for b, texts in enumerate(ocr_texts_list):
        k = int(n_real[b])                                                  # real boxes on this page
        out.append(decode_to_markdown(struct_ids[b].tolist(), pred_order[b, :k].tolist(), texts))
    return out


@torch.no_grad()
def reconstruct(order_model, formatter, image, ocr_boxes_xyxy_norm, ocr_texts,
                image_processor, device, max_new_tokens: int = 1024,
                sample: bool = False, temperature: float = 1.0) -> str:
    """Single-page convenience wrapper over :func:`reconstruct_batch`.

    Args:
        image:               PIL.Image (page).
        ocr_boxes_xyxy_norm: (N, 4) list/array, x1,y1,x2,y2 normalized to [0,1].
        ocr_texts:           list of N strings, SAME order as the boxes.
        sample/temperature:  greedy by default; set ``sample=True`` for temperature sampling.
    """
    return reconstruct_batch(order_model, formatter, [image], [ocr_boxes_xyxy_norm], [ocr_texts],
                             image_processor, device, max_new_tokens=max_new_tokens,
                             sample=sample, temperature=temperature)[0]


# --------------------------------------------------------------------------- #
# CLI: run on one or more PDF pages (batched). Wire your own OCR source where marked.
# --------------------------------------------------------------------------- #
def _parse_pages(spec: str) -> list:
    """Parse a page spec ('0', '0,2,5', '0-3', or a mix like '0-2,5') into a sorted,
    de-duplicated list of 0-based page indices."""
    pages = []
    for part in str(spec).split(","):
        part = part.strip()
        if not part:
            continue
        if "-" in part:
            a, b = part.split("-", 1)
            pages.extend(range(int(a), int(b) + 1))
        else:
            pages.append(int(part))
    return sorted(dict.fromkeys(pages))


@click.command(context_settings={"show_default": True})
@click.option("--order-ckpt", required=True, type=click.Path(exists=True),
              help="Phase-1 order model or a Phase-3 two-stage dump")
@click.option("--formatter-ckpt", required=True, type=click.Path(exists=True),
              help="Phase-4 formatter (GRPO) or a Phase-3 two-stage dump")
@click.option("--pdf", required=True, type=click.Path(exists=True))
@click.option("--pages", default="0", help="page index/range, e.g. '0', '0,2,5', or '0-3' (batched)")
@click.option("--backbone", default="docling-project/docling-layout-heron")
@click.option("--zoom", type=float, default=2.0)
@click.option("--max-new-tokens", type=int, default=1024)
@click.option("--sample/--no-sample", default=False, help="temperature-sample the structural stream instead of greedy")
@click.option("--temperature", type=float, default=1.0, help="sampling temperature (only used with --sample)")
@click.option("--device", default="cuda" if torch.cuda.is_available() else "cpu")
def main(order_ckpt, formatter_ckpt, pdf, pages, backbone, zoom, max_new_tokens, sample, temperature, device):
    import fitz

    device = torch.device(device)
    order_model, formatter, _ = load_models(order_ckpt, formatter_ckpt, device, backbone=backbone)
    image_processor = data.load_image_processor(backbone)

    doc = fitz.open(pdf)
    page_idxs = _parse_pages(pages)
    images = [data.rasterize_page(doc[p], zoom=zoom) for p in page_idxs]

    # ---- your OCR output per page -------------------------------------------
    # boxes normalized to [0,1] xyxy, in the SAME order as ocr_texts. Replace the
    # placeholder below with your OCR engine's output; build one (boxes, texts) pair
    # per requested page so the lists line up with ``images``.
    ocr_boxes = [
        [0.10, 0.05, 0.90, 0.09],
        [0.10, 0.12, 0.45, 0.15],
        [0.55, 0.12, 0.90, 0.15],
    ]
    ocr_texts = ["Patient Details", "Name: John", "Age: 45"]
    boxes_list = [ocr_boxes for _ in page_idxs]
    texts_list = [ocr_texts for _ in page_idxs]
    # -------------------------------------------------------------------------

    markdowns = reconstruct_batch(order_model, formatter, images, boxes_list, texts_list,
                                  image_processor, device, max_new_tokens=max_new_tokens,
                                  sample=sample, temperature=temperature)
    for p, md in zip(page_idxs, markdowns):
        print(f"===== page {p} =====")
        print(md)


if __name__ == "__main__":
    main()
