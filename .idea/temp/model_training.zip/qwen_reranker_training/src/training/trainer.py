"""Training utilities for Qwen reranker."""
from __future__ import annotations

import json
import math
from pathlib import Path
from typing import Dict, Optional, Sequence

import torch
from torch.cuda.amp import GradScaler, autocast
from torch.nn.utils import clip_grad_norm_
from torch.utils.data import DataLoader

from ..utils import AverageMeter, compute_metrics, confusion_matrix_figure, get_logger

LOGGER = get_logger(__name__)


class Trainer:
    """Encapsulates the full training loop with MLflow logging."""

    def __init__(
        self,
        model: torch.nn.Module,
        optimizer: torch.optim.Optimizer,
        train_loader: DataLoader,
        val_loader: DataLoader,
        device: torch.device,
        num_epochs: int,
        grad_accum_steps: int,
        max_grad_norm: Optional[float],
        output_dir: Path,
        scheduler: Optional[torch.optim.lr_scheduler.LambdaLR] = None,
        mlflow_client: Optional[object] = None,
        start_epoch: int = 0,
        use_bf16: bool = False,
        artifact_paths: Optional[Sequence[Path]] = None,
    ) -> None:
        self.model = model
        self.optimizer = optimizer
        self.scheduler = scheduler
        self.train_loader = train_loader
        self.val_loader = val_loader
        self.device = device
        self.num_epochs = num_epochs
        self.grad_accum_steps = grad_accum_steps
        self.max_grad_norm = max_grad_norm
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(parents=True, exist_ok=True)
        self.mlflow_client = mlflow_client
        self.start_epoch = start_epoch
        self.criterion = torch.nn.BCEWithLogitsLoss()
        self.autocast_enabled = device.type == "cuda"
        self.autocast_dtype = torch.bfloat16 if use_bf16 else torch.float16
        self.scaler = GradScaler(enabled=self.autocast_enabled and not use_bf16)
        self.artifact_paths = [Path(p) for p in (artifact_paths or [])]
        self.best_state = {
            "auroc": float("-inf"),
            "f1": float("-inf"),
            "loss": float("inf"),
        }
        self.best_predictions: Optional[Sequence[float]] = None
        self.best_targets: Optional[Sequence[int]] = None

    def _forward_batch(self, inputs, targets):
        context = autocast(enabled=self.autocast_enabled, dtype=self.autocast_dtype)
        with context:
            logits = self.model(**inputs)
            logit_diff = logits[:, 1] - logits[:, 0]
            loss = self.criterion(logit_diff, targets)
        return loss, logit_diff

    def train_epoch(self, dataloader: DataLoader) -> Dict[str, float]:
        self.model.train()
        loss_meter = AverageMeter()
        logits_all, targets_all = [], []
        self.optimizer.zero_grad(set_to_none=True)
        steps_processed = 0
        for step, (inputs, targets) in enumerate(dataloader):
            loss, logit_diff = self._forward_batch(inputs, targets)
            scaled_loss = loss / self.grad_accum_steps
            self.scaler.scale(scaled_loss).backward()
            if (step + 1) % self.grad_accum_steps == 0:
                self._optimizer_step()
            steps_processed += 1
            loss_meter.update(loss.detach().item(), inputs["input_ids"].size(0))
            logits_all.extend(logit_diff.detach().cpu().tolist())
            targets_all.extend(targets.detach().cpu().tolist())
        # Handle remainder gradients
        if steps_processed and steps_processed % self.grad_accum_steps != 0:
            self._optimizer_step()
        metrics = compute_metrics(logits_all, targets_all)
        metrics["loss"] = loss_meter.average
        return metrics

    def _optimizer_step(self) -> None:
        if self.scaler.is_enabled():
            self.scaler.unscale_(self.optimizer)
        if self.max_grad_norm is not None:
            clip_grad_norm_(self.model.parameters(), self.max_grad_norm)
        if self.scaler.is_enabled():
            self.scaler.step(self.optimizer)
            self.scaler.update()
        else:
            self.optimizer.step()
        self.optimizer.zero_grad(set_to_none=True)
        if self.scheduler is not None:
            self.scheduler.step()

    def eval_epoch(self, dataloader: DataLoader) -> Dict[str, float]:
        self.model.eval()
        loss_meter = AverageMeter()
        logits_all, targets_all = [], []
        with torch.no_grad():
            for inputs, targets in dataloader:
                loss, logit_diff = self._forward_batch(inputs, targets)
                loss_meter.update(loss.item(), inputs["input_ids"].size(0))
                logits_all.extend(logit_diff.detach().cpu().tolist())
                targets_all.extend(targets.detach().cpu().tolist())
        metrics = compute_metrics(logits_all, targets_all)
        metrics["loss"] = loss_meter.average
        metrics["logits"] = logits_all
        metrics["targets"] = targets_all
        return metrics

    def _is_better(self, current: Dict[str, float]) -> bool:
        if current["auroc"] > self.best_state["auroc"]:
            return True
        if math.isclose(current["auroc"], self.best_state["auroc"], rel_tol=1e-6):
            if current["f1"] > self.best_state["f1"]:
                return True
            if math.isclose(current["f1"], self.best_state["f1"], rel_tol=1e-6):
                return current["loss"] < self.best_state["loss"]
        return False

    def _log_mlflow(self, metrics: Dict[str, float], prefix: str, step: int) -> None:
        if self.mlflow_client is None:
            return
        loggable = {f"{prefix}_{k}": float(v) for k, v in metrics.items() if isinstance(v, (int, float))}
        if loggable:
            self.mlflow_client.log_metrics(loggable, step=step)

    def _save_checkpoint(self, epoch: int, best: bool) -> None:
        checkpoint = {
            "model": self.model.state_dict(),
            "optimizer": self.optimizer.state_dict(),
            "epoch": epoch,
        }
        torch.save(checkpoint, self.output_dir / "last_model.pt")
        if best:
            torch.save(self.model.state_dict(), self.output_dir / "best_model.pt")

    def _log_artifacts(self, paths: Sequence[Path]) -> None:
        if self.mlflow_client is None:
            return
        for path in paths:
            if path.exists():
                self.mlflow_client.log_artifact(str(path))

    def train_model(self) -> None:
        for epoch in range(self.start_epoch, self.num_epochs):
            epoch_num = epoch + 1
            train_metrics = self.train_epoch(self.train_loader)
            val_metrics = self.eval_epoch(self.val_loader)
            LOGGER.info(
                "Epoch %d | train_loss=%.4f val_loss=%.4f val_f1=%.4f val_auroc=%.4f",
                epoch_num,
                train_metrics["loss"],
                val_metrics["loss"],
                val_metrics["f1"],
                val_metrics["auroc"],
            )
            self._log_mlflow(train_metrics, "train", epoch_num)
            self._log_mlflow(val_metrics, "val", epoch_num)
            is_best = self._is_better(val_metrics)
            if is_best:
                self.best_state = {
                    "auroc": val_metrics["auroc"],
                    "f1": val_metrics["f1"],
                    "loss": val_metrics["loss"],
                }
                self.best_predictions = val_metrics["logits"]
                self.best_targets = val_metrics["targets"]
            self._save_checkpoint(epoch_num, is_best)
        summary = {
            "best": self.best_state,
            "epochs_completed": self.num_epochs,
        }
        summary_path = self.output_dir / "training_summary.json"
        summary_path.write_text(json.dumps(summary, indent=2))
        confusion_path = self.output_dir / "confusion_matrix.png"
        if self.best_predictions is not None and self.best_targets is not None:
            pred_labels = [1 if x >= 0 else 0 for x in self.best_predictions]
            confusion_matrix_figure(self.best_targets, pred_labels, confusion_path)
        artifact_list = self.artifact_paths + [summary_path, confusion_path]
        self._log_artifacts(artifact_list)
        if self.mlflow_client is not None:
            best_metrics = {f"best_{k}": v for k, v in self.best_state.items()}
            self.mlflow_client.log_metrics(best_metrics, step=self.num_epochs)
