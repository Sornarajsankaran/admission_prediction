from dataclasses import dataclass
from enum import Enum
from pathlib import Path
from typing import Tuple

from docling_core.types.doc.page import BoundingRectangle, CoordOrigin
class Device(str, Enum):
    CPU = "cpu"
    GPU = "gpu"

    @property
    def torch_device(self) -> str:
        return "cuda" if self is Device.GPU else "cpu"


class DType(str, Enum):
    FULL_FP_32 = "full_fp_32"
    MP_BF16 = "mp_bf16"

    @property
    def is_mixed_precision(self) -> bool:
        return self is DType.MP_BF16


@dataclass(slots=True)
class JobConfig:
    ocr_df_path: Path
    pdf_dir: Path
    output_dir: Path
    batch_name: str
    layout_model_name_or_path: str
    table_model_name_or_path: str
    layout_batch_size: int = 128
    table_batch_size: int = 64
    device: Device = Device.CPU
    dtype: DType = DType.FULL_FP_32


class TextractBBox(BoundingRectangle):
    @staticmethod
    def from_string(coords: str, page_size: Tuple[int, int]) -> "TextractBBox":

        page_width, page_height = page_size

        try:
            x1, y1, x2, y2 = map(float, coords.split(","))
        except Exception:
            raise ValueError("Invalid coords string. Expected format: 'x1,y1,x2,y2'")

        # denormalise coordinates (Textract provides normalized coordinates)
        x1 *= page_width
        y1 *= page_height
        x2 *= page_width
        y2 *= page_height

        return TextractBBox(
            r_x0=x1, r_y0=y1, 
            r_x1=x2, r_y1=y1,  
            r_x2=x2, r_y2=y2,  
            r_x3=x1, r_y3=y2,  
            coord_origin = CoordOrigin.TOPLEFT # Textract coordinates origin is top-left
        )
