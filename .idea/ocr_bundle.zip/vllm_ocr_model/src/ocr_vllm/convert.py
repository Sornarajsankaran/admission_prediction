"""
Training checkpoint(s) -> vLLM model directory.
===============================================

Accepted inputs (``torch.save`` files written by the training scripts):

  * a combined two-stage checkpoint (stage 3): keys ``order.*`` and ``formatter.*``
  * an order-model checkpoint (stage 1) and a formatter checkpoint (stage 2 or the
    GRPO stage 4), given separately
  * a combined checkpoint plus a formatter checkpoint that replaces its formatter

Each file may hold the bare ``state_dict`` or ``{"model": state_dict, ...}`` /
``{"state_dict": state_dict, ...}``. The training checkpoints do not store the model
config, so every dimension is inferred from tensor shapes; only the number of decoder
attention heads cannot be inferred (default 8, ``--decoder-heads``).

The shared RT-DETR box encoder is taken from the order checkpoint by default (as in
``stage_3_train._init_two_stage``); ``--encoder-from formatter`` takes it from the
formatter checkpoint instead.

    ocr-vllm-convert --model best.pt --out /cache/model
    ocr-vllm-convert --order order.pt --formatter grpo.pt --out /cache/model
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
from pathlib import Path

import torch

ASSETS = Path(__file__).with_name("assets")
HERON_DIR = ASSETS / "heron"
ENCODER_PREFIXES = ("rtdetr.", "box_content_mlp.", "box_input_norm.")


# --------------------------------------------------------------------------- #
# Loading / assembling the reference state dict
# --------------------------------------------------------------------------- #
def load_state_dict(path: str | os.PathLike) -> dict[str, torch.Tensor]:
    blob = torch.load(path, map_location="cpu", weights_only=False)
    if isinstance(blob, dict):
        for key in ("model", "state_dict"):
            if isinstance(blob.get(key), dict):
                return blob[key]
    if not isinstance(blob, dict):
        raise ValueError(f"{path}: expected a state dict, got {type(blob).__name__}")
    return blob


def checkpoint_kind(sd: dict) -> str:
    if any(k.startswith("order.") for k in sd) and any(k.startswith("formatter.") for k in sd):
        return "combined"
    if "order_bos" in sd and any(k.startswith("order_decoder.") for k in sd):
        return "order"
    if "cursor_done" in sd and any(k.startswith("markdown_decoder.") for k in sd):
        return "formatter"
    raise ValueError("unrecognised checkpoint: expected a two-stage, order-model or "
                     "formatter-model state dict")


def assemble(model: str | None = None, order: str | None = None, formatter: str | None = None,
             encoder_from: str = "order") -> dict[str, torch.Tensor]:
    """Build one ``OcrTwoStageModel``-style state dict (``order.*`` / ``formatter.*``)."""
    if not (model or (order and formatter)):
        raise ValueError("give --model (combined checkpoint) or both --order and --formatter")
    sd: dict[str, torch.Tensor] = {}

    def part(path, want):
        s = load_state_dict(path)
        kind = checkpoint_kind(s)
        if kind == "combined":
            return {k[len(want) + 1:]: v for k, v in s.items() if k.startswith(want + ".")}
        if kind != want:
            raise ValueError(f"{path} is a {kind} checkpoint, expected {want} (or combined)")
        return s

    if model:
        s = load_state_dict(model)
        if checkpoint_kind(s) != "combined":
            raise ValueError(f"--model {model} is not a combined two-stage checkpoint; "
                             "use --order/--formatter for single-stage checkpoints")
        sd.update(s)
    if order:
        sd = {k: v for k, v in sd.items() if not k.startswith("order.")}
        sd.update({"order." + k: v for k, v in part(order, "order").items()})
    if formatter:
        f = part(formatter, "formatter")
        sd = {k: v for k, v in sd.items()
              if not (k.startswith("formatter.") and not k[len("formatter."):].startswith(ENCODER_PREFIXES))}
        sd.update({"formatter." + k: v for k, v in f.items()})
    if encoder_from == "formatter":
        for k in [k for k in sd if k.startswith("order.") and k[6:].startswith(ENCODER_PREFIXES)]:
            del sd[k]
        sd.update({"order." + k[len("formatter."):]: v for k, v in sd.items()
                   if k.startswith("formatter.") and k[len("formatter."):].startswith(ENCODER_PREFIXES)})
    return sd


# --------------------------------------------------------------------------- #
# Reference names -> ocr_vllm names
# --------------------------------------------------------------------------- #
_LAYER_RENAMES = {
    "self_attn.in_proj_weight": "qkv.weight",
    "self_attn.in_proj_bias": "qkv.bias",
    "self_attn.out_proj.weight": "self_out.weight",
    "self_attn.out_proj.bias": "self_out.bias",
    "multihead_attn.out_proj.weight": "cross_out.weight",
    "multihead_attn.out_proj.bias": "cross_out.bias",
}


def _convert_layers(sd, src, dst, d, out):
    pat = re.compile(rf"^{re.escape(src)}\.(\d+)\.(.+)$")
    for name, w in sd.items():
        m = pat.match(name)
        if not m:
            continue
        i, rest = m.groups()
        base = f"{dst}.{i}."
        if rest in _LAYER_RENAMES:
            out[base + _LAYER_RENAMES[rest]] = w
        elif rest.startswith("multihead_attn.in_proj_"):
            kind = rest.rsplit("_", 1)[1]
            out[base + f"cross_q.{kind}"] = w[:d]
            out[base + f"cross_kv.{kind}"] = w[d:]
        else:
            out[base + rest] = w


def convert_state_dict(sd: dict, d: int) -> dict[str, torch.Tensor]:
    out = {}
    for name, w in sd.items():
        if name.startswith("order.") and name[6:].startswith(ENCODER_PREFIXES):
            out["encoder." + name[len("order."):]] = w
    out["order_bos"] = sd["order.order_bos"].reshape(1, d)
    out["order.pos_embedding"] = sd["order.pos_embedding"]
    out["order.norm.weight"] = sd["order.decoder_norm.weight"]
    out["order.norm.bias"] = sd["order.decoder_norm.bias"]
    out["pointer_key_proj.weight"] = sd["order.pointer_key_proj.weight"]
    _convert_layers(sd, "order.order_decoder.layers", "order.layers", d, out)

    out["formatter.pos_embedding"] = sd["formatter.pos_embedding"]
    out["formatter.norm.weight"] = sd["formatter.decoder_norm.weight"]
    out["formatter.norm.bias"] = sd["formatter.decoder_norm.bias"]
    out["token_embedding.weight"] = sd["formatter.token_embedding.weight"]
    out["cursor_done"] = sd["formatter.cursor_done"].reshape(1, d)
    out["head.weight"] = sd["formatter.head.weight"]
    out["head.bias"] = sd["formatter.head.bias"]
    _convert_layers(sd, "formatter.markdown_decoder.layers", "formatter.layers", d, out)

    out = {(k if k.startswith("encoder.") else "decoder." + k): v for k, v in out.items()}
    return {k: v.detach().float().contiguous().clone() for k, v in out.items()}


def infer_dims(sd: dict) -> dict:
    """Model dimensions from tensor shapes (training checkpoints carry no config)."""
    pos = sd["order.pos_embedding"]
    layer_ids = {int(m.group(1)) for k in sd
                 if (m := re.match(r"^order\.order_decoder\.layers\.(\d+)\.", k))}
    mlp_ids = {int(m.group(1)) for k in sd
               if (m := re.match(r"^order\.box_content_mlp\.layers\.(\d+)\.weight$", k))}
    return dict(
        d_model=pos.shape[-1],
        stage_max_positions=pos.shape[1],
        num_decoder_layers=len(layer_ids),
        decoder_ffn_dim=sd["order.order_decoder.layers.0.linear1.weight"].shape[0],
        content_mlp_hidden_dim=sd["order.box_content_mlp.layers.0.weight"].shape[0],
        content_mlp_num_layers=len(mlp_ids),
        num_special_tokens=sd["formatter.token_embedding.weight"].shape[0] - 1,
    )


# --------------------------------------------------------------------------- #
# Writing the vLLM model directory
# --------------------------------------------------------------------------- #
def write_model_dir(sd: dict, out: Path, *, dtype: str = "bfloat16", decoder_heads: int = 8,
                    max_boxes: int = 1024, max_format_tokens: int | None = None) -> Path:
    from safetensors.torch import save_file
    from transformers import AutoConfig

    from .config import OcrTwoStageConfig

    dims = infer_dims(sd)
    rtdetr_cfg = AutoConfig.from_pretrained(str(HERON_DIR)).to_dict()
    if rtdetr_cfg.get("d_model") != dims["d_model"]:
        raise ValueError(f"checkpoint d_model {dims['d_model']} != Heron RT-DETR d_model "
                         f"{rtdetr_cfg.get('d_model')}")
    cfg = OcrTwoStageConfig(
        **dims,
        decoder_attention_heads=decoder_heads,
        max_boxes=max_boxes,
        max_format_tokens=max_format_tokens or dims["stage_max_positions"],
        rtdetr_config=rtdetr_cfg,
        encoder_dtype=dtype,
        architectures=["OcrTwoStageForConditionalGeneration"],
    )
    cfg.torch_dtype = dtype
    cfg.dtype = dtype
    out.mkdir(parents=True, exist_ok=True)
    cfg.save_pretrained(out)
    (out / "generation_config.json").write_text(json.dumps(
        {"bos_token_id": cfg.ord_bos_id, "eos_token_id": cfg.eos_token_id,
         "decoder_start_token_id": cfg.ord_bos_id, "pad_token_id": cfg.pad_token_id}, indent=2))
    tensors = convert_state_dict(sd, dims["d_model"])
    save_file(tensors, out / "model.safetensors")
    return out


def is_model_dir(path: str | os.PathLike) -> bool:
    p = Path(path)
    return p.is_dir() and (p / "config.json").exists() and (p / "model.safetensors").exists()


def cached_convert(cache_dir: str | os.PathLike, *, model=None, order=None, formatter=None,
                   encoder_from="order", dtype="bfloat16", decoder_heads=8, max_boxes=1024) -> Path:
    """Convert once per distinct input (paths + sizes + mtimes + options); reuse after."""
    key = hashlib.sha1()
    for p in (model, order, formatter):
        if p:
            st = os.stat(p)
            key.update(f"{os.path.abspath(p)}:{st.st_size}:{int(st.st_mtime)}".encode())
    key.update(f"{encoder_from}:{dtype}:{decoder_heads}:{max_boxes}".encode())
    out = Path(cache_dir) / f"ocr_vllm_{key.hexdigest()[:16]}"
    if is_model_dir(out):
        return out
    sd = assemble(model, order, formatter, encoder_from)
    tmp = out.with_name(out.name + ".tmp")
    write_model_dir(sd, tmp, dtype=dtype, decoder_heads=decoder_heads, max_boxes=max_boxes)
    tmp.rename(out)
    return out


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--model", help="combined two-stage checkpoint (stage 3)")
    ap.add_argument("--order", help="order-model checkpoint (stage 1) or combined")
    ap.add_argument("--formatter", help="formatter checkpoint (stage 2 / GRPO stage 4) or combined")
    ap.add_argument("--encoder-from", choices=["order", "formatter"], default="order")
    ap.add_argument("--dtype", choices=["bfloat16", "float32"], default="bfloat16")
    ap.add_argument("--decoder-heads", type=int, default=8)
    ap.add_argument("--max-boxes", type=int, default=1024)
    ap.add_argument("--out", required=True)
    a = ap.parse_args(argv)
    sd = assemble(a.model, a.order, a.formatter, a.encoder_from)
    out = write_model_dir(sd, Path(a.out), dtype=a.dtype, decoder_heads=a.decoder_heads,
                          max_boxes=a.max_boxes)
    print(f"wrote {out} ({infer_dims(sd)})")


if __name__ == "__main__":
    main()
