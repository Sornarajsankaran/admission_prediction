"""RT-DETR-v2 box encoder: (page image, OCR boxes) -> H_box (K, d_model).

A self-contained copy of ``BoxEncoderMixin.encode_boxes`` from
``scripts_v0.1/modeling_ocr_reconstruction.py`` so the serving package does not import
the training code. Parameter names (``rtdetr.*``, ``box_content_mlp.*``,
``box_input_norm.*``) match the reference checkpoint, and
``tests/test_vllm_parity.py`` checks this module against the reference.
"""

from __future__ import annotations

import types

import torch
import torch.nn as nn
import torch.nn.functional as F
from transformers import RTDetrV2Config, RTDetrV2Model


def inverse_sigmoid(x: torch.Tensor, eps: float = 1e-5) -> torch.Tensor:
    x = x.clamp(min=0, max=1)
    return torch.log(x.clamp(min=eps) / (1 - x).clamp(min=eps))


def box_xyxy_to_cxcywh(boxes: torch.Tensor) -> torch.Tensor:
    x1, y1, x2, y2 = boxes.unbind(-1)
    return torch.stack(((x1 + x2) * 0.5, (y1 + y2) * 0.5,
                        (x2 - x1).clamp(min=0), (y2 - y1).clamp(min=0)), dim=-1)


class MLP(nn.Module):
    def __init__(self, input_dim: int, hidden_dim: int, output_dim: int, num_layers: int = 3):
        super().__init__()
        dims = [input_dim] + [hidden_dim] * (num_layers - 1) + [output_dim]
        self.layers = nn.ModuleList(nn.Linear(a, b) for a, b in zip(dims[:-1], dims[1:]))

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        for i, layer in enumerate(self.layers):
            x = F.relu(layer(x)) if i < len(self.layers) - 1 else layer(x)
        return x


def _rtdetr_self_attn_forward(self, hidden_states, attention_mask=None,
                              position_embeddings=None, output_attentions=False):
    """RT-DETR-v2 decoder query self-attention with a per-sample key-padding mask
    (identical to the reference ``_rtdetr_self_attn_forward``)."""
    b, t, e = hidden_states.shape
    h, hd = self.num_heads, self.head_dim
    q_in = self.with_pos_embed(hidden_states, position_embeddings)
    q = self.q_proj(q_in).view(b, t, h, hd).transpose(1, 2)
    k = self.k_proj(q_in).view(b, t, h, hd).transpose(1, 2)
    v = self.v_proj(hidden_states).view(b, t, h, hd).transpose(1, 2)
    out = F.scaled_dot_product_attention(q, k, v, attn_mask=attention_mask)
    return self.out_proj(out.transpose(1, 2).reshape(b, t, e)), None


class BoxEncoder(nn.Module):
    def __init__(self, rtdetr_config: dict, d_model: int, content_hidden: int, content_layers: int):
        super().__init__()
        cfg = RTDetrV2Config(**rtdetr_config)
        self.rtdetr = RTDetrV2Model(cfg)
        # Head-less: reference points stay pinned to the OCR boxes across layers.
        self.rtdetr.decoder.bbox_embed = None
        self.rtdetr.decoder.class_embed = None
        # The two-stage proposal heads are never run (queries are the OCR boxes).
        for name in ("enc_output", "enc_score_head", "enc_bbox_head"):
            if hasattr(self.rtdetr, name):
                delattr(self.rtdetr, name)
        for layer in self.rtdetr.decoder.layers:
            layer.self_attn.forward = types.MethodType(_rtdetr_self_attn_forward, layer.self_attn)
        self.box_content_mlp = MLP(4, content_hidden, d_model, content_layers)
        self.box_input_norm = nn.LayerNorm(d_model)

    def image_sources(self, pixel_values: torch.Tensor) -> list[torch.Tensor]:
        """Backbone + hybrid encoder + decoder input projections: the box-independent,
        compute-heavy part (static shapes -> worth torch.compile)."""
        rt = self.rtdetr
        batch_size, _, height, width = pixel_values.shape
        pixel_mask = torch.ones((batch_size, height, width), device=pixel_values.device)
        features = rt.backbone(pixel_values, pixel_mask)
        proj_feats = [rt.encoder_input_proj[lvl](src) for lvl, (src, _m) in enumerate(features)]
        encoder_outputs = rt.encoder(proj_feats, return_dict=True)

        sources = [rt.decoder_input_proj[lvl](src) for lvl, src in enumerate(encoder_outputs[0])]
        if rt.config.num_feature_levels > len(sources):
            n = len(sources)
            sources.append(rt.decoder_input_proj[n](encoder_outputs[0])[-1])
            for i in range(n + 1, rt.config.num_feature_levels):
                sources.append(rt.decoder_input_proj[i](encoder_outputs[0][-1]))
        return sources

    def forward(self, pixel_values: torch.Tensor, ocr_boxes: torch.Tensor,
                box_mask: torch.Tensor, sources: list[torch.Tensor] | None = None) -> torch.Tensor:
        """pixel_values (B,3,H,W), ocr_boxes (B,N,4) xyxy in [0,1], box_mask (B,N) bool
        -> H_box (B, N, d_model). ``sources`` may be precomputed by ``image_sources``."""
        rt = self.rtdetr
        device = pixel_values.device
        batch_size = ocr_boxes.shape[0]
        boxes_cxcywh = box_xyxy_to_cxcywh(ocr_boxes)
        if sources is None:
            sources = self.image_sources(pixel_values)

        source_flatten, spatial_shapes_list = [], []
        spatial_shapes = torch.empty((len(sources), 2), device=device, dtype=torch.long)
        for lvl, source in enumerate(sources):
            h, w = source.shape[-2:]
            spatial_shapes[lvl, 0] = h
            spatial_shapes[lvl, 1] = w
            spatial_shapes_list.append((h, w))
            source_flatten.append(source.flatten(2).transpose(1, 2))
        source_flatten = torch.cat(source_flatten, 1)
        level_start_index = torch.cat(
            (spatial_shapes.new_zeros((1,)), spatial_shapes.prod(1).cumsum(0)[:-1]))

        reference_points = inverse_sigmoid(boxes_cxcywh.to(source_flatten.dtype))
        target = self.box_content_mlp(boxes_cxcywh.to(source_flatten.dtype))
        self_attn_mask = torch.zeros(
            batch_size, 1, 1, boxes_cxcywh.size(1), device=device, dtype=source_flatten.dtype,
        ).masked_fill_(~box_mask[:, None, None, :], float("-inf"))

        decoder_outputs = rt.decoder(
            inputs_embeds=target,
            encoder_hidden_states=source_flatten,
            encoder_attention_mask=self_attn_mask,
            reference_points=reference_points,
            spatial_shapes=spatial_shapes,
            spatial_shapes_list=spatial_shapes_list,
            level_start_index=level_start_index,
            return_dict=True,
        )
        return decoder_outputs.last_hidden_state
