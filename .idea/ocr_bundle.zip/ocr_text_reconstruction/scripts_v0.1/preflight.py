#!/usr/bin/env python3
"""
preflight.py -- validate a training parquet against the v0.1 vocab before launching.
====================================================================================

The dangerous case this exists for: a parquet tokenized with the **v0** tokenizer
loads fine under v0.1 and trains without error, because every old id (10000..10016)
is still a valid id under M=69. The tokens just mean different things now --
10008 was '#' in v0 and is '###' in v0.1, 10011 was '|' and is '######'. You would
burn a full run before noticing.

Run this on the training box first:

    python preflight.py --parquet train.parquet
    python preflight.py --parquet train.parquet --stage 2 --max-len 2048

Exit code is 0 only if the parquet is safe to train on.
"""

from __future__ import annotations

import sys
from collections import Counter

import click
import numpy as np
import pandas as pd

import data

REQUIRED_COLUMNS = ("file_name", "page", "ocr_bbox", "encoded_ouput_ids_raw")

# Tag tokens that only exist in the v0.1 vocab. A corpus of real document pages
# that contains none of these was almost certainly tokenized with v0.
V01_ONLY_TOKENS = ("<TABLE>", "<TD>", "<TR>", "<UL>", "<LI>", "<IMG>", "<SUB>")


def _fail(message: str) -> None:
    click.secho(f"  FAIL  {message}", fg="red")


def _warn(message: str) -> None:
    click.secho(f"  WARN  {message}", fg="yellow")


def _ok(message: str) -> None:
    click.secho(f"  ok    {message}", fg="green")


@click.command()
@click.option("--parquet", "parquet_path", required=True,
              type=click.Path(exists=True, dir_okay=False),
              help="Training parquet (or .pkl) to validate.")
@click.option("--stage", type=click.Choice(["1", "2", "3", "4"]), default="2",
              help="Which stage's target builder to simulate (2/3/4 share one).")
@click.option("--max-len", type=int, default=2048,
              help="max_len the stage script will be launched with.")
@click.option("--sample", type=int, default=20000,
              help="Rows to inspect (0 = all). Full 320K scan is slow.")
def main(parquet_path: str, stage: str, max_len: int, sample: int) -> None:
    path = str(parquet_path)
    df = pd.read_pickle(path) if path.endswith((".pkl", ".pickle")) else pd.read_parquet(path)

    click.echo(f"\n{path}: {len(df):,} rows\n")
    problems = 0

    # ---- 1. columns -------------------------------------------------------
    click.secho("columns", bold=True)
    missing = [c for c in REQUIRED_COLUMNS if c not in df.columns]
    if missing:
        _fail(f"missing {missing}; have {list(df.columns)}")
        problems += 1
    else:
        _ok(f"all present: {list(REQUIRED_COLUMNS)}")

    if missing:
        sys.exit(1)

    if sample and len(df) > sample:
        df = df.sample(sample, random_state=0)
        click.echo(f"  (inspecting a {sample:,}-row sample)")

    base, M = data.GLOBAL_SPECIAL_BASE, data.NUM_SPECIAL_TOKENS

    # ---- 2. id ranges -----------------------------------------------------
    click.secho("\nid ranges", bold=True)
    seen_specials: Counter = Counter()
    out_of_range = 0
    box_over = 0
    lengths, box_counts = [], []

    for raw, bbox in zip(df["encoded_ouput_ids_raw"], df["ocr_bbox"]):
        ids = [int(t) for t in raw]
        lengths.append(len(ids))
        boxes = [t for t in ids if t < base]
        box_counts.append(len(set(boxes)))
        if boxes and max(boxes) >= len(np.asarray(bbox)):
            box_over += 1
        for t in ids:
            if t >= base:
                if t - base >= M:
                    out_of_range += 1
                else:
                    seen_specials[t] += 1

    if out_of_range:
        _fail(f"{out_of_range:,} special ids >= {base + M} (beyond M={M}) -- "
              "parquet was built with a NEWER vocab than this vocab.json")
        problems += 1
    else:
        _ok(f"all special ids inside [{base}, {base + M})")

    if box_over:
        _fail(f"{box_over:,} rows reference a box id >= len(ocr_bbox)")
        problems += 1
    else:
        _ok("every box pointer indexes a real bbox row")

    # ---- 3. vocab provenance ---------------------------------------------
    click.secho("\nvocab provenance", bold=True)
    present = {t for t, name in
               ((data._TOKENS[n], n) for n in V01_ONLY_TOKENS if n in data._TOKENS)
               if seen_specials.get(t)}
    if present:
        _ok(f"v0.1-only tokens found ({len(present)}/{len(V01_ONLY_TOKENS)}) -- "
            "tokenized with the v0.1 tokenizer")
    else:
        _fail("NO v0.1-only token (<TABLE>/<TD>/<UL>/<IMG>/...) appears anywhere. "
              "This parquet was almost certainly built with the v0 tokenizer. "
              "It will train without error and learn the WRONG token meanings "
              "(10008 was '#', is now '###'). Re-tokenize before training.")
        problems += 1

    top = seen_specials.most_common(8)
    click.echo("  most common specials: " + ", ".join(
        f"{data.SPECIAL_ID_TO_STR.get(t - base, t)!r}x{c:,}" for t, c in top))

    # ---- 4. bbox normalization -------------------------------------------
    click.secho("\nbbox normalization", bold=True)
    sample_bboxes = np.concatenate(
        [np.asarray(b, dtype=float).reshape(-1, 4) for b in df["ocr_bbox"].head(2000)]
    )
    lo, hi = float(sample_bboxes.min()), float(sample_bboxes.max())
    if hi > 1.5:
        _fail(f"bbox max is {hi:.1f} -- expected coords normalized to [0, 1]")
        problems += 1
    else:
        _ok(f"bbox range [{lo:.3f}, {hi:.3f}]")

    # ---- 5. what the stage builder will actually keep ---------------------
    click.secho(f"\nstage {stage} target build (max_len={max_len})", bold=True)
    builder = data.build_order_example if stage == "1" else data.build_markdown_example
    reasons: Counter = Counter()
    for raw, bbox in zip(df["encoded_ouput_ids_raw"], df["ocr_bbox"]):
        n_boxes = len(np.asarray(bbox))
        if stage == "1":
            _, reason = builder(n_boxes, [int(t) for t in raw])
        else:
            _, reason = builder(n_boxes, [int(t) for t in raw], max_len=max_len)
        reasons[reason] += 1

    kept = reasons["ok"]
    total = sum(reasons.values())
    for reason, count in reasons.most_common():
        line = f"  {reason:28s} {count:7,}  ({100 * count / total:5.1f}%)"
        click.secho(line, fg="green" if reason == "ok" else "yellow")

    if kept / total < 0.90:
        _warn(f"only {100 * kept / total:.1f}% of rows survive")
        if reasons.get("too_long"):
            _warn(f"raise --max-len: {reasons['too_long']:,} rows exceed {max_len}")

    # ---- 6. length distribution ------------------------------------------
    click.secho("\nsequence lengths", bold=True)
    arr = np.array(lengths)
    pcts = [50, 90, 95, 99, 99.9]
    click.echo("  " + "  ".join(f"p{p}={int(np.percentile(arr, p)):,}" for p in pcts)
               + f"  max={arr.max():,}")
    click.echo("  boxes/page: " + "  ".join(
        f"p{p}={int(np.percentile(box_counts, p)):,}" for p in pcts))
    for candidate in (2048, 3072, 4096, 6144):
        share = 100 * (arr <= candidate).mean()
        click.echo(f"    max_len {candidate:5d} keeps {share:5.1f}%")

    # ---- verdict ----------------------------------------------------------
    click.echo()
    if problems:
        click.secho(f"NOT SAFE TO TRAIN -- {problems} blocking problem(s).", fg="red", bold=True)
        sys.exit(1)
    click.secho("OK to train.", fg="green", bold=True)


if __name__ == "__main__":
    main()
