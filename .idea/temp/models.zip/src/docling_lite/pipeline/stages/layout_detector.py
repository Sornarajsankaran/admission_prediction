import gc
import fitz
import torch
import pandas as pd
from tqdm import tqdm
from itertools import islice
from typing import Iterator
from transformers import RTDetrForObjectDetection, RTDetrImageProcessor
from docling.datamodel.base_models import Cluster, LayoutPrediction
from docling.datamodel.pipeline_options import LayoutOptions
from docling_core.types.doc import BoundingBox, CoordOrigin, DocItemLabel
from docling.utils.layout_postprocessor import LayoutPostprocessor
from docling_lite.core.config import (
    LAYOUT_DPI,
    LAYOUT_MODEL_CONFIG,
    LAYOUT_POSTPROCESS_CONFIG,
)
from docling_lite.core.logging import log_function_calls, logger
from docling_lite.utils.rasterize import rasterize_page


class LayoutDetector:
    def __init__(
        self,
        model_name_or_path: str,
        is_mixed_precision: bool = False,
        device: str = "cuda",
        layout_batch_size: int = 128,
        dpi: int = LAYOUT_DPI,
        threshold: float | None = None,
    ):
        self.device = torch.device(device)
        self.is_mixed_precision = is_mixed_precision
        self.model_name_or_path = model_name_or_path
        self.batch_size = int(layout_batch_size)
        self.dpi = int(dpi)
        self.threshold = float(
            LAYOUT_MODEL_CONFIG["threshold"] if threshold is None else threshold
        )
        self.model = None
        self.processor = None
        self._label_map: dict[int, DocItemLabel] = {}

    @log_function_calls(logger)
    def _load_model_files(self):
        logger.info(
            f"Loading layout detection model: {self.model_name_or_path} on device: {self.device}"
        )

        model_kwargs = {}
        attn_implementation = LAYOUT_MODEL_CONFIG.get("attn_implementation")
        if attn_implementation:
            model_kwargs["attn_implementation"] = attn_implementation

        model = RTDetrForObjectDetection.from_pretrained(
            self.model_name_or_path,
            **model_kwargs,
        ).to(self.device).eval()

        self._label_map = self._build_label_map(model.config.id2label)
        if LAYOUT_MODEL_CONFIG.get("torch_compile", False):
            model = torch.compile(model)

        self.model = model
        self.processor = RTDetrImageProcessor.from_pretrained(self.model_name_or_path)

    def _build_label_map(self, id_to_label: dict[object, object]) -> dict[int, DocItemLabel]:
        label_map: dict[int, DocItemLabel] = {}
        for label_id, label_name in id_to_label.items():
            enum_name = (
                str(label_name).upper().replace(" ", "_").replace("-", "_").strip()
            )
            if enum_name in DocItemLabel.__members__:
                label_map[int(label_id)] = DocItemLabel[enum_name]
            else:
                label_map[int(label_id)] = DocItemLabel.TEXT
        return label_map

    def _iter_batches(
        self,
        pdf_pages: list[fitz.Page],
    ) -> Iterator[tuple[dict[str, torch.Tensor], torch.Tensor]]:
        if self.processor is None:
            raise RuntimeError("Layout processor is not loaded.")
        if self.batch_size <= 0:
            raise ValueError("batch_size must be > 0")

        pages_iter = iter(pdf_pages)
        while batch := list(islice(pages_iter, self.batch_size)):
            images = [rasterize_page(page, dpi=self.dpi) for page in batch]
            inputs = self.processor(images=images, return_tensors="pt")
            target_sizes = torch.tensor(
                [[img.height, img.width] for img in images],
                dtype=torch.int64,
            )
            yield inputs, target_sizes

    def _label_from_id(self, label_id: int) -> DocItemLabel:
        return self._label_map.get(int(label_id), DocItemLabel.TEXT)

    @staticmethod
    def _scale_bbox_to_page_space(
        box: list[float],
        page_width: float,
        page_height: float,
        image_width: float,
        image_height: float,
    ) -> BoundingBox:
        scale_x = page_width / max(image_width, 1e-6)
        scale_y = page_height / max(image_height, 1e-6)
        return BoundingBox(
            l=float(box[0]) * scale_x,
            t=float(box[1]) * scale_y,
            r=float(box[2]) * scale_x,
            b=float(box[3]) * scale_y,
            coord_origin=CoordOrigin.TOPLEFT,
        )

    def _build_layout_clusters(
        self,
        prediction: dict[str, torch.Tensor],
        page_width: float,
        page_height: float,
        image_width: float,
        image_height: float,
    ) -> list[Cluster]:
        labels = prediction["labels"].detach().cpu().tolist()
        scores = prediction["scores"].detach().cpu().tolist()
        boxes = prediction["boxes"].detach().cpu().tolist()

        clusters: list[Cluster] = []
        for idx, (label_id, score, box) in enumerate(zip(labels, scores, boxes)):
            bbox = self._scale_bbox_to_page_space(
                box=box,
                page_width=page_width,
                page_height=page_height,
                image_width=image_width,
                image_height=image_height,
            )
            clusters.append(
                Cluster(
                    id=idx,
                    label=self._label_from_id(int(label_id)),
                    confidence=float(score),
                    bbox=bbox,
                    cells=[],
                )
            )
        return clusters

    @log_function_calls(logger)
    def detect_layout(self, processed_df: pd.DataFrame) -> pd.DataFrame:
        
        try:
            self._load_model_files()

            pdf_pages = processed_df["pdf_page_obj"].tolist()
            batches = self._iter_batches(pdf_pages=pdf_pages)
            
            raw_layout_predictions = []
            for batch_inputs, target_sizes in tqdm(batches, desc="Detecting layout", unit="batch"):
                pixel_values = batch_inputs["pixel_values"].to(self.device)

                with torch.inference_mode():
                    if self.is_mixed_precision and self.device.type == "cuda":
                        with torch.autocast(device_type="cuda", dtype=torch.bfloat16):
                            outputs = self.model(pixel_values=pixel_values)
                    else:
                        outputs = self.model(pixel_values=pixel_values)

                batch_predictions = self.processor.post_process_object_detection(
                    outputs,
                    target_sizes=target_sizes,
                    threshold=self.threshold,
                )
                batch_predictions = [
                    {key: tensor.cpu() for key, tensor in prediction.items()}
                    for prediction in batch_predictions
                ]
                raw_layout_predictions.extend(zip(batch_predictions, target_sizes.cpu()))

            assert len(raw_layout_predictions) == len(processed_df), (
                f"Layout prediction count ({len(raw_layout_predictions)}) does not "
                f"match number of pages ({len(processed_df)}); cannot align predictions to pages."
            )

            for page, (prediction, image_size) in zip(
                processed_df["docling_page_obj"], raw_layout_predictions
            ):
                image_height = float(image_size[0].item())
                image_width = float(image_size[1].item())
                clusters = self._build_layout_clusters(
                    prediction=prediction,
                    page_width=float(page.size.width),
                    page_height=float(page.size.height),
                    image_width=image_width,
                    image_height=image_height,
                )
                page.predictions.layout = LayoutPrediction(clusters=clusters)

            return self._post_process_layout_clusters(processed_df)
        finally:
            self._unload_model()

    @staticmethod
    def _build_layout_postprocess_options() -> LayoutOptions:
        cfg = LAYOUT_POSTPROCESS_CONFIG
        return LayoutOptions(
            keep_empty_clusters=bool(cfg.get("keep_empty_clusters", False)),
            skip_cell_assignment=bool(cfg.get("skip_cell_assignment", False)),
            create_orphan_clusters=bool(cfg.get("create_orphan_clusters", False)),
        )

    @staticmethod
    def _normalize_layout_clusters(layout_prediction: object) -> list[Cluster]:
        if layout_prediction is None:
            return []

        if isinstance(layout_prediction, LayoutPrediction):
            return layout_prediction.clusters

        if isinstance(layout_prediction, list):
            return [
                cluster if isinstance(cluster, Cluster) else Cluster.model_validate(cluster)
                for cluster in layout_prediction
            ]

        return LayoutPrediction.model_validate(layout_prediction).clusters

    def _post_process_layout_clusters(self, processed_df: pd.DataFrame) -> pd.DataFrame:
        options = self._build_layout_postprocess_options()

        for page in processed_df["docling_page_obj"]:
            raw_clusters = self._normalize_layout_clusters(page.predictions.layout)
            processed_clusters, _ = LayoutPostprocessor(
                page=page,
                clusters=raw_clusters,
                options=options,
            ).postprocess()
            page.predictions.layout = LayoutPrediction(clusters=processed_clusters)

        return processed_df

    @log_function_calls(logger)
    def _unload_model(self):
        if self.model is None:
            logger.warning("Unload called before loading. Skipping.")
            return

        logger.info("Unloading model and releasing resources.")

        self.model = None
        self.processor = None

        gc.collect()

        if self.device.type == "cuda" and torch.cuda.is_available():
            torch.cuda.synchronize(device=self.device)
            torch.cuda.empty_cache()
            logger.info("CUDA cache cleared.")