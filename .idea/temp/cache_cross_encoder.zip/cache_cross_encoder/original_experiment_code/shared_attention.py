"""Exact grouped-query attention with shared document KV, implemented in Triton.

Query Q/K/V: [documents, groups, query_tokens, heads, head_dim].
Document K/V: [documents, document_tokens, heads, head_dim].
The kernel never repeats or concatenates document KV across query groups.
All Q and K must already have RoPE applied in a common coordinate system:
query position i - true_query_length, document position j.
"""
from __future__ import annotations

import math
import torch
import triton
import triton.language as tl


@triton.autotune(
    configs=[
        triton.Config({"BLOCK_M": 16, "BLOCK_N": 64}, num_warps=4, num_stages=2),
        triton.Config({"BLOCK_M": 32, "BLOCK_N": 64}, num_warps=4, num_stages=2),
        triton.Config({"BLOCK_M": 32, "BLOCK_N": 128}, num_warps=4, num_stages=2),
        triton.Config({"BLOCK_M": 64, "BLOCK_N": 64}, num_warps=4, num_stages=2),
    ],
    key=["QM", "QK", "ND", "HD", "WINDOW"],
)
@triton.jit
def _shared_attention_kernel(
    Q, KQ, VQ, KD, VD, O, QL, DL,
    qsb: tl.constexpr, qsg: tl.constexpr, qst: tl.constexpr, qsh: tl.constexpr,
    kqsb: tl.constexpr, kqsg: tl.constexpr, kqst: tl.constexpr, kqsh: tl.constexpr,
    vqsb: tl.constexpr, vqsg: tl.constexpr, vqst: tl.constexpr, vqsh: tl.constexpr,
    kdsb: tl.constexpr, kdst: tl.constexpr, kdsh: tl.constexpr,
    vdsb: tl.constexpr, vdst: tl.constexpr, vdsh: tl.constexpr,
    osb: tl.constexpr, osg: tl.constexpr, ost: tl.constexpr, osh: tl.constexpr,
    GROUPS: tl.constexpr, HEADS: tl.constexpr,
    QM: tl.constexpr, QK: tl.constexpr, ND: tl.constexpr, HD: tl.constexpr,
    HAS_QL: tl.constexpr, HAS_DL: tl.constexpr,
    Q_START: tl.constexpr, WINDOW: tl.constexpr, SCALE_LOG2: tl.constexpr,
    BLOCK_M: tl.constexpr, BLOCK_N: tl.constexpr, BLOCK_D: tl.constexpr,
):
    rows = tl.program_id(0) * BLOCK_M + tl.arange(0, BLOCK_M)
    group_doc = tl.program_id(1)
    b = group_doc // GROUPS
    g = group_doc % GROUPS
    h = tl.program_id(2)
    qlen = QK
    dlen = ND
    if HAS_QL:
        qlen = tl.load(QL + g)
    if HAS_DL:
        dlen = tl.load(DL + b)
    channels = tl.arange(0, BLOCK_D)
    valid_rows = (rows < QM) & (rows + Q_START < qlen)
    q = tl.load(
        Q + b*qsb + g*qsg + rows[:, None]*qst + h*qsh + channels[None, :],
        mask=valid_rows[:, None] & (channels[None, :] < HD), other=0,
    )
    m_i = tl.full((BLOCK_M,), -float("inf"), tl.float32)
    l_i = tl.zeros((BLOCK_M,), tl.float32)
    acc = tl.zeros((BLOCK_M, BLOCK_D), tl.float32)

    # First source: only this group's private query keys and values.
    for start in range(tl.cdiv(QK, BLOCK_N)):
        cols = start * BLOCK_N + tl.arange(0, BLOCK_N)
        k = tl.load(
            KQ + b*kqsb + g*kqsg + cols[None, :]*kqst + h*kqsh + channels[:, None],
            mask=(cols[None, :] < QK) & (cols[None, :] < qlen) & (channels[:, None] < HD), other=0,
        )
        scores = tl.dot(q, k) * SCALE_LOG2
        allowed = valid_rows[:, None] & (cols[None, :] < QK) & (cols[None, :] < qlen)
        if WINDOW >= 0:
            allowed = allowed & (tl.abs(rows[:, None] + Q_START - cols[None, :]) <= WINDOW)
        scores = tl.where(allowed, scores, -float("inf"))
        m_new = tl.maximum(m_i, tl.max(scores, 1))
        m_new = tl.where(m_new == -float("inf"), 0., m_new)
        alpha = tl.exp2(m_i - m_new)
        p = tl.exp2(scores - m_new[:, None])
        l_i = l_i*alpha + tl.sum(p, 1)
        acc = acc*alpha[:, None]
        v = tl.load(
            VQ + b*vqsb + g*vqsg + cols[:, None]*vqst + h*vqsh + channels[None, :],
            mask=(cols[:, None] < QK) & (cols[:, None] < qlen) & (channels[None, :] < HD), other=0,
        )
        acc = tl.dot(p.to(v.dtype), v, acc)
        m_i = m_new

    # Second source: the document keys/values shared by all query groups.
    # Local query positions are negative, so document keys >= WINDOW cannot
    # be visible to any query token. Avoid loading those tiles entirely.
    DOC_LIMIT: tl.constexpr = ND if WINDOW < 0 else min(ND, WINDOW)
    for start in range(tl.cdiv(DOC_LIMIT, BLOCK_N)):
        cols = start * BLOCK_N + tl.arange(0, BLOCK_N)
        k = tl.load(
            KD + b*kdsb + cols[None, :]*kdst + h*kdsh + channels[:, None],
            mask=(cols[None, :] < ND) & (cols[None, :] < dlen) & (channels[:, None] < HD), other=0,
        )
        scores = tl.dot(q, k) * SCALE_LOG2
        allowed = valid_rows[:, None] & (cols[None, :] < ND) & (cols[None, :] < dlen)
        if WINDOW >= 0:
            allowed = allowed & (tl.abs(rows[:, None] + Q_START - qlen - cols[None, :]) <= WINDOW)
        scores = tl.where(allowed, scores, -float("inf"))
        m_new = tl.maximum(m_i, tl.max(scores, 1))
        m_new = tl.where(m_new == -float("inf"), 0., m_new)
        alpha = tl.exp2(m_i - m_new)
        p = tl.exp2(scores - m_new[:, None])
        l_i = l_i*alpha + tl.sum(p, 1)
        acc = acc*alpha[:, None]
        v = tl.load(
            VD + b*vdsb + cols[:, None]*vdst + h*vdsh + channels[None, :],
            mask=(cols[:, None] < ND) & (cols[:, None] < dlen) & (channels[None, :] < HD), other=0,
        )
        acc = tl.dot(p.to(v.dtype), v, acc)
        m_i = m_new

    out = acc / tl.maximum(l_i[:, None], 1.e-20)
    tl.store(
        O + b*osb + g*osg + rows[:, None]*ost + h*osh + channels[None, :],
        out, mask=(rows[:, None] < QM) & (channels[None, :] < HD),
    )


def shared_attention(
    q: torch.Tensor,
    qk: torch.Tensor,
    qv: torch.Tensor,
    dk: torch.Tensor,
    dv: torch.Tensor,
    query_lengths: torch.Tensor | None = None,
    doc_lengths: torch.Tensor | None = None,
    window: int = -1,
    query_start: int = 0,
    out: torch.Tensor | None = None,
) -> torch.Tensor:
    """Compute joint softmax(query-private KV, shared-document KV).

    `window` is inclusive radius (64 for ModernBERT local_attention=128),
    or -1 for global. `query_lengths` has shape [groups], shared across docs;
    `doc_lengths` has shape [documents]. Length tensors must be on the GPU.
    `query_start` is the original index of q's first receiver in qk/qv. This
    supports final CLS-only output with q.shape[2]==1, query_start=0 while
    qk/qv retain all query tokens. Outputs at padded receiver positions zero.
    Tensors may be strided, but the final head channel must be contiguous.
    """
    if q.ndim != 5 or qk.ndim != 5 or dk.ndim != 4:
        raise ValueError("Expected q/qk/qv [B,G,Q,H,K] and dk/dv [B,D,H,K]")
    b, g, qm, h, hd = q.shape
    qn = qk.shape[2]
    nd = dk.shape[1]
    if qk.shape != qv.shape or qk.shape[:2] != (b,g) or qk.shape[3:] != (h,hd):
        raise ValueError("Query K/V shape mismatch")
    if dk.shape != dv.shape or dk.shape[0] != b or dk.shape[2:] != (h,hd):
        raise ValueError("Document K/V shape mismatch")
    if any(x.stride(-1) != 1 for x in (q,qk,qv,dk,dv)):
        raise ValueError("The last head channel must be contiguous")
    if not q.is_cuda or q.dtype not in (torch.float16, torch.bfloat16):
        raise ValueError("Triton shared attention requires CUDA FP16/BF16 tensors")
    if any(x.dtype != q.dtype or x.device != q.device for x in (qk,qv,dk,dv)):
        raise ValueError("All Q/K/V tensors must share dtype and device")
    if query_lengths is not None and (query_lengths.shape != (g,) or query_lengths.device != q.device):
        raise ValueError("query_lengths must have shape [G] on the Q device")
    if doc_lengths is not None and (doc_lengths.shape != (b,) or doc_lengths.device != q.device):
        raise ValueError("doc_lengths must have shape [B] on the Q device")
    if query_start < 0 or query_start + qm > qn:
        raise ValueError("Receiver span must be within the query key span")
    if out is None:
        out = torch.empty_like(q)
    elif out.shape != q.shape or out.dtype != q.dtype or out.device != q.device or out.stride(-1) != 1:
        raise ValueError("out must match q shape/dtype/device, contiguous last channel")
    grid = lambda meta: (triton.cdiv(qm, meta["BLOCK_M"]), b*g, h)
    _shared_attention_kernel[grid](
        q,qk,qv,dk,dv,out,
        query_lengths if query_lengths is not None else q,
        doc_lengths if doc_lengths is not None else q,
        *q.stride()[:-1], *qk.stride()[:-1], *qv.stride()[:-1],
        *dk.stride()[:-1], *dv.stride()[:-1], *out.stride()[:-1],
        g,h,qm,qn,nd,hd,query_lengths is not None,doc_lengths is not None,
        query_start,window,math.log2(math.e)/math.sqrt(hd),
        BLOCK_D=triton.next_power_of_2(hd),
    )
    return out


def shared_attention_reference(
    q: torch.Tensor,
    qk: torch.Tensor,
    qv: torch.Tensor,
    dk: torch.Tensor,
    dv: torch.Tensor,
    query_lengths: torch.Tensor | None = None,
    doc_lengths: torch.Tensor | None = None,
    window: int = -1,
    query_start: int = 0,
) -> torch.Tensor:
    """Plain FP32 PyTorch oracle; intentionally materializes repeated KV."""
    b,g,qm,h,hd=q.shape
    qn=qk.shape[2]
    nd=dk.shape[1]
    qlens = (torch.full((g,),qn,device=q.device,dtype=torch.long)
             if query_lengths is None else query_lengths)
    dlens = (torch.full((b,),nd,device=q.device,dtype=torch.long)
             if doc_lengths is None else doc_lengths)
    qq=q.permute(0,1,3,2,4).float()
    kk=torch.cat((qk,dk[:,None].expand(-1,g,-1,-1,-1)),2).permute(0,1,3,2,4).float()
    vv=torch.cat((qv,dv[:,None].expand(-1,g,-1,-1,-1)),2).permute(0,1,3,2,4).float()
    qi=torch.arange(qm,device=q.device)+query_start
    ki=torch.arange(qn,device=q.device)
    di=torch.arange(nd,device=q.device)
    maskq=(ki[None,:]<qlens[:,None])[None,:,None,None,:].expand(b,-1,1,qm,-1)
    maskd=(di[None,:]<dlens[:,None])[:,None,None,None,:].expand(-1,g,1,qm,-1)
    if window>=0:
        maskq=maskq & ((qi[:,None]-ki[None,:]).abs()<=window)[None,None,None,:,:]
        maskd=maskd & ((qi[None,:,None]-qlens[:,None,None]-di[None,None,:]).abs()<=window)[None,:,None,:,:]
    mask=torch.cat((maskq,maskd),-1)
    scores=(qq@kk.transpose(-1,-2))/math.sqrt(hd)
    scores=scores.masked_fill(~mask,-torch.inf)
    probs=scores.softmax(-1).nan_to_num(0.)
    result=(probs@vv).permute(0,1,3,2,4)
    result=result* (qi[None,:]<qlens[:,None])[None,:,:,None,None]
    return result.to(q.dtype)


if __name__ == "__main__":
    import argparse
    p=argparse.ArgumentParser()
    p.add_argument("--test", action="store_true")
    args=p.parse_args()
    if not args.test:
        p.error("Pass --test to run CUDA correctness cases")
    torch.manual_seed(7)
    for dtype in (torch.float16,torch.bfloat16):
        for qm,qn,nd in ((41,41,263),(81,81,129),(1,41,263)):
            b,g,h,hd=2,3,12,64
            q=torch.randn(b,g,qm,h,hd,device='cuda',dtype=dtype)
            qk=torch.randn(b,g,qn,h,hd,device='cuda',dtype=dtype)
            qv=torch.randn_like(qk)
            dk=torch.randn(b,nd,h,hd,device='cuda',dtype=dtype)
            dv=torch.randn_like(dk)
            ql=torch.tensor([qn,qn-7,1],device='cuda',dtype=torch.int32)
            dl=torch.tensor([nd,nd-21],device='cuda',dtype=torch.int32)
            for window in (-1,64,0):
                out=shared_attention(q,qk,qv,dk,dv,ql,dl,window)
                ref=shared_attention_reference(q,qk,qv,dk,dv,ql,dl,window)
                err=(out.float()-ref.float()).abs()
                tol=0.02 if dtype==torch.bfloat16 else 0.003
                torch.testing.assert_close(out,ref,atol=tol,rtol=tol)
                print(f'{dtype=} {qm=} {qn=} {nd=} {window=} max_abs={err.max().item():.6f}',flush=True)
