# vllm_ocr_model

High-throughput inference for the two-stage OCR reconstruction model: RT-DETR box encoder →
reading-order decoder → markdown formatter, served by vLLM 0.23. It takes **PDFs plus their
Textract OCR results** and writes one markdown file per page.

On one L40S (48 GB), 15-CPU quota, bf16, 4 engines:
- the model alone: **~79 pages/s** on pages with ~300 OCR lines (pre-rendered images);
- end to end through `ocr-vllm-run` including PDF rendering: **~60–70 pages/s** once all
  engines were up, on a mixed test set (median ~120 lines, some pages up to 1,024);
- startup: about 50 s per engine with a warm cache, one after another (~3 min for 4). The
  first run on a new cache compiles for several minutes more, so mount a persistent cache.

Detailed documentation lives in [`docs/`](docs/README.md): usage, architecture,
performance, validation, and development/troubleshooting.

## Quick start

```bash
make build                                  # docker image vllm-ocr-model:latest
make run PDF_DIR=/data/pdfs \
         OCR_DF=/data/textract.parquet \
         MODEL=/models/stage3/best.pt \
         OUT_DIR=/data/out
```

**First run on a new host:** run the end-to-end self-test. It needs only a few born-digital
PDFs and your checkpoint, no Textract output:

```bash
make selftest PDF_DIR=/data/some_pdfs MODEL=/models/stage3/best.pt
```

It builds the image, derives a Textract-layout OCR dataframe from the PDFs' embedded text
(`tools/pdf_text_to_ocr_df.py`), runs the container on 20 pages with one engine, and fails
unless every page comes back `ok`. The markdown lands in `./selftest/out`. Text-layer lines
differ from Textract lines, so this checks the plumbing, not output quality.

To move the image to a host without registry access, run `make save`, copy the tarball over
and run `make load` there. You can also copy this directory and run `make build` on the
host itself; the build needs network access to pull the base image and pip packages.

## Inputs

**`--pdf-dir`** is a directory of PDFs, searched recursively.

**`--ocr-df`** is the Textract OCR dataframe (`.parquet`, `.pkl`, `.csv` or `.jsonl`), one row
per page:

| column | content |
|---|---|
| `file_name` | PDF name, matched against `pdf-dir` by relative path, base name, or base name + `.pdf` |
| `page` | page number, 1-based by default (`--page-base 0` if yours start at 0) |
| `content` | page text: lines separated by `\n`, words within a line by `\t`. Tabs become spaces in the output |
| `line_cords` | one box per line, separated by `\|`. Each box is `x1,x2,y1,y2` normalized to [0,1]; it is converted to `(x1,y1),(x2,y2)` |

Line *i* of `content` belongs to box *i* of `line_cords`, the same alignment the training
data used. The dataframe's rows are the work list.

**Model** (the training scripts' `torch.save` files; the config is inferred from tensor
shapes):
- `MODEL=` a combined two-stage checkpoint (stage 3, keys `order.*` / `formatter.*`); or
- `ORDER_CKPT=` + `FORMATTER_CKPT=`, e.g. the stage-1 order model plus the stage-4 GRPO
  formatter. The shared RT-DETR encoder comes from the order checkpoint
  (`RUN_ARGS="--encoder-from formatter"` to take it from the formatter).

The checkpoint is converted to a vLLM model directory once and cached in `/cache` (the
Makefile mounts `CACHE_DIR`, default `./.cache`). The `torch.compile` caches go there too,
which makes later starts faster.

## Outputs (`--out-dir`)

```
markdown/<pdf name>/page_0001.md   one file per successfully processed page
results.jsonl                      one line per dataframe row: file_name, page, status,
                                   num_lines, markdown_path, num_tokens, error
results.parquet                    file_name, page, status, markdown
summary.json                       status counts, pages/s, settings
```

Statuses: `ok`, `missing_pdf`, `no_lines`, `line_box_mismatch` (line count ≠ box count),
`bad_cords`, `too_many_boxes` (> `--max-boxes`, default 1024), `duplicate_row` (the same
file and page appeared in an earlier row, which is the one processed), `page_out_of_range`,
`render_error`, `engine_error`, `not_processed`.

## Options

`make run ... RUN_ARGS="..."` passes flags through to `ocr-vllm-run` (full list:
`docker run --rm vllm-ocr-model --help`).

| flag | default | notes |
|---|---|---|
| `--engines` | 4 | vLLM engines sharing the GPU through CUDA MPS; use 2 on 24 GB GPUs |
| `--max-seqs` | 160 | pages in flight per engine |
| `--wave` | 40 | pages admitted to an engine at a time |
| `--gpu-memory` | 0.86 | GPU memory fraction for all engines together |
| `--dtype` | bfloat16 | `float32` matches the training-time model more closely but is slower (31 vs 45 pages/s in an earlier 2-engine measurement) |
| `--preprocess-workers` | from the CPU quota | PDF rendering processes |
| `--raster-zoom` | 2.0 | PDF render scale used in training; lower is faster to render |
| `--block-size` | 32 | vLLM KV-cache block size |
| `--mps` | auto | `auto` = on when `--engines > 1` |
| `--limit N` | | only the first N dataframe rows |
| `--save-order` | | also store each page's predicted reading order |

## Throughput notes

- **GPU:** 4 engines × 160 pages under MPS saturates an L40S at ~79 pages/s (300-line
  pages). MPS needs the driver's `nvidia-cuda-mps-control` in the container, which
  `NVIDIA_DRIVER_CAPABILITIES=compute,utility` (set in the image) provides. Without it the
  engines time-slice the GPU and throughput drops sharply; the log warns when that happens.
- **CPU:** check the container's CPU quota (`cat /sys/fs/cgroup/cpu.max`); it can be far
  below the visible core count. The image pins thread pools to one thread, because bursts
  above the quota trigger cgroup throttling that freezes every process. PDF rendering at
  zoom 2.0 (the training setting) costs ~45 ms of CPU per page, so ~79 pages/s needs ~4
  cores for rendering; each engine uses another ~2. By default the runner sizes
  `--preprocess-workers` from the quota (6 on a 15-core quota with 4 engines). If
  `summary.json` shows fewer pages/s than expected, give the container more CPU.
- **Startup:** engines start one after another (their memory profiling must not overlap),
  and each compiles and captures CUDA graphs. Pages are processed as soon as the first
  engine is ready. `summary.json` reports both the overall rate and the rate once every
  engine was up (`pages_per_s_all_engines`). Keep `CACHE_DIR` between runs; for small
  jobs, fewer engines start faster.

## Requirements

- An NVIDIA GPU with ≥ 24 GB and driver ≥ 580 (CUDA 13). For driver 575–579, build with
  `make build BASE_IMAGE=vllm/vllm-openai:v0.23.0-cu129`.
- Docker with the NVIDIA container toolkit. `make run` passes `--gpus` and `--ipc=host`
  (vLLM's inter-process transfers need large shared memory).

## Layout

```
Dockerfile, Makefile, requirements.txt, pyproject.toml
src/ocr_vllm/
  runner.py     ocr-vllm-run: orchestration (preprocess workers, engines, MPS, outputs)
  inputs.py     OCR dataframe parsing, PDF rendering + Heron preprocessing
  convert.py    ocr-vllm-convert: training checkpoint(s) -> vLLM model directory
  engine.py     vLLM engine construction, request / output helpers
  decode.py     formatter tokens -> markdown (mirrors the training tokenizer's decode)
  model.py      the vLLM model (encoder + both decoders, state kept in KV caches)
  kernels.py    Triton kernels: pointer scores, reading-order cursor, box lookups
  encoder.py    RT-DETR-v2 box encoder (copy of the training code's encode_boxes)
  config.py     model config / token-id layout
  assets/       Heron RT-DETR config + image-processor config, markdown vocab
tests/          CPU unit tests (run during the image build)
tools/pdf_text_to_ocr_df.py   builds a Textract-layout OCR dataframe from a PDF's text
                              layer, for smoke tests without Textract output
```

Version pins: vLLM 0.23.0 (the plugin relies on its KV-cache internals) and transformers
4.57.6 (the RT-DETR attention patch was validated on it). The vocab in `assets/vocab.json`
must be the one the checkpoint was trained with.
