"""
CPU consistency tests for OcrTextReconstructionModel.sample_decode.

No backbone download: the model is built with a stub rt-detr and ``encode_boxes``
is monkeypatched to return a deterministic random H_box, so only the AR decoder /
sampling / masking logic is exercised. The key test is `test_consistency_with_forward`:
the log-probs recorded during sampling must match a teacher-forced forward() pass
(this is the invariant the GRPO importance ratio relies on).

Run:  python test_sample_decode.py        (or: pytest test_sample_decode.py)
"""

from __future__ import annotations

from types import SimpleNamespace

import torch

from backup_code.modeling_ocr_reconstruction import OcrReconstructionConfig, OcrTextReconstructionModel

N_BOXES = 6
SEED_HBOX = 1234


def _build_model():
    """Model with a stubbed backbone; encode_boxes returns a fixed random H_box
    (deterministic across both the rollout and the forward() recompute)."""
    cfg = OcrReconstructionConfig()
    stub = SimpleNamespace(config=SimpleNamespace(d_model=cfg.d_model))
    model = OcrTextReconstructionModel(cfg, rtdetr=stub)

    def fake_encode(pixel_values, ocr_boxes, box_mask=None, pixel_mask=None, boxes_are_xyxy=True):
        g = torch.Generator().manual_seed(SEED_HBOX)
        B, N = ocr_boxes.shape[0], ocr_boxes.shape[1]
        return torch.randn(B, N, cfg.d_model, generator=g)

    model.encode_boxes = fake_encode   # shadows the bound method (called without self)
    model.eval()
    return model, cfg


def _dummy_inputs(B=2, N=N_BOXES):
    pixel_values = torch.zeros(B, 3, 640, 640)   # unused (encode_boxes is stubbed)
    ocr_boxes = torch.rand(B, N, 4)
    box_mask = torch.ones(B, N, dtype=torch.bool)
    return pixel_values, ocr_boxes, box_mask


# --------------------------------------------------------------------------- #
def test_shapes_and_dtypes():
    model, cfg = _build_model()
    pv, boxes, mask = _dummy_inputs(B=2)
    torch.manual_seed(0)
    seq, lp, valid = model.sample_decode(pv, boxes, box_mask=mask, max_new_tokens=20)

    B = pv.size(0)
    assert seq.shape == lp.shape == valid.shape
    assert seq.shape[0] == B
    assert seq.dtype == torch.long
    assert lp.dtype == torch.float32
    assert valid.dtype == torch.bool


def test_bos_column_is_inactive():
    model, cfg = _build_model()
    pv, boxes, mask = _dummy_inputs(B=2)
    torch.manual_seed(0)
    seq, lp, valid = model.sample_decode(pv, boxes, box_mask=mask, max_new_tokens=20)

    assert (seq[:, 0] == cfg.bos_token_id).all()
    assert (~valid[:, 0]).all()
    assert torch.allclose(lp[:, 0], torch.zeros(pv.size(0)))


def test_logprobs_are_nonpositive_on_valid():
    model, _ = _build_model()
    pv, boxes, mask = _dummy_inputs(B=2)
    torch.manual_seed(0)
    _, lp, valid = model.sample_decode(pv, boxes, box_mask=mask, max_new_tokens=20)
    assert (lp[valid] <= 1e-5).all()


def test_pad_and_invalid_after_eos():
    model, cfg = _build_model()
    pv, boxes, mask = _dummy_inputs(B=3)
    torch.manual_seed(0)
    seq, lp, valid = model.sample_decode(pv, boxes, box_mask=mask, max_new_tokens=40)

    for b in range(pv.size(0)):
        v = valid[b]
        if not v.any():
            continue
        last = int(v.nonzero().max())
        tail = slice(last + 1, seq.shape[1])
        # everything past the last valid action is inactive...
        assert (~valid[b, tail]).all()
        # ...and emitted as PAD, with a zero (ignored) log-prob
        assert (seq[b, tail] == cfg.pad_token_id).all()
        assert torch.allclose(lp[b, tail], torch.zeros_like(lp[b, tail]))


def test_consistency_with_forward():
    """Log-probs recorded while sampling must match a teacher-forced recompute."""
    model, _ = _build_model()
    pv, boxes, mask = _dummy_inputs(B=2)

    torch.manual_seed(0)
    seq, old_lp, valid = model.sample_decode(
        pv, boxes, box_mask=mask, max_new_tokens=24, temperature=1.0
    )

    out = model.forward(pv, boxes, decoder_input_ids=seq[:, :-1], box_mask=mask)
    logp = torch.log_softmax(out.logits, dim=-1)              # (B, S-1, V)
    actions = seq[:, 1:]                                      # (B, S-1)
    recomputed = logp.gather(-1, actions.unsqueeze(-1)).squeeze(-1)

    m = valid[:, 1:]
    assert m.any()
    assert torch.allclose(recomputed[m], old_lp[:, 1:][m], atol=1e-4)


def test_low_temperature_matches_greedy():
    """At T -> 0 sampling collapses to argmax, so it must reproduce generate()."""
    model, _ = _build_model()
    pv, boxes, mask = _dummy_inputs(B=2)

    greedy = model.generate(pv, boxes, box_mask=mask, max_new_tokens=24)
    torch.manual_seed(0)
    seq, _, _ = model.sample_decode(
        pv, boxes, box_mask=mask, max_new_tokens=24, temperature=1e-4
    )
    L = min(greedy.shape[1], seq.shape[1])
    assert torch.equal(greedy[:, :L], seq[:, :L])


def test_determinism_with_seed():
    model, _ = _build_model()
    pv, boxes, mask = _dummy_inputs(B=2)

    torch.manual_seed(42)
    s1, l1, v1 = model.sample_decode(pv, boxes, box_mask=mask, max_new_tokens=20)
    torch.manual_seed(42)
    s2, l2, v2 = model.sample_decode(pv, boxes, box_mask=mask, max_new_tokens=20)

    assert torch.equal(s1, s2)
    assert torch.allclose(l1, l2)
    assert torch.equal(v1, v2)


# --------------------------------------------------------------------------- #
if __name__ == "__main__":
    import sys

    tests = [v for k, v in sorted(globals().items())
             if k.startswith("test_") and callable(v)]
    failed = 0
    for fn in tests:
        try:
            fn()
            print(f"PASS  {fn.__name__}")
        except AssertionError as e:
            failed += 1
            print(f"FAIL  {fn.__name__}: {e}")
        except Exception as e:  # noqa: BLE001 - surface setup/runtime errors too
            failed += 1
            print(f"ERROR {fn.__name__}: {type(e).__name__}: {e}")
    print(f"\n{len(tests) - failed}/{len(tests)} passed")
    sys.exit(1 if failed else 0)
