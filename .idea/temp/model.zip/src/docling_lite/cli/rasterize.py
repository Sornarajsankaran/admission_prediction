import sys
import click
from pathlib import Path

from docling_lite.core.config import (
    LAYOUT_DPI,
    RASTER_JPEG_QUALITY,
    RASTER_WORKERS,
)
from docling_lite.core.logging import logger
from docling_lite.pipeline.rasterizer import PdfRasterizer


@click.command()
@click.option(
    "--pdf-dir",
    type=click.Path(exists=True, file_okay=False, path_type=Path),
    required=True,
)
@click.option(
    "--raster-dir",
    type=click.Path(file_okay=False, path_type=Path),
    required=True,
)
@click.option(
    "--ocr-df",
    "ocr_df_path",
    type=click.Path(exists=True, dir_okay=False, path_type=Path),
    default=None,
    help="Optional OCR df; if given, only its (file_name, page) pairs are rasterized.",
)
@click.option("--dpi", type=int, default=LAYOUT_DPI)
@click.option("--jpeg-quality", type=int, default=RASTER_JPEG_QUALITY)
@click.option("--workers", type=int, default=RASTER_WORKERS)
def main(
    pdf_dir: Path,
    raster_dir: Path,
    ocr_df_path: Path | None,
    dpi: int,
    jpeg_quality: int,
    workers: int,
):
    try:
        rasterizer = PdfRasterizer(
            dpi=dpi, jpeg_quality=jpeg_quality, workers=workers
        )
        rasterizer.rasterize(
            pdf_dir=pdf_dir,
            raster_dir=raster_dir,
            ocr_df_path=ocr_df_path,
        )
        sys.exit(0)
    except Exception as exc:
        logger.exception(f"Rasterizer Failed: {exc}")
        sys.exit(1)


if __name__ == "__main__":
    main()
