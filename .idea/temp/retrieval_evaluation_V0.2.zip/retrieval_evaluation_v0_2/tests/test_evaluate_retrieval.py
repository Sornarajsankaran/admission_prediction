from __future__ import annotations

import csv
import json
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from evaluate_retrieval import (  # noqa: E402
    CATEGORIES, DEFAULT_KS, EvaluationError, aggregate, dcg, evaluate_files,
    evaluate_query, flatten, load_dataset, parse_chunk_id, prepare_queries,
    run, to_mapping,
)
from compare_runs import compare  # noqa: E402


def eval_grades(grades, flags=None, ks=(2, 4, 10), scores=None):
    flags = flags if flags is not None else [1 if grade else 0 for grade in grades]
    scores = scores if scores is not None else [float(len(grades)-i) for i in range(len(grades))]
    entries = [(f"AUD:pdf.pdf:1:{i}", grade, score, flag)
               for i, (grade, score, flag) in enumerate(zip(grades, scores, flags))]
    return {r["k"]: r for r in evaluate_query("AUD", "pdf.pdf", "code_resolver", "q", entries, ks)}


def test_relevance_positive_includes_grade_one():
    result = eval_grades([1, 0, 0, 0], ks=(1,))[1]
    assert result["n_positive"] == 1
    assert result["query_group"] == "positive"
    assert result["recall"] == 1
    assert result["ndcg"] == 1


def test_tied_ground_truth_grades_do_not_affect_dcg():
    a = eval_grades([3, 3, 1, 0], ks=(2,))[2]
    b = eval_grades([3, 3, 1, 0], scores=[3, 4, 2, 1], ks=(2,))[2]
    assert a["ndcg"] == pytest.approx(b["ndcg"])
    assert a["ndcg"] == 1


def test_ndcg_penalizes_wrong_order():
    result = eval_grades([0, 1, 3, 2], ks=(4,))[4]
    assert 0 < result["ndcg"] < 1
    assert result["ndcg"] == pytest.approx(dcg([0, 1, 3, 2]) / dcg([3, 2, 1, 0]))


def test_recall_capacity_and_precision_when_r_ge_k():
    e = eval_grades([3, 0, 1, 1], ks=(2,))[2]
    assert e["recall"] == pytest.approx(1/3)
    assert e["normalized_recall"] == pytest.approx(.5)
    assert e["precision"] == pytest.approx(.5)


def test_capacity_when_r_less_than_k():
    e = eval_grades([1, 0, 0, 0], ks=(4,))[4]
    assert e["recall"] == 1
    assert e["normalized_recall"] == 1
    assert e["precision"] == pytest.approx(.25)


def test_ap_denominator_uses_total_r_not_min_k_r():
    e = eval_grades([1, 0, 1, 1], ks=(2,))[2]
    assert e["ap"] == pytest.approx(1/3)
    assert e["rr"] == 1


def test_reciprocal_rank_at_k_zero_if_no_positive_in_top_k():
    e = eval_grades([0, 0, 1], ks=(2,))[2]
    assert e["rr"] == 0
    assert e["positive_evidence_hit_at_k"] == 0


def test_no_positive_query_has_only_binary_rejection_metrics():
    e = eval_grades([0, 0, 0, 0], flags=[0, 1, 0, 1], ks=(2, 4))
    assert e[2]["query_group"] == "no_positive"
    assert all(e[4][metric] is None for metric in (
        "ndcg", "recall", "normalized_recall", "precision", "ap", "rr"))
    assert e[2]["false_alarm_at_k"] == 1
    assert e[2]["correct_rejection_at_k"] == 0
    assert e[2]["false_positive_rate_at_k"] == pytest.approx(.5)
    assert e[4]["false_positive_rate_at_k"] == pytest.approx(.5)
    assert e[4]["positive_evidence_hit_at_k"] is None


def test_correct_rejection_if_all_top_k_flags_zero():
    e = eval_grades([0, 0, 0], flags=[0, 0, 1], ks=(2,))[2]
    assert e["false_alarm_at_k"] == 0
    assert e["correct_rejection_at_k"] == 1
    assert e["false_positive_rate_at_k"] == 0


def test_positive_hit_only_true_positive():
    no_tp = eval_grades([0, 1], flags=[1, 0], ks=(2,))[2]
    yes_tp = eval_grades([0, 1], flags=[1, 1], ks=(2,))[2]
    assert no_tp["positive_evidence_hit_at_k"] == 0
    assert yes_tp["positive_evidence_hit_at_k"] == 1
    assert no_tp["fp_at_k"] == 1
    assert yes_tp["tp_at_k"] == 1


def test_top_k_binary_metrics_are_score_sorted():
    e = eval_grades([1, 0, 0], flags=[1, 0, 1], scores=[.2, .9, .8], ks=(2,))[2]
    assert e["positive_evidence_hit_at_k"] == 0
    assert e["n_predicted_positive_at_k"] == 1
    assert e["fp_at_k"] == 1


def test_short_pool_effective_k():
    e = eval_grades([1, 0], flags=[1, 1], ks=(10,))[10]
    assert e["effective_k"] == 2
    assert e["precision"] == .5
    assert e["normalized_recall"] == 1
    assert e["tp_at_k"] + e["fp_at_k"] == 2


def test_tied_scores_tie_break_by_chunk_id():
    e = eval_grades([0, 1], flags=[0, 1], scores=[0.3, 0.3], ks=(1,))[1]
    assert e["rr"] == 0
    assert e["n_score_ties"] == 1


def test_aggregation_has_72_rows_and_stratified_non_null():
    positive = eval_grades([1, 0], ks=(2,))[2]
    negative = eval_grades([0, 0], flags=[1, 0], ks=(2,))[2]
    negative["query"] = "different"
    negative["category"] = "signs_and_symptoms"
    rows = aggregate([positive, negative], (2,))
    assert len(rows) == 6 * 3
    overall = next(row for row in rows if (row["category"], row["query_group"]) == ("overall", "all"))
    assert overall["n_queries"] == 2
    assert overall["no_positive_rate"] == .5
    assert overall["recall"] == 1
    assert overall["n_valid_recall"] == 1
    assert overall["n_valid_false_alarm_rate"] == 1
    assert overall["false_alarm_rate"] == 1
    assert overall["precision"] == .5
    no_pos = next(row for row in rows if (row["category"], row["query_group"]) == ("overall", "no_positive"))
    assert no_pos["recall"] is None
    assert no_pos["correct_rejection_rate"] == 0


def test_macro_mean_over_queries_not_categories():
    positives = [eval_grades([1, 0], ks=(2,))[2] for _ in range(3)]
    negatives = [eval_grades([0, 1], ks=(2,))[2]]
    for i, row in enumerate(positives):
        row["query"] = f"q{i}"
    negatives[0]["category"] = "signs_and_symptoms"
    rows = aggregate(positives + negatives, (2,))
    overall = next(r for r in rows if r["category"] == "overall" and r["query_group"] == "all")
    assert overall["mrr"] == pytest.approx(.875)  # (1+1+1+0.5)/4


def test_chunk_id_parser():
    assert parse_chunk_id("ABC:file.part.pdf:4:2") == ("ABC", "file.part.pdf")
    with pytest.raises(EvaluationError):
        parse_chunk_id("ABC:doc.pdf:not_a_page:2")


def test_json_parser_rejects_duplicate_keys():
    with pytest.raises(EvaluationError, match="duplicate"):
        to_mapping('{"foo": 1, "foo": 2}', "test")


def test_binary_rejects_boolean_and_fraction():
    with pytest.raises(EvaluationError):
        flatten({"code_resolver": {"q": True}}, "binary", "test")
    with pytest.raises(EvaluationError):
        flatten({"code_resolver": {"q": 0.5}}, "binary", "test")


def test_score_rejects_nan():
    with pytest.raises(EvaluationError):
        flatten({"code_resolver": {"q": float("nan")}}, "score", "test")


def test_strict_query_coverage_in_pdf():
    ground = {("A", "p.pdf"): {
        "A:p.pdf:1:0": {("code_resolver", "q"): 1},
        "A:p.pdf:1:1": {},
    }}
    pred = {("A", "p.pdf"): {
        "A:p.pdf:1:0": {"scores": {("code_resolver", "q"): .5}, "binary": {("code_resolver", "q"): 1}},
        "A:p.pdf:1:1": {"scores": {("code_resolver", "q"): .4}, "binary": {("code_resolver", "q"): 0}},
    }}
    with pytest.raises(EvaluationError, match="Incomplete ground truth"):
        prepare_queries(ground, pred)


def test_binary_score_key_coverage_csv(tmp_path):
    gt = tmp_path / "gt.csv"
    pred = tmp_path / "pred.csv"
    gt.write_text('chunk_id,labels\nA:p.pdf:1:1,"{""code_resolver"":{""q"":""not_relevant""}}"\n')
    pred.write_text('chunk_id,labels,binary_predictions\nA:p.pdf:1:1,"{""code_resolver"":{""q"":0.5}}","{}"\n')
    with pytest.raises(EvaluationError, match="binary/score keys disagree"):
        evaluate_files(gt, pred, (10,))


def test_full_csv_end_to_end(tmp_path):
    examples = ROOT / "examples"
    gt = examples / "ground_truth_V0.1.csv"
    pred = examples / "predictions_model_A_V0.2.csv"
    per_query, summary = evaluate_files(gt, pred)
    assert len(per_query) == 11 * len(DEFAULT_KS)
    assert len(summary) == 6 * 3 * len(DEFAULT_KS)
    assert sum(r["query_group"] == "no_positive" for r in per_query if r["k"] == 10) == 4
    out = run(gt, pred, run_id="test_model", output_dir=tmp_path, per_query_format="csv")
    assert (out / "metadata.json").is_file()
    assert (out / "per_query.csv").is_file()
    assert (out / "summary.csv").is_file()
    metadata = json.loads((out / "metadata.json").read_text())
    assert metadata["no_positive_rate"] == pytest.approx(4/11)
    with pytest.raises(EvaluationError, match="already exists"):
        run(gt, pred, run_id="test_model", output_dir=tmp_path, per_query_format="csv")


def test_compare_runs(tmp_path):
    examples = ROOT / "examples"
    a = run(examples / "ground_truth_V0.1.csv", examples / "predictions_model_A_V0.2.csv",
            run_id="A", output_dir=tmp_path, per_query_format="csv")
    b = run(examples / "ground_truth_V0.1.csv", examples / "predictions_model_B_V0.2.csv",
            run_id="B", output_dir=tmp_path, per_query_format="csv")
    comparison = tmp_path / "comparison.csv"
    rows = compare([a, b], comparison)
    assert comparison.is_file()
    assert len(rows) == 2 * 6 * 3 * len(DEFAULT_KS)


def test_native_parquet_optional(tmp_path):
    pq = pytest.importorskip("pyarrow.parquet")
    pa = pytest.importorskip("pyarrow")
    # Native nested Parquet maps (as opposed to JSON-string labels).
    nested_strings = pa.map_(pa.string(), pa.map_(pa.string(), pa.string()))
    nested_scores = pa.map_(pa.string(), pa.map_(pa.string(), pa.float64()))
    nested_binary = pa.map_(pa.string(), pa.map_(pa.string(), pa.int64()))
    ground = pa.Table.from_pylist([{
        "chunk_id": "A:one.pdf:1:1",
        "labels": [("code_resolver", [("q", "less_relevant")])],
    }], schema=pa.schema([pa.field("chunk_id", pa.string()), pa.field("labels", nested_strings)]))
    predictions = pa.Table.from_pylist([{
        "chunk_id": "A:one.pdf:1:1",
        "labels": [("code_resolver", [("q", .6)])],
        "binary_predictions": [("code_resolver", [("q", 1)])],
    }], schema=pa.schema([pa.field("chunk_id", pa.string()),
                          pa.field("labels", nested_scores),
                          pa.field("binary_predictions", nested_binary)]))
    gpath, ppath = tmp_path / "ground.parquet", tmp_path / "pred.parquet"
    pq.write_table(ground, gpath)
    pq.write_table(predictions, ppath)
    out = run(gpath, ppath, run_id="native_parquet", output_dir=tmp_path)
    table = pq.read_table(out / "per_query.parquet")
    assert table.num_rows == 4
    assert table.to_pylist()[0]["n_positive"] == 1
