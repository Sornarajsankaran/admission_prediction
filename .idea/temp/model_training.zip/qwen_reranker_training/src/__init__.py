"""
Project package marker for the Qwen reranker codebase.
Keeping this file minimal intentionally; it simply enables absolute imports like
`import src.utils` when running scripts from the repository root.
"""

