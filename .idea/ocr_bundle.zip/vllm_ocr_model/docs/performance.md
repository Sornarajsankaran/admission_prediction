# Performance

All numbers are from one **NVIDIA L40S (48 GB)**, driver 580, in a container with a
**15.3-CPU cgroup quota**, vLLM 0.23.0, torch 2.11. They use randomly initialised decoders
with the pretrained Heron encoder, calibrated to realistic output lengths (see
[validation.md](validation.md) §1). Speed depends on the number of lines per page and the
output length, not on the weights themselves.

## 1. Headline

Workload: 2,048 pages averaging 300 OCR lines, ~300 order tokens and ~740 formatter tokens
per page, bf16, greedy.

| Setup | pages/s | vs baseline |
|---|---:|---:|
| PyTorch `generate_end_to_end`, fp32, batch 32 | 2.36 | 1× |
| PyTorch, bf16 autocast | 2.38 | 1× |
| vLLM port, 1 engine (measured before tuning steps 12–14) | 30.7 | 13× |
| vLLM port, 3 engines × 256 | 74.5 | 32× |
| vLLM port, 4 engines × 128 | 78.5 | 33× |
| **vLLM port, 4 engines × 160, wave 40, block 32 (defaults)** | **79.5** | **34×** |
| `ocr-vllm-run` end to end with PDF rendering, mixed set (median 120 lines), steady state | ~60–70 | |

## 2. Tuning history

Each row was measured on the 300-line workload unless noted.

| # | Change | pages/s | What it fixed |
|---|---|---:|---|
| 0 | First working port (fp32, 1 engine, eager; 2-page smoke test, uncalibrated weights) | ~0.03 | correctness first |
| 1 | CUDA graphs (after fixing `max_source_positions` and the workspace sizing) | 6.2 | 25 ms → ~10 ms per step |
| 2 | Pointer via a Triton kernel instead of a 256-wide fp32 attention call | 7.7 | that call alone took 16 ms per step |
| 3 | 29 → 4 KV-cache groups; counter/used/lookup attention replaced by state kernels | 12.5 | vLLM's per-group per-step overhead |
| 4 | bf16 | 12.0 | nothing yet: steps were host-bound |
| 5 | `restrict_attention` (the unused stack reads one KV entry) | | GPU per step 5.5 → 3.55 ms |
| 6 | Wave admission (64 pages at a time) | 18.3 → 22.5 | most steps back on CUDA graphs |
| 7 | GAP-aligned formatter region: no mask channel, 2 KV groups | 28.5 | formatter self-attention KV reads −3× |
| 8 | 2 engines under CUDA MPS | 45.6 | hides host overhead; without MPS only +16% |
| 9 | Box lookup as a direct cache read; compiled encoder backbone; final-only outputs | 50.4 | |
| 10 | **Thread pools pinned to 1 thread** | 3 engines: 41 → 63 | container CPU quota throttling (§4) |
| 11 | 4 engines | 65 | |
| 12 | Decoder dense parts compiled, both stacks as batched GEMMs | 67.7 | fewer kernels |
| 13 | KV block size 32 | 68.4 | less block bookkeeping |
| 14 | **Encoder chunks of 8 + channels-last + compiled box half** | **79.5** | encoder 3.8 → ~1.9 ms per page |

## 3. Where the time goes now

One engine, 256 pages in flight, bf16:

| Component | Cost |
|---|---|
| Decode step, GPU time | ~1.9 ms per step (all 256 pages advance one token) |
| of which attention | ~55%, at the KV memory-bandwidth limit |
| of which matmuls / elementwise / copies | ~0.2 / 0.2–0.3 / 0.23 ms |
| Decode step, wall time on one engine | ~6.5–7 ms (vLLM scheduler ~2.8 ms, input prep ~1 ms, output bookkeeping ~1 ms) |
| Encoder | ~1.9 ms GPU per page (image half 1.4, box half 0.4) |
| Admitting a wave of 32 pages | ~130 ms (encoder ~75 ms + one eager step) |
| PDF render + preprocess (CPU) | ~45 ms per page per core at zoom 2.0; 16 ms at zoom 1.0 |

With 4 engines the GPU is ~95% busy. Going further needs less GPU work per token (§6).

## 4. The CPU-quota trap (important on shared/cloud hosts)

The development container showed **128 cores** (`nproc`) but had a **15.3-core cgroup
quota** (`/sys/fs/cgroup/cpu.max`). Every vLLM engine process, and anything using
OpenMP, BLAS or blake3 (vLLM hashes multimodal inputs with it), spawns thread pools sized
to the visible core count. With 3–4 engines, bursts exceeded the quota, and cgroup
throttling then **froze every thread in the container** for the rest of each 100 ms
period. That is why 3 engines used to be *slower* than 2.

The fix, applied by both the image `ENV` and the plugin's `register()`:
`OMP_NUM_THREADS`, `MKL_NUM_THREADS`, `OPENBLAS_NUM_THREADS`, `NUMEXPR_NUM_THREADS` and
`RAYON_NUM_THREADS` all set to 1, and `torch.set_num_threads(1)`. After it, the
throttling counters stayed at zero during full runs.

Check on any new host:

```bash
cat /sys/fs/cgroup/cpu.max                       # "max 100000" = no quota
grep throttled /sys/fs/cgroup/cpu.stat           # watch nr_throttled during a run
```

CPU budget per run is roughly 2 cores per engine, plus ~1 core per 20 pages/s of PDF
rendering at zoom 2.0, plus 1 for the main process.

## 5. Tuning a new machine

1. **Engines and MPS.** More engines hide more host overhead until the GPU saturates. On
   an L40S: 1 → ~30, 2 → ~54, 3 → 65–74, 4 → 79.5 pages/s (the 1- and 2-engine figures
   were measured mid-tuning). Without MPS the processes
   time-slice the GPU; check the log for the MPS warning.
2. **Pages in flight** (`--max-seqs`). 128–160 per engine with 4 engines. Larger values
   raise per-step host cost; smaller ones starve the GPU. Each engine needs
   `max_seqs × ~20 MB` of KV cache at 300 lines per page (bf16).
3. **Wave** (`--wave`). ~25% of `--max-seqs`, and a multiple of the encoder chunk (8).
   Larger waves mean fewer eager steps but a deeper dip in pages in flight.
4. **GPU memory** (`--gpu-memory`). Split evenly across engines. Engines start one after
   another because concurrent startup confuses vLLM's memory profiling.
5. **CPU.** If `summary.json`'s steady-state rate is well below the GPU numbers, check
   throttling and `--preprocess-workers`. Lowering `--raster-zoom` makes rendering ~3×
   cheaper, but the images then differ from training.
6. **Block size.** 32 was best (16 → 64: 68.4 / 68.4 / 67.2 pages/s).

A quick benchmark: run a few thousand pages and read `pages_per_s_all_engines` in
`summary.json`. Short runs are dominated by the ~50 s-per-engine sequential startup.

## 6. Headroom not yet used

| Idea | Expected | Cost / risk |
|---|---|---|
| fp8 KV cache | attention ~−40% → +15–25% throughput | quantization error in attention; the state-cache digits would need base ≤ 16 |
| Speculative decoding: geometric draft for the order, n-gram draft for the formatter | 2–3× fewer steps if the trained model is predictable | large kernel changes (multi-token per step); needs the trained weights to evaluate |
| A second GPU | ~linear (independent engines) | hardware |
| A lower render zoom | cheaper CPU | train/serve image mismatch |
| DeepSeek-OCR-2 encoder (evaluated, on hold) | slower: SAM-B at 1024 px costs 13–17 ms per page vs RT-DETR's 3.8 | quality unknown |

## 7. Startup time

| | |
|---|---|
| Checkpoint conversion | seconds (cached afterwards) |
| First engine, empty cache | ~4 min (inductor compile + CUDA-graph capture) |
| Each engine, warm cache | ~50 s, one after another (4 engines ≈ 3 min) |

Pages start processing as soon as the first engine is ready. Keep `CACHE_DIR` persistent.
For small jobs (< ~1,000 pages), `--engines 1` or `2` finishes sooner.
