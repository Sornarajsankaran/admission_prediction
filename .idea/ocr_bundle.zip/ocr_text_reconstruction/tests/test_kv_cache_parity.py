"""
Phase 2 correctness test: KV-cached decode must match teacher-forced forward.

The GRPO importance ratio is exp(new_lp - old_lp).  old_lp comes from
sample_decode (KV cache path) and new_lp from model.forward (teacher-forced
full-sequence path).  If they disagree the ratio diverges from 1 at init,
breaking training stability.

Run with:
    python test_kv_cache_parity.py              # CPU (fast, ~5s)
    python test_kv_cache_parity.py --device cuda
"""

from __future__ import annotations

import json
import sys
from pathlib import Path

import click

import torch
import torch.nn.functional as F

# ---- locate repo root ---------------------------------------------------
_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(_ROOT / "scripts"))

from modeling_ocr_reconstruction import (
    OcrReconstructionConfig,
    OcrTextReconstructionModel,
)
from transformers import RTDetrV2Config, RTDetrV2Model

_HERON_CFG   = _ROOT / "layout_heron" / "heron_config.json"
_HERON_SKIP  = {
    "architectures", "model_type", "torch_dtype", "transformers_version",
    "id2label", "label2id",
}


def build_model(device: str) -> OcrTextReconstructionModel:
    with open(_HERON_CFG) as f:
        hcfg = json.load(f)
    rt_cfg = RTDetrV2Config(**{k: v for k, v in hcfg.items() if k not in _HERON_SKIP})
    rt     = RTDetrV2Model(rt_cfg)
    cfg    = OcrReconstructionConfig(d_model=rt_cfg.d_model)
    model  = OcrTextReconstructionModel(cfg, rtdetr=rt).to(device).eval()
    return model


def make_batch(B: int, N: int, device: str):
    pixel_values = torch.randn(B, 3, 640, 640, device=device)
    ocr_boxes    = torch.rand(B, N, 4, device=device)
    # make valid xyxy boxes
    ocr_boxes[:, :, 2:] = ocr_boxes[:, :, :2] + ocr_boxes[:, :, 2:] * 0.4
    ocr_boxes.clamp_(0, 1)
    # random box mask: last 10 boxes padded for variety
    box_mask = torch.ones(B, N, dtype=torch.bool, device=device)
    if N > 10:
        box_mask[:, N - 10:] = False
    return pixel_values, ocr_boxes, box_mask


# -------------------------------------------------------------------------
# Test 1: _ar_decode_step  ≡  markdown_decoder(full_seq)[:, -1:]
# -------------------------------------------------------------------------
def test_single_step_matches_full_decoder(model, device):
    print("Test 1: _ar_decode_step matches full decoder at each step ... ", end="", flush=True)
    B, N, L = 2, 20, 8
    pixel_values, ocr_boxes, box_mask = make_batch(B, N, device)

    with torch.no_grad():
        h_box = model.encode_boxes(pixel_values, ocr_boxes, box_mask=box_mask)
        cross_kv, cross_mask = model._precompute_cross_kv(h_box, box_mask)

        # Build a random token sequence (ids in [0, 17+N))
        vocab = model.config.num_special_tokens + N
        seq   = torch.randint(0, vocab, (B, L), device=device)

        # Full decoder pass (reference)
        T      = seq.size(1)
        tok_emb = model._embed_tokens(seq, h_box)
        x_full  = tok_emb + model.pos_embedding[:, :T]
        causal  = torch.triu(torch.full((T, T), float("-inf"), device=device), diagonal=1)
        mem_mask = (~box_mask)
        hidden_full = model.markdown_decoder(
            tgt=x_full, memory=h_box,
            tgt_mask=causal, memory_key_padding_mask=mem_mask,
        )
        hidden_full = model.decoder_norm(hidden_full)  # (B, T, d)

        # KV-cache step-by-step
        self_kv: list = [None] * len(model.markdown_decoder.layers)
        for t in range(L):
            tok_id = seq[:, t:t + 1]
            emb    = model._embed_tokens(tok_id, h_box)
            x_new  = emb + model.pos_embedding[:, t:t + 1]
            hidden_step, self_kv = model._ar_decode_step(x_new, self_kv, cross_kv, cross_mask)

            ref = hidden_full[:, t:t + 1]  # (B, 1, d) from full pass
            diff = (hidden_step - ref).abs().max().item()
            assert diff < 1e-4, f"step {t}: max hidden diff = {diff:.2e} (> 1e-4)"

    print(f"PASSED  (max diff < 1e-4 across all {L} steps)")


# -------------------------------------------------------------------------
# Test 2: sample_decode log-probs  ≡  forward log-probs  (importance ratio ≈ 1)
# -------------------------------------------------------------------------
def test_logprob_parity(model, device):
    print("Test 2: sample_decode log-probs match forward recompute ... ", end="", flush=True)
    B, N = 2, 30
    pixel_values, ocr_boxes, box_mask = make_batch(B, N, device)

    torch.manual_seed(0)
    with torch.no_grad():
        sequences, old_lp, valid = model.sample_decode(
            pixel_values, ocr_boxes, box_mask=box_mask,
            max_new_tokens=32, temperature=1.0,
        )

        # Teacher-forced recompute (same as grpo_train.sequence_logprobs)
        out = model.forward(
            pixel_values, ocr_boxes,
            decoder_input_ids=sequences[:, :-1],
            box_mask=box_mask,
        )
        new_lp = F.log_softmax(out.logits.float(), dim=-1)
        actions = sequences[:, 1:]                                    # (B, S-1)
        new_lp_gathered = new_lp.gather(-1, actions.unsqueeze(-1)).squeeze(-1)  # (B, S-1)

    # Compare: old_lp[:, 1:] vs new_lp_gathered (both cover the generated actions)
    # old_lp col 0 is always 0 (BOS placeholder), skip it.
    old = old_lp[:, 1:].float()
    new = new_lp_gathered
    mask = valid[:, 1:]  # True for real actions

    diff = (old - new).abs()
    max_diff  = diff[mask].max().item()
    mean_diff = diff[mask].mean().item()

    # GRPO importance ratio = exp(new_lp - old_lp); should start at 1.
    ratio = (new - old)[mask].exp()
    ratio_min = ratio.min().item()
    ratio_max = ratio.max().item()

    assert max_diff < 5e-4, f"max |Δlogp| = {max_diff:.2e} (> 5e-4)"
    assert abs(ratio_min - 1.0) < 1e-2, f"min importance ratio = {ratio_min:.6f}"
    assert abs(ratio_max - 1.0) < 1e-2, f"max importance ratio = {ratio_max:.6f}"

    print(f"PASSED  max|Δlogp|={max_diff:.2e}  ratio∈[{ratio_min:.5f}, {ratio_max:.5f}]")


# -------------------------------------------------------------------------
# Test 3: generate is deterministic and identical to a second run
# -------------------------------------------------------------------------
def test_generate_deterministic(model, device):
    print("Test 3: generate is deterministic ... ", end="", flush=True)
    B, N = 2, 25
    pixel_values, ocr_boxes, box_mask = make_batch(B, N, device)

    with torch.no_grad():
        gen1 = model.generate(pixel_values, ocr_boxes, box_mask=box_mask, max_new_tokens=20)
        gen2 = model.generate(pixel_values, ocr_boxes, box_mask=box_mask, max_new_tokens=20)

    assert torch.equal(gen1, gen2), "generate gave different results on the same input"
    print(f"PASSED  shape={tuple(gen1.shape)}")


# -------------------------------------------------------------------------
@click.command(context_settings={"show_default": True})
@click.option("--device", default="cpu", help="Compute device.")
def main(device):
    print(f"\nBuilding model on {device} ...")
    model = build_model(device)
    print(f"Model ready ({sum(p.numel() for p in model.parameters())/1e6:.1f}M params)\n")

    test_single_step_matches_full_decoder(model, device)
    test_logprob_parity(model, device)
    test_generate_deterministic(model, device)

    print("\nAll tests passed.")


if __name__ == "__main__":
    main()
