"""
Unit tests for the GRPO core math (pure, CPU-only).

End-to-end wiring (rollout -> reward -> advantage -> loss -> step) is validated
separately by `python grpo_train.py --smoke`. Here we lock down the advantage
normalization, which is correctness-critical and easy to get subtly wrong.

Run:  python test_grpo.py   (or: pytest test_grpo.py)
"""

from __future__ import annotations

import torch

from backup_code.grpo_train import group_advantages


def approx(a, b, tol=1e-5):
    assert abs(float(a) - float(b)) <= tol, f"expected {b}, got {a}"


def test_group_advantages_shape():
    rewards = torch.arange(12, dtype=torch.float32)
    adv = group_advantages(rewards, group_size=4)
    assert adv.shape == rewards.shape


def test_group_advantages_zero_mean_within_group():
    rewards = torch.tensor([0.0, 1.0, 2.0, 10.0, 20.0, 30.0])
    adv = group_advantages(rewards, group_size=3).view(2, 3)
    approx(adv[0].mean(), 0.0)
    approx(adv[1].mean(), 0.0)


def test_group_advantages_values():
    # [0,1,2] -> mean 1, unbiased std 1 -> advantages ~ [-1, 0, 1]
    rewards = torch.tensor([0.0, 1.0, 2.0])
    adv = group_advantages(rewards, group_size=3)
    approx(adv[0], -1.0, tol=1e-3)
    approx(adv[1], 0.0, tol=1e-3)
    approx(adv[2], 1.0, tol=1e-3)


def test_group_advantages_equal_rewards_give_zero():
    # a group whose K rewards are all equal -> no learning signal
    rewards = torch.tensor([5.0, 5.0, 5.0, 5.0])
    adv = group_advantages(rewards, group_size=4)
    assert torch.allclose(adv, torch.zeros(4), atol=1e-4)


def test_group_advantages_independent_groups():
    # group 1 is constant (-> 0), group 2 has spread (-> non-zero); they don't mix
    rewards = torch.tensor([1.0, 1.0, 0.0, 1.0])
    adv = group_advantages(rewards, group_size=2).view(2, 2)
    assert torch.allclose(adv[0], torch.zeros(2), atol=1e-4)
    assert adv[1].abs().sum() > 0.5


# --------------------------------------------------------------------------- #
if __name__ == "__main__":
    import sys

    tests = [v for k, v in sorted(globals().items())
             if k.startswith("test_") and callable(v)]
    failed = 0
    for fn in tests:
        try:
            fn()
            print(f"PASS  {fn.__name__}")
        except AssertionError as e:
            failed += 1
            print(f"FAIL  {fn.__name__}: {e}")
    print(f"\n{len(tests) - failed}/{len(tests)} passed")
    sys.exit(1 if failed else 0)
