#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "${BASH_SOURCE[0]}")"
if command -v uv >/dev/null 2>&1; then
  uv venv --python 3.12 .venv
  uv pip install --python .venv/bin/python -r requirements.lock.txt
else
  python3.12 -m venv .venv
  .venv/bin/python -m pip install --upgrade pip
  .venv/bin/python -m pip install -r requirements.lock.txt
fi
.venv/bin/python -c 'import torch,vllm,transformers; print("Torch",torch.__version__,"vLLM",vllm.__version__,"Transformers",transformers.__version__); print("CUDA available:",torch.cuda.is_available()); print(torch.cuda.get_device_name() if torch.cuda.is_available() else "GPU not available")'
