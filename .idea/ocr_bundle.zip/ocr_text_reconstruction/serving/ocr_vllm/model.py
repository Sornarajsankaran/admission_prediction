"""
vLLM port of ``OcrTwoStageModel`` (order decoder -> markdown formatter).
========================================================================

One vLLM request = one page. The encoder (RT-DETR box encoder) runs once per page as
vLLM's multimodal encoder; the decoder stream is

    ORD_BOS  BOX_o0 ... BOX_o{K-1}  GAP ... GAP  FMT_BOS  f_1 ... f_T(=eos)
    '--------------- order stage --------------'  '---- formatter stage ----'

Both reference decoders are exact ports. The difficulty is that they need per-page
state that vLLM does not give a model: the page's H_box (pointer targets and input
embeddings), which boxes are already placed, K, and the formatter cursor. This model
keeps ALL of that state in vLLM-managed KV caches, so it works with continuous
batching, preemption and CUDA graphs without any side tables:

  box_store  (cross cache, row per box)  K = pointer_key_proj(H_box), V = norm(H_box);
                                         read directly by pointer.py for the exact
                                         pointer scores and the box embeddings.
  state      (self cache, row per pos)   (box id, is_box, is_emit) -> placed boxes and
                                         the formatter cursor (pointer.py kernels).
  K                                      the box_store layer's cross-attention length.

The formatter's self-attention must not see the order-stage positions: GAP tokens
align FMT_BOS to a KV block boundary and the formatter layers get a block table shifted
past the order stage (``restrict_attention``).

Every token runs through both decoder stacks and the phase picks the result, which
keeps the forward free of data-dependent control flow (CUDA-graph friendly);
``restrict_attention`` stops the unused stack from reading its KV cache.

``forward`` returns the final logits (masked, per phase) and ``compute_logits`` passes
them through.
"""

from __future__ import annotations

import copy
from collections.abc import Iterable, Mapping, Sequence
from contextlib import contextmanager

import torch
import torch._dynamo
import torch.nn as nn
import torch.nn.functional as F
from transformers import BatchFeature

from vllm.config import VllmConfig
from vllm.config.multimodal import BaseDummyOptions
from vllm.forward_context import get_forward_context
from vllm.model_executor.layers.attention import Attention
from vllm.model_executor.layers.attention.cross_attention import CrossAttention
from vllm.model_executor.model_loader.weight_utils import default_weight_loader
from vllm.model_executor.models.interfaces import MultiModalEmbeddings, SupportsMultiModal
from vllm.multimodal import MULTIMODAL_REGISTRY
from vllm.multimodal.inputs import MultiModalFieldConfig, MultiModalKwargsItems
from vllm.multimodal.parse import DictEmbeddingItems, MultiModalDataItems, MultiModalDataParser
from vllm.multimodal.processing import (
    BaseDummyInputsBuilder,
    BaseProcessingInfo,
    EncDecMultiModalProcessor,
    PromptReplacement,
    PromptUpdate,
)
from vllm.v1.attention.backend import AttentionType

from .config import OcrTwoStageConfig
from .encoder import BoxEncoder
from .pointer import (STATE_BOX_HI, STATE_BOX_LO, STATE_IS_BOX, STATE_IS_EMIT,
                      gather_box_rows, page_cursor, pointer_scores)



# --------------------------------------------------------------------------- #
# Decoder layer (== nn.TransformerDecoderLayer, norm_first=True, gelu)
# --------------------------------------------------------------------------- #
class DecoderLayer(nn.Module):
    def __init__(self, d: int, heads: int, ffn: int, prefix: str, cache_config):
        super().__init__()
        self.d = d
        scale = (d // heads) ** -0.5
        self.norm1, self.norm2, self.norm3 = nn.LayerNorm(d), nn.LayerNorm(d), nn.LayerNorm(d)
        self.qkv = nn.Linear(d, 3 * d)
        self.self_out = nn.Linear(d, d)
        self.cross_q = nn.Linear(d, d)
        self.cross_kv = nn.Linear(d, 2 * d)
        self.cross_out = nn.Linear(d, d)
        self.linear1 = nn.Linear(d, ffn)
        self.linear2 = nn.Linear(ffn, d)
        self.self_attn = Attention(heads, d // heads, scale, num_kv_heads=heads,
                                   cache_config=cache_config, prefix=f"{prefix}.self_attn",
                                   attn_type=AttentionType.DECODER)
        self.cross_attn = CrossAttention(heads, d // heads, scale, num_kv_heads=heads,
                                         cache_config=cache_config, prefix=f"{prefix}.cross_attn",
                                         attn_type=AttentionType.ENCODER_DECODER)

    # dense pieces between the attention calls; compiled (fused) when compile_decoder
    def _pre_self(self, x):
        return self.qkv(self.norm1(x)).split(self.d, dim=-1)

    def _post_self(self, x, sa):
        x = x + self.self_out(sa)
        return x, self.cross_q(self.norm2(x))

    def _post_cross(self, x, ca):
        x = x + self.cross_out(ca)
        return x + self.linear2(F.gelu(self.linear1(self.norm3(x))))

    def forward(self, x, memory):
        q, k, v = self._pre_self(x)
        x, cq = self._post_self(x, self.self_attn(q, k, v))
        # cross-attention over H_box (K/V written once, on the page's first decoder step)
        if memory is not None:
            ck, cv = self.cross_kv(memory).split(self.d, dim=-1)
        else:
            ck = cv = None
        return self._post_cross(x, self.cross_attn(cq, ck, cv))


@contextmanager
def restrict_attention(layers, active: torch.Tensor, start: torch.Tensor | None = None):
    """Within the block, narrow what ``layers`` attend to, per request (= per token):

      * inactive requests attend to a single KV entry (their output is discarded);
      * with ``start`` (block-aligned positions), active requests attend only to
        positions [start, p] -- done by shifting their block table by start/block_size.

    Every token runs through both decoder stacks but uses one stack's result; without
    this the unused stack would still read its whole KV history / all boxes, and the
    formatter would read the order stage's positions. Implemented by handing the layers
    a copy of their attention metadata with adjusted seq_lens / block_table, computed
    on-device (so it is captured in CUDA graphs).
    """
    ctx = get_forward_context()
    all_md = ctx.attn_metadata
    if not isinstance(all_md, dict):
        yield
        return
    saved, cache = {}, {}
    try:
        for layer in layers:
            name = layer.layer_name
            md = all_md.get(name)
            if md is None:
                continue
            if id(md) not in cache:                      # layers of one group share metadata
                R = md.seq_lens.shape[0]
                act = active[:R] if active.shape[0] >= R else F.pad(active, (0, R - active.shape[0]))
                new = copy.copy(md)
                seq_lens = md.seq_lens
                if start is not None:
                    st = start[:R] if start.shape[0] >= R else F.pad(start, (0, R - start.shape[0]))
                    st = torch.where(act, st, torch.zeros_like(st))
                    kv = layer.kv_cache[0] if isinstance(layer.kv_cache, list) else layer.kv_cache
                    shift = (st // kv.shape[2]).unsqueeze(-1)
                    cols = torch.arange(md.block_table.shape[1], device=st.device).unsqueeze(0)
                    idx = (cols + shift).clamp(max=md.block_table.shape[1] - 1)
                    new.block_table = torch.gather(md.block_table, 1, idx)
                    seq_lens = seq_lens - st.to(seq_lens.dtype)
                new.seq_lens = torch.where(act, seq_lens, torch.ones_like(seq_lens))
                cache[id(md)] = new
            saved[name] = md
            all_md[name] = cache[id(md)]
        yield
    finally:
        all_md.update(saved)


class DecoderStack(nn.Module):
    def __init__(self, cfg: OcrTwoStageConfig, prefix: str, cache_config):
        super().__init__()
        d = cfg.d_model
        self.pos_embedding = nn.Parameter(torch.zeros(1, cfg.stage_max_positions, d))
        self.layers = nn.ModuleList(
            DecoderLayer(d, cfg.decoder_attention_heads, cfg.decoder_ffn_dim,
                         f"{prefix}.layers.{i}", cache_config)
            for i in range(cfg.num_decoder_layers))
        self.norm = nn.LayerNorm(d)

    def self_attention_layers(self):
        return [layer.self_attn for layer in self.layers]

    def cross_attention_layers(self):
        return [layer.cross_attn for layer in self.layers]

    def forward(self, x, memory):
        for layer in self.layers:
            x = layer(x, memory)
        return self.norm(x)


# --------------------------------------------------------------------------- #
# Multimodal processing: one "image" item = {pixel_values, ocr_boxes}
# --------------------------------------------------------------------------- #
def _field_config(hf_inputs: Mapping[str, torch.Tensor]) -> Mapping[str, MultiModalFieldConfig]:
    return dict(pixel_values=MultiModalFieldConfig.batched("image"),
                ocr_boxes=MultiModalFieldConfig.batched("image"))


class OcrDataParser(MultiModalDataParser):
    def _parse_image_data(self, data):
        if isinstance(data, dict):
            return DictEmbeddingItems(data, modality="image",
                                      required_fields={"pixel_values", "ocr_boxes"},
                                      fields_factory=_field_config)
        raise ValueError("OCR pages must be passed as {'pixel_values': uint8 (1,3,640,640), "
                         "'ocr_boxes': float (1,K,4) xyxy in [0,1]}")


class OcrProcessingInfo(BaseProcessingInfo):
    def get_tokenizer(self):
        # The model runs with skip_tokenizer_init: prompts are token ids and every
        # vLLM prompt-update path accepts tokenizer=None for them.
        return None

    def get_data_parser(self):
        return OcrDataParser()

    def get_supported_mm_limits(self) -> Mapping[str, int | None]:
        return {"image": 1}

    def get_mm_max_tokens_per_item(self, seq_len, mm_counts):
        return {"image": self.get_hf_config().max_boxes}

    @property
    def skip_prompt_length_check(self) -> bool:
        return True


class OcrDummyInputsBuilder(BaseDummyInputsBuilder[OcrProcessingInfo]):
    def get_dummy_text(self, mm_counts: Mapping[str, int]) -> str:
        return ""

    def get_dummy_processor_inputs(self, seq_len, mm_counts, mm_options):
        # There is no tokenizer (skip_tokenizer_init): profile with token ids.
        inputs = super().get_dummy_processor_inputs(seq_len, mm_counts, mm_options)
        inputs.prompt = [self.info.get_hf_config().ord_bos_id]
        return inputs

    def get_dummy_mm_data(self, seq_len: int, mm_counts: Mapping[str, int],
                          mm_options: Mapping[str, BaseDummyOptions]):
        if not mm_counts.get("image", 0):
            return {}
        k = self.info.get_hf_config().max_boxes
        g = torch.Generator().manual_seed(0)
        xy = torch.rand(1, k, 2, generator=g) * 0.9
        boxes = torch.cat([xy, xy + 0.05], dim=-1)
        return {"image": {"pixel_values": torch.zeros(1, 3, 640, 640, dtype=torch.uint8),
                          "ocr_boxes": boxes}}


class OcrMultiModalProcessor(EncDecMultiModalProcessor[OcrProcessingInfo]):
    def create_encoder_prompt(self, prompt, mm_items: MultiModalDataItems):
        return [0]

    def create_decoder_prompt(self, prompt, mm_items: MultiModalDataItems):
        return [self.info.get_hf_config().ord_bos_id]

    def _call_hf_processor(self, prompt, mm_data, mm_kwargs, tok_kwargs) -> BatchFeature:
        # Dict items are passthrough; there is no HF processor / tokenizer to run.
        ids = prompt if isinstance(prompt, list) else [0]
        return BatchFeature({"input_ids": torch.tensor([ids])})

    def _get_mm_fields_config(self, hf_inputs, hf_processor_mm_kwargs):
        return _field_config(hf_inputs)

    def _get_prompt_updates(self, mm_items: MultiModalDataItems, hf_processor_mm_kwargs,
                            out_mm_kwargs: MultiModalKwargsItems) -> Sequence[PromptUpdate]:
        def num_boxes(item_idx: int) -> list[int]:
            item = out_mm_kwargs["image"][item_idx].get_data()
            return [0] * int(item["ocr_boxes"].shape[-2])

        return [PromptReplacement(modality="image", target=[0], replacement=num_boxes)]


# --------------------------------------------------------------------------- #
# Both decoder stacks as one batched computation
# --------------------------------------------------------------------------- #
# Layer i of the order stack and layer i of the formatter stack have the same shapes, so
# their dense parts run as (2, T, .) batched GEMMs on stacked weights -- half the kernel
# launches of running the stacks one after the other (the step is launch-bound at these
# batch sizes). Attention stays per stack. Compiled to fuse the elementwise work.
_LAYER_PARAMS = ("norm1", "norm2", "norm3", "qkv", "self_out", "cross_q", "cross_out",
                 "linear1", "linear2")


def _ln(x, p):
    return F.layer_norm(x, (x.shape[-1],)) * p["weight"][:, None] + p["bias"][:, None]


def _lin(x, p):
    return torch.baddbmm(p["bias"][:, None], x, p["weight"].transpose(1, 2))


def _pair_pre_self(x, W):
    """-> contiguous (q, k, v) for each stack (vLLM attention would copy strided views)."""
    qkv = _lin(_ln(x, W["norm1"]), W["qkv"])
    d = x.shape[-1]
    return tuple(qkv[s, :, i * d:(i + 1) * d].contiguous() for s in (0, 1) for i in range(3))


def _pair_post_self(x, sa_o, sa_f, W):
    x = x + _lin(torch.stack([sa_o, sa_f]), W["self_out"])
    cq = _lin(_ln(x, W["norm2"]), W["cross_q"])
    return x, cq[0], cq[1]


def _pair_post_cross(x, ca_o, ca_f, W):
    x = x + _lin(torch.stack([ca_o, ca_f]), W["cross_out"])
    return x + _lin(F.gelu(_lin(_ln(x, W["norm3"]), W["linear1"])), W["linear2"])


def _pair_final_norm(x, W):
    return _ln(x, W)


# --------------------------------------------------------------------------- #
# Decoder side: both stacks + the per-page state layers
# --------------------------------------------------------------------------- #
class OcrDecoder(nn.Module):
    """KV-cache layout: vLLM groups layers with identical cache specs and its per-step
    overhead grows with the number of groups, so every layer is 8 heads x 32 and there
    are two specs of 13 layers each -> 2 groups:

      self   order + formatter self_attn (12), state (write-only)
      cross  order + formatter cross_attn (12), box_store (write-only):
             K = pointer_key_proj(H_box), V = box_input_norm(H_box), one row per box
    """

    def __init__(self, cfg: OcrTwoStageConfig, cache_config, prefix: str):
        super().__init__()
        d, M, B = cfg.d_model, cfg.num_special_tokens, cfg.max_boxes
        self.cfg, self.d, self.M, self.B = cfg, d, M, B
        H = cfg.decoder_attention_heads
        hd = d // H
        self.heads, self.head_dim = H, hd

        self.order = DecoderStack(cfg, f"{prefix}.order", cache_config=cache_config)
        self.order_bos = nn.Parameter(torch.zeros(1, d))
        self.pointer_key_proj = nn.Linear(d, d, bias=False)

        self.formatter = DecoderStack(cfg, f"{prefix}.formatter", cache_config=cache_config)
        self.token_embedding = nn.Embedding(M + 1, d)
        self.cursor_done = nn.Parameter(torch.zeros(1, d))
        self.head = nn.Linear(d, M + 1)

        def cross(name, scale=1.0):
            return CrossAttention(H, hd, scale, num_kv_heads=H, cache_config=cache_config,
                                  prefix=f"{prefix}.aux.0.{name}", attn_type=AttentionType.ENCODER_DECODER)

        def self_attn(name):
            return Attention(H, hd, 1.0, num_kv_heads=H, cache_config=cache_config,
                             prefix=f"{prefix}.aux.0.{name}", attn_type=AttentionType.DECODER)

        # box_store: per-box pointer keys (K) and normed H_box (V); read directly by
        # pointer.pointer_scores / pointer.gather_box_rows, never attended
        self.box_store = cross("box_store")
        # state: V cache holds (box_hi, box_lo, is_box, is_emit) per decoded position
        self.state = self_attn("state")

        self._stacked = None                                           # built after loading
        fns = (_pair_pre_self, _pair_post_self, _pair_post_cross, _pair_final_norm)
        if cfg.compile_decoder:
            # fuse the ~hundreds of tiny per-step kernels (norms, residuals, GELU, masking)
            torch._dynamo.config.cache_size_limit = max(torch._dynamo.config.cache_size_limit, 64)
            fns = tuple(torch.compile(f, dynamic=True) for f in fns)
            self._logits = torch.compile(self._logits, dynamic=True)
        self._pre_self, self._post_self, self._post_cross, self._final_norm = fns

    def build_stacked(self):
        """After loading: make each order/formatter layer pair's dense parameters views of
        one (2, ...) tensor, so ``_run_stacks`` can use batched GEMMs without copies."""
        def stack(mo, mf):
            out = {}
            for name in ("weight", "bias"):
                po, pf = getattr(mo, name), getattr(mf, name)
                both = torch.stack([po.data, pf.data])
                po.data, pf.data = both[0], both[1]
                out[name] = both
            return out

        self._stacked = [{n: stack(getattr(lo, n), getattr(lf, n)) for n in _LAYER_PARAMS}
                         for lo, lf in zip(self.order.layers, self.formatter.layers)]
        self._stacked_final = stack(self.order.norm, self.formatter.norm)

    def _run_stacks(self, x_ord, x_fmt, memory, is_order, fmt_start):
        """Both decoder stacks, layer by layer; returns (h_order, h_formatter)."""
        is_fmt = ~is_order
        x = torch.stack([x_ord, x_fmt])
        with restrict_attention(self.order.self_attention_layers() + self.order.cross_attention_layers(),
                                is_order), \
                restrict_attention(self.formatter.self_attention_layers(), is_fmt, start=fmt_start), \
                restrict_attention(self.formatter.cross_attention_layers(), is_fmt):
            for W, lo, lf in zip(self._stacked, self.order.layers, self.formatter.layers):
                qo, ko, vo, qf, kf, vf = self._pre_self(x, W)
                x, cq_o, cq_f = self._post_self(x, lo.self_attn(qo, ko, vo), lf.self_attn(qf, kf, vf), W)
                # cross-attention over H_box (K/V written once, on a page's first step)
                kv_o = lo.cross_kv(memory).chunk(2, dim=-1) if memory is not None else (None, None)
                kv_f = lf.cross_kv(memory).chunk(2, dim=-1) if memory is not None else (None, None)
                x = self._post_cross(x, lo.cross_attn(cq_o, *kv_o), lf.cross_attn(cq_f, *kv_f), W)
            h = self._final_norm(x, self._stacked_final)
        return h[0], h[1]

    def embed_input_ids(self, input_ids: torch.Tensor) -> torch.Tensor:
        # Required by vLLM's multimodal interface; forward() builds its own inputs.
        return self.token_embedding(input_ids.clamp(0, self.M))

    @staticmethod
    def _layer_io(layer):
        md = get_forward_context().attn_metadata
        md = md.get(layer.layer_name) if isinstance(md, dict) else md
        kv = layer.kv_cache[0] if isinstance(layer.kv_cache, list) else layer.kv_cache
        return md, kv

    def forward(self, ids: torch.Tensor, pos: torch.Tensor, memory, memory_normed) -> torch.Tensor:
        """ids/pos (T,); memory = H_box rows of pages starting this step (else None),
        memory_normed = box_input_norm(H_box)."""
        cfg, d, M, B = self.cfg, self.d, self.M, self.B
        ids, pos = ids.long(), pos.long()                              # vLLM passes int32 ids
        T = ids.shape[0]
        dev, dt = ids.device, self.head.weight.dtype

        is_box = ids >= cfg.box0_id
        is_ord_bos = ids == cfg.ord_bos_id
        is_order = is_box | is_ord_bos | (ids == cfg.gap_id)
        is_emit = ids == cfg.emit_id
        box = (ids - cfg.box0_id).clamp(0, B - 1)

        # ---- write this position's state; K per page from the cross-attn lengths ----
        st_md, st_kv = self._layer_io(self.state)
        ptr_md, ptr_kv = self._layer_io(self.box_store)
        if st_md is None or ptr_md is None:                             # profiling / dummy run
            K = torch.full((T,), float(B), device=dev)
            cursor = torch.zeros(T, device=dev, dtype=torch.long)
            cursor_box = torch.zeros(T, device=dev, dtype=torch.long)
        else:
            sv = torch.zeros(T, self.heads, self.head_dim, device=dev, dtype=dt)
            sv[:, 0, STATE_BOX_HI] = (box // 32).to(dt)
            sv[:, 0, STATE_BOX_LO] = (box % 32).to(dt)
            sv[:, 0, STATE_IS_BOX] = is_box.to(dt)
            sv[:, 0, STATE_IS_EMIT] = is_emit.to(dt)
            self.state.impl.do_kv_cache_update(self.state, torch.zeros_like(sv), sv, st_kv,
                                               st_md.slot_mapping)
            if memory is not None:                                      # new pages: store boxes
                pk = self.pointer_key_proj(memory).view(-1, self.heads, self.head_dim)
                pv = memory_normed.view(-1, self.heads, self.head_dim)
                self.box_store.impl.do_kv_cache_update(self.box_store, pk, pv, ptr_kv,
                                                       ptr_md.slot_mapping)
            R = min(T, ptr_md.seq_lens.shape[0])
            K = torch.zeros(T, device=dev)
            K[:R] = ptr_md.seq_lens[:R].float()
            c32, b32 = page_cursor(T, st_kv, st_md.block_table, st_md.seq_lens)
            cursor, cursor_box = c32.long(), b32.long().clamp(0, B - 1)
        Kl = K.long()
        done = cursor >= Kl
        # FMT_BOS goes at the first self-attention block boundary after the K boxes
        bs = st_kv.shape[2] if st_md is not None else 16
        fmt_start = (Kl + 1 + bs - 1) // bs * bs

        # ---- one lookup for both stacks: order input box, or the formatter's cursor box ----
        q_box = torch.where(is_order, box, cursor_box)
        if ptr_md is None:
            looked = torch.zeros(T, d, device=dev, dtype=dt)
        else:
            looked = gather_box_rows(ptr_kv, ptr_md.block_table, q_box)  # (T, d) = norm(H_box[q_box])

        # ---- inputs of both stacks ----
        order_pos = pos.clamp(0, cfg.stage_max_positions - 1)
        x_ord = torch.where(is_ord_bos.unsqueeze(-1), self.order_bos.expand(T, d), looked)
        x_ord = x_ord + self.order.pos_embedding[0, order_pos]
        fmt_pos = (pos - fmt_start).clamp(0, cfg.stage_max_positions - 1)
        tok = torch.where(ids == cfg.fmt_bos_id, torch.zeros_like(ids), ids).clamp(0, M)
        hint = torch.where(done.unsqueeze(-1), self.cursor_done.expand(T, d), looked)
        x_fmt = self.token_embedding(tok) + self.formatter.pos_embedding[0, fmt_pos] + hint

        h_o, h_f = self._run_stacks(x_ord, x_fmt, memory, is_order, fmt_start)

        # ---- order logits: exact pointer scores, placed boxes and j >= K at -inf ----
        if ptr_md is None:
            ptr_logits = torch.zeros(T, B, device=dev)
        else:
            ptr_logits = pointer_scores(h_o, ptr_kv, ptr_md.block_table, ptr_md.seq_lens,
                                        st_kv, st_md.block_table, st_md.seq_lens, B, d ** -0.5)

        return self._logits(h_f, ptr_logits, done, is_order, pos, Kl, fmt_start)

    def _logits(self, h_f, ptr_logits, done, is_order, pos, Kl, fmt_start):
        """Final logits over [specials + EMIT | ORD_BOS | FMT_BOS | GAP | boxes], with every
        structural constraint applied. Pure elementwise work -> compiled when enabled."""
        cfg, M = self.cfg, self.M
        T = h_f.shape[0]
        dev = h_f.device
        fmt_pos_raw = pos - fmt_start
        # ---- formatter logits: EMIT masked once all blocks are placed, EOS until then ----
        ninf = float("-inf")
        f_logits = self.head(h_f).float()
        eos_col = torch.where(done, f_logits[:, cfg.eos_token_id], ninf)
        emit_col = torch.where(done, ninf, f_logits[:, M])
        f_logits = torch.cat([f_logits[:, :1], eos_col.unsqueeze(-1),
                              f_logits[:, 2:M], emit_col.unsqueeze(-1)], dim=-1)
        # the formatter's positional table ends at stage_max_positions: stop there (the
        # reference generates at most stage_max_positions - 1 formatter tokens)
        at_cap = fmt_pos_raw >= cfg.stage_max_positions - 1
        eos_only = torch.full_like(f_logits, ninf)
        eos_only[:, cfg.eos_token_id] = 0.0
        f_logits = torch.where(at_cap.unsqueeze(-1), eos_only, f_logits)

        # ---- assemble [specials + EMIT | ORD_BOS | FMT_BOS | GAP | boxes] ----
        order_open = is_order & (pos < Kl)                             # still placing boxes
        order_done = is_order & ~order_open                            # K placed: GAP.. FMT_BOS
        next_is_fmt = order_done & (pos + 1 >= fmt_start)
        left = torch.where(is_order.unsqueeze(-1), ninf, f_logits)
        ord_bos = torch.full((T, 1), ninf, device=dev)
        fmt_bos = torch.where(next_is_fmt, 0.0, ninf).unsqueeze(-1)
        gap = torch.where(order_done & ~next_is_fmt, 0.0, ninf).unsqueeze(-1)
        boxes = torch.where(order_open.unsqueeze(-1), ptr_logits, ninf)
        return torch.cat([left, ord_bos, fmt_bos, gap, boxes], dim=-1)


# --------------------------------------------------------------------------- #
# The model
# --------------------------------------------------------------------------- #
@MULTIMODAL_REGISTRY.register_processor(OcrMultiModalProcessor, info=OcrProcessingInfo,
                                        dummy_inputs=OcrDummyInputsBuilder)
class OcrTwoStageForConditionalGeneration(nn.Module, SupportsMultiModal):

    def __init__(self, *, vllm_config: VllmConfig, prefix: str = ""):
        super().__init__()
        cfg: OcrTwoStageConfig = vllm_config.model_config.hf_config
        # box ids are stored as two base-32 digits in the state cache (exact in bf16)
        assert cfg.max_boxes % 64 == 0 and cfg.max_boxes <= 1024, \
            "max_boxes must be a multiple of 64 and <= 1024"
        assert cfg.d_model % cfg.decoder_attention_heads == 0
        self.cfg = cfg
        self.encoder_dtype = getattr(torch, cfg.encoder_dtype)

        with self._mark_tower_model(vllm_config, "image"):
            self.encoder = BoxEncoder(cfg.rtdetr_config, cfg.d_model, cfg.content_mlp_hidden_dim,
                                      cfg.content_mlp_num_layers)
        # the image half of the encoder always sees (encoder_max_batch, 3, 640, 640): one
        # static shape, compiled once (~2x faster than eager on L40S)
        self._image_sources = (torch.compile(self.encoder.image_sources, dynamic=False)
                               if cfg.compile_encoder else self.encoder.image_sources)
        # the box half (deformable decoder over the OCR boxes) varies with K -> dynamic
        self._box_features = (torch.compile(self.encoder.forward, dynamic=True)
                              if cfg.compile_encoder else self.encoder.forward)
        with self._mark_language_model(vllm_config):
            self.decoder = OcrDecoder(cfg, vllm_config.cache_config, f"{prefix}.decoder" if prefix else "decoder")

    # ------------------------------------------------------------------ #
    # encoder: one output row per OCR box
    # ------------------------------------------------------------------ #
    def embed_multimodal(self, **kwargs) -> MultiModalEmbeddings:
        """One output row per OCR box: H_box (K, d)."""
        pixels, boxes = kwargs["pixel_values"], kwargs["ocr_boxes"]
        pixels = list(pixels.unbind(0)) if isinstance(pixels, torch.Tensor) else list(pixels)
        boxes = list(boxes.unbind(0)) if isinstance(boxes, torch.Tensor) else list(boxes)
        pixels = [p.reshape(3, *p.shape[-2:]) for p in pixels]
        boxes = [b.reshape(-1, 4) for b in boxes]
        param = next(self.encoder.parameters())
        dev, wdt = param.device, param.dtype
        counts = [b.shape[0] for b in boxes]
        n = len(boxes)

        # vLLM budgets encoder work in "encoder tokens" (= boxes), but RT-DETR's cost and
        # memory scale per page image. Run the images in fixed-size chunks so peak memory
        # stays at what profiling measured, however many small pages get scheduled at once.
        chunk = self.cfg.encoder_max_batch
        hs = []
        for c in range(0, n, chunk):
            sl = slice(c, c + chunk)
            px = torch.stack(pixels[sl]).to(dev)
            px = ((px.float() / 255.0) if px.dtype == torch.uint8 else px.float()).to(wdt)
            if self.cfg.encoder_channels_last:
                px = px.contiguous(memory_format=torch.channels_last)
            n_real = px.shape[0]
            if n_real < chunk:                                  # keep the compiled shape static
                px = F.pad(px, (0, 0, 0, 0, 0, 0, 0, chunk - n_real))
            kc = max(counts[sl])
            bx = torch.zeros(n_real, kc, 4, device=dev)
            mask = torch.zeros(n_real, kc, dtype=torch.bool, device=dev)
            for i, b in enumerate(boxes[sl]):
                bx[i, : b.shape[0]] = b.to(dev, torch.float32)
                mask[i, : b.shape[0]] = True
            # encoder_dtype below the weight dtype (e.g. fp32 model, bf16 encoder) -> autocast
            with torch.autocast("cuda", dtype=self.encoder_dtype, enabled=self.encoder_dtype != wdt):
                sources = [src[:n_real] for src in self._image_sources(px)]
                h = self._box_features(px[:n_real], bx, mask, sources=sources)
            hs.extend(h[i, : counts[c + i]] for i in range(h.shape[0]))

        return hs

    def embed_input_ids(self, input_ids: torch.Tensor, *args, **kwargs) -> torch.Tensor:
        return self.decoder.embed_input_ids(input_ids)

    # ------------------------------------------------------------------ #
    # decoder step; returns final logits
    # ------------------------------------------------------------------ #
    def forward(self, input_ids: torch.Tensor, positions: torch.Tensor,
                encoder_outputs: list[torch.Tensor] | None = None, **kwargs) -> torch.Tensor:
        memory = normed = None
        if encoder_outputs:
            dt = self.decoder.head.weight.dtype
            memory = torch.cat(encoder_outputs, dim=0).to(dt)
            normed = self.encoder.box_input_norm(memory)
        return self.decoder(input_ids, positions, memory, normed)

    def compute_logits(self, hidden_states: torch.Tensor) -> torch.Tensor:
        return hidden_states

    # ------------------------------------------------------------------ #
    # weights (checkpoint produced by convert_checkpoint.py; names match 1:1)
    # ------------------------------------------------------------------ #
    def load_weights(self, weights: Iterable[tuple[str, torch.Tensor]]) -> set[str]:
        params = dict(self.named_parameters())
        buffers = dict(self.named_buffers())
        loaded = set()
        for name, w in weights:
            if name in params:
                getattr(params[name], "weight_loader", default_weight_loader)(params[name], w)
            elif name in buffers:
                buffers[name].copy_(w)
            else:
                continue
            loaded.add(name)
        # vLLM attention layers own k/v/q scale params that no checkpoint carries
        missing = {n for n in set(params) - loaded if not n.endswith("_scale")}
        if missing:
            raise ValueError(f"checkpoint is missing {len(missing)} params, e.g. {sorted(missing)[:5]}")
        self.decoder.build_stacked()
        if self.cfg.encoder_channels_last:
            self.encoder.to(memory_format=torch.channels_last)        # faster convs
        return loaded

    @classmethod
    def get_placeholder_str(cls, modality: str, i: int) -> str | None:
        return None
