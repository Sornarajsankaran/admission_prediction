"""
benchmark_grpo.py — Phase 0: GRPO step baseline timing.

Measures the cost of every component in the current (un-optimised) train_step
across representative box counts and three max_new_tokens budgets, so we have
hard numbers before touching any code.

Real dataset distribution:
    boxes / page:  min / median / p90 / p99 / max  =  2 / 73 / 153 / 258 / 443

What is timed (per component, independently):
    T_encode  – one encode_boxes(B=P×K, N) call
    T_ar      – AR decode loop, forced exactly L steps (no EOS, pre-computed H_box)
    T_tf      – teacher-forced AR pass for seq_len tokens (no encode, pre-computed H_box)

Composed to match the real train_step:
    T_step = T_encode          [inside sample_decode]
           + T_ar              [AR rollout]
           + (T_encode + T_tf) [policy sequence_logprobs → forward → encode + tf]
           + (T_encode + T_tf) [ref   sequence_logprobs → forward → encode + tf]
           = 3·T_encode + T_ar + 2·T_tf

Projection rows show the expected gain from Phase 1 + Phase 2 using those
same measured numbers.

Usage:
    # Tiny random model on CPU/GPU (validates harness, relative scaling only):
    python benchmark_grpo.py --smoke

    # Production-size random weights on GPU (realistic timing, no checkpoint needed):
    python benchmark_grpo.py --device cuda

    # Production-size real SFT weights (most accurate):
    python benchmark_grpo.py --device cuda --init-from ./runs/sft/best.pt
"""

from __future__ import annotations

import os
import sys
import time
from pathlib import Path
from types import SimpleNamespace

import click

import torch
import torch.nn.functional as F

_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(_ROOT / "scripts"))

from modeling_ocr_reconstruction import OcrReconstructionConfig, OcrTextReconstructionModel


# ── sweep config ──────────────────────────────────────────────────────────────
N_VALUES            = [73, 153, 258, 443]   # median / p90 / p99 / max of real dataset
MAX_NEW_TOKENS_LIST = [512, 1024, 2048]     # max AR budget to benchmark

PAGES_PER_STEP = 4   # P  (default --pages-per-step)
GROUP_SIZE     = 8   # K  (default --group-size)
B              = PAGES_PER_STEP * GROUP_SIZE  # 32 rollout images per micro-batch

IMAGE_SHAPE = (3, 640, 640)
WARMUP      = 2   # warmup runs (discarded)
REPEATS     = 3   # timed runs for encode_boxes and teacher-forced (fast, <300 ms each)
WARMUP_AR   = 1   # warmup for AR rollout (slow, O(L²))
REPEATS_AR  = 2   # timed runs for AR rollout
# torch.compile warmup: 1st run triggers compilation (slow), 2nd is compiled;
# both branches of the KV-cache (past=None / past!=None) are traced in run 1.
WARMUP_COMPILE  = 2
REPEATS_COMPILE = 2


# ── timing helpers ─────────────────────────────────────────────────────────────
def _sync(device: torch.device) -> None:
    if device.type == "cuda":
        torch.cuda.synchronize(device)


def measure_ms(fn, device: torch.device, warmup: int = WARMUP, repeats: int = REPEATS) -> float:  # noqa: E501
    """Return mean wall-clock time in milliseconds over `repeats` calls (after warmup)."""
    for _ in range(warmup):
        fn()
    _sync(device)

    if device.type == "cuda":
        t0_ev = [torch.cuda.Event(enable_timing=True) for _ in range(repeats)]
        t1_ev = [torch.cuda.Event(enable_timing=True) for _ in range(repeats)]
        for i in range(repeats):
            t0_ev[i].record()
            fn()
            t1_ev[i].record()
        _sync(device)
        return sum(e0.elapsed_time(e1) for e0, e1 in zip(t0_ev, t1_ev)) / repeats
    else:
        times = []
        for _ in range(repeats):
            t0 = time.perf_counter()
            fn()
            t1 = time.perf_counter()
            times.append((t1 - t0) * 1_000)
        return sum(times) / len(times)


# ── synthetic data ─────────────────────────────────────────────────────────────
def make_batch(n_boxes: int, batch_size: int, device: torch.device) -> dict:
    """Synthetic RL batch: random images + valid xyxy boxes in [0, 1]."""
    raw = torch.rand(batch_size, n_boxes, 4, device=device)
    # ensure x1<x2, y1<y2
    x1 = torch.min(raw[..., 0], raw[..., 2])
    y1 = torch.min(raw[..., 1], raw[..., 3])
    x2 = torch.max(raw[..., 0], raw[..., 2])
    y2 = torch.max(raw[..., 1], raw[..., 3])
    boxes = torch.stack([x1, y1, x2, y2], dim=-1)
    return {
        "pixel_values": torch.rand(batch_size, *IMAGE_SHAPE, device=device),
        "ocr_boxes":    boxes,
        "box_mask":     torch.ones(batch_size, n_boxes, dtype=torch.bool, device=device),
    }


def make_dummy_seq(batch_size: int, seq_len: int, n_boxes: int, device: torch.device) -> torch.Tensor:
    """Random token ids in [0, M + N) for teacher-forced recompute timing."""
    M = 17  # OcrReconstructionConfig.num_special_tokens
    return torch.randint(0, M + n_boxes, (batch_size, seq_len + 1), device=device)


# ── component benchmark functions (bypass encode_boxes when h_box is supplied) ──
@torch.no_grad()
def bench_encode_boxes(model, batch) -> None:
    """One encode_boxes call — what the current code runs 3× per step."""
    model.encode_boxes(batch["pixel_values"], batch["ocr_boxes"], box_mask=batch["box_mask"])


@torch.no_grad()
def bench_ar_forced(model, h_box, box_mask, n_steps: int, device: torch.device) -> None:
    """AR decode loop for exactly n_steps (EOS suppressed) using pre-computed H_box.
    Measures the O(L²) autoregressive decoder cost without the encoder overhead."""
    B   = h_box.size(0)
    cfg = model.config
    mem_pad = (~box_mask) if box_mask is not None else None
    seq = torch.full((B, 1), cfg.bos_token_id, dtype=torch.long, device=device)

    for _ in range(n_steps):
        T      = seq.size(1)
        emb    = model._embed_tokens(seq, h_box)
        x      = emb + model.pos_embedding[:, :T]
        cmask  = torch.triu(torch.full((T, T), float("-inf"), device=device), diagonal=1)
        hidden = model.markdown_decoder(tgt=x, memory=h_box,
                                        tgt_mask=cmask,
                                        memory_key_padding_mask=mem_pad)
        hidden = model.decoder_norm(hidden[:, -1:])
        logits, _, _ = model._compute_logits(hidden, h_box, box_mask)
        nxt = logits[:, -1].argmax(-1)
        seq = torch.cat([seq, nxt.unsqueeze(1)], dim=1)


@torch.no_grad()
def bench_ar_kv(model, h_box, box_mask, n_steps: int, device: torch.device) -> None:
    """KV-cached AR decode for exactly n_steps using pre-computed H_box.
    Measures the Phase-2 O(L) path (includes cross-KV precomputation)."""
    B   = h_box.size(0)
    cfg = model.config
    cross_kv, cross_mask = model._precompute_cross_kv(h_box, box_mask)
    seq    = torch.full((B, 1), cfg.bos_token_id, dtype=torch.long, device=device)
    self_kv: list = [None] * len(model.markdown_decoder.layers)

    for t in range(n_steps):
        emb    = model._embed_tokens(seq[:, t:t + 1], h_box)
        x      = emb + model.pos_embedding[:, t:t + 1]
        hidden, self_kv = model._ar_decode_step(x, self_kv, cross_kv, cross_mask)
        logits, _, _ = model._compute_logits(hidden, h_box, box_mask)
        nxt = logits[:, -1].argmax(-1)
        seq = torch.cat([seq, nxt.unsqueeze(1)], dim=1)


@torch.no_grad()
def bench_encode_compiled(compiled_encode, batch) -> None:
    """encode_boxes with torch.compile."""
    compiled_encode(batch["pixel_values"], batch["ocr_boxes"], box_mask=batch["box_mask"])


@torch.no_grad()
def bench_ar_kv_compiled(model, compiled_step, h_box, box_mask,
                          n_steps: int, device: torch.device) -> None:
    """KV-cached AR with torch.compile applied to _ar_decode_step.
    compiled_step is created once outside the timing loop and reused."""
    B   = h_box.size(0)
    cfg = model.config
    cross_kv, cross_mask = model._precompute_cross_kv(h_box, box_mask)
    seq    = torch.full((B, 1), cfg.bos_token_id, dtype=torch.long, device=device)
    self_kv: list = [None] * len(model.markdown_decoder.layers)

    for t in range(n_steps):
        emb    = model._embed_tokens(seq[:, t:t + 1], h_box)
        x      = emb + model.pos_embedding[:, t:t + 1]
        hidden, self_kv = compiled_step(x, self_kv, cross_kv, cross_mask)
        logits, _, _ = model._compute_logits(hidden, h_box, box_mask)
        nxt = logits[:, -1].argmax(-1)
        seq = torch.cat([seq, nxt.unsqueeze(1)], dim=1)


@torch.no_grad()
def bench_teacher_forced(model, h_box, box_mask, seq_len: int, n_boxes: int,
                          device: torch.device) -> None:
    """Single parallel AR decoder pass for seq_len tokens using pre-computed H_box.
    Represents the teacher-forced recompute (O(T) not O(T²)) minus the encoder."""
    seq      = make_dummy_seq(h_box.size(0), seq_len, n_boxes, device)
    inp      = seq[:, :-1]   # (B, seq_len)
    T        = inp.size(1)
    mem_pad  = (~box_mask) if box_mask is not None else None

    emb    = model._embed_tokens(inp, h_box)
    x      = model.embed_dropout(emb + model.pos_embedding[:, :T])
    cmask  = torch.triu(torch.full((T, T), float("-inf"), device=device), diagonal=1)
    hidden = model.markdown_decoder(tgt=x, memory=h_box,
                                    tgt_mask=cmask,
                                    memory_key_padding_mask=mem_pad)
    hidden = model.decoder_norm(hidden)
    model._compute_logits(hidden, h_box, box_mask)


# ── model builders ─────────────────────────────────────────────────────────────
def build_smoke_model(device: torch.device):
    from transformers import RTDetrV2Config, RTDetrV2Model
    rt = RTDetrV2Model(RTDetrV2Config(
        d_model=64, encoder_hidden_dim=64, decoder_in_channels=[64, 64, 64],
        encoder_ffn_dim=128, decoder_ffn_dim=128, decoder_layers=2,
        encoder_layers=1, num_denoising=0,
    ))
    cfg   = OcrReconstructionConfig(d_model=64, num_markdown_layers=2,
                                    markdown_attention_heads=8, markdown_ffn_dim=128,
                                    content_mlp_hidden_dim=64)
    model = OcrTextReconstructionModel(cfg, rtdetr=rt).to(device).eval()
    return model, cfg


_HERON_CFG_PATH = str(_ROOT / "layout_heron" / "heron_config.json")
# Keys in heron_config.json that RTDetrV2Config does not accept.
_HERON_SKIP_KEYS = {"architectures", "model_type", "transformers_version", "torch_dtype"}


def build_production_model(device: torch.device, init_from: str | None = None):
    """Production architecture (Layout-Heron / RTDetrV2) with random or checkpoint weights.

    Loads the exact architecture from layout_heron/heron_config.json so timing
    reflects the real model (52 M params, ResNet-50 backbone, 6-layer decoder).
    No download needed — random weight init is sufficient for accurate step timing.
    """
    import json
    from transformers import RTDetrV2Config, RTDetrV2Model
    with open(_HERON_CFG_PATH) as f:
        hcfg = json.load(f)
    rt_cfg = RTDetrV2Config(**{k: v for k, v in hcfg.items() if k not in _HERON_SKIP_KEYS})
    rt     = RTDetrV2Model(rt_cfg)
    cfg    = OcrReconstructionConfig(d_model=rt_cfg.d_model)
    model  = OcrTextReconstructionModel(cfg, rtdetr=rt).to(device).eval()

    if init_from:
        ck    = torch.load(init_from, map_location=device)
        state = ck["model"] if isinstance(ck, dict) and "model" in ck else ck
        info  = model.load_state_dict(state, strict=False)
        print(f"Loaded {init_from}  (missing {len(info.missing_keys)}, "
              f"unexpected {len(info.unexpected_keys)})")
    return model, cfg


# ── main benchmark ─────────────────────────────────────────────────────────────
def run_benchmark(model, device: torch.device, smoke: bool) -> None:
    cfg = model.config

    print(f"\n{'='*90}")
    print(f"GRPO Step Baseline Benchmark")
    print(f"Device : {device}    d_model={cfg.d_model}    AR layers={cfg.num_markdown_layers}")
    print(f"P={PAGES_PER_STEP} pages × K={GROUP_SIZE} rollouts → B={B} rollout batch")
    print(f"N_values={N_VALUES}    max_new_tokens={MAX_NEW_TOKENS_LIST}")
    print(f"warmup={WARMUP}  repeats={REPEATS}")
    print(f"{'='*90}\n")

    # Collect rows for the summary table
    rows: list[dict] = []

    # ── compile once — reused across all N and L values ───────────────────────
    # dynamic=True: handles growing self_kv shapes (t grows 1→L) without recompilation.
    # fullgraph=False (default): graph-breaks at Python list ops; only tensor kernels compiled.
    # encode_boxes is NOT compiled — RT-DETR's deformable attention hits an inductor bug
    # (SymInt.size) and deformable-attn ops are already heavily optimised CUDA kernels.
    print("Compiling _ar_decode_step with torch.compile(dynamic=True) ...")
    compiled_ar_step = torch.compile(model._ar_decode_step, dynamic=True)
    print("Compiled (graph traced on first timed call).\n")

    for n_boxes in N_VALUES:
        batch = make_batch(n_boxes, B, device)

        # ── encode_boxes (eager only — RT-DETR doesn't compile) ──────────
        t_encode = measure_ms(lambda: bench_encode_boxes(model, batch), device)

        # Pre-compute H_box once for the AR / TF benchmarks below.
        with torch.no_grad():
            h_box    = model.encode_boxes(batch["pixel_values"], batch["ocr_boxes"],
                                          box_mask=batch["box_mask"])
        box_mask = batch["box_mask"]

        header = f"\n── N = {n_boxes} boxes/page ──  encode_boxes={t_encode:.1f} ms (eager, RT-DETR not compilable)"
        print(header)

        for L in MAX_NEW_TOKENS_LIST:
            seq_len = min(2 * n_boxes + 30, L)

            # ── AR rollout: O(L²) baseline ──────────────────────────────────
            t_ar = measure_ms(
                lambda _l=L: bench_ar_forced(model, h_box, box_mask, _l, device),
                device, warmup=WARMUP_AR, repeats=REPEATS_AR,
            )

            # ── AR rollout: O(L) KV-cache eager ─────────────────────────────
            t_ar_kv = measure_ms(
                lambda _l=L: bench_ar_kv(model, h_box, box_mask, _l, device),
                device, warmup=WARMUP_AR, repeats=REPEATS_AR,
            )

            # ── AR rollout: O(L) KV-cache + torch.compile ───────────────────
            t_ar_kv_c = measure_ms(
                lambda _l=L: bench_ar_kv_compiled(model, compiled_ar_step,
                                                   h_box, box_mask, _l, device),
                device, warmup=WARMUP_COMPILE, repeats=REPEATS_COMPILE,
            )

            # ── teacher-forced recompute: O(T), single pass ─────────────────
            t_tf = measure_ms(
                lambda _sl=seq_len: bench_teacher_forced(model, h_box, box_mask,
                                                          _sl, n_boxes, device),
                device,
            )

            # ── compose step costs ───────────────────────────────────────────
            t_step_old  = 3 * t_encode + t_ar      + 2 * t_tf   # original baseline
            t_step_kv   = 3 * t_encode + t_ar_kv   + 2 * t_tf   # KV eager
            t_step_kv_c = 3 * t_encode + t_ar_kv_c + 2 * t_tf   # KV + compiled AR

            ar_speedup   = t_ar    / t_ar_kv
            ar_c_speedup = t_ar_kv / t_ar_kv_c
            step_kv_su   = t_step_old / t_step_kv
            step_kvc_su  = t_step_old / t_step_kv_c

            def _eta(ms): return ms * 2000 / 60_000

            print(f"\n  max_new_tokens = {L:4d}   seq_len_for_recompute ≈ {seq_len}")
            print(f"    T_encode  (eager, not compilable) : {t_encode:7.1f} ms")
            print(f"    T_ar      old O(L²)               : {t_ar:7.1f} ms")
            print(f"    T_ar_kv   eager                   : {t_ar_kv:7.1f} ms  [{ar_speedup:.1f}× vs O(L²)]")
            print(f"    T_ar_kv   compiled                : {t_ar_kv_c:7.1f} ms  [{ar_c_speedup:.2f}× vs eager KV]")
            print(f"    T_tf                              : {t_tf:7.1f} ms")
            print(f"    ┌─────────────────────────────────────────────────────────────────┐")
            print(f"    │  Baseline  (old O(L²))      : {t_step_old:7.1f} ms  ETA(2k)={_eta(t_step_old):6.1f} min           │")
            print(f"    │  KV cache  (eager)          : {t_step_kv:7.1f} ms  ETA(2k)={_eta(t_step_kv):6.1f} min  {step_kv_su:.1f}×    │")
            print(f"    │  KV cache  (compile AR)     : {t_step_kv_c:7.1f} ms  ETA(2k)={_eta(t_step_kv_c):6.1f} min  {step_kvc_su:.1f}×    │")
            print(f"    └─────────────────────────────────────────────────────────────────┘")

            rows.append(dict(
                N=n_boxes, L=L, seq_len=seq_len,
                t_encode=t_encode, t_ar=t_ar, t_ar_kv=t_ar_kv, t_ar_kv_c=t_ar_kv_c, t_tf=t_tf,
                t_step_old=t_step_old, t_step_kv=t_step_kv, t_step_kv_c=t_step_kv_c,
                ar_speedup=ar_speedup, ar_c_speedup=ar_c_speedup,
                step_kv_su=step_kv_su, step_kvc_su=step_kvc_su,
            ))

    # ── Summary table ──────────────────────────────────────────────────────────
    W = 140
    def _eta(ms): return ms * 2000 / 60_000
    print(f"\n\n{'='*W}")
    print("SUMMARY  (all times in ms  |  ETA in minutes for 2000 steps)")
    print(f"{'='*W}")
    hdr = (f"{'N':>5}  {'L':>5}  {'T_ar(old)':>10}  {'T_ar(KV)':>10}  {'T_ar(KV+C)':>11}  {'AR×':>5}  {'AR+C×':>7}  "
           f"{'step(old)':>10}  {'ETA_old':>8}  "
           f"{'step(KV)':>10}  {'ETA_kv':>8}  {'KV×':>5}  "
           f"{'step(KV+C)':>11}  {'ETA_kvc':>8}  {'KVC×':>6}")
    print(hdr)
    print("-" * W)
    for r in rows:
        print(
            f"{r['N']:>5}  {r['L']:>5}  {r['t_ar']:>10.1f}  {r['t_ar_kv']:>10.1f}  {r['t_ar_kv_c']:>11.1f}  "
            f"{r['ar_speedup']:>4.1f}×  {r['ar_c_speedup']:>6.2f}×  "
            f"{r['t_step_old']:>10.1f}  {_eta(r['t_step_old']):>8.1f}  "
            f"{r['t_step_kv']:>10.1f}  {_eta(r['t_step_kv']):>8.1f}  {r['step_kv_su']:>4.1f}×  "
            f"{r['t_step_kv_c']:>11.1f}  {_eta(r['t_step_kv_c']):>8.1f}  {r['step_kvc_su']:>5.1f}×"
        )
    print(f"{'='*W}")
    print("AR×=KV_eager vs O(L²)  AR+C×=KV_compiled vs KV_eager  KVC×=KV+compile vs baseline")
    print()


# ── entry point ────────────────────────────────────────────────────────────────
@click.command(context_settings={"show_default": True})
@click.option("--smoke",     is_flag=True,  help="Tiny random model (CPU/GPU). Shows relative scaling only.")
@click.option("--device",    default="cuda" if torch.cuda.is_available() else "cpu", help="Compute device.")
@click.option("--init-from", default=None,  help="SFT checkpoint path for production-weight timing.")
@click.option("--seed",      default=42,    type=int, help="Random seed.")
def main(smoke, device, init_from, seed) -> None:
    torch.manual_seed(seed)
    dev = torch.device(device)

    if smoke:
        print("[smoke] building tiny random model...")
        model, _ = build_smoke_model(dev)
    else:
        print("[production-size] building model with RTDetrV2Config defaults + d_model=256 ...")
        model, _ = build_production_model(dev, init_from=init_from)

    model.eval()
    run_benchmark(model, dev, smoke=smoke)


if __name__ == "__main__":
    main()
