import re
from collections.abc import Sequence

import pandas as pd
from docling_core.types.doc import DocItemLabel
from docling_lite.core.logging import log_function_calls, logger
from docling.datamodel.base_models import (
    AssembledUnit,
    Cluster,
    ContainerElement,
    FigureElement,
    LayoutPrediction,
    Page,
    PageElement,
    Table,
    TextElement,
)


class PageAssembly:

    _WORD_PATTERN = re.compile(r"\b[\w]+\b")
    _UNICODE_FIXUPS = str.maketrans(
        {
            "⁄": "/",
            "’": "'",
            "‘": "'",
            "“": '"',
            "”": '"',
            "•": "·",
        }
    )
    _TEXT_ELEM_LABELS = {
        DocItemLabel.TEXT,
        DocItemLabel.FOOTNOTE,
        DocItemLabel.CAPTION,
        DocItemLabel.CHECKBOX_UNSELECTED,
        DocItemLabel.CHECKBOX_SELECTED,
        DocItemLabel.SECTION_HEADER,
        DocItemLabel.PAGE_HEADER,
        DocItemLabel.PAGE_FOOTER,
        DocItemLabel.CODE,
        DocItemLabel.LIST_ITEM,
        DocItemLabel.FORMULA,
    }
    _PAGE_HEADER_LABELS = {DocItemLabel.PAGE_HEADER, DocItemLabel.PAGE_FOOTER}
    _TABLE_LABELS = {DocItemLabel.TABLE, DocItemLabel.DOCUMENT_INDEX}
    _CONTAINER_LABELS = {DocItemLabel.FORM, DocItemLabel.KEY_VALUE_REGION}
    _FIGURE_LABEL = DocItemLabel.PICTURE

    @classmethod
    def _join_text_lines(cls, lines: Sequence[str]) -> str:
        if len(lines) <= 1:
            return " ".join(lines).strip()

        normalized = list(lines)
        for index in range(1, len(normalized)):
            prev_line = normalized[index - 1]
            current_line = normalized[index]

            if prev_line.endswith("-"):
                prev_words = cls._WORD_PATTERN.findall(prev_line)
                current_words = cls._WORD_PATTERN.findall(current_line)
                if (
                    prev_words
                    and current_words
                    and prev_words[-1].isalnum()
                    and current_words[0].isalnum()
                ):
                    normalized[index - 1] = prev_line[:-1]
            else:
                normalized[index - 1] = f"{prev_line} "

        return "".join(normalized).strip()

    @classmethod
    def _sanitize_text(cls, lines: Sequence[str]) -> str:
        return cls._join_text_lines(lines).translate(cls._UNICODE_FIXUPS)

    @staticmethod
    def _cluster_text_lines(cluster: Cluster) -> list[str]:
        return [
            cell.text.replace("\x02", "-").strip()
            for cell in cluster.cells
            if cell.text and cell.text.strip()
        ]

    @staticmethod
    def _normalize_layout_prediction(page: Page) -> LayoutPrediction:
        layout_prediction = page.predictions.layout
        if layout_prediction is None:
            normalized_prediction = LayoutPrediction()
            page.predictions.layout = normalized_prediction
            return normalized_prediction

        if isinstance(layout_prediction, LayoutPrediction):
            return layout_prediction

        if isinstance(layout_prediction, list):
            clusters = [
                cluster
                if isinstance(cluster, Cluster)
                else Cluster.model_validate(cluster)
                for cluster in layout_prediction
            ]
            normalized_prediction = LayoutPrediction(clusters=clusters)
            page.predictions.layout = normalized_prediction
            return normalized_prediction

        normalized_prediction = LayoutPrediction.model_validate(layout_prediction)
        page.predictions.layout = normalized_prediction
        return normalized_prediction

    def _build_text_element(self, cluster: Cluster, page: Page) -> TextElement:
        return TextElement(
            label=cluster.label,
            id=cluster.id,
            text=self._sanitize_text(self._cluster_text_lines(cluster)),
            page_no=page.page_no,
            cluster=cluster,
        )

    @staticmethod
    def _build_table_element(cluster: Cluster, page: Page) -> Table:
        table_structure = page.predictions.tablestructure
        if table_structure is not None:
            existing = table_structure.table_map.get(cluster.id)
            if existing is not None:
                return existing
        return Table(
            label=cluster.label,
            id=cluster.id,
            text="",
            otsl_seq=[],
            table_cells=[],
            cluster=cluster,
            page_no=page.page_no,
        )

    @staticmethod
    def _build_figure_element(cluster: Cluster, page: Page) -> FigureElement:
        figures = page.predictions.figures_classification
        if figures is not None:
            existing = figures.figure_map.get(cluster.id)
            if existing is not None:
                return existing
        return FigureElement(
            label=cluster.label,
            id=cluster.id,
            text="",
            data=None,
            cluster=cluster,
            page_no=page.page_no,
        )

    @staticmethod
    def _build_container_element(cluster: Cluster, page: Page) -> ContainerElement:
        return ContainerElement(
            label=cluster.label,
            id=cluster.id,
            page_no=page.page_no,
            cluster=cluster,
        )

    def _build_element(self, cluster: Cluster, page: Page) -> PageElement | None:
        if cluster.label in self._TEXT_ELEM_LABELS:
            return self._build_text_element(cluster, page)
        if cluster.label in self._TABLE_LABELS:
            return self._build_table_element(cluster, page)
        if cluster.label == self._FIGURE_LABEL:
            return self._build_figure_element(cluster, page)
        if cluster.label in self._CONTAINER_LABELS:
            return self._build_container_element(cluster, page)
        return None

    def _is_header(self, element: PageElement) -> bool:
        return element.label in self._PAGE_HEADER_LABELS

    def _assemble_page(self, page: Page) -> None:
        layout_prediction = self._normalize_layout_prediction(page)

        elements: list[PageElement] = []
        headers: list[PageElement] = []
        body: list[PageElement] = []

        for cluster in layout_prediction.clusters:
            element = self._build_element(cluster, page)
            if element is None:
                continue
            elements.append(element)
            (headers if self._is_header(element) else body).append(element)

        page.assembled = AssembledUnit(elements=elements, headers=headers, body=body)

    @log_function_calls(logger)
    def assemble_pages(self, table_results: pd.DataFrame) -> pd.DataFrame:
        for page in table_results["docling_page_obj"]:
            self._assemble_page(page)
        return table_results
