"""
Stage-3 training script: end-to-end joint fine-tune (class-based).
=================================================================

Trains :class:`OcrTwoStageModel` -- one shared box encoder feeding BOTH the order
decoder and the markdown formatter -- with a joint loss

    L = w_order * L_order + w_format * L_format

Both decoders are teacher-forced on gold (no argmax in the graph); the point is that
both losses backprop into the SAME H_box, so the encoder is co-adapted to serve both.
Full network trainable; RT-DETR at ``--backbone-lr`` (low), everything else at ``--lr``.

Init is two-source: order decoder + shared encoder from a Phase-1 checkpoint
(``--init-order-from``), markdown formatter from a Stage-2 checkpoint
(``--init-format-from``); the formatter's encoder is dropped (shared from the order side).

Headline eval metric: **e2e_edit_sim** -- the formatter run on the order decoder's OWN
predicted order (the real product). Compare it to **gold_edit_sim** (formatter on gold
order = its ceiling); the gap is the cost of order errors. Run ``--eval-only`` first
(after the two inits) to get the glued baseline before spending training compute.

Real run (GPU box):

    python stage_3_train.py \
        --train-parquet /data/train.parquet --test-parquet /data/test.parquet --pdf-dir /data/pdfs \
        --init-order-from ./runs/order_full/best.pt --init-format-from ./runs/md_frozen/best.pt \
        --output-dir ./runs/joint --epochs 6 --batch-size 8 --grad-accum 2 \
        --lr 1e-4 --backbone-lr 1e-5 --eval-steps 0

Glued baseline (no training):  add --eval-only.
CPU smoke:                     python stage_3_train.py --smoke
"""

from __future__ import annotations

import json
import os
import sys
import time
from pathlib import Path
from types import SimpleNamespace

sys.path.insert(0, str(Path(__file__).resolve().parent))

import click
import torch
from torch.utils.data import DataLoader

import data
from modeling_ocr_reconstruction import OcrReconstructionConfig, OcrTwoStageModel
from train import build_scheduler
from stage_1_train import reading_order_metrics
from stage_2_train import edit_similarity, _clean_generated, _clean_labels, _SyntheticMarkdownDataset


# --------------------------------------------------------------------------- #
# Two-source init + optimizer (rt-detr lives under order.rtdetr.*)
# --------------------------------------------------------------------------- #
def _init_two_stage(model, order_ckpt, format_ckpt, device):
    """Load order decoder + shared encoder from a Phase-1 checkpoint into ``order.*`` and
    the formatter (minus its encoder, which is shared) into ``formatter.*``."""
    remapped = {}
    if order_ckpt:
        ck = torch.load(order_ckpt, map_location=device)
        state = ck["model"] if isinstance(ck, dict) and "model" in ck else ck
        for k, v in state.items():
            remapped["order." + k] = v
    if format_ckpt:
        ck = torch.load(format_ckpt, map_location=device)
        state = ck["model"] if isinstance(ck, dict) and "model" in ck else ck
        enc = ("rtdetr.", "box_content_mlp.", "box_input_norm.")  # shared from order side -> skip
        for k, v in state.items():
            if k.startswith(enc):
                continue
            remapped["formatter." + k] = v
    info = model.load_state_dict(remapped, strict=False)
    # expected-missing = formatter.{rtdetr,box_content_mlp,box_input_norm} (tied to order.*)
    real_missing = [k for k in info.missing_keys
                    if not (k.startswith("formatter.") and any(
                        k.startswith("formatter." + p) for p in ("rtdetr", "box_content_mlp", "box_input_norm")))]
    print(f"init two-stage: loaded {len(remapped)} tensors | "
          f"non-shared missing {len(real_missing)} | unexpected {len(info.unexpected_keys)}")
    if real_missing:
        print(f"  WARNING missing (fresh): {real_missing[:6]}")


def build_optimizer(model, args):
    """Two LR tiers: RT-DETR (``.rtdetr.``, at backbone-lr) vs everything else (at lr).
    ``named_parameters`` de-duplicates the shared encoder, so it lands in one group."""
    def no_decay(name, p):
        return (p.ndim <= 1 or "norm" in name.lower() or "embedding" in name.lower()
                or name.endswith("pos_embedding") or name.endswith("cursor_done")
                or name.endswith("order_bos"))

    buckets = {("rtdetr", True): [], ("rtdetr", False): [], ("new", True): [], ("new", False): []}
    for name, p in model.named_parameters():
        if not p.requires_grad:
            continue
        section = "rtdetr" if ".rtdetr." in name or name.startswith("rtdetr.") else "new"
        buckets[(section, no_decay(name, p))].append(p)

    lr_map = {"rtdetr": args.backbone_lr, "new": args.lr}
    groups = [{"params": ps, "lr": lr_map[sec], "weight_decay": 0.0 if nd else args.weight_decay}
              for (sec, nd), ps in buckets.items() if ps]
    return torch.optim.AdamW(groups, betas=(0.9, 0.999), eps=1e-8)


# --------------------------------------------------------------------------- #
# Construction
# --------------------------------------------------------------------------- #
def build_model(args, device):
    if args.smoke:
        from transformers import RTDetrV2Config, RTDetrV2Model

        rt = RTDetrV2Model(RTDetrV2Config(
            d_model=64, encoder_hidden_dim=64, decoder_in_channels=[64, 64, 64],
            encoder_ffn_dim=128, decoder_ffn_dim=128, decoder_layers=2,
            encoder_layers=1, num_denoising=0))
        cfg = OcrReconstructionConfig(d_model=64, num_markdown_layers=2, markdown_attention_heads=8,
                                      markdown_ffn_dim=128, content_mlp_hidden_dim=64, dropout=args.dropout)
        model = OcrTwoStageModel(cfg, rtdetr=rt, strict_transformers_version=False,
                                 w_order=args.w_order, w_format=args.w_format)
    else:
        cfg = OcrReconstructionConfig(backbone_name_or_path=args.backbone, dropout=args.dropout)
        model = OcrTwoStageModel(cfg, w_order=args.w_order, w_format=args.w_format)
    return model.to(device), cfg


def build_dataloaders(args):
    if args.smoke:
        train_ds, val_ds = _SyntheticMarkdownDataset(32, seed=0), _SyntheticMarkdownDataset(8, seed=1)
    else:
        image_processor = data.load_image_processor(args.backbone)
        train_ds = data.MarkdownDataset(args.train_parquet, args.pdf_dir, image_processor,
                                        max_len=args.max_len, max_boxes=args.max_boxes)
        val_ds = (data.MarkdownDataset(args.test_parquet, args.pdf_dir, image_processor,
                                       max_len=args.max_len, max_boxes=args.max_boxes)
                  if args.test_parquet else None)

    train_loader = DataLoader(train_ds, batch_size=args.batch_size, shuffle=True,
                              collate_fn=data.twostage_collate_fn,
                              pin_memory=not args.smoke, drop_last=True,
                              **data.make_loader_kwargs(args.num_workers))
    val_loader = (DataLoader(val_ds, batch_size=args.batch_size, shuffle=False,
                             collate_fn=data.twostage_collate_fn,
                             **data.make_loader_kwargs(args.num_workers))
                  if val_ds is not None else None)
    return train_loader, val_loader


# --------------------------------------------------------------------------- #
# Trainer
# --------------------------------------------------------------------------- #
class Stage3Trainer:
    def __init__(self, model, train_loader, val_loader, model_cfg, args, device):
        self.model = model
        self.train_loader = train_loader
        self.val_loader = val_loader
        self.cfg = model_cfg
        self.args = args
        self.device = device

        self.steps_per_epoch = max(1, len(train_loader) // args.grad_accum)
        self.total_steps = self.steps_per_epoch * args.epochs
        self.optimizer = build_optimizer(model, args)
        self.scheduler = build_scheduler(self.optimizer, args, self.total_steps)
        self.use_amp = device.type == "cuda" and not args.no_amp
        self.scaler = torch.amp.GradScaler("cuda", enabled=self.use_amp)

        self.step, self.start_epoch, self.best = 0, 0, -1.0  # best = max end-to-end edit-sim
        self.sample_dir = os.path.join(args.output_dir, "samples")
        os.makedirs(self.sample_dir, exist_ok=True)
        if args.resume:
            self._load(args.resume)

    def _autocast(self):
        return torch.amp.autocast(device_type=self.device.type, enabled=self.use_amp)

    def _to_device(self, batch):
        return {k: v.to(self.device, non_blocking=True) for k, v in batch.items()}

    def train_epoch(self, epoch):
        self.model.train()
        self.optimizer.zero_grad(set_to_none=True)
        run_l = run_o = run_f = 0.0
        t0 = time.time()

        for i, batch in enumerate(self.train_loader):
            batch = self._to_device(batch)
            with self._autocast():
                out = self.model(**batch)
                loss = out.loss / self.args.grad_accum
            self.scaler.scale(loss).backward()
            run_l += float(out.loss.detach()); run_o += float(out.order_loss); run_f += float(out.format_loss)

            if (i + 1) % self.args.grad_accum != 0:
                continue

            self.scaler.unscale_(self.optimizer)
            torch.nn.utils.clip_grad_norm_((p for p in self.model.parameters() if p.requires_grad),
                                           self.args.grad_clip)
            self.scaler.step(self.optimizer)
            self.scaler.update()
            self.scheduler.step()
            self.optimizer.zero_grad(set_to_none=True)
            self.step += 1

            if self.step % self.args.log_every == 0:
                denom = self.args.grad_accum * self.args.log_every
                print(f"epoch {epoch} step {self.step}/{self.total_steps} "
                      f"loss {run_l/denom:.4f} (ord {run_o/denom:.4f} fmt {run_f/denom:.4f}) "
                      f"lr {self.scheduler.get_last_lr()[0]:.2e} "
                      f"{denom/(time.time()-t0):.1f} it/s")
                run_l = run_o = run_f = 0.0
                t0 = time.time()

            if (self.val_loader is not None and self.args.eval_steps
                    and self.step % self.args.eval_steps == 0):
                m = self.eval_epoch(tag=f"step{self.step}")
                self._print_eval(m)
                self._maybe_save_best(m["e2e_edit_sim"], epoch)

    @torch.no_grad()
    def eval_epoch(self, tag):
        self.model.eval()
        metrics = self._teacher_forced_metrics()
        metrics.update(self._free_running_metrics(tag))
        self.model.train()
        return metrics

    @torch.no_grad()
    def _teacher_forced_metrics(self):
        o_loss = f_loss = 0.0
        o_tot = o_ok = f_tot = f_ok = emit_tot = emit_ok = spc_tot = spc_ok = nseq = 0
        EMIT = self.model.formatter.emit_next_id
        cap, seen = self.args.max_eval_samples, 0
        for batch in self.val_loader:
            batch = self._to_device(batch)
            with self._autocast():
                out = self.model(**batch)
            ol = batch["order_label"]; ov = ol != data.IGNORE_INDEX
            o_ok += int(((out.order_logits.argmax(-1) == ol) & ov).sum()); o_tot += int(ov.sum())
            lab = batch["labels"]; fv = lab != data.IGNORE_INDEX
            fok = (out.format_logits.argmax(-1) == lab) & fv
            f_ok += int(fok.sum()); f_tot += int(fv.sum())
            ie, isp = fv & (lab == EMIT), fv & (lab < EMIT)
            emit_tot += int(ie.sum()); emit_ok += int((fok & ie).sum())
            spc_tot += int(isp.sum()); spc_ok += int((fok & isp).sum())
            o_loss += float(out.order_loss); f_loss += float(out.format_loss); nseq += 1
            seen += batch["labels"].size(0)
            if cap is not None and seen >= cap:
                break
        return {
            "order_loss": o_loss / max(nseq, 1), "format_loss": f_loss / max(nseq, 1),
            "order_acc": o_ok / max(o_tot, 1), "format_token_acc": f_ok / max(f_tot, 1),
            "emit_acc": emit_ok / max(emit_tot, 1), "special_acc": spc_ok / max(spc_tot, 1),
        }

    @torch.no_grad()
    def _free_running_metrics(self, tag):
        pw = gold_sim = e2e_sim = e2e_exact = 0.0
        n = 0
        records, n_store = [], self.args.num_eval_samples
        cap = self.args.max_eval_samples
        m = self.model
        for batch in self.val_loader:
            batch = self._to_device(batch)
            gen, pred_order, n_real = m.generate_end_to_end(
                batch["pixel_values"], batch["ocr_boxes"], box_mask=batch["box_mask"],
                max_new_tokens=self.args.max_gen_tokens)
            gold_gen = m.formatter.generate_markdown(
                batch["pixel_values"], batch["ocr_boxes"], batch["order"],
                box_mask=batch["box_mask"], max_new_tokens=self.args.max_gen_tokens)
            for b in range(gen.size(0)):
                k = int(n_real[b])
                gold_order = batch["order"][b, :k].tolist()
                pred_ord = pred_order[b, :k].tolist()
                pw += reading_order_metrics(pred_ord, gold_order)["pairwise"]

                gold_ids = _clean_labels(batch["labels"][b].tolist(), self.cfg.eos_token_id, data.IGNORE_INDEX)
                e2e_ids = _clean_generated(gen[b].tolist(), self.cfg.bos_token_id,
                                           self.cfg.eos_token_id, self.cfg.pad_token_id)
                gold_fmt = _clean_generated(gold_gen[b].tolist(), self.cfg.bos_token_id,
                                            self.cfg.eos_token_id, self.cfg.pad_token_id)
                e2e_sim += edit_similarity(e2e_ids, gold_ids)
                e2e_exact += int(e2e_ids == gold_ids)
                gold_sim += edit_similarity(gold_fmt, gold_ids)
                n += 1
                if len(records) < n_store:
                    records.append({"tag": tag, "step": self.step, "K": k,
                                    "gold_order": gold_order, "pred_order": pred_ord,
                                    "e2e": data.render_sequence(gen[b].tolist(), self.cfg.num_special_tokens)})
            if cap is not None and n >= cap:
                break
        path = os.path.join(self.sample_dir, f"{tag}.jsonl")
        with open(path, "w", encoding="utf-8") as f:
            for r in records:
                f.write(json.dumps(r, ensure_ascii=False) + "\n")
        d = max(n, 1)
        return {"order_pairwise": pw / d, "gold_edit_sim": gold_sim / d,
                "e2e_edit_sim": e2e_sim / d, "e2e_exact": e2e_exact / d}

    def _print_eval(self, m):
        print(f"[eval@{self.step}] loss(ord {m['order_loss']:.3f} fmt {m['format_loss']:.3f}) "
              f"order_acc {m['order_acc']:.3f} fmt_tok {m['format_token_acc']:.3f} "
              f"special {m['special_acc']:.3f}")
        print(f"  order_pairwise {m['order_pairwise']:.3f} | "
              f"gold_edit_sim {m['gold_edit_sim']:.3f}  e2e_edit_sim {m['e2e_edit_sim']:.3f} "
              f"(gap {m['gold_edit_sim'] - m['e2e_edit_sim']:.3f})  e2e_exact {m['e2e_exact']:.3f}")

    def train_model(self):
        n_train = sum(p.numel() for p in self.model.parameters() if p.requires_grad)
        n_total = sum(p.numel() for p in self.model.parameters())
        print(f"trainable {n_train/1e6:.2f}M / {n_total/1e6:.2f}M | "
              f"w_order {self.args.w_order} w_format {self.args.w_format} | "
              f"steps/epoch {self.steps_per_epoch} | total {self.total_steps}")
        for epoch in range(self.start_epoch, self.args.epochs):
            self.train_epoch(epoch)
            if self.val_loader is not None:
                m = self.eval_epoch(tag=f"epoch{epoch}")
                self._print_eval(m)
                self._maybe_save_best(m["e2e_edit_sim"], epoch)
            self._save(os.path.join(self.args.output_dir, "last.pt"), epoch + 1)
        print("done.")

    @torch.no_grad()
    def eval_model(self, ckpt=None):
        if ckpt:
            self._load(ckpt)
        if self.val_loader is None:
            raise ValueError("eval_model requires a validation loader")
        m = self.eval_epoch(tag="eval_model")
        self._print_eval(m)
        return m

    def _maybe_save_best(self, e2e, epoch):
        if e2e > self.best:
            self.best = e2e
            self._save(os.path.join(self.args.output_dir, "best.pt"), epoch + 1)
            print(f"  saved best (e2e_edit_sim {self.best:.4f})")

    def _save(self, path, epoch):
        os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
        torch.save({"model": self.model.state_dict(), "optimizer": self.optimizer.state_dict(),
                    "scheduler": self.scheduler.state_dict(), "scaler": self.scaler.state_dict(),
                    "step": self.step, "epoch": epoch, "best": self.best}, path)

    def _load(self, path):
        ck = torch.load(path, map_location=self.device)
        self.model.load_state_dict(ck["model"])
        self.optimizer.load_state_dict(ck["optimizer"])
        self.scheduler.load_state_dict(ck["scheduler"])
        self.scaler.load_state_dict(ck["scaler"])
        self.step, self.start_epoch, self.best = ck["step"], ck["epoch"], ck["best"]
        print(f"resumed from {path} @ step {self.step}, epoch {self.start_epoch}")


# --------------------------------------------------------------------------- #
# CLI
# --------------------------------------------------------------------------- #
@click.command(context_settings={"show_default": True})
@click.option("--train-parquet", type=click.Path(), default=None)
@click.option("--test-parquet", type=click.Path(), default=None)
@click.option("--pdf-dir", type=click.Path(), default=None)
@click.option("--backbone", default="docling-project/docling-layout-heron")
@click.option("--max-len", type=int, default=2048)
@click.option("--max-boxes", type=int, default=None)
@click.option("--epochs", type=int, default=6)
@click.option("--batch-size", type=int, default=8)
@click.option("--grad-accum", type=int, default=2)
@click.option("--lr", type=float, default=1e-4, help="LR for new modules")
@click.option("--backbone-lr", type=float, default=1e-5, help="LR for rt-detr")
@click.option("--weight-decay", type=float, default=0.01)
@click.option("--warmup-steps", type=int, default=500)
@click.option("--min-lr-ratio", type=float, default=0.05)
@click.option("--grad-clip", type=float, default=1.0)
@click.option("--dropout", type=float, default=0.1)
@click.option("--w-order", type=float, default=1.0, help="weight on the order loss")
@click.option("--w-format", type=float, default=1.0, help="weight on the format loss")
@click.option("--init-order-from", type=click.Path(), default=None, help="Phase-1 checkpoint (order + encoder)")
@click.option("--init-format-from", type=click.Path(), default=None, help="Stage-2 checkpoint (formatter)")
@click.option("--num-workers", type=int, default=8)
@click.option("--device", default="cuda" if torch.cuda.is_available() else "cpu")
@click.option("--no-amp", is_flag=True)
@click.option("--seed", type=int, default=42)
@click.option("--output-dir", type=click.Path(), default="./runs/joint")
@click.option("--resume", type=click.Path(), default=None)
@click.option("--eval-only", is_flag=True, help="glued baseline: eval the two loaded models, no training")
@click.option("--log-every", type=int, default=20)
@click.option("--eval-steps", type=int, default=0, help="eval every N steps (0 = epoch end only)")
@click.option("--num-eval-samples", type=int, default=25, help="how many eval samples to dump to jsonl")
@click.option("--max-eval-samples", type=int, default=None,
              help="cap eval to the first N test samples (None = full set); free-running gen is the bottleneck")
@click.option("--max-gen-tokens", type=int, default=1024)
@click.option("--smoke", is_flag=True)
def main(**kwargs):
    args = SimpleNamespace(**kwargs)

    if args.smoke:
        args.epochs = 2 if args.epochs == 6 else args.epochs
        args.batch_size, args.grad_accum, args.num_workers = 2, 2, 0
        args.warmup_steps, args.log_every = 2, 1
        args.eval_steps, args.num_eval_samples, args.max_gen_tokens = 4, 4, 40
        args.max_eval_samples = 8
        args.output_dir = "./runs/joint_smoke"
    elif not args.eval_only and not (args.train_parquet and args.pdf_dir):
        raise click.UsageError("--train-parquet and --pdf-dir are required (or use --smoke)")

    torch.manual_seed(args.seed)
    device = torch.device(args.device)
    print(f"device={device}  smoke={args.smoke}")

    model, cfg = build_model(args, device)
    if args.init_order_from or args.init_format_from:
        _init_two_stage(model, args.init_order_from, args.init_format_from, device)
    train_loader, val_loader = build_dataloaders(args)
    trainer = Stage3Trainer(model, train_loader, val_loader, cfg, args, device)

    if args.eval_only:
        trainer.eval_model(ckpt=args.resume)
    else:
        trainer.train_model()


if __name__ == "__main__":
    main()
