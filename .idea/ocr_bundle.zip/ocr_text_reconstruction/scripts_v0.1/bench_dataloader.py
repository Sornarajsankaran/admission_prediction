#!/usr/bin/env python3
"""
bench_dataloader.py -- find where __getitem__ spends its time, on the REAL corpus.
=================================================================================

Run this on the training box. A synthetic vector PDF and a 300-dpi scan have
completely different rasterization costs (a scan makes get_pixmap decode a large
embedded JPEG), so the split below has to be measured on your actual pages.

    python bench_dataloader.py --parquet train.parquet --pdf-dir /data/pdfs
    python bench_dataloader.py --parquet train.parquet --pdf-dir /data/pdfs \
        --loader-test --num-workers 8 --batch-size 16

Reports:
  1. per-stage timing of the current path (raster vs image-processor)
  2. candidate replacements, each with its numerical difference vs the current
     output -- a fast variant that changes pixels is NOT free when stage 2 runs
     on a frozen encoder trained against the current ones
  3. optional end-to-end DataLoader throughput at a given worker count
"""

from __future__ import annotations

import time

import click
import numpy as np
import pandas as pd


def _timeit(fn, n, warmup=2):
    for _ in range(warmup):
        fn()
    t0 = time.perf_counter()
    for _ in range(n):
        fn()
    return (time.perf_counter() - t0) / n * 1000.0


@click.command()
@click.option("--parquet", "parquet_path", required=True,
              type=click.Path(exists=True, dir_okay=False))
@click.option("--pdf-dir", required=True, type=click.Path(exists=True, file_okay=False))
@click.option("--n", type=int, default=25, help="pages to time")
@click.option("--zoom", type=float, default=2.0, help="current rasterize zoom")
@click.option("--target", type=int, default=640, help="model input size")
@click.option("--loader-test", is_flag=True, help="also time a real DataLoader")
@click.option("--num-workers", type=int, default=8)
@click.option("--batch-size", type=int, default=16)
def main(parquet_path, pdf_dir, n, zoom, target, loader_test, num_workers, batch_size):
    import fitz
    from pathlib import Path
    from PIL import Image
    from transformers import RTDetrImageProcessor

    pdf_dir = Path(pdf_dir)
    path = str(parquet_path)
    df = pd.read_pickle(path) if path.endswith((".pkl", ".pickle")) else pd.read_parquet(path)
    df = df.sample(min(n, len(df)), random_state=0)

    proc = RTDetrImageProcessor()
    pages = []
    for _, row in df.iterrows():
        doc = fitz.open(pdf_dir / str(row["file_name"]))
        pages.append((doc, doc[int(row["page"]) - 1]))

    click.secho(f"\n{len(pages)} real pages from {parquet_path}\n", bold=True)

    def raster(page, z):
        pix = page.get_pixmap(matrix=fitz.Matrix(z, z), alpha=False)
        return Image.frombytes("RGB", (pix.width, pix.height), pix.samples)

    # ---- 1. current path, split into its two halves --------------------
    imgs = [raster(p, zoom) for _, p in pages]
    mp = np.mean([im.size[0] * im.size[1] for im in imgs]) / 1e6
    t_raster = _timeit(lambda: [raster(p, zoom) for _, p in pages], 3) / len(pages)
    t_proc = _timeit(
        lambda: [proc(images=im, return_tensors="pt")["pixel_values"][0] for im in imgs], 3
    ) / len(pages)
    total = t_raster + t_proc

    click.secho("current path", bold=True)
    click.echo(f"  raster zoom={zoom} -> {mp:.2f} MPix avg     {t_raster:7.2f} ms  "
               f"({100 * t_raster / total:4.1f}%)")
    click.echo(f"  RTDetrImageProcessor                {t_proc:7.2f} ms  "
               f"({100 * t_proc / total:4.1f}%)")
    click.echo(f"  TOTAL per item                      {total:7.2f} ms")
    click.echo(f"  waste: rasterizing {mp * 1e6 / (target * target):.1f}x the pixels the model reads")

    # ---- 2. candidates, with fidelity ----------------------------------
    ref = [proc(images=im, return_tensors="pt")["pixel_values"][0] for im in imgs]

    import torch

    def pil_hand(im):
        a = np.asarray(im.resize((target, target), Image.BILINEAR), dtype=np.uint8)
        return torch.from_numpy(np.ascontiguousarray(a.transpose(2, 0, 1))).float().mul_(1 / 255)

    def zoom_for(page):
        r = page.rect
        return target / max(r.width, r.height)

    cands = [
        ("A. raster zoom={} + PIL resize by hand".format(zoom),
         lambda: [pil_hand(raster(p, zoom)) for _, p in pages]),
        ("B. raster direct(~{}) + PIL resize".format(target),
         lambda: [pil_hand(raster(p, zoom_for(p))) for _, p in pages]),
    ]
    try:
        import cv2

        def cv2_hand(im, interp):
            a = np.frombuffer(im.tobytes(), np.uint8).reshape(im.size[1], im.size[0], 3)
            o = cv2.resize(a, (target, target), interpolation=interp)
            return torch.from_numpy(np.ascontiguousarray(o.transpose(2, 0, 1))).float().mul_(1 / 255)

        cands.append(("C. raster direct + cv2 INTER_AREA",
                      lambda: [cv2_hand(raster(p, zoom_for(p)), cv2.INTER_AREA) for _, p in pages]))
    except ImportError:
        click.secho("  (cv2 not installed -- skipping the cv2 candidate)", fg="yellow")

    click.secho("\ncandidates", bold=True)
    click.echo(f"  {'option':44s} {'ms':>8} {'speedup':>8} {'maxdiff':>9} {'meandiff':>9}")
    for label, fn in cands:
        t = _timeit(fn, 3) / len(pages)
        outs = fn()
        d = torch.stack([(o - r).abs().max() for o, r in zip(outs, ref)]).max().item()
        m = torch.stack([(o - r).abs().mean() for o, r in zip(outs, ref)]).mean().item()
        flag = "  <- bit-identical" if d == 0 else ""
        click.echo(f"  {label:44s} {t:8.2f} {total / t:7.2f}x {d:9.5f} {m:9.6f}{flag}")

    click.echo("\n  maxdiff/meandiff are vs the CURRENT output, in [0,1] pixel units.")
    click.echo("  A changes nothing numerically -- it is pure HF-wrapper overhead removal.")
    click.echo("  B/C are faster still but DO change pixels; stage 2 runs a frozen encoder")
    click.echo("  trained on the current ones, so treat that as a distribution shift.")

    # ---- 3. projected throughput ---------------------------------------
    click.secho("\nprojected steps/s (batch %d)" % batch_size, bold=True)
    for label, per_item in [("current", total)] + [
        (lbl.split(".")[0], _timeit(fn, 3) / len(pages)) for lbl, fn in cands
    ]:
        click.echo(f"  {label:10s} " + "   ".join(
            f"{w}w={1000 / per_item * w / batch_size:6.2f}" for w in (4, 8, 16, 32)))

    for doc, _ in pages:
        doc.close()

    # ---- 4. optional end-to-end loader test ----------------------------
    if loader_test:
        click.secho("\nend-to-end DataLoader", bold=True)
        import data
        from torch.utils.data import DataLoader

        ds = data.MarkdownDataset(
            parquet_path=parquet_path, pdf_dir=str(pdf_dir),
            image_processor=proc,
        )
        for persistent in (False, True):
            dl = DataLoader(ds, batch_size=batch_size, shuffle=True,
                            num_workers=num_workers, collate_fn=data.md_collate_fn,
                            pin_memory=True, drop_last=True,
                            persistent_workers=persistent and num_workers > 0,
                            prefetch_factor=4 if num_workers > 0 else None)
            it = iter(dl)
            for _ in range(3):
                next(it)
            t0 = time.perf_counter()
            steps = 0
            while steps < 20:
                next(it)
                steps += 1
            dt = time.perf_counter() - t0
            click.echo(f"  persistent_workers={str(persistent):5s} "
                       f"{steps / dt:6.2f} steps/s  ({steps * batch_size / dt:7.1f} pages/s)")


if __name__ == "__main__":
    main()
