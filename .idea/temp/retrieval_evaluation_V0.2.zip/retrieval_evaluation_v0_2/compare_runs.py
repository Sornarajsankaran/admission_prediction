#!/usr/bin/env python3
"""Combine independent V0.2 evaluation runs after checking comparability."""
from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path

from evaluate_retrieval import EvaluationError, SUMMARY_COLUMNS


def compare(run_dirs: list[Path], output: Path) -> list[dict]:
    if len(run_dirs) < 2:
        raise EvaluationError("Supply at least two run directories")
    rows = []
    baseline = None
    seen_ids = set()
    fields = ("run_id", "model_id", *SUMMARY_COLUMNS)
    for folder in run_dirs:
        metadata = json.loads((folder / "metadata.json").read_text(encoding="utf-8"))
        config = (
            metadata["evaluation_version"], metadata["ground_truth_sha256"],
            tuple(metadata["k_values"]), tuple(metadata["categories"]),
            tuple(metadata["positive_labels"]), metadata["ap_denominator"],
            metadata["short_pool_policy"], metadata["score_ties"],
        )
        if baseline is None:
            baseline = config
        elif config != baseline:
            raise EvaluationError(
                f"Non-comparable run {folder}: ground-truth hash or metric configuration differs"
            )
        rid = metadata["run_id"]
        if rid in seen_ids:
            raise EvaluationError(f"Duplicate run_id: {rid}")
        seen_ids.add(rid)
        with (folder / "summary.csv").open(encoding="utf-8", newline="") as stream:
            reader = csv.DictReader(stream)
            if reader.fieldnames is None or set(reader.fieldnames) != set(SUMMARY_COLUMNS):
                raise EvaluationError(f"Unexpected summary columns in {folder}")
            row_count = 0
            for data in reader:
                rows.append({"run_id": rid, "model_id": metadata["model_id"], **data})
                row_count += 1
            if row_count != len(metadata["categories"]) * 3 * len(metadata["k_values"]) + 3 * len(metadata["k_values"]):
                raise EvaluationError(f"Unexpected summary row count in {folder}: {row_count}")
    if output.exists():
        raise EvaluationError(f"Refusing to overwrite {output}")
    output.parent.mkdir(parents=True, exist_ok=True)
    with output.open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)
    return rows


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("run_dirs", nargs="+", type=Path)
    parser.add_argument("--output", type=Path, default=Path("comparison.csv"))
    args = parser.parse_args()
    try:
        rows = compare(args.run_dirs, args.output)
        print(f"Wrote {len(rows)} comparison rows to {args.output}")
    except (OSError, EvaluationError, KeyError, json.JSONDecodeError) as exc:
        parser.exit(2, f"Comparison error: {exc}\n")


if __name__ == "__main__":
    main()
