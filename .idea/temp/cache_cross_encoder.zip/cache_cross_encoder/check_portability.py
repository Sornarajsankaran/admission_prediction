"""Check variable-length document updates during graph replay against dense FP32."""
import json
from pathlib import Path
import torch
from transformers import AutoModelForSequenceClassification
from cached_model import CachedModernBert
from bench_cached import make_graph
from validate import dense_inputs,metrics

@torch.inference_mode()
def main():
    root=Path(__file__).resolve().parent
    torch.set_num_threads(8)
    torch.backends.cuda.matmul.allow_tf32=False
    data=torch.load(root/'examples/prepared/tokenized.pt',weights_only=True)
    model=AutoModelForSequenceClassification.from_pretrained(root/'models/benchmark-cls',dtype=torch.float32,attn_implementation='sdpa',local_files_only=True).cuda().eval()
    runner=CachedModernBert(model,backend='sdpa',doc_backend='sdpa')
    q=data['query_input_ids'].cuda();ql=data['query_lengths'].cuda()
    d=data['doc_input_ids'][:1].cuda();dl=data['doc_lengths'][:1].cuda()
    meta=runner.metadata(q,ql,d,dl);runner.prepare_joint_metadata(meta)
    fn,graph=make_graph(lambda:runner.stream_joint(q,d,meta))
    results=[]
    for i in range(len(data['doc_lengths'])):
        d.copy_(data['doc_input_ids'][i:i+1]);dl.copy_(data['doc_lengths'][i:i+1])
        got=fn().clone()
        ids=list(range(i*len(ql),(i+1)*len(ql)))
        dense,_=dense_inputs(data,ids,64,shift=True)
        expected=model(**dense).logits.reshape_as(got)
        torch.testing.assert_close(got,expected,atol=5e-5,rtol=5e-5)
        results.append({'document':i,'length':int(dl[0]),**metrics(got,expected)})
    (root/'examples/portability_check.json').write_text(json.dumps({'passed':True,'checks':results},indent=2)+'\n')
    print(json.dumps(results,indent=2))
if __name__=='__main__':main()
