import fitz
import pandas as pd
from typing import Dict

from docling_lite.core.datamodels import TextractBBox
from docling_lite.core.logging import log_function_calls, logger
from docling.datamodel.base_models import Page
from docling_core.types.doc import BoundingBox, CoordOrigin, Size
from docling_core.types.doc.page import (
    BoundingRectangle,
    PdfPageBoundaryType,
    PdfPageGeometry,
    SegmentedPdfPage,
    TextCell,
)
from docling_lite.core.config import (
    LINE_COORDS_SEPARATOR,
    LINE_SEPARATOR,
    WORD_COORDS_SEPARATOR,
    WORD_SEPARATOR,
)


class Preprocessor:
    @staticmethod
    def _get_page_size(page: fitz.Page) -> Size:
        page_rect = page.rect
        return Size(width=float(page_rect.width), height=float(page_rect.height))

    @classmethod
    def _get_page_geometry(cls, page: fitz.Page) -> PdfPageGeometry:
        page_size = cls._get_page_size(page)
        page_bbox = BoundingBox.from_tuple(
            coord=(0.0, 0.0, float(page_size.width), float(page_size.height)),
            origin=CoordOrigin.BOTTOMLEFT,
        )
        page_rect = BoundingRectangle.from_bounding_box(page_bbox)
        return PdfPageGeometry(
            angle=0.0,
            rect=page_rect,
            boundary_type=PdfPageBoundaryType.CROP_BOX,
            art_bbox=page_bbox,
            bleed_bbox=page_bbox,
            crop_bbox=page_bbox,
            media_bbox=page_bbox,
            trim_bbox=page_bbox,
        )

    @staticmethod
    def _parse_ocr_results(content, line_cord, word_cord, page_size):
        raw_lines = str(content).split(LINE_SEPARATOR)
        words = [w for line in raw_lines for w in line.split(WORD_SEPARATOR)]
        lines = [line.replace(WORD_SEPARATOR, " ") for line in raw_lines]

        line_coords_items = str(line_cord).split(LINE_COORDS_SEPARATOR)
        word_coords_items = str(word_cord).split(WORD_COORDS_SEPARATOR)

        line_bboxs = [TextractBBox.from_string(c, page_size) for c in line_coords_items]
        word_bboxs = [TextractBBox.from_string(c, page_size) for c in word_coords_items]

        line_cells = [
            TextCell(text=line, orig=line, rect=bbox, from_ocr=True, index=index)
            for index, (line, bbox) in enumerate(zip(lines, line_bboxs))
        ]
        word_cells = [
            TextCell(text=word, orig=word, rect=bbox, from_ocr=True, index=index)
            for index, (word, bbox) in enumerate(zip(words, word_bboxs))
        ]

        return line_cells, word_cells

    @classmethod
    def _build_page_objects(cls, row, pdfs: Dict[str, fitz.Document]) -> pd.Series:
        pdf_page = pdfs[row["file_name"]].load_page(int(row["page"]))
        page_size = cls._get_page_size(pdf_page)
        pdf_page_geometry = cls._get_page_geometry(pdf_page)

        lines, words = cls._parse_ocr_results(
            row["content"], row["line_cord"], row["word_cord"], page_size.as_tuple()
        )

        ocr_page = SegmentedPdfPage(
            dimension=pdf_page_geometry,
            textline_cells=lines,
            word_cells=words,
            char_cells=[],
        )
        docling_page = Page(
            page_no=int(row["page"]), size=page_size, parsed_page=ocr_page
        )
        return pd.Series({"pdf_page_obj": pdf_page, "docling_page_obj": docling_page})

    @classmethod
    @log_function_calls(logger)
    def preprocess(cls, ocr_df: pd.DataFrame, pdfs: Dict[str, fitz.Document]):
        try:
            df = ocr_df.copy()
            df[["pdf_page_obj", "docling_page_obj"]] = df.apply(
                lambda row: cls._build_page_objects(row, pdfs), axis=1
            )
            preprocessed_df = df[
                [
                    "file_name",
                    "page",
                    "content",
                    "line_cord",
                    "word_cord",
                    "pdf_page_obj",
                    "docling_page_obj",
                ]
            ]

            return preprocessed_df

        except Exception as e:
            logger.error(f"Error during preprocessing: {e}")
            raise
