"""
Data pipeline for the OCR Text Reconstruction model.
=====================================================

Source: parquet files with columns
    file_name              : PDF filename (under PDF_DIR)
    page                   : 1-based page number  (page = doc[page - 1])
    ocr_bbox               : np.ndarray (N, 4)  x1,y1,x2,y2  ALREADY normalized to [0, 1]
    encoded_ouput_ids_raw  : list[int]  target sequence in the GLOBAL tokenizer scheme
                             (box id = ocr index in [0, 9999]; special = 10000..10068)

Per-row processing (see the conversation / plan.md):

  1. Drop <unk> (global id 10003) from the sequence entirely.
  2. Compaction: keep only OCR boxes actually referenced in the sequence, renumber
     the survivors contiguously, and rewrite the box pointer ids to match. This
     avoids training the model to "skip" boxes that were only lost to matching
     failures (v1 = order+format every box it is given).
  3. Global -> model-compact id remap (padding-independent):
         special g  ->  g - 10000        (in [0, M))
         box     i  ->  M + new_index    (M = num_special_tokens)
  4. Teacher forcing: decoder_input_ids = ids[:-1], labels = ids[1:].
  5. Drop the row if it has no referenced boxes, or if the (post-shift) length
     exceeds ``max_len`` (default 2048).

The model's ``H_box[i]`` corresponds to ``ocr_bbox[i]`` (confirmed: row order ==
ocr id order), which is what makes the pointer ids meaningful.

v0.1: the special vocab is no longer hardcoded here. It is read from
``vocab.json`` (the same file ``tokenizer.py`` loads), because the v0 copy of it
drifted -- ``SPECIAL_ID_TO_STR`` still described the 17-token markdown vocab long
after the tokenizer moved on. M grew 17 -> 69 when tables became HTML, and a
mismatch between this module and the tokenizer silently drops every page that
contains a table (special_id_out_of_range), so there is exactly one source of
truth now.
"""

from __future__ import annotations

import json
from collections import OrderedDict
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Optional

import numpy as np
import torch
from torch.utils.data import Dataset

# --------------------------------------------------------------------------- #
# Vocab (single source of truth: vocab.json, shared with tokenizer.py)
# --------------------------------------------------------------------------- #
VOCAB_PATH = Path(__file__).with_name("vocab.json")
_VOCAB = json.loads(VOCAB_PATH.read_text(encoding="utf-8"))
_TOKENS: dict[str, int] = _VOCAB["tokens"]

GLOBAL_SPECIAL_BASE = min(_TOKENS.values())   # specials start here (10000)
# Span, not count: a hole in the id range (e.g. a token retired without
# renumbering) must still map to a valid embedding row.
NUM_SPECIAL_TOKENS = max(_TOKENS.values()) - GLOBAL_SPECIAL_BASE + 1  # M
UNK_GLOBAL_ID = _TOKENS["<unk>"]              # <unk> -> dropped from labels
PAD_MODEL_ID = _TOKENS["<pad>"] - GLOBAL_SPECIAL_BASE
BOS_MODEL_ID = _TOKENS["<bos>"] - GLOBAL_SPECIAL_BASE
EOS_MODEL_ID = _TOKENS["<eos>"] - GLOBAL_SPECIAL_BASE
IGNORE_INDEX = -100
MAX_BOXES = GLOBAL_SPECIAL_BASE  # box ids must stay below the special range
# Stage-2 (markdown formatter) vocab: the M specials + a single EMIT_NEXT action.
# EMIT_NEXT places the current cursor block and advances -- box identity is carried by
# the cursor, not the token, so it is one fixed id just past the specials.
EMIT_NEXT_MODEL_ID = NUM_SPECIAL_TOKENS

# reward.py, infer.py and OcrReconstructionConfig hardcode bos/eos/pad as 0/1/2.
# Fail loudly here rather than corrupt every rollout if vocab.json is reordered.
assert (BOS_MODEL_ID, EOS_MODEL_ID, PAD_MODEL_ID) == (0, 1, 2), (
    "vocab.json must keep <bos>/<eos>/<pad> as the first three ids; got "
    f"{(BOS_MODEL_ID, EOS_MODEL_ID, PAD_MODEL_ID)}."
)


# --------------------------------------------------------------------------- #
# Core id transform (pure python, PDF-free, unit-testable)
# --------------------------------------------------------------------------- #
@dataclass
class BuiltExample:
    present: list[int]            # original box ids kept, ascending (len K)
    decoder_input_ids: list[int]  # model-compact ids, len T
    labels: list[int]             # model-compact ids, len T


def build_example(
    num_boxes: int,
    raw_ids,
    max_len: int = 2048,
    num_special: int = NUM_SPECIAL_TOKENS,
    base: int = GLOBAL_SPECIAL_BASE,
    unk_id: int = UNK_GLOBAL_ID,
) -> tuple[Optional[BuiltExample], str]:
    """Apply drop-unk -> compaction -> global->model remap -> shift.

    Returns ``(BuiltExample | None, reason)``. ``reason`` is ``"ok"`` for a valid
    example, otherwise a short tag explaining why the row was dropped.
    """
    # 1. drop <unk>
    ids = [int(t) for t in raw_ids if int(t) != unk_id]

    # 2. boxes actually referenced
    present = sorted({t for t in ids if t < base})
    if not present:
        return None, "no_boxes"
    if present[-1] >= num_boxes:
        return None, "box_id_out_of_range"
    if present[-1] >= MAX_BOXES:
        return None, "box_id_collides_with_specials"

    old_to_new = {old: i for i, old in enumerate(present)}

    # 3. global -> model-compact ids
    model_ids: list[int] = []
    for t in ids:
        if t < base:
            model_ids.append(num_special + old_to_new[t])  # box -> M + new_index
        else:
            s = t - base                                    # special -> g - base
            if not (0 <= s < num_special):
                return None, "special_id_out_of_range"
            model_ids.append(s)

    if len(model_ids) < 2:
        return None, "too_short"
    if len(model_ids) - 1 > max_len:  # length after the teacher-forcing shift
        return None, "too_long"

    # 4. teacher forcing shift
    return (
        BuiltExample(
            present=present,
            decoder_input_ids=model_ids[:-1],
            labels=model_ids[1:],
        ),
        "ok",
    )


@dataclass
class BuiltOrderExample:
    """Stage-1 (reading-order) training example.

    ``order`` is the gold reading-order permutation over the *compacted* box
    indices ``0..K-1`` (K == len(present)): the box-pointer tokens read out of the
    target sequence in first-occurrence order. Because compaction keeps only boxes
    the sequence references, every compacted index appears exactly once, so
    ``order`` is always a complete permutation of ``range(K)``.
    """

    present: list[int]   # original box ids kept, ascending (len K)
    order: list[int]     # reading-order permutation over compacted indices (len K)


def build_order_example(
    num_boxes: int,
    raw_ids,
    max_boxes: Optional[int] = None,
    base: int = GLOBAL_SPECIAL_BASE,
    unk_id: int = UNK_GLOBAL_ID,
) -> tuple[Optional[BuiltOrderExample], str]:
    """Extract the Stage-1 reading-order target from a raw target sequence.

    Mirrors :func:`build_example`'s drop-unk + compaction, but instead of building
    a teacher-forcing token sequence it returns the reading-order permutation of
    the compacted boxes: each box pointer's *first* occurrence, in sequence order.

    Returns ``(BuiltOrderExample | None, reason)`` -- ``reason`` is ``"ok"`` for a
    valid example, else a short drop tag (same vocabulary as build_example).
    """
    # 1. drop <unk> (parity with build_example; specials are ignored below anyway)
    ids = [int(t) for t in raw_ids if int(t) != unk_id]

    # 2. boxes actually referenced (compaction), ascending original id
    present = sorted({t for t in ids if t < base})
    if not present:
        return None, "no_boxes"
    if present[-1] >= num_boxes:
        return None, "box_id_out_of_range"
    if present[-1] >= MAX_BOXES:
        return None, "box_id_collides_with_specials"
    num_kept = len(present)
    if max_boxes is not None and num_kept > max_boxes:
        return None, "too_many_boxes"

    old_to_new = {old: i for i, old in enumerate(present)}

    # 3. reading order = first-occurrence order of the box pointers, mapped to the
    #    compacted indices. A box referenced twice keeps only its first position.
    order: list[int] = []
    seen: set[int] = set()
    for t in ids:
        if t < base:
            new_index = old_to_new[t]
            if new_index not in seen:
                seen.add(new_index)
                order.append(new_index)

    # invariant (guaranteed by construction): order is a full permutation of range(K)
    assert len(order) == num_kept and sorted(order) == list(range(num_kept)), (order, num_kept)

    return BuiltOrderExample(present=present, order=order), "ok"


@dataclass
class BuiltMarkdownExample:
    """Stage-2 (markdown formatter) training example, EMIT_NEXT scheme.

    The target sequence is over the FIXED vocab ``{0..M-1 specials, M=EMIT_NEXT}``:
    every OCR box pointer becomes a single ``EMIT_NEXT`` (id ``EMIT_NEXT_MODEL_ID``),
    and ``order`` records which compacted box each successive ``EMIT_NEXT`` places
    (the gold reading-order permutation). At train time the model reorders ``H_box``
    by ``order`` and feeds ``H_ord[cursor]`` as the per-step hint; the cursor is just
    the running count of ``EMIT_NEXT`` tokens emitted so far.
    """

    present: list[int]            # boxes kept, ascending original id (len K)
    order: list[int]             # reading-order permutation over compacted indices (len K)
    decoder_input_ids: list[int]  # over {specials, EMIT_NEXT}, len T
    labels: list[int]             # over {specials, EMIT_NEXT}, len T


def build_markdown_example(
    num_boxes: int,
    raw_ids,
    max_len: int = 2048,
    num_special: int = NUM_SPECIAL_TOKENS,
    base: int = GLOBAL_SPECIAL_BASE,
    unk_id: int = UNK_GLOBAL_ID,
) -> tuple[Optional[BuiltMarkdownExample], str]:
    """Build the Stage-2 EMIT_NEXT target from a raw target sequence.

    Mirrors :func:`build_example`'s drop-unk + compaction, but replaces each box
    pointer with ``EMIT_NEXT`` and records the reading order separately. Rows where a
    box is referenced more than once are dropped (reason ``repeated_box``): the cursor
    only moves forward, so a block can be placed exactly once.

    Returns ``(BuiltMarkdownExample | None, reason)``.
    """
    emit_next = num_special  # EMIT_NEXT_MODEL_ID

    # 1. drop <unk>
    ids = [int(t) for t in raw_ids if int(t) != unk_id]

    # 2. boxes actually referenced (compaction), ascending original id
    present = sorted({t for t in ids if t < base})
    if not present:
        return None, "no_boxes"
    if present[-1] >= num_boxes:
        return None, "box_id_out_of_range"
    if present[-1] >= MAX_BOXES:
        return None, "box_id_collides_with_specials"

    # 3. each box referenced at most once (EMIT_NEXT <-> block must be a bijection)
    box_tokens = [t for t in ids if t < base]
    if len(box_tokens) != len(set(box_tokens)):
        return None, "repeated_box"

    old_to_new = {old: i for i, old in enumerate(present)}

    # 4. build the emit sequence (box -> EMIT_NEXT, special -> compact id) + order
    model_ids: list[int] = []
    order: list[int] = []
    for t in ids:
        if t < base:
            order.append(old_to_new[t])
            model_ids.append(emit_next)
        else:
            s = t - base
            if not (0 <= s < num_special):
                return None, "special_id_out_of_range"
            model_ids.append(s)

    if len(model_ids) < 2:
        return None, "too_short"
    if len(model_ids) - 1 > max_len:  # length after the teacher-forcing shift
        return None, "too_long"

    # order is guaranteed a full permutation of range(K) (no repeats, all present appear)
    assert sorted(order) == list(range(len(present))), (order, len(present))

    # 5. teacher forcing shift
    return (
        BuiltMarkdownExample(
            present=present,
            order=order,
            decoder_input_ids=model_ids[:-1],
            labels=model_ids[1:],
        ),
        "ok",
    )


def model_ids_to_global_ids(
    model_ids,
    num_special: int = NUM_SPECIAL_TOKENS,
    base: int = GLOBAL_SPECIAL_BASE,
) -> list[int]:
    """Inverse remap (model-compact -> global tokenizer scheme) for decoding/eval.

    NOTE: box ids returned are the *compacted* indices, so to recover text you
    must index into the compacted box/line list (the one aligned with the boxes
    actually fed to the model), not the original full OCR list.
    """
    out = []
    for m in model_ids:
        m = int(m)
        out.append((m + base) if m < num_special else (m - num_special))
    return out


# model-compact special id -> display string, derived from vocab.json so it cannot
# drift from the tokenizer (the v0 hand-written copy did). Previews still need no
# tokenizer import.
SPECIAL_ID_TO_STR = {
    token_id - GLOBAL_SPECIAL_BASE: token for token, token_id in _TOKENS.items()
}

# Inverse: token string -> model-compact id. Lets callers name a token ("<TD>")
# instead of hardcoding an integer that shifts whenever the vocab grows.
SPECIAL_STR_TO_ID = {token: model_id for model_id, token in SPECIAL_ID_TO_STR.items()}


def render_sequence(model_ids, num_special: int = NUM_SPECIAL_TOKENS, stop_at_eos: bool = True) -> str:
    """Human-readable preview of a model-compact id sequence: special tokens become
    their markdown strings, box pointers become ``[BOX_k]`` placeholders. Text is
    not recoverable here (OCR strings are not in the training data)."""
    parts = []
    for m in model_ids:
        m = int(m)
        if m < num_special:
            if stop_at_eos and m == 1:  # <eos>
                break
            if m in (0, 2):  # skip <bos>/<pad> in the preview
                continue
            parts.append(SPECIAL_ID_TO_STR.get(m, f"<s{m}>"))
        else:
            parts.append(f"[BOX_{m - num_special}]")
    return "".join(parts)


# --------------------------------------------------------------------------- #
# PDF rasterization (lazy fitz/PIL imports so the transforms above stay light)
# --------------------------------------------------------------------------- #
def rasterize_page(page, zoom: float = 2.0):
    """Render a PyMuPDF page to a PIL RGB image. ``zoom`` ~= dpi/72 (2.0 ~= 144 dpi).
    Box coords are already normalized to [0, 1], so ``zoom`` only affects sharpness."""
    import fitz  # noqa: F401  (PyMuPDF) -- imported lazily
    from PIL import Image

    matrix = fitz.Matrix(zoom, zoom)
    pix = page.get_pixmap(matrix=matrix, alpha=False)
    return Image.frombytes("RGB", (pix.width, pix.height), pix.samples)


def load_image_processor(name_or_path: str = "docling-project/docling-layout-heron",
                         use_fast: bool = True):
    """Convenience loader for the RT-DETR image processor (resize 640, rescale).

    ``use_fast`` selects the torchvision-backed processor, which measured 3.4x
    faster per item than the slow one and dominated __getitem__ before the swap
    (78% of the per-item cost, vs 22% for rasterization).

    The two are not bit-identical: the fast path resizes in a different order, so
    a handful of pixels land one 8-bit step apart (max abs diff 1/255, mean 2e-6).
    That is quantization noise, not a distribution shift -- safe to switch between
    stages even though Stage-2 runs a frozen encoder trained via the slow path.
    Pass ``use_fast=False`` to reproduce the old tensors exactly.
    """
    from transformers import AutoImageProcessor

    processor = AutoImageProcessor.from_pretrained(name_or_path, use_fast=use_fast)

    # transformers falls back to the slow processor silently when it cannot
    # resolve a fast variant for the checkpoint. That costs ~3.4x on the
    # dominant term of __getitem__, so say so instead of quietly training slow.
    if use_fast and not type(processor).__name__.endswith("Fast"):
        import warnings

        warnings.warn(
            f"use_fast=True but got {type(processor).__name__}; the fast image "
            "processor could not be resolved for "
            f"{name_or_path!r}. Data loading will be ~3x slower per item.",
            RuntimeWarning,
            stacklevel=2,
        )

    return processor


class DocCache:
    """Bounded LRU of open ``fitz.Document`` handles, one instance per worker.

    Unbounded (the previous behaviour) this accumulates every PDF a worker has
    ever touched. Over a 320K-page epoch that is both a memory leak and a file
    descriptor leak; capping it costs an occasional reopen and nothing else.
    """

    __slots__ = ("pdf_dir", "max_open", "_cache")

    def __init__(self, pdf_dir, max_open: int = 64) -> None:
        self.pdf_dir = Path(pdf_dir)
        self.max_open = max_open
        self._cache: OrderedDict[str, Any] = OrderedDict()

    def get(self, file_name: str):
        doc = self._cache.get(file_name)
        if doc is not None:
            self._cache.move_to_end(file_name)
            return doc

        import fitz

        doc = fitz.open(self.pdf_dir / file_name)
        self._cache[file_name] = doc

        while len(self._cache) > self.max_open:
            _, evicted = self._cache.popitem(last=False)
            try:
                evicted.close()
            except Exception:  # already closed / never opened cleanly
                pass

        return doc

    def __len__(self) -> int:
        return len(self._cache)


def worker_init_fn(worker_id: int) -> None:
    """Pin each DataLoader worker to a single torch thread.

    The fast image processor is already near-optimal single-threaded (measured
    19.0 / 16.9 / 17.6 ms per image at 1 / 4 / 8 threads), so letting N workers
    each spawn N threads only buys oversubscription on the loader cores.
    """
    torch.set_num_threads(1)


def make_loader_kwargs(num_workers: int, prefetch_factor: int = 4) -> dict:
    """DataLoader kwargs shared by every stage.

    ``persistent_workers`` is the one that matters: without it the workers are
    torn down at the end of each epoch, and since the fitz document cache lives
    per worker, every epoch re-opens every PDF from scratch.
    """
    if num_workers <= 0:
        return {"num_workers": 0}

    return {
        "num_workers": num_workers,
        "persistent_workers": True,
        "prefetch_factor": prefetch_factor,
        "worker_init_fn": worker_init_fn,
    }


# --------------------------------------------------------------------------- #
# Dataset
# --------------------------------------------------------------------------- #
class OcrReconstructionDataset(Dataset):
    """Map-style dataset over a parquet file + a directory of source PDFs.

    Invalid rows (no referenced boxes, out-of-range ids, over-length) are filtered
    out at construction time, so ``__len__`` and indexing only ever see valid rows.
    """

    def __init__(
        self,
        parquet_path: str,
        pdf_dir: str,
        image_processor,
        max_len: int = 2048,
        zoom: float = 2.0,
        max_open_pdfs: int = 64,
        file_name_column: str = "file_name",
        page_column: str = "page",
        bbox_column: str = "ocr_bbox",
        output_ids_column: str = "encoded_ouput_ids_raw",
        verbose: bool = True,
    ):
        import pandas as pd
        from pathlib import Path

        _p = str(parquet_path)
        self.df = pd.read_pickle(_p) if _p.endswith((".pkl", ".pickle")) else pd.read_parquet(_p)
        self.pdf_dir = Path(pdf_dir)
        self.image_processor = image_processor
        self.max_len = max_len
        self.zoom = zoom
        self.cols = dict(
            file_name=file_name_column,
            page=page_column,
            bbox=bbox_column,
            output_ids=output_ids_column,
        )
        missing = [c for c in self.cols.values() if c not in self.df.columns]
        if missing:
            raise KeyError(
                f"Missing columns {missing}. Available: {list(self.df.columns)}"
            )

        self._doc_cache = DocCache(self.pdf_dir, max_open=max_open_pdfs)
        self.samples: list[tuple[int, BuiltExample]] = []
        self._build_index(verbose)

    def _build_index(self, verbose: bool):
        from collections import Counter

        reasons = Counter()
        lengths, unk_dropped, total_tokens = [], 0, 0
        bbox_col, out_col = self.cols["bbox"], self.cols["output_ids"]

        for df_idx in range(len(self.df)):
            row = self.df.iloc[df_idx]
            raw = list(row[out_col])
            total_tokens += len(raw)
            unk_dropped += sum(1 for t in raw if int(t) == UNK_GLOBAL_ID)
            num_boxes = int(np.asarray(row[bbox_col]).reshape(-1, 4).shape[0])

            built, reason = build_example(num_boxes, raw, max_len=self.max_len)
            reasons[reason] += 1
            if built is not None:
                self.samples.append((df_idx, built))
                lengths.append(len(built.decoder_input_ids))

        if verbose:
            kept = len(self.samples)
            print(f"[OcrReconstructionDataset] kept {kept}/{len(self.df)} rows")
            print(f"  drop reasons: {dict(reasons)}")
            unk_pct = 100.0 * unk_dropped / max(total_tokens, 1)
            print(f"  <unk> dropped: {unk_dropped} tokens ({unk_pct:.2f}% of all tokens)")
            if lengths:
                arr = np.array(lengths)
                pct = np.percentile(arr, [50, 90, 99]).astype(int)
                print(f"  seq len  min/median/p90/p99/max = "
                      f"{arr.min()}/{pct[0]}/{pct[1]}/{pct[2]}/{arr.max()}")

    def __len__(self):
        return len(self.samples)

    def _get_doc(self, file_name: str):
        return self._doc_cache.get(file_name)

    def __getitem__(self, idx: int):
        df_idx, built = self.samples[idx]
        row = self.df.iloc[df_idx]

        # image: open PDF (cached) -> rasterize -> RT-DETR preprocessing
        doc = self._get_doc(str(row[self.cols["file_name"]]))
        page = doc[int(row[self.cols["page"]]) - 1]
        image = rasterize_page(page, zoom=self.zoom)
        pixel_values = self.image_processor(images=image, return_tensors="pt")["pixel_values"][0]

        # boxes, compacted to the referenced set, aligned with the pointer ids
        boxes = np.asarray(row[self.cols["bbox"]], dtype=np.float32).reshape(-1, 4)[built.present]

        return {
            "pixel_values": pixel_values,                                   # (3, 640, 640)
            "ocr_boxes": torch.from_numpy(boxes),                           # (K, 4) xyxy in [0,1]
            "decoder_input_ids": torch.tensor(built.decoder_input_ids, dtype=torch.long),  # (T,)
            "labels": torch.tensor(built.labels, dtype=torch.long),         # (T,)
        }


# --------------------------------------------------------------------------- #
# Collate: pad variable N (boxes) and T (sequence)
# --------------------------------------------------------------------------- #
def collate_fn(batch, pad_id: int = PAD_MODEL_ID, ignore_index: int = IGNORE_INDEX):
    B = len(batch)
    pixel_values = torch.stack([b["pixel_values"] for b in batch])  # (B, 3, 640, 640)

    Ks = [b["ocr_boxes"].shape[0] for b in batch]
    Ts = [b["decoder_input_ids"].shape[0] for b in batch]
    max_K, max_T = max(Ks), max(Ts)

    ocr_boxes = torch.zeros(B, max_K, 4, dtype=torch.float32)
    box_mask = torch.zeros(B, max_K, dtype=torch.bool)
    decoder_input_ids = torch.full((B, max_T), pad_id, dtype=torch.long)
    labels = torch.full((B, max_T), ignore_index, dtype=torch.long)

    for i, b in enumerate(batch):
        k, t = Ks[i], Ts[i]
        ocr_boxes[i, :k] = b["ocr_boxes"]
        box_mask[i, :k] = True
        decoder_input_ids[i, :t] = b["decoder_input_ids"]
        labels[i, :t] = b["labels"]

    return {
        "pixel_values": pixel_values,
        "ocr_boxes": ocr_boxes,
        "box_mask": box_mask,
        "decoder_input_ids": decoder_input_ids,
        "labels": labels,
    }


# --------------------------------------------------------------------------- #
# RL (GRPO) dataset: feed ALL boxes, no compaction, no targets
# --------------------------------------------------------------------------- #
class RLDataset(Dataset):
    """Map-style dataset for GRPO / RL fine-tuning.

    Unlike :class:`OcrReconstructionDataset` (which compacts to the *matched*
    boxes and builds teacher-forcing targets), this feeds **every** OCR box for
    the page -- the same distribution the model sees at inference -- and returns
    **no targets**. The reward (coverage / duplicates) is computed from the
    model's own rollout, so no gold markdown is needed here.

    Rows are filtered only by box count: pages with fewer than ``min_boxes`` are
    useless, and ``max_boxes`` caps rollout length / memory during training.
    """

    def __init__(
        self,
        parquet_path: str,
        pdf_dir: str,
        image_processor,
        zoom: float = 2.0,
        max_open_pdfs: int = 64,
        min_boxes: int = 1,
        max_boxes: Optional[int] = None,
        file_name_column: str = "file_name",
        page_column: str = "page",
        bbox_column: str = "ocr_bbox",
        verbose: bool = True,
    ):
        import pandas as pd
        from pathlib import Path

        _p = str(parquet_path)
        self.df = pd.read_pickle(_p) if _p.endswith((".pkl", ".pickle")) else pd.read_parquet(_p)
        self.pdf_dir = Path(pdf_dir)
        self.image_processor = image_processor
        self.zoom = zoom
        self.cols = dict(file_name=file_name_column, page=page_column, bbox=bbox_column)
        missing = [c for c in self.cols.values() if c not in self.df.columns]
        if missing:
            raise KeyError(f"Missing columns {missing}. Available: {list(self.df.columns)}")

        self._doc_cache = DocCache(self.pdf_dir, max_open=max_open_pdfs)
        self.samples: list[int] = []             # kept df indices
        self._build_index(min_boxes, max_boxes, verbose)

    def _build_index(self, min_boxes: int, max_boxes: Optional[int], verbose: bool):
        from collections import Counter

        reasons = Counter()
        bbox_col = self.cols["bbox"]
        box_counts = []
        for df_idx in range(len(self.df)):
            row = self.df.iloc[df_idx]
            n = int(np.asarray(row[bbox_col]).reshape(-1, 4).shape[0])
            if n < min_boxes:
                reasons["too_few_boxes"] += 1
                continue
            if max_boxes is not None and n > max_boxes:
                reasons["too_many_boxes"] += 1
                continue
            self.samples.append(df_idx)
            box_counts.append(n)

        if verbose:
            print(f"[RLDataset] kept {len(self.samples)}/{len(self.df)} rows")
            if reasons:
                print(f"  drop reasons: {dict(reasons)}")
            if box_counts:
                arr = np.array(box_counts)
                pct = np.percentile(arr, [50, 90, 99]).astype(int)
                print(f"  boxes/page  min/median/p90/p99/max = "
                      f"{arr.min()}/{pct[0]}/{pct[1]}/{pct[2]}/{arr.max()}")

    def __len__(self):
        return len(self.samples)

    def _get_doc(self, file_name: str):
        return self._doc_cache.get(file_name)

    def __getitem__(self, idx: int):
        df_idx = self.samples[idx]
        row = self.df.iloc[df_idx]

        doc = self._get_doc(str(row[self.cols["file_name"]]))
        page = doc[int(row[self.cols["page"]]) - 1]
        image = rasterize_page(page, zoom=self.zoom)
        pixel_values = self.image_processor(images=image, return_tensors="pt")["pixel_values"][0]

        # ALL boxes (no [built.present] compaction): the inference distribution
        boxes = np.asarray(row[self.cols["bbox"]], dtype=np.float32).reshape(-1, 4)

        return {
            "pixel_values": pixel_values,                 # (3, 640, 640)
            "ocr_boxes": torch.from_numpy(boxes),         # (N, 4) xyxy in [0, 1]
            "num_boxes": boxes.shape[0],                  # int N
            "df_idx": df_idx,                             # for monitoring / gold join
        }


def rl_collate_fn(batch):
    """Pad variable N (boxes) across a batch of pages. No sequence padding -- the
    decoder sequence is produced by sampling, not supplied here."""
    B = len(batch)
    pixel_values = torch.stack([b["pixel_values"] for b in batch])
    Ns = [b["ocr_boxes"].shape[0] for b in batch]
    max_N = max(Ns)

    ocr_boxes = torch.zeros(B, max_N, 4, dtype=torch.float32)
    box_mask = torch.zeros(B, max_N, dtype=torch.bool)
    for i, b in enumerate(batch):
        n = Ns[i]
        ocr_boxes[i, :n] = b["ocr_boxes"]
        box_mask[i, :n] = True

    return {
        "pixel_values": pixel_values,                              # (B, 3, 640, 640)
        "ocr_boxes": ocr_boxes,                                    # (B, max_N, 4)
        "box_mask": box_mask,                                      # (B, max_N)
        "num_boxes": torch.tensor(Ns, dtype=torch.long),           # (B,)
        "df_idx": torch.tensor([b["df_idx"] for b in batch], dtype=torch.long),
    }


# --------------------------------------------------------------------------- #
# Stage-1 (reading-order) dataset: same parquet, target is the permutation
# --------------------------------------------------------------------------- #
class OrderingDataset(Dataset):
    """Map-style dataset for Stage-1 reading-order training.

    Reuses the SAME parquet + PDFs + columns as :class:`OcrReconstructionDataset`;
    the only difference is the target: :func:`build_order_example` reads the gold
    reading-order permutation off ``encoded_ouput_ids_raw`` (over the compacted /
    matched boxes) instead of building a teacher-forcing token sequence.

    Rows are filtered by build_order_example's drop reasons, plus:
      * ``< min_boxes`` matched boxes  -> ``too_few_boxes`` (K=1 is a trivial
        permutation and only inflates the metrics).
      * ``> max_boxes`` matched boxes  -> ``too_many_boxes`` (rollout length/memory).
    """

    def __init__(
        self,
        parquet_path: str,
        pdf_dir: str,
        image_processor,
        zoom: float = 2.0,
        max_open_pdfs: int = 64,
        min_boxes: int = 2,
        max_boxes: Optional[int] = None,
        file_name_column: str = "file_name",
        page_column: str = "page",
        bbox_column: str = "ocr_bbox",
        output_ids_column: str = "encoded_ouput_ids_raw",
        verbose: bool = True,
    ):
        import pandas as pd
        from pathlib import Path

        _p = str(parquet_path)
        self.df = pd.read_pickle(_p) if _p.endswith((".pkl", ".pickle")) else pd.read_parquet(_p)
        self.pdf_dir = Path(pdf_dir)
        self.image_processor = image_processor
        self.zoom = zoom
        self.cols = dict(
            file_name=file_name_column,
            page=page_column,
            bbox=bbox_column,
            output_ids=output_ids_column,
        )
        missing = [c for c in self.cols.values() if c not in self.df.columns]
        if missing:
            raise KeyError(f"Missing columns {missing}. Available: {list(self.df.columns)}")

        self._doc_cache = DocCache(self.pdf_dir, max_open=max_open_pdfs)
        self.samples: list[tuple[int, BuiltOrderExample]] = []
        self._build_index(min_boxes, max_boxes, verbose)

    def _build_index(self, min_boxes: int, max_boxes: Optional[int], verbose: bool):
        from collections import Counter

        reasons = Counter()
        Ks, valid_perm = [], 0
        bbox_col, out_col = self.cols["bbox"], self.cols["output_ids"]

        for df_idx in range(len(self.df)):
            row = self.df.iloc[df_idx]
            raw = list(row[out_col])
            num_boxes = int(np.asarray(row[bbox_col]).reshape(-1, 4).shape[0])

            built, reason = build_order_example(num_boxes, raw, max_boxes=max_boxes)
            if built is not None and len(built.present) < min_boxes:
                reason, built = "too_few_boxes", None
            reasons[reason] += 1
            if built is not None:
                K = len(built.present)
                if sorted(built.order) == list(range(K)):  # bulk-validate the invariant
                    valid_perm += 1
                self.samples.append((df_idx, built))
                Ks.append(K)

        if verbose:
            kept = len(self.samples)
            print(f"[OrderingDataset] kept {kept}/{len(self.df)} rows")
            print(f"  drop reasons: {dict(reasons)}")
            print(f"  valid permutations: {valid_perm}/{kept} "
                  f"({100.0 * valid_perm / max(kept, 1):.1f}%)")
            if Ks:
                arr = np.array(Ks)
                pct = np.percentile(arr, [50, 90, 99]).astype(int)
                print(f"  boxes/page (K)  min/median/p90/p99/max = "
                      f"{arr.min()}/{pct[0]}/{pct[1]}/{pct[2]}/{arr.max()}")

    def __len__(self):
        return len(self.samples)

    def _get_doc(self, file_name: str):
        return self._doc_cache.get(file_name)

    def __getitem__(self, idx: int):
        df_idx, built = self.samples[idx]
        row = self.df.iloc[df_idx]

        doc = self._get_doc(str(row[self.cols["file_name"]]))
        page = doc[int(row[self.cols["page"]]) - 1]
        image = rasterize_page(page, zoom=self.zoom)
        pixel_values = self.image_processor(images=image, return_tensors="pt")["pixel_values"][0]

        # matched boxes in ascending id order (aligned with the compacted order values)
        boxes = np.asarray(row[self.cols["bbox"]], dtype=np.float32).reshape(-1, 4)[built.present]

        return {
            "pixel_values": pixel_values,                          # (3, 640, 640)
            "ocr_boxes": torch.from_numpy(boxes),                  # (K, 4) xyxy in [0,1]
            "order": torch.tensor(built.order, dtype=torch.long),  # (K,) reading-order perm
        }


def order_collate_fn(batch, ignore_index: int = IGNORE_INDEX):
    """Pad variable K (boxes) across a batch. ``order`` is padded with
    ``ignore_index`` so padded decode steps are dropped from the loss/metrics."""
    B = len(batch)
    pixel_values = torch.stack([b["pixel_values"] for b in batch])
    Ks = [b["ocr_boxes"].shape[0] for b in batch]
    max_K = max(Ks)

    ocr_boxes = torch.zeros(B, max_K, 4, dtype=torch.float32)
    box_mask = torch.zeros(B, max_K, dtype=torch.bool)
    order = torch.full((B, max_K), ignore_index, dtype=torch.long)
    for i, b in enumerate(batch):
        k = Ks[i]
        ocr_boxes[i, :k] = b["ocr_boxes"]
        box_mask[i, :k] = True
        order[i, :k] = b["order"]

    return {
        "pixel_values": pixel_values,   # (B, 3, 640, 640)
        "ocr_boxes": ocr_boxes,         # (B, max_K, 4)
        "box_mask": box_mask,           # (B, max_K)
        "order": order,                 # (B, max_K)  padded = ignore_index
    }


# --------------------------------------------------------------------------- #
# Stage-2 (markdown formatter) dataset: EMIT_NEXT targets + reading order
# --------------------------------------------------------------------------- #
class MarkdownDataset(Dataset):
    """Map-style dataset for Stage-2 (markdown formatter) training.

    Same parquet / PDFs / columns as :class:`OcrReconstructionDataset`; the target is
    the EMIT_NEXT sequence (:func:`build_markdown_example`) plus the reading-order
    permutation ``order`` (used by the model to reorder H_box for the per-step cursor
    hint). Rows are filtered by build_markdown_example's drop reasons (incl.
    ``repeated_box``) plus ``min_boxes`` / ``max_boxes``.
    """

    def __init__(
        self,
        parquet_path: str,
        pdf_dir: str,
        image_processor,
        max_len: int = 2048,
        zoom: float = 2.0,
        max_open_pdfs: int = 64,
        min_boxes: int = 1,
        max_boxes: Optional[int] = None,
        file_name_column: str = "file_name",
        page_column: str = "page",
        bbox_column: str = "ocr_bbox",
        output_ids_column: str = "encoded_ouput_ids_raw",
        verbose: bool = True,
    ):
        import pandas as pd
        from pathlib import Path

        _p = str(parquet_path)
        self.df = pd.read_pickle(_p) if _p.endswith((".pkl", ".pickle")) else pd.read_parquet(_p)
        self.pdf_dir = Path(pdf_dir)
        self.image_processor = image_processor
        self.max_len = max_len
        self.zoom = zoom
        self.cols = dict(
            file_name=file_name_column, page=page_column,
            bbox=bbox_column, output_ids=output_ids_column,
        )
        missing = [c for c in self.cols.values() if c not in self.df.columns]
        if missing:
            raise KeyError(f"Missing columns {missing}. Available: {list(self.df.columns)}")

        self._doc_cache = DocCache(self.pdf_dir, max_open=max_open_pdfs)
        self.samples: list[tuple[int, BuiltMarkdownExample]] = []
        self._build_index(min_boxes, max_boxes, verbose)

    def _build_index(self, min_boxes: int, max_boxes: Optional[int], verbose: bool):
        from collections import Counter

        reasons = Counter()
        Ks, lengths = [], []
        bbox_col, out_col = self.cols["bbox"], self.cols["output_ids"]

        for df_idx in range(len(self.df)):
            row = self.df.iloc[df_idx]
            raw = list(row[out_col])
            num_boxes = int(np.asarray(row[bbox_col]).reshape(-1, 4).shape[0])

            built, reason = build_markdown_example(num_boxes, raw, max_len=self.max_len)
            if built is not None:
                K = len(built.present)
                if K < min_boxes:
                    reason, built = "too_few_boxes", None
                elif max_boxes is not None and K > max_boxes:
                    reason, built = "too_many_boxes", None
            reasons[reason] += 1
            if built is not None:
                self.samples.append((df_idx, built))
                Ks.append(len(built.present))
                lengths.append(len(built.decoder_input_ids))

        if verbose:
            kept = len(self.samples)
            print(f"[MarkdownDataset] kept {kept}/{len(self.df)} rows")
            print(f"  drop reasons: {dict(reasons)}")
            if Ks:
                aK, aL = np.array(Ks), np.array(lengths)
                pK = np.percentile(aK, [50, 90, 99]).astype(int)
                pL = np.percentile(aL, [50, 90, 99]).astype(int)
                print(f"  boxes/page (K)  min/median/p90/p99/max = "
                      f"{aK.min()}/{pK[0]}/{pK[1]}/{pK[2]}/{aK.max()}")
                print(f"  seq len         min/median/p90/p99/max = "
                      f"{aL.min()}/{pL[0]}/{pL[1]}/{pL[2]}/{aL.max()}")

    def __len__(self):
        return len(self.samples)

    def _get_doc(self, file_name: str):
        return self._doc_cache.get(file_name)

    def __getitem__(self, idx: int):
        df_idx, built = self.samples[idx]
        row = self.df.iloc[df_idx]

        doc = self._get_doc(str(row[self.cols["file_name"]]))
        page = doc[int(row[self.cols["page"]]) - 1]
        image = rasterize_page(page, zoom=self.zoom)
        pixel_values = self.image_processor(images=image, return_tensors="pt")["pixel_values"][0]

        boxes = np.asarray(row[self.cols["bbox"]], dtype=np.float32).reshape(-1, 4)[built.present]

        return {
            "pixel_values": pixel_values,                                             # (3, 640, 640)
            "ocr_boxes": torch.from_numpy(boxes),                                     # (K, 4)
            "order": torch.tensor(built.order, dtype=torch.long),                     # (K,)
            "decoder_input_ids": torch.tensor(built.decoder_input_ids, dtype=torch.long),  # (T,)
            "labels": torch.tensor(built.labels, dtype=torch.long),                   # (T,)
        }


def md_collate_fn(batch, pad_id: int = PAD_MODEL_ID, ignore_index: int = IGNORE_INDEX):
    """Pad variable K (boxes) and T (sequence). ``order`` is an INPUT (used to reorder
    H_box), not a target, so it is padded with 0 (a safe gather index); padded box rows
    are masked by ``box_mask`` and the cursor never indexes them."""
    B = len(batch)
    pixel_values = torch.stack([b["pixel_values"] for b in batch])
    Ks = [b["ocr_boxes"].shape[0] for b in batch]
    Ts = [b["decoder_input_ids"].shape[0] for b in batch]
    max_K, max_T = max(Ks), max(Ts)

    ocr_boxes = torch.zeros(B, max_K, 4, dtype=torch.float32)
    box_mask = torch.zeros(B, max_K, dtype=torch.bool)
    order = torch.zeros(B, max_K, dtype=torch.long)                     # pad = 0 (safe gather idx)
    decoder_input_ids = torch.full((B, max_T), pad_id, dtype=torch.long)
    labels = torch.full((B, max_T), ignore_index, dtype=torch.long)

    for i, b in enumerate(batch):
        k, t = Ks[i], Ts[i]
        ocr_boxes[i, :k] = b["ocr_boxes"]
        box_mask[i, :k] = True
        order[i, :k] = b["order"]
        decoder_input_ids[i, :t] = b["decoder_input_ids"]
        labels[i, :t] = b["labels"]

    return {
        "pixel_values": pixel_values,           # (B, 3, 640, 640)
        "ocr_boxes": ocr_boxes,                 # (B, max_K, 4)
        "box_mask": box_mask,                   # (B, max_K)
        "order": order,                         # (B, max_K)  padded = 0
        "decoder_input_ids": decoder_input_ids, # (B, max_T)
        "labels": labels,                       # (B, max_T)  padded = ignore_index
    }


def twostage_collate_fn(batch, pad_id: int = PAD_MODEL_ID, ignore_index: int = IGNORE_INDEX):
    """Phase-3 collate (uses :class:`MarkdownDataset` items). Emits ``order`` two ways from
    the same permutation: 0-padded for the format cursor (safe gather) and ``order_label``
    IGNORE-padded for the order-decoder loss (padded steps dropped from CE)."""
    B = len(batch)
    pixel_values = torch.stack([b["pixel_values"] for b in batch])
    Ks = [b["ocr_boxes"].shape[0] for b in batch]
    Ts = [b["decoder_input_ids"].shape[0] for b in batch]
    max_K, max_T = max(Ks), max(Ts)

    ocr_boxes = torch.zeros(B, max_K, 4, dtype=torch.float32)
    box_mask = torch.zeros(B, max_K, dtype=torch.bool)
    order = torch.zeros(B, max_K, dtype=torch.long)                       # 0-pad -> cursor
    order_label = torch.full((B, max_K), ignore_index, dtype=torch.long)  # IGNORE-pad -> order loss
    decoder_input_ids = torch.full((B, max_T), pad_id, dtype=torch.long)
    labels = torch.full((B, max_T), ignore_index, dtype=torch.long)

    for i, b in enumerate(batch):
        k, t = Ks[i], Ts[i]
        ocr_boxes[i, :k] = b["ocr_boxes"]
        box_mask[i, :k] = True
        order[i, :k] = b["order"]
        order_label[i, :k] = b["order"]
        decoder_input_ids[i, :t] = b["decoder_input_ids"]
        labels[i, :t] = b["labels"]

    return {
        "pixel_values": pixel_values,
        "ocr_boxes": ocr_boxes,
        "box_mask": box_mask,
        "order": order,                         # 0-padded
        "order_label": order_label,             # IGNORE-padded
        "decoder_input_ids": decoder_input_ids,
        "labels": labels,
    }


# --------------------------------------------------------------------------- #
# Self-test for the pure data logic (no PDF / model needed)
# --------------------------------------------------------------------------- #
if __name__ == "__main__":
    M, BASE = NUM_SPECIAL_TOKENS, GLOBAL_SPECIAL_BASE
    BOS, EOS = _TOKENS["<bos>"], _TOKENS["<eos>"]
    HASH, NL = _TOKENS["#"], _TOKENS["\n"]
    TD, TD_END = _TOKENS["<TD>"], _TOKENS["</TD>"]

    # 500 boxes, output references {3, 7, 499}; contains an <unk> to be dropped
    raw = [BOS, 3, HASH, 7, UNK_GLOBAL_ID, NL, 499, EOS]
    built, reason = build_example(num_boxes=500, raw_ids=raw, max_len=2048)
    assert reason == "ok", reason
    assert built.present == [3, 7, 499]
    # model-compact: bos=0, box3->M+0, '#', box7->M+1, '\n', box499->M+2, eos=1
    expected_full = [0, M + 0, HASH - BASE, M + 1, NL - BASE, M + 2, 1]
    assert built.decoder_input_ids == expected_full[:-1], built.decoder_input_ids
    assert built.labels == expected_full[1:], built.labels
    assert model_ids_to_global_ids(expected_full) == [BOS, 0, HASH, 1, NL, 2, EOS]

    # v0.1 regression: HTML tag ids sit far above the old M=17 ceiling. With a
    # stale NUM_SPECIAL_TOKENS these drop as special_id_out_of_range -- which is
    # how every table page would silently vanish from the dataset.
    raw_html = [BOS, TD, 3, TD_END, TD, 7, TD_END, EOS]
    built_html, reason_html = build_example(num_boxes=500, raw_ids=raw_html)
    assert reason_html == "ok", reason_html
    assert built_html.present == [3, 7]
    assert (TD - BASE) < M and (TD_END - BASE) < M

    # drop conditions
    assert build_example(500, [BOS, EOS])[1] == "no_boxes"
    assert build_example(2, [BOS, 5, EOS])[1] == "box_id_out_of_range"
    assert build_example(500, [BOS] + [3, NL] * 2000 + [EOS], max_len=64)[1] == "too_long"

    # ---- build_order_example: reading-order extraction ----
    # same row as above: boxes {3,7,499} -> compacted {0,1,2}, appear in id order
    bo, r = build_order_example(num_boxes=500, raw_ids=raw)
    assert r == "ok", r
    assert bo.present == [3, 7, 499]
    assert bo.order == [0, 1, 2], bo.order

    # reading order != ascending id order, AND a box repeated -> first occurrence only
    raw2 = [BOS, 7, HASH, 3, NL, 499, 3, EOS]     # box 3 appears twice
    bo2, r2 = build_order_example(num_boxes=500, raw_ids=raw2)
    assert r2 == "ok", r2
    assert bo2.present == [3, 7, 499]              # compaction is id-sorted
    assert bo2.order == [1, 0, 2], bo2.order        # 7->1 first, then 3->0, then 499->2
    assert sorted(bo2.order) == list(range(len(bo2.present)))  # always a permutation

    # drop conditions mirror build_example
    assert build_order_example(500, [BOS, EOS])[1] == "no_boxes"
    assert build_order_example(2, [BOS, 5, EOS])[1] == "box_id_out_of_range"
    assert build_order_example(500, raw, max_boxes=2)[1] == "too_many_boxes"

    # ---- build_markdown_example: EMIT_NEXT substitution + order ----
    EMIT = EMIT_NEXT_MODEL_ID  # == M
    bm, r = build_markdown_example(num_boxes=500, raw_ids=raw)  # BOS,3,#,7,<unk>,\n,499,EOS
    assert r == "ok", r
    assert bm.present == [3, 7, 499]
    assert bm.order == [0, 1, 2], bm.order
    # full seq: bos=0, EMIT(box3), '#', EMIT(box7), '\n', EMIT(box499), eos=1
    expected_full = [0, EMIT, HASH - BASE, EMIT, NL - BASE, EMIT, 1]
    assert bm.decoder_input_ids == expected_full[:-1], bm.decoder_input_ids
    assert bm.labels == expected_full[1:], bm.labels
    # cursor = inclusive cumsum of EMIT over decoder_input_ids -> which block is in focus
    cur, cursor = 0, []
    for t in bm.decoder_input_ids:
        cur += (t == EMIT)
        cursor.append(cur)
    assert cursor == [0, 1, 1, 2, 2, 3], cursor  # 3 == K -> "done" at the final step

    # non-identity reading order (boxes out of id order), still one EMIT per block
    raw3 = [BOS, 7, HASH, 3, NL, 499, EOS]
    bm3, r3 = build_markdown_example(500, raw3)
    assert r3 == "ok" and bm3.present == [3, 7, 499]
    assert bm3.order == [1, 0, 2], bm3.order          # 7->1 placed first, then 3->0, then 499->2

    # a box referenced twice -> dropped (cursor can't place a block twice)
    assert build_markdown_example(500, [BOS, 7, HASH, 3, NL, 499, 3, EOS])[1] == "repeated_box"
    assert build_markdown_example(500, [BOS, EOS])[1] == "no_boxes"

    # md_collate_fn: pad K (3 vs 2) and T (6 vs 4)
    def md_item(K, ids):
        b, _ = build_markdown_example(K, ids)
        return {
            "pixel_values": torch.zeros(3, 640, 640),
            "ocr_boxes": torch.rand(len(b.present), 4),
            "order": torch.tensor(b.order, dtype=torch.long),
            "decoder_input_ids": torch.tensor(b.decoder_input_ids, dtype=torch.long),
            "labels": torch.tensor(b.labels, dtype=torch.long),
        }

    mbatch = [md_item(500, raw), md_item(5, [BOS, 0, HASH, 1, EOS])]
    mout = md_collate_fn(mbatch)
    assert mout["ocr_boxes"].shape == (2, 3, 4), mout["ocr_boxes"].shape
    assert mout["order"].shape == (2, 3), mout["order"].shape
    assert mout["decoder_input_ids"].shape == mout["labels"].shape == (2, 6)
    assert mout["box_mask"].tolist() == [[True, True, True], [True, True, False]]
    assert mout["decoder_input_ids"][1].tolist() == [
        0, EMIT, HASH - BASE, EMIT, PAD_MODEL_ID, PAD_MODEL_ID
    ]

    # twostage_collate_fn: order is 0-padded, order_label is IGNORE-padded (same perm)
    tout = twostage_collate_fn(mbatch)
    assert tout["order"][1].tolist() == [0, 1, 0], tout["order"][1].tolist()          # pad = 0
    assert tout["order_label"][1].tolist() == [0, 1, IGNORE_INDEX], tout["order_label"][1].tolist()
    assert tout["order"][0].tolist() == tout["order_label"][0].tolist() == [0, 1, 2]  # full row: identical
    assert set(tout) == {"pixel_values", "ocr_boxes", "box_mask", "order", "order_label",
                         "decoder_input_ids", "labels"}

    # collate shapes (synthetic, skip image with a dummy tensor)
    def item(K, ids):
        b, _ = build_example(K, ids)
        return {
            "pixel_values": torch.zeros(3, 640, 640),
            "ocr_boxes": torch.rand(len(b.present), 4),
            "decoder_input_ids": torch.tensor(b.decoder_input_ids),
            "labels": torch.tensor(b.labels),
        }

    batch = [item(500, raw), item(10, [BOS, 0, NL, 5, HASH, 9, EOS])]
    out = collate_fn(batch)
    assert out["ocr_boxes"].shape == (2, 3, 4), out["ocr_boxes"].shape
    assert out["box_mask"].tolist() == [[True, True, True], [True, True, True]]
    assert out["decoder_input_ids"].shape == out["labels"].shape

    # order_collate_fn: pad two pages of different K (3 vs 2) -> max_K = 3
    def order_item(K, ids):
        b, _ = build_order_example(K, ids)
        return {
            "pixel_values": torch.zeros(3, 640, 640),
            "ocr_boxes": torch.rand(len(b.present), 4),
            "order": torch.tensor(b.order, dtype=torch.long),
        }

    obatch = [order_item(500, raw), order_item(5, [BOS, 1, HASH, 0, EOS])]  # K=3 and K=2
    oout = order_collate_fn(obatch)
    assert oout["ocr_boxes"].shape == (2, 3, 4), oout["ocr_boxes"].shape
    assert oout["order"].shape == (2, 3), oout["order"].shape
    assert oout["box_mask"].tolist() == [[True, True, True], [True, True, False]]
    assert oout["order"][0].tolist() == [0, 1, 2]        # raw -> identity order
    assert oout["order"][1].tolist() == [1, 0, IGNORE_INDEX]  # boxes 1 then 0, then pad
    print("data.py self-test OK")
    print("collate keys:", {k: tuple(v.shape) for k, v in out.items()})
    print("order collate keys:", {k: tuple(v.shape) for k, v in oout.items()})
    print("md collate keys:", {k: tuple(v.shape) for k, v in mout.items()})
