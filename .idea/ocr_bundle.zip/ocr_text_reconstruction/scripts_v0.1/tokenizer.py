from __future__ import annotations

import bisect
import html
import json
import logging
import re
import unicodedata
from copy import deepcopy
from functools import lru_cache
from math import floor, hypot
from pathlib import Path
from typing import Any, Callable, Iterator, Sequence

import numpy as np
from fuzzysearch import find_near_matches


logger = logging.getLogger(__name__)

BBox = tuple[float, float, float, float]
Span = tuple[int, int]
ThresholdFunction = Callable[[int], int | None]

DEFAULT_VOCAB_PATH = Path(__file__).with_name("vocab.json")

# Stand-in for a region that must never take part in OCR matching (HTML tags,
# image placeholders). It is not alphanumeric, so a normalized needle can never
# match across one.
MASK_CHAR = "\x00"


# ========================================================
# Normalization
# ========================================================

@lru_cache(maxsize=None)
def _canon(ch: str) -> str:
    # per-char: may expand (ﬁ -> fi) or drop (space/punct -> "")
    # Cached: called once per character of every page, over a tiny domain.
    return "".join(c for c in unicodedata.normalize("NFKC", ch).casefold()
                   if c.isalnum())


def normalize(text: str):
    buf, imap = [], []
    for i, ch in enumerate(text):
        for c in _canon(ch):
            buf.append(c); imap.append(i)
    return "".join(buf), imap


def _normalize_masked(text: str, masked_spans: Sequence[Span]):
    """``normalize`` with masked regions replaced by a single ``MASK_CHAR``.

    Without this, tag names and attribute values leak into the searchable
    stream: ``<TD>`` contributes ``"td"`` and ``style="text-align:center"``
    contributes ``"styletextaligncenter"``. That both blocks genuine matches
    and invents false ones.
    """
    buf: list[str] = []
    imap: list[int] = []
    cursor = 0

    def emit(start: int, end: int) -> None:
        for i in range(start, end):
            for c in _canon(text[i]):
                buf.append(c); imap.append(i)

    for start, end in masked_spans:
        emit(cursor, start)
        buf.append(MASK_CHAR); imap.append(start)
        cursor = end

    emit(cursor, len(text))
    return "".join(buf), imap


_FOLD = str.maketrans({"“":'"', "”":'"', "‘":"'", "’":"'",
                       "‐":"-", "‑":"-", "‒":"-", "–":"-", "—":"-", "−":"-"})


@lru_cache(maxsize=None)
def _p(ch: str) -> str:             # canonical form of a punctuation char
    return unicodedata.normalize("NFKC", ch).translate(_FOLD)


def _affixes(sub: str):
    """Punctuation hanging off the front/back of the needle (whitespace ignored)."""
    i = 0
    while i < len(sub) and not _canon(sub[i]): i += 1
    j = len(sub)
    while j > i and not _canon(sub[j - 1]): j -= 1
    return ([_p(c) for c in sub[:i] if not c.isspace()],
            [_p(c) for c in sub[j:] if not c.isspace()])


def _grow_right(text, end, tail, limit):
    """Reclaim trailing punctuation, without crossing ``limit``.

    ``limit`` is the start of the next masked region. ``<``, ``/`` and ``>``
    are non-alphanumeric, so an unbounded walk happily steps through
    ``</TD><TD>`` to find a trailing ``.`` and returns a span covering two
    cells.
    """
    k, i, out = 0, end, end
    while i < limit and k < len(tail) and not text[i].isalnum():
        if _p(text[i]) == tail[k]:
            k += 1; out = i + 1
        i += 1
    return out


def _grow_left(text, start, head, limit):
    head = head[::-1]
    k, i, out = 0, start - 1, start
    while i >= limit and k < len(head) and not text[i].isalnum():
        if _p(text[i]) == head[k]:
            k += 1; out = i
        i -= 1
    return out


def _merge_spans(spans: Sequence[Span]) -> list[Span]:
    if not spans:
        return []

    ordered = sorted(spans)
    merged: list[list[int]] = [list(ordered[0])]

    for start, end in ordered[1:]:
        if start <= merged[-1][1]:
            merged[-1][1] = max(merged[-1][1], end)
        else:
            merged.append([start, end])

    return [(start, end) for start, end in merged]


class PageIndex:
    """Per-page normalized view of the markdown, built once and reused.

    The previous implementation re-normalized the whole page for every OCR
    line, which is O(n_lines x page_len) per page.
    """

    __slots__ = ("text", "masked", "hay", "imap", "_starts", "_ends")

    def __init__(self, text: str, masked_spans: Sequence[Span]) -> None:
        self.text = text
        self.masked = _merge_spans(masked_spans)
        self.hay, self.imap = _normalize_masked(text, self.masked)
        self._starts = [start for start, _ in self.masked]
        self._ends = [end for _, end in self.masked]

    def limit_right(self, pos: int) -> int:
        """Start of the first masked region at or after ``pos``."""
        index = bisect.bisect_left(self._starts, pos)
        return self._starts[index] if index < len(self._starts) else len(self.text)

    def limit_left(self, pos: int) -> int:
        """End of the last masked region at or before ``pos``."""
        index = bisect.bisect_right(self._ends, pos) - 1
        return self._ends[index] if index >= 0 else 0

    def find_all(self, sub: str, include_affixes: bool = True) -> list[Span]:
        needle, _ = normalize(sub)
        if not needle:
            return []

        head, tail = _affixes(sub) if include_affixes else ([], [])
        spans: list[Span] = []

        position = self.hay.find(needle)
        while position != -1:
            start = self.imap[position]
            end = self.imap[position + len(needle) - 1] + 1
            spans.append(
                (
                    _grow_left(self.text, start, head, self.limit_left(start)),
                    _grow_right(self.text, end, tail, self.limit_right(end)),
                )
            )
            position = self.hay.find(needle, position + 1)

        return spans

    def to_raw_span(self, hay_start: int, hay_end: int) -> Span | None:
        """Translate a span in normalized space back to raw markdown offsets."""
        if hay_end <= hay_start:
            return None
        if MASK_CHAR in self.hay[hay_start:hay_end]:
            return None

        return self.imap[hay_start], self.imap[hay_end - 1] + 1


def find_all(sub, full_text, include_affixes=True) -> Iterator[Span]:
    """Backwards-compatible standalone search (rebuilds the index each call)."""
    page = PageIndex(full_text, CustomTokenizer.masked_regions(full_text))
    yield from page.find_all(sub, include_affixes=include_affixes)


# ========================================================
# Markup patterns
# ========================================================

_TAG_RE = re.compile(r"</?[A-Za-z][A-Za-z0-9]*(?:\s[^<>]*)?/?\s*>")
_TAG_PARTS_RE = re.compile(r"</?\s*([A-Za-z][A-Za-z0-9]*)([^>]*?)/?\s*>", re.S)

# [Image: ...] / [Figure: ...] / [Picture: ...] -- the whole bracket, description
# included, collapses to a single token. No nesting: the match stops at the
# first ']', so an unterminated bracket simply does not match.
_IMAGE_BLOCK_RE = re.compile(r"\[\s*(image|figure|picture)\b[^\]]*\]", re.I)
_MD_IMAGE_RE = re.compile(r"!\[[^\]]*\]\([^)]*\)")

# The form ``decode`` emits, so encode(decode(x)) == x.
_PLACEHOLDER_RE = re.compile(r"<<-+\s*(IMG|FIGURE|PICTURE)\s*-+>>", re.I)

_CHECKBOX_RE = re.compile(r"\[([ xX])\]")
_ENTITY_RE = re.compile(
    r"&(?:#[0-9]{1,7}|#[xX][0-9A-Fa-f]{1,6}|[A-Za-z][A-Za-z0-9]{1,31});"
)
_SPAN_ATTR_RE = re.compile(r"\b(colspan|rowspan)\s*=\s*[\"']?\s*(\d+)", re.I)
_CHECKED_ATTR_RE = re.compile(r"\bchecked\b", re.I)

_IMAGE_KEYWORD_TO_TOKEN = {
    "image": "<IMG>",
    "figure": "<FIGURE>",
    "picture": "<PICTURE>",
}

# HTML tags with a 1:1 token pair in the vocab. Synonyms fold onto the token
# that already exists (<em> -> <I>).
_TAG_TO_VOCAB = {
    "table": "TABLE", "tr": "TR", "td": "TD", "th": "TH",
    "thead": "THEAD", "tbody": "TBODY", "tfoot": "TFOOT",
    "caption": "CAPTION",
    "ul": "UL", "ol": "OL", "li": "LI",
    "span": "SPAN", "small": "SMALL",
    "sup": "SUP", "sub": "SUB",
    "b": "B", "strong": "STRONG",
    "i": "I", "em": "I", "cite": "I", "var": "I",
}

# Tags rendered as a literal token sequence instead of a tag token:
# name -> (tokens emitted on the opening tag, tokens emitted on the closing tag)
_TAG_TO_LITERAL = {
    "h1": (["#"], []),
    "h2": (["##"], []),
    "h3": (["###"], []),
    "h4": (["####"], []),
    "h5": (["#####"], []),
    "h6": (["######"], []),
    "hr": (["---"], []),
    "br": (["<BR>"], []),
    "img": (["<IMG>"], []),
    "p": ([], ["\n", "\n"]),
    "div": ([], ["\n"]),
}

# Structural or unrepresentable wrappers: the tag goes, the inner text stays.
# Dropped silently -- only genuinely unrecognised tags warn and become <unk>.
_DROP_TAGS = frozenset({
    "a", "u", "mark", "code", "pre", "s", "strike", "del", "ins",
    "colgroup", "col", "figure", "figcaption", "picture",
    "font", "tt", "abbr", "label", "form", "wbr",
})

_VOID_TAGS = frozenset({"br", "img", "hr", "input", "col", "wbr"})

# Tokens that render straight to a string during decode (never carry a span).
_TOKEN_RENDER = {
    "<IMG>": "<<-------IMG----->>",
    "<FIGURE>": "<<-------FIGURE----->>",
    "<PICTURE>": "<<-------PICTURE----->>",
    "<INPUT_CHECKED>": '<input type="checkbox" checked>',
    "<INPUT_UNCHECKED>": '<input type="checkbox">',
    "<BR>": "<br>",
    "<BR/>": "<br>",
}

_CONTROL_TOKENS = ("<bos>", "<eos>", "<pad>", "<unk>")


class CustomTokenizer:
    """Map OCR blocks to Markdown/HTML, then encode the result to token ids."""

    EXACT_ANCHOR_STATUSES = {
        "SINGLE_MATCH",
        "MULTIPLE_MATCH_RESOLVED",
    }

    def __init__(
        self,
        *,
        vocab_path: str | Path | None = None,
        block_token_template: str = "<OCR_{id}>",
        same_row_overlap_threshold: float = 0.30,
        fuzzy_threshold_fn: ThresholdFunction | None = None,
        fuzzy_on_normalized: bool = True,
        max_l_dist_cap: int = 10,
    ) -> None:
        if "{id}" not in block_token_template:
            raise ValueError("block_token_template must contain '{id}'.")

        if not 0.0 <= same_row_overlap_threshold <= 1.0:
            raise ValueError(
                "same_row_overlap_threshold must be between 0 and 1."
            )

        self.block_token_template = block_token_template
        self.same_row_overlap_threshold = same_row_overlap_threshold
        self.fuzzy_on_normalized = fuzzy_on_normalized
        self.max_l_dist_cap = max_l_dist_cap
        self.fuzzy_threshold_fn = (
            fuzzy_threshold_fn or self.dynamic_max_l_dist
        )

        vocab = json.loads(
            Path(vocab_path or DEFAULT_VOCAB_PATH).read_text(encoding="utf-8")
        )
        self.min_ocr_id, self.max_ocr_id = vocab["ocr_id_range"]
        self.token_to_id: dict[str, int] = dict(vocab["tokens"])
        self.id_to_token: dict[int, str] = {
            token_id: token for token, token_id in self.token_to_id.items()
        }

        # Literal markdown pieces, longest first so '######' wins over '#'
        # and '---' over '-'. Bucketed by first character to keep the scan
        # cheap on long pages.
        literals = [
            token
            for token in self.token_to_id
            if not (token.startswith("<") and token.endswith(">"))
        ]
        self._literals_by_first_char: dict[str, list[str]] = {}
        for token in sorted(literals, key=len, reverse=True):
            self._literals_by_first_char.setdefault(token[0], []).append(token)

        # Tag tokens that may be followed by <COLSPAN>/<ROWSPAN> on decode.
        self._openable_tags = {
            f"<{name}>"
            for name in _TAG_TO_VOCAB.values()
            if f"<{name}>" in self.token_to_id
        }

        self._ocr_token_re = re.compile(
            re.escape(block_token_template).replace(r"\{id\}", r"(\d+)")
        )

        # Populated after map_ocr_blocks().
        self.last_mapping_result: dict[str, Any] | None = None

    # ========================================================
    # Public API
    # ========================================================

    def encode(
        self,
        markdown: str,
        ocr_lines: Sequence[str],
        ocr_line_coordinates: np.ndarray,
        *,
        use_unk: bool = True,
    ) -> tuple[list[int], dict[str, Any]]:
        """Encode a page into global token ids.

        Ids below ``max_ocr_id`` are pointers into ``ocr_lines``; everything
        above is a fixed vocab token. Returns ``(ids, info)`` where ``info``
        carries ``ocr_mapped_coverage`` and the rest of the mapping diagnostics.
        """
        clean_markdown = self.sanitize_entities(markdown)

        mapped_markdown = self.map_ocr_blocks(
            ocr_lines=ocr_lines,
            ocr_line_coordinates=ocr_line_coordinates,
            markdown=clean_markdown,
        )
        mapping = self.last_mapping_result or {}

        body, unknown_spans, unknown_tags, emitted_ocr_ids = self._tokenize(
            mapped_markdown,
            use_unk=use_unk,
        )

        ids = [self.token_to_id["<bos>"], *body, self.token_to_id["<eos>"]]

        total_lines = len(ocr_lines)
        total_chars = sum(len(line) for line in ocr_lines)
        matched_chars = sum(len(ocr_lines[i]) for i in emitted_ocr_ids)
        emitted = set(emitted_ocr_ids)

        info = {
            "ocr_mapped_coverage": (
                len(emitted_ocr_ids) / total_lines if total_lines else 0.0
            ),
            "char_coverage": (
                matched_chars / total_chars if total_chars else 0.0
            ),
            "mapped_ids": emitted_ocr_ids,
            "unmapped_ids": [
                ocr_id for ocr_id in range(total_lines) if ocr_id not in emitted
            ],
            "empty_ocr_ids": [
                ocr_id
                for ocr_id, line in enumerate(ocr_lines)
                if not line.strip()
            ],
            "unknown_spans": unknown_spans,
            "unknown_tags": sorted(set(unknown_tags)),
            "clean_markdown": clean_markdown,
            "mapped_markdown": mapped_markdown,
            "mapping": mapping,
        }

        return ids, info

    def decode(
        self,
        ids: Sequence[int],
        ocr_lines: Sequence[str],
        *,
        skip_special_tokens: bool = True,
    ) -> str:
        """Rebuild the page string from token ids.

        Repeated ``<COLSPAN>``/``<ROWSPAN>`` tokens are folded back into
        ``colspan=``/``rowspan=`` attributes on the tag that opened them, so
        the output is renderable HTML.
        """
        parts: list[str] = []
        pending_tag: str | None = None
        pending_colspan = 0
        pending_rowspan = 0

        def flush_tag() -> None:
            nonlocal pending_tag, pending_colspan, pending_rowspan

            if pending_tag is None:
                return

            attributes = ""
            if pending_colspan >= 2:
                attributes += f' colspan="{pending_colspan}"'
            if pending_rowspan >= 2:
                attributes += f' rowspan="{pending_rowspan}"'

            parts.append(f"<{pending_tag.lower()}{attributes}>")
            pending_tag, pending_colspan, pending_rowspan = None, 0, 0

        for raw_id in ids:
            token_id = int(raw_id)

            if self.min_ocr_id <= token_id <= self.max_ocr_id:
                if token_id < len(ocr_lines):
                    flush_tag()
                    parts.append(ocr_lines[token_id])
                else:
                    logger.warning(
                        "OCR pointer %d is out of range (%d lines); dropped.",
                        token_id,
                        len(ocr_lines),
                    )
                continue

            token = self.id_to_token.get(token_id)
            if token is None:
                continue

            if token in ("<COLSPAN>", "<ROWSPAN>"):
                if pending_tag is None:
                    logger.warning(
                        "%s with no preceding open tag; dropped.", token
                    )
                    continue

                if token == "<COLSPAN>":
                    pending_colspan += 1
                else:
                    pending_rowspan += 1
                continue

            flush_tag()

            if token == "<eos>":
                break

            if token in ("<bos>", "<pad>"):
                continue

            if token == "<unk>":
                if not skip_special_tokens:
                    parts.append("<unk>")
                continue

            if token in self._openable_tags:
                pending_tag = token[1:-1]
                continue

            parts.append(self._render_token(token))

        flush_tag()
        return "".join(parts)

    def map_ocr_blocks(
        self,
        ocr_lines: Sequence[str],
        ocr_line_coordinates: np.ndarray,
        markdown: str,
    ) -> str:
        """
        Map OCR lines to Markdown and replace each resolved Markdown span
        with the corresponding OCR block token.

        Processing order:
            1. Exact matching
            2. Fuzzy matching for exact NO_MATCH blocks
            3. Right-to-left span replacement

        Returns:
            Markdown with resolved OCR text replaced by block tokens.
        """
        self._validate_inputs(
            ocr_lines=ocr_lines,
            ocr_line_coordinates=ocr_line_coordinates,
            markdown=markdown,
        )

        boxes = self._coordinates_to_bboxes(ocr_line_coordinates)
        page = PageIndex(markdown, self.masked_regions(markdown))

        exact_output = self.exact_match_search(
            ocr_lines=ocr_lines,
            boxes=boxes,
            markdown=markdown,
            page=page,
        )

        final_output = self.fuzzy_match_search(
            ocr_lines=ocr_lines,
            markdown=markdown,
            exact_output=exact_output,
            page=page,
        )

        mapped_markdown = self._replace_mapped_spans(
            markdown=markdown,
            results=final_output["results"],
        )

        final_output["original_markdown"] = markdown
        final_output["mapped_markdown"] = mapped_markdown
        final_output["mapped_ids"] = [
            result["ocr_id"]
            for result in final_output["results"]
            if result.get("resolved_span") is not None
        ]
        final_output["unmapped_ids"] = [
            result["ocr_id"]
            for result in final_output["results"]
            if result.get("resolved_span") is None
        ]

        self.last_mapping_result = final_output
        return mapped_markdown

    def exact_match_search(
        self,
        ocr_lines: Sequence[str],
        boxes: Sequence[BBox],
        markdown: str,
        page: PageIndex | None = None,
    ) -> dict[str, Any]:
        """Run exact matching and spatially resolve repeated matches."""
        page = page or PageIndex(markdown, self.masked_regions(markdown))

        results: list[dict[str, Any]] = []
        raw_single_ids: list[int] = []
        multiple_match_ids: list[int] = []
        no_match_ids: list[int] = []

        # First collect every exact candidate. Masked regions are absent from
        # the search stream, so no candidate can land inside a tag.
        for ocr_id, text in enumerate(ocr_lines):
            candidate_spans = page.find_all(text) if text else []

            if not candidate_spans:
                status = "NO_MATCH"
                no_match_ids.append(ocr_id)
            elif len(candidate_spans) == 1:
                status = "SINGLE_MATCH_PENDING"
                raw_single_ids.append(ocr_id)
            else:
                status = "MULTIPLE_MATCH_UNRESOLVED"
                multiple_match_ids.append(ocr_id)

            results.append(
                self._new_result(
                    ocr_id=ocr_id,
                    text=text,
                    bbox=boxes[ocr_id],
                    status=status,
                    candidate_spans=candidate_spans,
                )
            )

        occupied_spans: list[Span] = []
        single_match_ids: list[int] = []
        exact_conflict_ids: list[int] = []

        # Claim unique exact spans first. This also prevents duplicate OCR
        # blocks from mapping to the same Markdown occurrence.
        for ocr_id in sorted(raw_single_ids, key=lambda oid: len(ocr_lines[oid]), reverse=True):
            span = results[ocr_id]["candidate_spans"][0]

            if self._is_span_available(span, occupied_spans):
                results[ocr_id].update(
                    {
                        "status": "SINGLE_MATCH",
                        "resolved_span": span,
                        "matched_text": markdown[span[0] : span[1]],
                        "match_type": "EXACT",
                    }
                )
                occupied_spans.append(span)
                single_match_ids.append(ocr_id)
            else:
                results[ocr_id]["status"] = "EXACT_SPAN_CONFLICT"
                exact_conflict_ids.append(ocr_id)

        # Use only reliable, originally unique exact matches as anchors.
        anchor_ids = list(single_match_ids)

        for ocr_id in sorted(multiple_match_ids, key=lambda oid: len(ocr_lines[oid]), reverse=True):
            available_spans = [
                span
                for span in results[ocr_id]["candidate_spans"]
                if self._is_span_available(span, occupied_spans)
            ]

            results[ocr_id]["available_candidate_spans"] = available_spans

            if not available_spans:
                continue

            # Occupancy filtering may leave exactly one occurrence.
            if len(available_spans) == 1:
                selected_span = available_spans[0]
                results[ocr_id].update(
                    {
                        "status": "MULTIPLE_MATCH_RESOLVED",
                        "resolved_span": selected_span,
                        "matched_text": markdown[
                            selected_span[0] : selected_span[1]
                        ],
                        "match_type": "EXACT",
                    }
                )
                occupied_spans.append(selected_span)
                continue

            if not anchor_ids:
                continue

            anchor_id, spatial_distance = self._find_nearest_anchor(
                target_id=ocr_id,
                anchor_ids=anchor_ids,
                results=results,
            )

            anchor_span_value = results[anchor_id]["resolved_span"]
            if anchor_span_value is None:
                raise RuntimeError(f"Anchor {anchor_id} has no resolved span.")

            anchor_span: Span = tuple(anchor_span_value)
            relation = self._determine_spatial_relation(
                target_box=tuple(results[ocr_id]["bbox"]),
                anchor_box=tuple(results[anchor_id]["bbox"]),
            )

            selected_span, used_fallback = self._select_span_using_anchor(
                candidate_spans=available_spans,
                anchor_span=anchor_span,
                relation=relation,
            )

            results[ocr_id].update(
                {
                    "status": "MULTIPLE_MATCH_RESOLVED",
                    "resolved_span": selected_span,
                    "matched_text": markdown[
                        selected_span[0] : selected_span[1]
                    ],
                    "match_type": "EXACT",
                    "anchor_id": anchor_id,
                    "anchor_text": results[anchor_id]["text"],
                    "anchor_span": anchor_span,
                    "spatial_relation": relation,
                    "spatial_distance": spatial_distance,
                    "used_direction_fallback": used_fallback,
                }
            )
            occupied_spans.append(selected_span)

        unresolved_multiple_ids = [
            ocr_id
            for ocr_id in multiple_match_ids
            if results[ocr_id]["resolved_span"] is None
        ]

        return {
            "results": results,
            "no_match_ids": no_match_ids,
            "single_match_ids": single_match_ids,
            "multiple_match_ids": multiple_match_ids,
            "unresolved_multiple_match_ids": unresolved_multiple_ids,
            "exact_conflict_ids": exact_conflict_ids,
            "occupied_spans": sorted(set(occupied_spans)),
        }

    def fuzzy_match_search(
        self,
        ocr_lines: Sequence[str],
        markdown: str,
        exact_output: dict[str, Any],
        page: PageIndex | None = None,
    ) -> dict[str, Any]:
        """Fuzzy-match the blocks exact matching could not place.

        Both the NO_MATCH blocks and the EXACT_SPAN_CONFLICT ones are retried;
        the latter lost their only occurrence to a longer line and would
        otherwise never be looked at again.
        """
        page = page or PageIndex(markdown, self.masked_regions(markdown))

        output = deepcopy(exact_output)
        results: list[dict[str, Any]] = output["results"]
        occupied_spans: list[Span] = list(output["occupied_spans"])
        tag_spans = page.masked

        retry_ids = list(
            dict.fromkeys(
                list(output["no_match_ids"])
                + list(output.get("exact_conflict_ids", []))
            )
        )

        anchor_ids = [
            result["ocr_id"]
            for result in results
            if result.get("status") in self.EXACT_ANCHOR_STATUSES
            and result.get("resolved_span") is not None
        ]

        fuzzy_matched_ids: list[int] = []
        fuzzy_unmatched_ids: list[int] = []
        fuzzy_ambiguous_ids: list[int] = []
        fuzzy_skipped_ids: list[int] = []

        for ocr_id in sorted(retry_ids, key=lambda oid: len(ocr_lines[oid]), reverse=True):
            result = results[ocr_id]
            text = ocr_lines[ocr_id]

            if self.fuzzy_on_normalized:
                needle, _ = normalize(text)
                haystack = page.hay
            else:
                needle = text
                haystack = markdown

            max_l_dist = self.fuzzy_threshold_fn(len(needle))

            result.update(
                {
                    "fuzzy_max_l_dist": max_l_dist,
                    "fuzzy_distance": None,
                    "fuzzy_normalized_distance": None,
                    "fuzzy_candidate_details": [],
                    "fuzzy_best_candidate_spans": [],
                    "fuzzy_rejected_occupied_spans": [],
                }
            )

            if not needle or max_l_dist is None:
                result["status"] = "FUZZY_SKIPPED_SHORT_TEXT"
                fuzzy_skipped_ids.append(ocr_id)
                continue

            raw_matches = find_near_matches(
                needle,
                haystack,
                max_l_dist=max_l_dist,
            )

            # Deduplicate by span and keep the lowest distance for that span.
            candidate_by_span: dict[Span, dict[str, Any]] = {}

            for match in raw_matches:
                if self.fuzzy_on_normalized:
                    raw_span = page.to_raw_span(int(match.start), int(match.end))
                    if raw_span is None:
                        continue
                    start, end = raw_span
                else:
                    start, end = int(match.start), int(match.end)

                distance = int(match.dist)

                if start < 0 or end > len(markdown) or end <= start:
                    continue

                span = (start, end)
                candidate = {
                    "start": start,
                    "end": end,
                    "span": span,
                    "distance": distance,
                    "matched_text": markdown[start:end],
                }

                existing = candidate_by_span.get(span)
                if existing is None or distance < existing["distance"]:
                    candidate_by_span[span] = candidate

            rejected_spans: list[Span] = []
            available_candidates: list[dict[str, Any]] = []

            for candidate in candidate_by_span.values():
                if any(
                    self._spans_overlap(candidate["span"], tag)
                    for tag in tag_spans
                ):
                    continue
                if self._is_span_available(
                    candidate["span"],
                    occupied_spans,
                ):
                    available_candidates.append(candidate)
                else:
                    rejected_spans.append(candidate["span"])

            available_candidates.sort(
                key=lambda candidate: (
                    candidate["distance"],
                    candidate["start"],
                    candidate["end"],
                )
            )

            result["fuzzy_candidate_details"] = available_candidates
            result["fuzzy_rejected_occupied_spans"] = sorted(
                set(rejected_spans)
            )

            if not available_candidates:
                result["status"] = "FUZZY_NO_MATCH"
                fuzzy_unmatched_ids.append(ocr_id)
                continue

            best_distance = min(
                candidate["distance"]
                for candidate in available_candidates
            )
            best_candidates = [
                candidate
                for candidate in available_candidates
                if candidate["distance"] == best_distance
            ]

            result["fuzzy_best_candidate_spans"] = [
                candidate["span"] for candidate in best_candidates
            ]

            selected_candidate: dict[str, Any] | None = None
            resolved_status: str | None = None

            if len(best_candidates) == 1:
                selected_candidate = best_candidates[0]
                resolved_status = "FUZZY_UNIQUE_BEST"

            elif anchor_ids:
                anchor_id, spatial_distance = self._find_nearest_anchor(
                    target_id=ocr_id,
                    anchor_ids=anchor_ids,
                    results=results,
                )

                anchor_span_value = results[anchor_id]["resolved_span"]
                if anchor_span_value is None:
                    raise RuntimeError(
                        f"Anchor {anchor_id} has no resolved span."
                    )

                anchor_span: Span = tuple(anchor_span_value)
                relation = self._determine_spatial_relation(
                    target_box=tuple(result["bbox"]),
                    anchor_box=tuple(results[anchor_id]["bbox"]),
                )

                selected_span, used_fallback = self._select_span_using_anchor(
                    candidate_spans=[
                        candidate["span"] for candidate in best_candidates
                    ],
                    anchor_span=anchor_span,
                    relation=relation,
                )

                selected_candidate = next(
                    candidate
                    for candidate in best_candidates
                    if candidate["span"] == selected_span
                )
                resolved_status = "FUZZY_TIE_RESOLVED"

                result.update(
                    {
                        "anchor_id": anchor_id,
                        "anchor_text": results[anchor_id]["text"],
                        "anchor_span": anchor_span,
                        "spatial_relation": relation,
                        "spatial_distance": spatial_distance,
                        "used_direction_fallback": used_fallback,
                    }
                )

            else:
                result["status"] = "FUZZY_AMBIGUOUS"
                fuzzy_ambiguous_ids.append(ocr_id)
                continue

            if selected_candidate is None or resolved_status is None:
                result["status"] = "FUZZY_AMBIGUOUS"
                fuzzy_ambiguous_ids.append(ocr_id)
                continue

            resolved_span: Span = selected_candidate["span"]
            fuzzy_distance = selected_candidate["distance"]

            result.update(
                {
                    "status": resolved_status,
                    "resolved_span": resolved_span,
                    "matched_text": selected_candidate["matched_text"],
                    "match_type": "FUZZY",
                    "fuzzy_distance": fuzzy_distance,
                    "fuzzy_normalized_distance": (
                        fuzzy_distance / max(len(needle), 1)
                    ),
                }
            )

            occupied_spans.append(resolved_span)
            fuzzy_matched_ids.append(ocr_id)

        output.update(
            {
                "results": results,
                "occupied_spans": sorted(set(occupied_spans)),
                "fuzzy_retry_ids": retry_ids,
                "fuzzy_matched_ids": fuzzy_matched_ids,
                "fuzzy_unmatched_ids": fuzzy_unmatched_ids,
                "fuzzy_ambiguous_ids": fuzzy_ambiguous_ids,
                "fuzzy_skipped_ids": fuzzy_skipped_ids,
            }
        )
        return output

    # ========================================================
    # Encoding helpers
    # ========================================================

    @staticmethod
    def sanitize_entities(text: str) -> str:
        """Unescape HTML entities that cannot turn into markup.

        ``&amp;`` -> ``&`` helps OCR lines match, but ``&lt;TD&gt;`` would
        become a real tag, so anything decoding to ``<`` or ``>`` is dropped
        instead. Runs before mapping, so every offset downstream is consistent.
        """
        def replace(match: re.Match[str]) -> str:
            decoded = html.unescape(match.group(0))

            if decoded == match.group(0):
                return match.group(0)

            if "<" in decoded or ">" in decoded:
                return ""

            return decoded.replace("\xa0", " ")

        return _ENTITY_RE.sub(replace, text)

    @staticmethod
    def masked_regions(text: str) -> list[Span]:
        """Regions OCR text must never match into: markup and image placeholders."""
        spans: list[Span] = []

        for pattern in (
            _PLACEHOLDER_RE,
            _MD_IMAGE_RE,
            _IMAGE_BLOCK_RE,
            _TAG_RE,
        ):
            spans.extend(
                (match.start(), match.end()) for match in pattern.finditer(text)
            )

        return _merge_spans(spans)

    def _tokenize(
        self,
        text: str,
        *,
        use_unk: bool,
    ) -> tuple[list[int], list[str], list[str], list[int]]:
        """Single left-to-right scan of the mapped markdown."""
        ids: list[int] = []
        unknown_spans: list[str] = []
        unknown_tags: list[str] = []
        emitted_ocr_ids: list[int] = []
        buffer: list[str] = []

        unk_id = self.token_to_id["<unk>"]

        def flush() -> None:
            """Emit one <unk> per contiguous run of unrepresentable text."""
            if not buffer:
                return

            raw = "".join(buffer)
            buffer.clear()

            if not raw.strip():
                return

            unknown_spans.append(raw)
            if use_unk:
                ids.append(unk_id)

        position = 0
        length = len(text)

        while position < length:
            char = text[position]

            if char == "<":
                match = self._ocr_token_re.match(text, position)
                if match:
                    flush()
                    ocr_id = int(match.group(1))
                    ids.append(ocr_id)
                    emitted_ocr_ids.append(ocr_id)
                    position = match.end()
                    continue

                match = _PLACEHOLDER_RE.match(text, position)
                if match:
                    flush()
                    ids.append(self.token_to_id[f"<{match.group(1).upper()}>"])
                    position = match.end()
                    continue

                match = _TAG_RE.match(text, position)
                if match:
                    flush()
                    ids.extend(self._tag_to_ids(match.group(0), unknown_tags))
                    position = match.end()
                    continue

            elif char == "[":
                match = _IMAGE_BLOCK_RE.match(text, position)
                if match:
                    flush()
                    token = _IMAGE_KEYWORD_TO_TOKEN[match.group(1).lower()]
                    ids.append(self.token_to_id[token])
                    position = match.end()
                    continue

                match = _CHECKBOX_RE.match(text, position)
                if match:
                    flush()
                    token = (
                        "<INPUT_CHECKED>"
                        if match.group(1).lower() == "x"
                        else "<INPUT_UNCHECKED>"
                    )
                    ids.append(self.token_to_id[token])
                    position = match.end()
                    continue

            elif char == "!":
                match = _MD_IMAGE_RE.match(text, position)
                if match:
                    flush()
                    ids.append(self.token_to_id["<IMG>"])
                    position = match.end()
                    continue

            literal = self._match_literal(text, position)
            if literal is not None:
                flush()
                ids.append(self.token_to_id[literal])
                position += len(literal)
                continue

            buffer.append(char)
            position += 1

        flush()
        return ids, unknown_spans, unknown_tags, emitted_ocr_ids

    def _match_literal(self, text: str, position: int) -> str | None:
        for token in self._literals_by_first_char.get(text[position], ()):
            if text.startswith(token, position):
                return token
        return None

    def _tag_to_ids(self, raw_tag: str, unknown_tags: list[str]) -> list[int]:
        """Normalize one HTML tag to token ids, attributes discarded except spans."""
        def unknown(key: str, reason: str) -> list[int]:
            # Warn once per distinct tag per page; a 320K-page run would
            # otherwise drown in duplicates.
            if key not in unknown_tags:
                logger.warning("%s %r -> <unk>.", reason, raw_tag)
            unknown_tags.append(key)
            return [self.token_to_id["<unk>"]]

        match = _TAG_PARTS_RE.match(raw_tag)
        if match is None:
            return unknown(raw_tag, "Unparseable tag")

        name = match.group(1).lower()
        attributes = match.group(2) or ""
        closing = raw_tag.startswith("</")

        if name == "input":
            if closing:
                return []
            checked = _CHECKED_ATTR_RE.search(attributes) is not None
            token = "<INPUT_CHECKED>" if checked else "<INPUT_UNCHECKED>"
            return [self.token_to_id[token]]

        if name in _DROP_TAGS:
            return []

        if name in _TAG_TO_LITERAL:
            open_tokens, close_tokens = _TAG_TO_LITERAL[name]
            tokens = close_tokens if closing else open_tokens
            base = [self.token_to_id[token] for token in tokens]

        elif name in _TAG_TO_VOCAB:
            vocab_name = _TAG_TO_VOCAB[name]
            token = f"</{vocab_name}>" if closing else f"<{vocab_name}>"

            if token not in self.token_to_id:
                return unknown(name, "Tag has no vocab entry")

            base = [self.token_to_id[token]]

        elif closing and name in _VOID_TAGS:
            return []

        else:
            return unknown(name, "Unknown HTML tag")

        if closing or not base:
            return base

        return base + self._span_token_ids(attributes)

    def _span_token_ids(self, attributes: str) -> list[int]:
        """``colspan="2" rowspan="3"`` -> <COLSPAN><COLSPAN><ROWSPAN><ROWSPAN><ROWSPAN>.

        A span of 1 is the HTML default and carries no information, so it emits
        nothing. Colspan always precedes rowspan regardless of attribute order.
        """
        counts = {"colspan": 0, "rowspan": 0}

        for match in _SPAN_ATTR_RE.finditer(attributes):
            counts[match.group(1).lower()] = int(match.group(2))

        ids: list[int] = []
        for attribute, token in (
            ("colspan", "<COLSPAN>"),
            ("rowspan", "<ROWSPAN>"),
        ):
            if counts[attribute] >= 2:
                ids.extend([self.token_to_id[token]] * counts[attribute])

        return ids

    def _render_token(self, token: str) -> str:
        if token in _TOKEN_RENDER:
            return _TOKEN_RENDER[token]

        if token.startswith("</") and token.endswith(">"):
            return f"</{token[2:-1].lower()}>"

        if (
            token.startswith("<")
            and token.endswith(">")
            and token not in _CONTROL_TOKENS
        ):
            return f"<{token[1:-1].lower()}>"

        return token

    # ========================================================
    # Matching helpers
    # ========================================================

    def dynamic_max_l_dist(self, text_length: int) -> int | None:
        """
        Return the maximum allowed Levenshtein distance.

        None means fuzzy matching should be skipped. The cap matters: at 30%
        an uncapped 200-character line gets a budget of 60, which is both slow
        and matches almost anything.
        """
        if text_length <= 10:
            return None

        return min(floor(text_length * 0.30), self.max_l_dist_cap)

    @staticmethod
    def _get_html_tag_spans(markdown: str) -> list[Span]:
        """Return (start, end) spans of all HTML-like tags in the markdown."""
        return [
            (m.start(), m.end()) for m in re.finditer(r"<[^>]+>", markdown)
        ]

    @staticmethod
    def _new_result(
        *,
        ocr_id: int,
        text: str,
        bbox: BBox,
        status: str,
        candidate_spans: Sequence[Span],
    ) -> dict[str, Any]:
        return {
            "ocr_id": ocr_id,
            "text": text,
            "bbox": bbox,
            "status": status,
            "candidate_spans": list(candidate_spans),
            "available_candidate_spans": [],
            "resolved_span": None,
            "matched_text": None,
            "match_type": None,
            "anchor_id": None,
            "anchor_text": None,
            "anchor_span": None,
            "spatial_relation": None,
            "spatial_distance": None,
            "used_direction_fallback": False,
        }

    # ========================================================
    # Replacement helpers
    # ========================================================

    def _replace_mapped_spans(
        self,
        markdown: str,
        results: Sequence[dict[str, Any]],
    ) -> str:
        """Replace resolved spans from right to left to preserve offsets."""
        replacements: list[tuple[int, int, int]] = []

        for result in results:
            resolved_span = result.get("resolved_span")
            if resolved_span is None:
                continue

            start, end = map(int, resolved_span)
            replacements.append((start, end, int(result["ocr_id"])))

        # Defensive validation. Mapping should already guarantee this.
        ascending = sorted(replacements, key=lambda item: (item[0], item[1]))
        for previous, current in zip(ascending, ascending[1:]):
            if previous[1] > current[0]:
                raise RuntimeError(
                    "Resolved OCR spans overlap: "
                    f"OCR {previous[2]}={previous[:2]} and "
                    f"OCR {current[2]}={current[:2]}."
                )

        mapped_markdown = markdown

        for start, end, ocr_id in sorted(
            replacements,
            key=lambda item: item[0],
            reverse=True,
        ):
            token = self.block_token_template.format(id=ocr_id)
            mapped_markdown = (
                mapped_markdown[:start]
                + token
                + mapped_markdown[end:]
            )

        return mapped_markdown

    # ========================================================
    # Span helpers
    # ========================================================

    @staticmethod
    def _spans_overlap(span_a: Span, span_b: Span) -> bool:
        return max(span_a[0], span_b[0]) < min(span_a[1], span_b[1])

    @classmethod
    def _is_span_available(
        cls,
        candidate_span: Span,
        occupied_spans: Sequence[Span],
    ) -> bool:
        return not any(
            cls._spans_overlap(candidate_span, occupied_span)
            for occupied_span in occupied_spans
        )

    @staticmethod
    def _markdown_span_gap(span_a: Span, span_b: Span) -> int:
        return max(
            span_b[0] - span_a[1],
            span_a[0] - span_b[1],
            0,
        )

    def _select_span_using_anchor(
        self,
        candidate_spans: Sequence[Span],
        anchor_span: Span,
        relation: str,
    ) -> tuple[Span, bool]:
        if relation == "BEFORE":
            directional_spans = [
                span for span in candidate_spans if span[1] <= anchor_span[0]
            ]
        elif relation == "AFTER":
            directional_spans = [
                span for span in candidate_spans if span[0] >= anchor_span[1]
            ]
        else:
            raise ValueError(f"Unsupported spatial relation: {relation!r}")

        used_fallback = not directional_spans
        spans_to_rank = directional_spans or list(candidate_spans)
        anchor_midpoint = (anchor_span[0] + anchor_span[1]) / 2.0

        selected_span = min(
            spans_to_rank,
            key=lambda span: (
                self._markdown_span_gap(span, anchor_span),
                abs(((span[0] + span[1]) / 2.0) - anchor_midpoint),
                span[0],
                span[1],
            ),
        )

        return selected_span, used_fallback

    # ========================================================
    # Geometry helpers
    # ========================================================

    @staticmethod
    def _bounding_box_distance(box_a: BBox, box_b: BBox) -> float:
        ax1, ay1, ax2, ay2 = box_a
        bx1, by1, bx2, by2 = box_b

        horizontal_gap = max(bx1 - ax2, ax1 - bx2, 0.0)
        vertical_gap = max(by1 - ay2, ay1 - by2, 0.0)

        return hypot(horizontal_gap, vertical_gap)

    @staticmethod
    def _center_distance(box_a: BBox, box_b: BBox) -> float:
        ax1, ay1, ax2, ay2 = box_a
        bx1, by1, bx2, by2 = box_b

        return hypot(
            ((ax1 + ax2) / 2.0) - ((bx1 + bx2) / 2.0),
            ((ay1 + ay2) / 2.0) - ((by1 + by2) / 2.0),
        )

    @staticmethod
    def _vertical_overlap_ratio(box_a: BBox, box_b: BBox) -> float:
        _, ay1, _, ay2 = box_a
        _, by1, _, by2 = box_b

        overlap = max(0.0, min(ay2, by2) - max(ay1, by1))
        minimum_height = min(ay2 - ay1, by2 - by1)

        if minimum_height <= 0:
            return 0.0

        return overlap / minimum_height

    def _determine_spatial_relation(
        self,
        target_box: BBox,
        anchor_box: BBox,
    ) -> str:
        tx1, ty1, tx2, ty2 = target_box
        ax1, ay1, ax2, ay2 = anchor_box

        target_center_x = (tx1 + tx2) / 2.0
        target_center_y = (ty1 + ty2) / 2.0
        anchor_center_x = (ax1 + ax2) / 2.0
        anchor_center_y = (ay1 + ay2) / 2.0

        if (
            self._vertical_overlap_ratio(target_box, anchor_box)
            >= self.same_row_overlap_threshold
        ):
            return "BEFORE" if target_center_x < anchor_center_x else "AFTER"

        return "BEFORE" if target_center_y < anchor_center_y else "AFTER"

    def _find_nearest_anchor(
        self,
        target_id: int,
        anchor_ids: Sequence[int],
        results: Sequence[dict[str, Any]],
    ) -> tuple[int, float]:
        target_box: BBox = tuple(results[target_id]["bbox"])

        def rank(anchor_id: int) -> tuple[float, float, int, int]:
            anchor_box: BBox = tuple(results[anchor_id]["bbox"])
            status_priority = (
                0 if results[anchor_id]["status"] == "SINGLE_MATCH" else 1
            )

            return (
                self._bounding_box_distance(target_box, anchor_box),
                self._center_distance(target_box, anchor_box),
                status_priority,
                anchor_id,
            )

        anchor_id = min(anchor_ids, key=rank)
        distance = self._bounding_box_distance(
            target_box,
            tuple(results[anchor_id]["bbox"]),
        )

        return anchor_id, distance

    # ========================================================
    # Coordinate and input handling
    # ========================================================

    @staticmethod
    def _coordinate_to_bbox(coordinate: np.ndarray) -> BBox:
        coordinate = np.asarray(coordinate, dtype=float)

        if coordinate.shape == (4,):
            x1, y1, x2, y2 = map(float, coordinate)
            x_min, x_max = sorted((x1, x2))
            y_min, y_max = sorted((y1, y2))
        elif coordinate.shape == (4, 2):
            x_min = float(coordinate[:, 0].min())
            y_min = float(coordinate[:, 1].min())
            x_max = float(coordinate[:, 0].max())
            y_max = float(coordinate[:, 1].max())
        elif coordinate.shape == (8,):
            points = coordinate.reshape(4, 2)
            x_min = float(points[:, 0].min())
            y_min = float(points[:, 1].min())
            x_max = float(points[:, 0].max())
            y_max = float(points[:, 1].max())
        else:
            raise ValueError(
                "Each coordinate must have shape (4,), (4, 2), or (8,), "
                f"but received {coordinate.shape}."
            )

        values = np.asarray([x_min, y_min, x_max, y_max])
        if not np.isfinite(values).all():
            raise ValueError("OCR coordinates contain NaN or infinity.")

        return x_min, y_min, x_max, y_max

    def _coordinates_to_bboxes(
        self,
        coordinates: np.ndarray,
    ) -> list[BBox]:
        return [
            self._coordinate_to_bbox(coordinate)
            for coordinate in coordinates
        ]

    @staticmethod
    def _validate_inputs(
        *,
        ocr_lines: Sequence[str],
        ocr_line_coordinates: np.ndarray,
        markdown: str,
    ) -> None:
        if isinstance(ocr_lines, (str, bytes)):
            raise TypeError("ocr_lines must be a sequence of strings.")

        if not isinstance(ocr_line_coordinates, np.ndarray):
            raise TypeError("ocr_line_coordinates must be a NumPy array.")

        if not isinstance(markdown, str):
            raise TypeError("markdown must be a string.")

        if len(ocr_lines) != len(ocr_line_coordinates):
            raise ValueError(
                "OCR length mismatch: "
                f"len(ocr_lines)={len(ocr_lines)}, "
                "len(ocr_line_coordinates)="
                f"{len(ocr_line_coordinates)}."
            )

        invalid_ids = [
            ocr_id
            for ocr_id, text in enumerate(ocr_lines)
            if not isinstance(text, str)
        ]
        if invalid_ids:
            raise TypeError(
                "Every OCR line must be a string. "
                f"Invalid OCR IDs: {invalid_ids}"
            )
