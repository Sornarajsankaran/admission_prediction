﻿import re
from collections.abc import Sequence

import pandas as pd
from docling_core.types.doc import DocItemLabel
from docling_lite.core.logging import log_function_calls, logger
from docling.datamodel.base_models import (
    AssembledUnit,
    Cluster,
    ContainerElement,
    FigureElement,
    LayoutPrediction,
    Page,
    PageElement,
    Table,
    TextElement,
)


class PageAssembly:

    _WORD_PATTERN = re.compile(r"\b[\w]+\b")
    _TEXT_ELEM_LABELS = {
        DocItemLabel.TEXT,
        DocItemLabel.FOOTNOTE,
        DocItemLabel.CAPTION,
        DocItemLabel.CHECKBOX_UNSELECTED,
        DocItemLabel.CHECKBOX_SELECTED,
        DocItemLabel.SECTION_HEADER,
        DocItemLabel.PAGE_HEADER,
        DocItemLabel.PAGE_FOOTER,
        DocItemLabel.CODE,
        DocItemLabel.LIST_ITEM,
        DocItemLabel.FORMULA,
    }
    _PAGE_HEADER_LABELS = {DocItemLabel.PAGE_HEADER, DocItemLabel.PAGE_FOOTER}
    _TABLE_LABELS = {DocItemLabel.TABLE, DocItemLabel.DOCUMENT_INDEX}
    _CONTAINER_LABELS = {DocItemLabel.FORM, DocItemLabel.KEY_VALUE_REGION}
    _FIGURE_LABEL = DocItemLabel.PICTURE

    @classmethod
    def _sanitize_text(cls, lines: Sequence[str]) -> str:
        if len(lines) <= 1:
            return " ".join(lines).strip()

        normalized_lines = list(lines)
        for index in range(1, len(normalized_lines)):
            prev_line = normalized_lines[index - 1]
            current_line = normalized_lines[index]

            if prev_line.endswith("-"):
                prev_words = cls._WORD_PATTERN.findall(prev_line)
                current_words = cls._WORD_PATTERN.findall(current_line)
                if (
                    prev_words
                    and current_words
                    and prev_words[-1].isalnum()
                    and current_words[0].isalnum()
                ):
                    normalized_lines[index - 1] = prev_line[:-1]
            else:
                normalized_lines[index - 1] = f"{prev_line} "

        sanitized_text = "".join(normalized_lines)
        sanitized_text = sanitized_text.replace("\u2044", "/")
        sanitized_text = sanitized_text.replace("\u2019", "'")
        sanitized_text = sanitized_text.replace("\u2018", "'")
        sanitized_text = sanitized_text.replace("\u201c", '"')
        sanitized_text = sanitized_text.replace("\u201d", '"')
        sanitized_text = sanitized_text.replace("\u2022", "\u00b7")
        return sanitized_text.strip()

    @staticmethod
    def _normalize_layout_prediction(page: Page) -> LayoutPrediction:
        layout_prediction = page.predictions.layout
        if layout_prediction is None:
            normalized_prediction = LayoutPrediction()
            page.predictions.layout = normalized_prediction
            return normalized_prediction

        if isinstance(layout_prediction, LayoutPrediction):
            return layout_prediction

        if isinstance(layout_prediction, list):
            clusters = [
                cluster
                if isinstance(cluster, Cluster)
                else Cluster.model_validate(cluster)
                for cluster in layout_prediction
            ]
            normalized_prediction = LayoutPrediction(clusters=clusters)
            page.predictions.layout = normalized_prediction
            return normalized_prediction

        normalized_prediction = LayoutPrediction.model_validate(layout_prediction)
        page.predictions.layout = normalized_prediction
        return normalized_prediction

    def _assemble_page(self, page: Page) -> None:
        layout_prediction = self._normalize_layout_prediction(page)

        elements: list[PageElement] = []
        headers: list[PageElement] = []
        body: list[PageElement] = []

        for cluster in layout_prediction.clusters:
            if cluster.label in self._TEXT_ELEM_LABELS:
                text_lines = [
                    cell.text.replace("\x02", "-").strip()
                    for cell in cluster.cells
                    if cell.text and cell.text.strip()
                ]
                text_element = TextElement(
                    label=cluster.label,
                    id=cluster.id,
                    text=self._sanitize_text(text_lines),
                    page_no=page.page_no,
                    cluster=cluster,
                )
                elements.append(text_element)
                if cluster.label in self._PAGE_HEADER_LABELS:
                    headers.append(text_element)
                else:
                    body.append(text_element)
                continue

            if cluster.label in self._TABLE_LABELS:
                table_element = None
                if page.predictions.tablestructure is not None:
                    table_element = page.predictions.tablestructure.table_map.get(
                        cluster.id
                    )
                if table_element is None:
                    table_element = Table(
                        label=cluster.label,
                        id=cluster.id,
                        text="",
                        otsl_seq=[],
                        table_cells=[],
                        cluster=cluster,
                        page_no=page.page_no,
                    )
                elements.append(table_element)
                body.append(table_element)
                continue

            if cluster.label == self._FIGURE_LABEL:
                figure_element = None
                if page.predictions.figures_classification is not None:
                    figure_element = page.predictions.figures_classification.figure_map.get(
                        cluster.id
                    )
                if figure_element is None:
                    figure_element = FigureElement(
                        label=cluster.label,
                        id=cluster.id,
                        text="",
                        data=None,
                        cluster=cluster,
                        page_no=page.page_no,
                    )
                elements.append(figure_element)
                body.append(figure_element)
                continue

            if cluster.label in self._CONTAINER_LABELS:
                container_element = ContainerElement(
                    label=cluster.label,
                    id=cluster.id,
                    page_no=page.page_no,
                    cluster=cluster,
                )
                elements.append(container_element)
                body.append(container_element)

        page.assembled = AssembledUnit(elements=elements, headers=headers, body=body)

    @log_function_calls(logger)
    def assemble_pages(self, table_results: pd.DataFrame) -> pd.DataFrame:
        try:
            for page in table_results["docling_page_obj"]:
                self._assemble_page(page)

            return table_results
        except Exception as exc:
            logger.error(f"Error during page assembly: {exc}")
            raise
