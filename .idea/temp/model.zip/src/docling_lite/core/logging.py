import functools
import sys
import time
from typing import Callable, Any, Optional


class Logger:
    _instance = None
    _logger = None
    _configured = False
    _verbose_exceptions = True

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
            from loguru import logger
            cls._logger = logger
        return cls._instance

    @property
    def logger(self):
        return self._logger

    def configure(
        self,
        log_to_file: bool = False,
        file_path: Optional[str] = None,
        level: Optional[str] = "DEBUG",
        colorize: Optional[bool] = True,
        verbose_exceptions: bool = True,
    ):
        self._logger.remove()

        level = level or "DEBUG"

        self._logger.add(sys.stdout, level=level, colorize=colorize)

        if log_to_file and file_path is not None:
            self._logger.add(
                file_path,
                level=level,
                backtrace=True,
                diagnose=True,
            )

        self._configured = True
        self._verbose_exceptions = verbose_exceptions

    def get_logger(self):
        return self._logger

    def info(self, message: str):
        self._logger.opt(depth=1).info(message)

    def success(self, message: str):
        self._logger.opt(depth=1).success(message)

    def error(self, message: str):
        self._logger.opt(depth=1).error(message)

    def exception(self, message: str):
        if self._verbose_exceptions:
            self._logger.opt(depth=1).exception(message)
        else:
            self._logger.opt(depth=1).error(message)

    def warning(self, message: str):
        self._logger.opt(depth=1).warning(message)

    def debug(self, message: str):
        self._logger.opt(depth=1).debug(message)

    def trace(self, message: str):
        self._logger.opt(depth=1).trace(message)


def get_func_display_name(func, args):
    func_name = func.__name__

    if hasattr(func, "__qualname__") and "." in func.__qualname__:
        return func.__qualname__

    if args and hasattr(args[0], func_name):
        instance = args[0]
        class_name = instance.__class__.__name__
        return f"{class_name}.{func_name}"

    return func_name


def log_function_calls(custom_logger: Optional[Logger] = None):
    def decorator(func: Callable) -> Callable:
        logger = custom_logger or Logger()

        if not hasattr(func, "_call_count"):
            func._call_count = 0

        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            func_name = get_func_display_name(func, args)
            func._call_count += 1

            start_time = time.time()

            logger.info(
                f"----- Start of {func_name} [call #{func._call_count}] -----"
            )

            try:
                result = func(*args, **kwargs)
                duration = time.time() - start_time

                logger.info(
                    f"----- End of {func_name} [took {duration:.3f}s] -----"
                )

                return result

            except Exception as e:
                duration = time.time() - start_time
                logger.error(
                    f"----- {func_name} failed with {type(e).__name__}: {e} "
                    f"[after {duration:.3f}s] -----"
                )
                raise

        return wrapper

    return decorator


logger = Logger()