"""
Offline vLLM engine for the OCR two-stage model + request/response helpers.
==========================================================================

    engine = make_llm("/workspace/models/ocr_vllm")
    outs = engine.generate([page_request(pixels_u8, boxes)], sampling_params(max_boxes))
    order, fmt_ids = split_output(outs[0].outputs[0].token_ids, cfg)

``page_request`` takes the RT-DETR-preprocessed page as uint8 (3, 640, 640) -- i.e.
``round(pixel_values * 255)`` from the Heron image processor, which does not
normalize -- so each request carries 1.2 MB instead of 4.9 MB of float32.
"""

from __future__ import annotations

import numpy as np
import torch

from ocr_vllm.config import OcrTwoStageConfig


def make_llm(model_dir: str, *, dtype: str | None = None, max_num_seqs: int = 256, max_num_batched_tokens: int = 32768,
             gpu_memory_utilization: float = 0.85, enforce_eager: bool = False,
             cudagraph_mode: str | None = "FULL_DECODE_ONLY", **kwargs):
    from vllm import LLM

    if dtype is None:
        # the model directory decides: vLLM's "auto" would downcast fp32 checkpoints
        cfg = OcrTwoStageConfig.from_pretrained(model_dir)
        dtype = str(getattr(cfg, "dtype", None) or cfg.torch_dtype).replace("torch.", "")
    compilation_config = {"cudagraph_mode": cudagraph_mode} if cudagraph_mode else None
    return LLM(
        model=model_dir,
        skip_tokenizer_init=True,
        dtype=dtype,
        attention_backend="TRITON_ATTN",
        enable_prefix_caching=False,
        limit_mm_per_prompt={"image": 1},
        # pages arrive as {pixel_values, ocr_boxes} dicts, which vLLM treats as
        # pre-processed multimodal inputs
        enable_mm_embeds=True,
        max_num_seqs=max_num_seqs,
        max_num_batched_tokens=max_num_batched_tokens,
        gpu_memory_utilization=gpu_memory_utilization,
        enforce_eager=enforce_eager,
        compilation_config=compilation_config,
        **kwargs,
    )


def to_uint8(pixel_values: torch.Tensor) -> torch.Tensor:
    """Heron pixel_values in [0, 1] (resize + rescale only) -> uint8, lossless."""
    return (pixel_values * 255.0).round_().clamp_(0, 255).to(torch.uint8)


def page_request(pixels_u8: torch.Tensor, boxes: np.ndarray | torch.Tensor, cfg: OcrTwoStageConfig) -> dict:
    boxes = torch.as_tensor(np.asarray(boxes, np.float32)).reshape(1, -1, 4)
    k = boxes.shape[1]
    if not 0 < k <= cfg.max_boxes:
        raise ValueError(f"page has {k} boxes; supported range is 1..{cfg.max_boxes}")
    return {
        "prompt_token_ids": [cfg.ord_bos_id],
        "multi_modal_data": {"image": {"pixel_values": pixels_u8.reshape(1, 3, *pixels_u8.shape[-2:]),
                                       "ocr_boxes": boxes}},
    }


def sampling_params(cfg: OcrTwoStageConfig, num_boxes: int | None = None):
    """Greedy decoding. The stream is K+1 order tokens, < 64 GAP tokens, then the
    formatter tokens up to EOS."""
    from vllm import SamplingParams
    from vllm.sampling_params import RequestOutputKind

    k = cfg.max_boxes if num_boxes is None else num_boxes
    return SamplingParams(temperature=0.0, max_tokens=k + 64 + 1 + cfg.max_format_tokens,
                          stop_token_ids=[cfg.eos_token_id], detokenize=False,
                          # one output per page instead of a partial output every step
                          output_kind=RequestOutputKind.FINAL_ONLY)


def split_output(token_ids, cfg: OcrTwoStageConfig):
    """Generated ids -> (order: list[int] box indices, formatter ids in the reference's
    model-compact scheme, i.e. specials [0, M) and EMIT_NEXT = M, ending with EOS)."""
    ids = [t for t in token_ids if t != cfg.gap_id]
    if cfg.fmt_bos_id in ids:
        cut = ids.index(cfg.fmt_bos_id)
        order_ids, fmt = ids[:cut], ids[cut + 1:]
    else:
        order_ids, fmt = ids, []
    return [t - cfg.box0_id for t in order_ids], fmt
