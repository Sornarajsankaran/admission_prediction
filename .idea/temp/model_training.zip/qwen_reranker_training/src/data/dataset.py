from typing import Callable, Sequence, Tuple
import torch
from torch.utils.data import Dataset

class CustomDataset(Dataset):
    def __init__(self, df):
        self.df = df

    def _format_instruction(self, instruction, query: str, doc: str) -> str:
        return  f"<Instruct>: {instruction}\n<Query>: {query}\n<Document>: {doc}"

    def __len__(self) -> int:
        return len(self.df)

    def __getitem__(self, idx: int):
        row = self.df.iloc[idx]
        prompt = self._format_instruction(row["instruction"], row["query"], row["doc"])
        target = int(row["label"])

        return prompt, target


def get_collate_fn(tokenizer , config):
    prefix_tokens = tokenizer.encode(config['tokenizer']['prefix'], add_special_tokens=False)
    suffix_tokens = tokenizer.encode(config['tokenizer']['suffix'], add_special_tokens=False)

    def process_inputs(batch):
        prompts, targets = zip(*batch)
        
        inputs = tokenizer(
            prompts,
            padding=False,
            truncation=config['tokenizer']['truncation'],
            max_length = config['tokenizer']['max_length'] - len(prefix_tokens) - len(suffix_tokens)
        )

        for i, ele in enumerate(inputs['input_ids']):
            inputs['input_ids'][i] = prefix_tokens + ele + suffix_tokens

        inputs = tokenizer.pad(inputs, padding=config['tokenizer']['padding'], return_tensors="pt", max_length=config['tokenizer']['max_length'])
        for key in inputs:
            inputs[key] = inputs[key].to(config['general']['device'])

        targets = torch.tensor(targets, dtype=torch.long, device=config['general']['device'])

        return inputs, targets

    return process_inputs




