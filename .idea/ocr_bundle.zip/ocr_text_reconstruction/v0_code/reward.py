"""
Reward functions for GRPO fine-tuning of the OCR Text Reconstruction model.
==========================================================================

The reward is computed purely from the model's own rollout -- NO ground-truth
markdown is needed. Two factors (see the GRPO plan):

  * coverage        : fraction of the input OCR boxes that appear in the output.
                      This is the failure we are fixing (the model drops boxes),
                      so it is the primary signal.
  * duplicate_rate  : fraction of the emitted box-pointers that are repeats.
                      Stops the model from gaming coverage by spamming boxes.

      reward = w_cov * coverage  -  w_dup * duplicate_rate

Maximised exactly when every box is emitted once and only once (D == E == N).
Formatting / reading-order quality is intentionally NOT rewarded here -- it is
held in place by the KL leash to the SFT reference model, and watched via a
separate monitor.

Id scheme (special-first, matches data.py and the model config):
    id <  M (=17)   -> special token   (0=<bos> 1=<eos> 2=<pad> ...)
    id >= M         -> box pointer, box index = id - M
"""

from __future__ import annotations

from typing import List, Sequence, Tuple, Union

import torch

import backup_code.data as data

M = data.NUM_SPECIAL_TOKENS   # 17 ; ids >= M are box pointers (box index = id - M)
BOS_ID = 0                    # } match the special-first scheme / OcrReconstructionConfig
EOS_ID = 1                    # }  (see data.SPECIAL_ID_TO_STR)
PAD_ID = data.PAD_MODEL_ID    # 2


# --------------------------------------------------------------------------- #
# Extract the box pointers a rollout actually emitted
# --------------------------------------------------------------------------- #
def extract_box_ids(sequence: Sequence[int], num_boxes: int) -> List[int]:
    """Box indices emitted in ``sequence`` (in order), stopping at the first
    <eos>. Special tokens (incl. <bos>/<pad>) are skipped; a box pointer is
    mapped id -> id - M and kept only if it indexes a real box (0 <= idx < N).
    Out-of-range pointers cannot occur in practice (box_mask masks them), but
    are dropped defensively."""
    out: List[int] = []
    for tok in sequence:
        tok = int(tok)
        if tok == EOS_ID:
            break
        if tok < M:                      # any special token
            continue
        idx = tok - M
        if 0 <= idx < num_boxes:
            out.append(idx)
    return out


# --------------------------------------------------------------------------- #
# The two factors (also used by the eval monitor for logging)
# --------------------------------------------------------------------------- #
def coverage_dup(emitted_box_ids: Sequence[int], num_boxes: int) -> Tuple[float, float]:
    """Return ``(coverage, duplicate_rate)`` for one rollout.

        coverage      = distinct(emitted) / num_boxes      in [0, 1]
        duplicate_rate = (E - D) / E                        in [0, 1)

    ``num_boxes <= 0`` is degenerate (a page always has boxes) -> (0.0, 0.0)."""
    if num_boxes <= 0:
        return 0.0, 0.0
    E = len(emitted_box_ids)
    D = len(set(emitted_box_ids))
    coverage = D / num_boxes
    dup_rate = (E - D) / E if E > 0 else 0.0
    return coverage, dup_rate


# --------------------------------------------------------------------------- #
# Scalar reward for a single rollout
# --------------------------------------------------------------------------- #
def compute_reward(emitted_box_ids: Sequence[int], num_boxes: int,
                   w_cov: float = 1.0, w_dup: float = 0.5) -> float:
    """``w_cov * coverage - w_dup * duplicate_rate``.

    Range with defaults: (-w_dup, w_cov]. Group normalisation in GRPO turns the
    spread of this scalar across the K samples into the learning signal, so the
    absolute scale matters less than that better rollouts score higher."""
    coverage, dup_rate = coverage_dup(emitted_box_ids, num_boxes)
    return w_cov * coverage - w_dup * dup_rate


# --------------------------------------------------------------------------- #
# Batched reward for a group of rollouts (P*K sequences)
# --------------------------------------------------------------------------- #
def batch_rewards(sequences: Union[torch.Tensor, Sequence[Sequence[int]]],
                  box_mask: torch.Tensor,
                  w_cov: float = 1.0, w_dup: float = 0.5) -> torch.Tensor:
    """
    Args:
        sequences: (B, L) generated ids (tensor or list of lists), special-first.
        box_mask:  (B, N) bool, True = real box. Per-row ``N = box_mask.sum(1)``.
    Returns:
        (B,) float reward tensor (on ``box_mask``'s device).
    """
    if isinstance(sequences, torch.Tensor):
        sequences = sequences.tolist()
    num_boxes = box_mask.sum(dim=1).tolist()
    rewards = [
        compute_reward(extract_box_ids(seq, int(n)), int(n), w_cov, w_dup)
        for seq, n in zip(sequences, num_boxes)
    ]
    return torch.tensor(rewards, dtype=torch.float32, device=box_mask.device)


# --------------------------------------------------------------------------- #
# Batched (coverage, dup) for the eval monitor (mean coverage = the real metric)
# --------------------------------------------------------------------------- #
def batch_coverage_dup(sequences: Union[torch.Tensor, Sequence[Sequence[int]]],
                       box_mask: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor]:
    """Return ``(coverage, duplicate_rate)`` as two (B,) float tensors."""
    if isinstance(sequences, torch.Tensor):
        sequences = sequences.tolist()
    num_boxes = box_mask.sum(dim=1).tolist()
    pairs = [coverage_dup(extract_box_ids(seq, int(n)), int(n))
             for seq, n in zip(sequences, num_boxes)]
    cov = torch.tensor([c for c, _ in pairs], dtype=torch.float32, device=box_mask.device)
    dup = torch.tensor([d for _, d in pairs], dtype=torch.float32, device=box_mask.device)
    return cov, dup


__all__ = [
    "extract_box_ids",
    "coverage_dup",
    "compute_reward",
    "batch_rewards",
    "batch_coverage_dup",
    "M", "BOS_ID", "EOS_ID", "PAD_ID",
]
