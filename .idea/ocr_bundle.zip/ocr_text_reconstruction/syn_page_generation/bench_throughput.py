
#!/usr/bin/env python3
"""
bench_throughput.py — measure vLLM page->markdown throughput on one GPU.

Sweeps several client-side concurrency levels against a running vLLM server
and reports, per level: pages/sec, prompt/output tokens/sec, latency
percentiles, and truncation/failure counts. Each level gets a DISTINCT set
of pages so vLLM's prefix cache can't inflate later levels by replaying
image tokens it has already seen (the shared instruction prefix, however,
is cached across all requests — same as production).

Pages are fully rasterized into RAM up front so the GPU measurement is not
confounded by CPU rasterization speed.

Usage:
    python bench_throughput.py --pdf-dir /data/pdfs --base-url http://gpu-node:8000/v1

Outputs (in --out-dir):
    level_XXX.jsonl   per-page results incl. markdown, for quality inspection
    summary.json      machine-readable stats for every level
"""

from __future__ import annotations

import asyncio
import base64
import json
import random
import time
from pathlib import Path

import click
import httpx
import pymupdf
from openai import AsyncOpenAI

from raster_pool import RasterPool

DEFAULT_PROMPT = """Convert this document page to clean Markdown.
- Preserve the reading order, headings, lists, and tables.
- Use Markdown table syntax for tables.
- Transcribe all visible text exactly; do not summarize, translate, or add commentary.
- Output only the Markdown for the page, nothing else."""

WARMUP_REQUESTS = 8


def build_messages(prompt: str, jpg: bytes) -> list[dict]:
    # Text first, image second: the instruction is identical across requests,
    # so vLLM's prefix cache computes it once for the whole job.
    b64 = base64.b64encode(jpg).decode()
    return [{
        "role": "user",
        "content": [
            {"type": "text", "text": prompt},
            {"type": "image_url",
             "image_url": {"url": f"data:image/jpeg;base64,{b64}"}},
        ],
    }]


def collect_pages(pdf_dir: Path, needed: int, dpi: int, seed: int,
                  max_pixels: int | None) -> list:
    """Rasterize ~`needed` pages (jpg bytes, in RAM) from a shuffled pdf list."""
    pdfs = sorted(pdf_dir.rglob("*.pdf"))
    if not pdfs:
        raise click.ClickException(f"no PDFs found under {pdf_dir}")
    random.Random(seed).shuffle(pdfs)

    # Pick just enough PDFs to cover `needed` pages, then render only those —
    # never hand the whole corpus to the pool for a benchmark.
    selected, total = [], 0
    for p in pdfs:
        try:
            with pymupdf.open(p) as d:
                n = d.page_count
        except Exception:
            continue
        selected.append(p)
        total += n
        if total >= needed:
            break
    if total < needed:
        click.echo(f"warning: corpus has only {total} pages, "
                   f"benchmark wanted {needed}; using all of them")

    pages, t0 = [], time.perf_counter()
    with RasterPool() as pool:
        for batch in pool.iter_batches(selected, batch_size=64, dpi=dpi,
                                       encode="jpg", max_pixels=max_pixels):
            pages.extend(pg for pg in batch if pg.ok)
            click.echo(f"\r  rasterized {len(pages)} pages "
                       f"({len(pages) / (time.perf_counter() - t0):.0f}/s)",
                       nl=False)
    click.echo()
    random.Random(seed).shuffle(pages)  # decouple level splits from doc order
    return pages


async def one_request(client: AsyncOpenAI, model: str, prompt: str, page,
                      max_tokens: int) -> dict:
    t0 = time.perf_counter()
    rec = {"pdf": page.pdf_path, "page_no": page.page_no}
    try:
        resp = await client.chat.completions.create(
            model=model,
            messages=build_messages(prompt, page.jpg),
            max_tokens=max_tokens,
            temperature=0.0,
        )
        choice = resp.choices[0]
        rec.update(
            ok=True,
            latency_s=round(time.perf_counter() - t0, 3),
            prompt_tokens=resp.usage.prompt_tokens,
            completion_tokens=resp.usage.completion_tokens,
            finish_reason=choice.finish_reason,
            markdown=choice.message.content,
        )
    except Exception as e:
        rec.update(ok=False,
                   latency_s=round(time.perf_counter() - t0, 3),
                   error=f"{type(e).__name__}: {e}"[:500])
    return rec


async def run_level(client: AsyncOpenAI, model: str, prompt: str, pages: list,
                    concurrency: int, max_tokens: int) -> tuple[list[dict], float]:
    sem = asyncio.Semaphore(concurrency)
    done = 0

    async def worker(page):
        nonlocal done
        async with sem:
            rec = await one_request(client, model, prompt, page, max_tokens)
        done += 1
        if done % 10 == 0 or done == len(pages):
            click.echo(f"\r  {done}/{len(pages)} pages", nl=False)
        return rec

    t0 = time.perf_counter()
    results = await asyncio.gather(*(worker(pg) for pg in pages))
    wall = time.perf_counter() - t0
    click.echo()
    return results, wall


def pct(values: list[float], q: float) -> float:
    s = sorted(values)
    return s[min(len(s) - 1, int(q * len(s)))]


def summarize(concurrency: int, results: list[dict], wall: float) -> dict:
    ok = [r for r in results if r["ok"]]
    lat = [r["latency_s"] for r in ok] or [0.0]
    in_tok = sum(r["prompt_tokens"] for r in ok)
    out_tok = sum(r["completion_tokens"] for r in ok)
    return {
        "concurrency": concurrency,
        "pages": len(results),
        "ok": len(ok),
        "failed": len(results) - len(ok),
        "truncated": sum(r["finish_reason"] == "length" for r in ok),
        "wall_s": round(wall, 1),
        "pages_per_s": round(len(ok) / wall, 3),
        "in_tok_per_s": round(in_tok / wall),
        "out_tok_per_s": round(out_tok / wall),
        "mean_prompt_tok": round(in_tok / max(len(ok), 1)),
        "mean_out_tok": round(out_tok / max(len(ok), 1)),
        "lat_p50_s": round(pct(lat, 0.50), 1),
        "lat_p95_s": round(pct(lat, 0.95), 1),
    }


async def bench(pages: list, levels: list[int], pages_per_level: list[int],
                base_url: str, api_key: str, model: str, prompt: str,
                max_tokens: int, timeout: float, out_dir: Path) -> list[dict]:
    http_client = httpx.AsyncClient(
        limits=httpx.Limits(max_connections=2048, max_keepalive_connections=2048),
        timeout=httpx.Timeout(timeout, connect=30),
    )
    client = AsyncOpenAI(base_url=base_url, api_key=api_key,
                         http_client=http_client, max_retries=0)

    # Warmup: loads the vision path, triggers any lazy compilation, and fails
    # fast if the checkpoint is not vision-capable.
    click.echo(f"warmup ({WARMUP_REQUESTS} requests)...")
    warm = pages[:WARMUP_REQUESTS]
    warm_res = await asyncio.gather(
        *(one_request(client, model, prompt, pg, max_tokens) for pg in warm))
    if not any(r["ok"] for r in warm_res):
        raise click.ClickException(
            f"all warmup requests failed, first error: {warm_res[0].get('error')}")

    summaries, cursor = [], WARMUP_REQUESTS
    for conc, n in zip(levels, pages_per_level):
        chunk = pages[cursor:cursor + n]
        cursor += n
        click.echo(f"\nconcurrency={conc} on {len(chunk)} pages")
        results, wall = await run_level(client, model, prompt, chunk, conc, max_tokens)

        out_path = out_dir / f"level_{conc:03d}.jsonl"
        with out_path.open("w", encoding="utf-8") as f:
            for r in results:
                f.write(json.dumps(r, ensure_ascii=False) + "\n")

        s = summarize(conc, results, wall)
        summaries.append(s)
        click.echo(f"  {s['pages_per_s']:.2f} pages/s | "
                   f"in {s['in_tok_per_s']} tok/s | out {s['out_tok_per_s']} tok/s | "
                   f"p50 {s['lat_p50_s']}s p95 {s['lat_p95_s']}s | "
                   f"truncated {s['truncated']} | failed {s['failed']}")

    await http_client.aclose()
    return summaries


@click.command()
@click.option("--pdf-dir", type=click.Path(exists=True, file_okay=False, path_type=Path),
              required=True, help="Directory searched recursively for PDFs.")
@click.option("--base-url", default="http://localhost:8000/v1", show_default=True)
@click.option("--api-key", default="EMPTY", show_default=True)
@click.option("--model", default="unsloth/Qwen3.6-35B-A3B-NVFP4-Fast", show_default=True)
@click.option("--prompt-file", type=click.Path(exists=True, dir_okay=False, path_type=Path),
              default=None, help="Text file overriding the built-in prompt.")
@click.option("--levels", default="32,64,128,256", show_default=True,
              help="Comma-separated concurrency levels to sweep.")
@click.option("--pages-per-level", default=0, show_default=True,
              help="Pages per level; 0 = auto (4x concurrency, min 64).")
@click.option("--dpi", default=144, show_default=True)
@click.option("--max-pixels", default=2_359_296, show_default=True,
              help="Downscale any page render above this pixel area "
                   "(match the production job); 0 disables the cap.")
@click.option("--max-tokens", default=8192, show_default=True)
@click.option("--timeout", default=600.0, show_default=True,
              help="Per-request timeout in seconds.")
@click.option("--out-dir", type=click.Path(file_okay=False, path_type=Path),
              default=Path("bench_out"), show_default=True)
@click.option("--seed", default=0, show_default=True)
def main(pdf_dir: Path, base_url: str, api_key: str, model: str,
         prompt_file: Path | None, levels: str, pages_per_level: int,
         dpi: int, max_pixels: int, max_tokens: int, timeout: float,
         out_dir: Path, seed: int):
    """Benchmark page->markdown throughput of a vLLM server."""
    level_list = [int(x) for x in levels.split(",")]
    per_level = [pages_per_level or max(4 * c, 64) for c in level_list]
    prompt = prompt_file.read_text(encoding="utf-8") if prompt_file else DEFAULT_PROMPT
    out_dir.mkdir(parents=True, exist_ok=True)

    needed = WARMUP_REQUESTS + sum(per_level)
    click.echo(f"rasterizing ~{needed} pages at {dpi} dpi...")
    pages = collect_pages(pdf_dir, needed, dpi, seed, max_pixels or None)
    if len(pages) < needed:
        # Small corpus: reuse pages across levels. Later levels may then read
        # image tokens from the prefix cache and look faster than they are.
        click.echo("warning: reusing pages across levels; "
                   "prefix-cache hits may inflate later levels")
        while len(pages) < needed:
            pages = pages + pages
    mean_kb = sum(len(pg.jpg) for pg in pages[:200]) / min(len(pages), 200) / 1024
    click.echo(f"  mean jpg size: {mean_kb:.0f} KB")

    summaries = asyncio.run(bench(
        pages, level_list, per_level, base_url, api_key, model,
        prompt, max_tokens, timeout, out_dir))

    click.echo("\n=== summary ===")
    header = ("conc", "pages", "pages/s", "in tok/s", "out tok/s",
              "p50 s", "p95 s", "trunc", "fail")
    click.echo(" | ".join(f"{h:>9}" for h in header))
    for s in summaries:
        row = (s["concurrency"], s["ok"], s["pages_per_s"], s["in_tok_per_s"],
               s["out_tok_per_s"], s["lat_p50_s"], s["lat_p95_s"],
               s["truncated"], s["failed"])
        click.echo(" | ".join(f"{v:>9}" for v in row))

    best = max(summaries, key=lambda s: s["pages_per_s"])
    for n_gpus in (1, 2):
        hours = 200_000 / (best["pages_per_s"] * n_gpus) / 3600
        click.echo(f"200K pages @ {best['pages_per_s']:.2f} pages/s x {n_gpus} GPU"
                   f"{'s' if n_gpus > 1 else ''}: ~{hours:.1f} h")

    (out_dir / "summary.json").write_text(
        json.dumps({"model": model, "dpi": dpi, "max_pixels": max_pixels,
                    "max_tokens": max_tokens, "base_url": base_url,
                    "levels": summaries}, indent=2),
        encoding="utf-8")
    click.echo(f"\nresults in {out_dir}/")


if __name__ == "__main__":
    main()
