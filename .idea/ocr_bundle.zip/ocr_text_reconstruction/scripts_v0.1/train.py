"""
Training script for the OCR Text Reconstruction model (class-based).
====================================================================

`CustomTrainer` owns the loop:
    __init__      build optimizer / scheduler / scaler, restore state
    train_epoch   one epoch (grad-accum, AMP, clip, schedule, periodic eval)
    eval_epoch    teacher-forced metrics  +  autoregressive generate() on a few
                  eval samples, stored to output_dir/samples/<tag>.jsonl
    train_model   outer epoch loop + checkpoint best/last
    eval_model    standalone full evaluation (optionally from a checkpoint)

The full network is trainable by default (pretrained rt-detr at --backbone-lr,
new modules at --lr; set them equal for a uniform LR). Use --freeze-rtdetr to
train only the new modules.

Real run (GPU box, parquet + PDFs present):

    python train.py \
        --train-parquet /data/train_data.parquet --test-parquet /data/test_data.parquet \
        --pdf-dir /data/pdfs --output-dir ./runs/v1 \
        --epochs 20 --batch-size 4 --grad-accum 4 --lr 3e-4 --backbone-lr 3e-5 \
        --eval-steps 1000 --num-eval-samples 8

CPU smoke test (no parquet / PDFs / GPU; validates the whole loop incl. generate):

    python train.py --smoke
"""

from __future__ import annotations

import json
import math
import os
import sys
import time
from pathlib import Path
from types import SimpleNamespace

sys.path.insert(0, str(Path(__file__).resolve().parent))

import click
import torch
from torch.utils.data import DataLoader, Dataset

import data
from modeling_ocr_reconstruction import OcrReconstructionConfig, OcrTextReconstructionModel


# --------------------------------------------------------------------------- #
# Synthetic dataset for --smoke (mirrors the real per-item dict)
# --------------------------------------------------------------------------- #
class _SyntheticDataset(Dataset):
    # Global ids looked up by name: the old literal 10008 was '#' in v0's vocab
    # but is '###' in v0.1's, so the constant kept working while meaning
    # something else.
    _G = data.GLOBAL_SPECIAL_BASE
    BOS = _G + data.SPECIAL_STR_TO_ID["<bos>"]
    EOS = _G + data.SPECIAL_STR_TO_ID["<eos>"]
    HASH = _G + data.SPECIAL_STR_TO_ID["#"]
    NL = _G + data.SPECIAL_STR_TO_ID["\n"]

    def __init__(self, n: int = 32, seed: int = 0):
        self.n, self.rng = n, torch.Generator().manual_seed(seed)

    def __len__(self):
        return self.n

    def __getitem__(self, idx):
        k = int(torch.randint(3, 9, (1,), generator=self.rng).item())
        body = []
        for i in range(k):
            body += [i, self.NL] if i % 2 else [self.HASH, i]
        built, reason = data.build_example(num_boxes=k, raw_ids=[self.BOS] + body + [self.EOS])
        assert reason == "ok", reason
        return {
            "pixel_values": torch.rand(3, 640, 640, generator=self.rng),
            "ocr_boxes": torch.rand(len(built.present), 4, generator=self.rng).sort(-1).values,
            "decoder_input_ids": torch.tensor(built.decoder_input_ids, dtype=torch.long),
            "labels": torch.tensor(built.labels, dtype=torch.long),
        }


# --------------------------------------------------------------------------- #
# Construction helpers
# --------------------------------------------------------------------------- #
def build_model(args, device):
    if args.smoke:
        from transformers import RTDetrV2Config, RTDetrV2Model

        # tiny RANDOM rt-detr -- smoke only. The real path never overrides Heron's config.
        rt = RTDetrV2Model(RTDetrV2Config(
            d_model=64, encoder_hidden_dim=64, decoder_in_channels=[64, 64, 64],
            encoder_ffn_dim=128, decoder_ffn_dim=128, decoder_layers=2,
            encoder_layers=1, num_denoising=0))
        cfg = OcrReconstructionConfig(d_model=64, num_markdown_layers=2,
                                      markdown_attention_heads=8, markdown_ffn_dim=128,
                                      content_mlp_hidden_dim=64)
        model = OcrTextReconstructionModel(cfg, rtdetr=rt)
    else:
        # loads pretrained Heron with its native config -- no architecture overrides
        cfg = OcrReconstructionConfig(backbone_name_or_path=args.backbone)
        model = OcrTextReconstructionModel(cfg)

    if args.freeze_encoder:      # Stage-2: freeze the whole H_box path (rtdetr + content mlp + input norm)
        model.freeze_box_encoder()
    elif args.freeze_rtdetr:     # opt-in; default = full network trainable
        model.freeze_rtdetr(freeze_decoder=True)
    return model.to(device), cfg


def build_dataloaders(args):
    if args.smoke:
        train_ds, val_ds = _SyntheticDataset(32, seed=0), _SyntheticDataset(8, seed=1)
    else:
        image_processor = data.load_image_processor(args.backbone)
        train_ds = data.OcrReconstructionDataset(args.train_parquet, args.pdf_dir,
                                                  image_processor, max_len=args.max_len)
        val_ds = (data.OcrReconstructionDataset(args.test_parquet, args.pdf_dir,
                                                image_processor, max_len=args.max_len)
                  if args.test_parquet else None)

    train_loader = DataLoader(train_ds, batch_size=args.batch_size, shuffle=True,
                              collate_fn=data.collate_fn,
                              pin_memory=not args.smoke, drop_last=True,
                              **data.make_loader_kwargs(args.num_workers))
    val_loader = (DataLoader(val_ds, batch_size=args.batch_size, shuffle=False,
                             collate_fn=data.collate_fn,
                             **data.make_loader_kwargs(args.num_workers))
                  if val_ds is not None else None)
    return train_loader, val_loader


def build_optimizer(model, args):
    """Two LR tiers (pretrained rt-detr vs new modules) x decay/no-decay.
    With the full network trainable, all rt-detr params land in the 'rtdetr' tier."""
    def no_decay(name, p):
        return (p.ndim <= 1 or "norm" in name.lower()
                or "embedding" in name.lower() or "pos_embedding" in name)

    buckets = {("rtdetr", True): [], ("rtdetr", False): [],
               ("new", True): [], ("new", False): []}
    for name, p in model.named_parameters():
        if not p.requires_grad:
            continue
        section = "rtdetr" if name.startswith("rtdetr.") else "new"
        buckets[(section, no_decay(name, p))].append(p)

    lr_map = {"rtdetr": args.backbone_lr, "new": args.lr}
    groups = [{"params": ps, "lr": lr_map[sec],
               "weight_decay": 0.0 if nd else args.weight_decay}
              for (sec, nd), ps in buckets.items() if ps]
    return torch.optim.AdamW(groups, betas=(0.9, 0.999), eps=1e-8)


def build_scheduler(optimizer, args, total_steps):
    warmup = args.warmup_steps

    def lr_lambda(step):
        if step < warmup:
            return step / max(1, warmup)
        progress = (step - warmup) / max(1, total_steps - warmup)
        cosine = 0.5 * (1.0 + math.cos(math.pi * min(progress, 1.0)))
        return args.min_lr_ratio + (1 - args.min_lr_ratio) * cosine

    return torch.optim.lr_scheduler.LambdaLR(optimizer, lr_lambda)


def _init_from_checkpoint(model, path, device):
    """Load ONLY model weights (e.g. phase-2 init from a phase-1 checkpoint).
    Leaves optimizer / scheduler / step fresh; tolerant of key diffs."""
    ck = torch.load(path, map_location=device)
    state = ck["model"] if isinstance(ck, dict) and "model" in ck else ck
    info = model.load_state_dict(state, strict=False)
    print(f"init-from {path}: loaded weights "
          f"(missing {len(info.missing_keys)}, unexpected {len(info.unexpected_keys)})")


def _init_encoder_from_checkpoint(model, path, device):
    """Load ONLY the shared box-encoder weights (rtdetr / box_content_mlp /
    box_input_norm) from a checkpoint -- e.g. a Phase-1 ordering model -- into
    ``model``. Decoder-specific params (pos_embedding, decoder_norm, pointer_key_proj,
    ...) are intentionally left FRESH, even where their names collide with the source
    (the order decoder and markdown decoder share those names but not their meaning).
    This is the Stage-2 init: the markdown decoder then trains against the Phase-1
    H_box."""
    ck = torch.load(path, map_location=device)
    state = ck["model"] if isinstance(ck, dict) and "model" in ck else ck
    prefixes = ("rtdetr.", "box_content_mlp.", "box_input_norm.")
    enc_state = {k: v for k, v in state.items() if k.startswith(prefixes)}
    info = model.load_state_dict(enc_state, strict=False)
    if info.unexpected_keys:
        print(f"WARNING: {len(info.unexpected_keys)} encoder keys from {path} not in model "
              f"(e.g. {info.unexpected_keys[:3]})")
    print(f"init-encoder-from {path}: loaded {len(enc_state)} encoder tensors; "
          f"decoder params left fresh")


# --------------------------------------------------------------------------- #
# Trainer
# --------------------------------------------------------------------------- #
class CustomTrainer:
    def __init__(self, model, train_loader, val_loader, model_cfg, args, device):
        self.model = model
        self.train_loader = train_loader
        self.val_loader = val_loader
        self.cfg = model_cfg
        self.args = args
        self.device = device

        self.steps_per_epoch = max(1, len(train_loader) // args.grad_accum)
        self.total_steps = self.steps_per_epoch * args.epochs
        self.optimizer = build_optimizer(model, args)
        self.scheduler = build_scheduler(self.optimizer, args, self.total_steps)
        self.use_amp = device.type == "cuda" and not args.no_amp
        self.scaler = torch.amp.GradScaler("cuda", enabled=self.use_amp)
        # keep a frozen backbone in eval mode (static BatchNorm/dropout) whenever
        # rt-detr is frozen -- explicitly (--freeze-rtdetr-eval) or via --freeze-encoder
        self.freeze_rtdetr_eval = args.freeze_encoder or (args.freeze_rtdetr and args.freeze_rtdetr_eval)

        self.step, self.start_epoch, self.best = 0, 0, float("inf")
        self.sample_dir = os.path.join(args.output_dir, "samples")
        os.makedirs(self.sample_dir, exist_ok=True)
        if args.resume:
            self._load(args.resume)

    # ---- small utilities -------------------------------------------------- #
    def _autocast(self):
        return torch.amp.autocast(device_type=self.device.type, enabled=self.use_amp)

    def _to_device(self, batch):
        return {k: v.to(self.device, non_blocking=True) for k, v in batch.items()}

    def _trainable(self):
        return (p for p in self.model.parameters() if p.requires_grad)

    def _set_train_mode(self):
        """Train mode, but keep a frozen rt-detr in eval (static BatchNorm/dropout)."""
        self.model.train()
        if self.freeze_rtdetr_eval:
            self.model.rtdetr.eval()

    # ---- training --------------------------------------------------------- #
    def train_epoch(self, epoch):
        self._set_train_mode()
        self.optimizer.zero_grad(set_to_none=True)
        running, t0 = 0.0, time.time()

        for i, batch in enumerate(self.train_loader):
            batch = self._to_device(batch)
            with self._autocast():
                out = self.model(**batch)
                loss = out.loss / self.args.grad_accum
            self.scaler.scale(loss).backward()
            running += float(out.loss.detach())

            if (i + 1) % self.args.grad_accum != 0:
                continue

            self.scaler.unscale_(self.optimizer)
            torch.nn.utils.clip_grad_norm_(self._trainable(), self.args.grad_clip)
            self.scaler.step(self.optimizer)
            self.scaler.update()
            self.scheduler.step()
            self.optimizer.zero_grad(set_to_none=True)
            self.step += 1

            if self.step % self.args.log_every == 0:
                avg = running / (self.args.grad_accum * self.args.log_every)
                ips = self.args.grad_accum * self.args.log_every / (time.time() - t0)
                print(f"epoch {epoch} step {self.step}/{self.total_steps} "
                      f"loss {avg:.4f} lr {self.scheduler.get_last_lr()[0]:.2e} {ips:.1f} it/s")
                running, t0 = 0.0, time.time()

            if (self.val_loader is not None and self.args.eval_steps
                    and self.step % self.args.eval_steps == 0):
                m = self.eval_epoch(tag=f"step{self.step}")
                print(f"[eval@{self.step}] loss {m['loss']:.4f} token_acc {m['token_acc']:.3f} "
                      f"pointer_acc {m['pointer_acc']:.3f} special_acc {m['special_acc']:.3f}")
                self._maybe_save_best(m["loss"], epoch)

    @torch.no_grad()
    def eval_epoch(self, tag):
        """Teacher-forced metrics over the whole val set + stored generations for
        a few samples (written to output_dir/samples/<tag>.jsonl)."""
        self.model.eval()
        metrics = self._teacher_forced_metrics()
        self._generate_and_store(tag)
        self._set_train_mode()
        return metrics

    @torch.no_grad()
    def _teacher_forced_metrics(self):
        tot_loss = tot_tok = tot_correct = 0
        ptr_tot = ptr_ok = spc_tot = spc_ok = 0
        M = self.cfg.num_special_tokens

        for batch in self.val_loader:
            batch = self._to_device(batch)
            with self._autocast():
                out = self.model(**batch)
            labels = batch["labels"]
            mask = labels != data.IGNORE_INDEX
            n = int(mask.sum())
            tot_loss += float(out.loss) * n
            correct = (out.logits.argmax(-1) == labels) & mask
            tot_correct += int(correct.sum())
            tot_tok += n
            is_spc, is_ptr = mask & (labels < M), mask & (labels >= M)
            spc_tot += int(is_spc.sum()); spc_ok += int((correct & is_spc).sum())
            ptr_tot += int(is_ptr.sum()); ptr_ok += int((correct & is_ptr).sum())

        return {
            "loss": tot_loss / max(tot_tok, 1),
            "token_acc": tot_correct / max(tot_tok, 1),
            "pointer_acc": ptr_ok / max(ptr_tot, 1),
            "special_acc": spc_ok / max(spc_tot, 1),
        }

    @torch.no_grad()
    def _generate_and_store(self, tag):
        n_left = self.args.num_eval_samples
        records = []
        for batch in self.val_loader:
            if n_left <= 0:
                break
            batch = self._to_device(batch)
            gen = self.model.generate(
                pixel_values=batch["pixel_values"], ocr_boxes=batch["ocr_boxes"],
                box_mask=batch["box_mask"], max_new_tokens=self.args.max_gen_tokens)
            for b in range(gen.size(0)):
                if n_left <= 0:
                    break
                records.append({
                    "tag": tag, "step": self.step,
                    "pred": data.render_sequence(gen[b].tolist(), self.cfg.num_special_tokens),
                    "gt": data.render_sequence(batch["decoder_input_ids"][b].tolist(),
                                               self.cfg.num_special_tokens),
                })
                n_left -= 1

        path = os.path.join(self.sample_dir, f"{tag}.jsonl")
        with open(path, "w", encoding="utf-8") as f:
            for r in records:
                f.write(json.dumps(r, ensure_ascii=False) + "\n")
        print(f"  wrote {len(records)} generations -> {path}")

    def train_model(self):
        n_train = sum(p.numel() for p in self.model.parameters() if p.requires_grad)
        n_total = sum(p.numel() for p in self.model.parameters())
        print(f"trainable {n_train/1e6:.2f}M / {n_total/1e6:.2f}M | "
              f"groups {len(self.optimizer.param_groups)} | "
              f"steps/epoch {self.steps_per_epoch} | total {self.total_steps}")

        for epoch in range(self.start_epoch, self.args.epochs):
            self.train_epoch(epoch)
            if self.val_loader is not None:
                m = self.eval_epoch(tag=f"epoch{epoch}")
                print(f"[eval] epoch {epoch} loss {m['loss']:.4f} token_acc {m['token_acc']:.3f} "
                      f"pointer_acc {m['pointer_acc']:.3f} special_acc {m['special_acc']:.3f}")
                self._maybe_save_best(m["loss"], epoch)
            self._save(os.path.join(self.args.output_dir, "last.pt"), epoch + 1)
        print("done.")

    @torch.no_grad()
    def eval_model(self, ckpt=None):
        if ckpt:
            self._load(ckpt)
        if self.val_loader is None:
            raise ValueError("eval_model requires a validation loader")
        m = self.eval_epoch(tag="eval_model")
        print(f"[eval_model] loss {m['loss']:.4f} token_acc {m['token_acc']:.3f} "
              f"pointer_acc {m['pointer_acc']:.3f} special_acc {m['special_acc']:.3f}")
        return m

    # ---- checkpointing ---------------------------------------------------- #
    def _maybe_save_best(self, val_loss, epoch):
        if val_loss < self.best:
            self.best = val_loss
            self._save(os.path.join(self.args.output_dir, "best.pt"), epoch + 1)
            print(f"  saved best (loss {self.best:.4f})")

    def _save(self, path, epoch):
        os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
        torch.save({"model": self.model.state_dict(),
                    "optimizer": self.optimizer.state_dict(),
                    "scheduler": self.scheduler.state_dict(),
                    "scaler": self.scaler.state_dict(),
                    "step": self.step, "epoch": epoch, "best": self.best}, path)

    def _load(self, path):
        ck = torch.load(path, map_location=self.device)
        self.model.load_state_dict(ck["model"])
        self.optimizer.load_state_dict(ck["optimizer"])
        self.scheduler.load_state_dict(ck["scheduler"])
        self.scaler.load_state_dict(ck["scaler"])
        self.step, self.start_epoch, self.best = ck["step"], ck["epoch"], ck["best"]
        print(f"resumed from {path} @ step {self.step}, epoch {self.start_epoch}")


# --------------------------------------------------------------------------- #
# CLI (click)
# --------------------------------------------------------------------------- #
@click.command(context_settings={"show_default": True})
# data
@click.option("--train-parquet", type=click.Path(), default=None)
@click.option("--test-parquet", type=click.Path(), default=None)
@click.option("--pdf-dir", type=click.Path(), default=None)
@click.option("--backbone", default="docling-project/docling-layout-heron")
@click.option("--max-len", type=int, default=2048)
# optim
@click.option("--epochs", type=int, default=20)
@click.option("--batch-size", type=int, default=4)
@click.option("--grad-accum", type=int, default=4)
@click.option("--lr", type=float, default=3e-4, help="LR for new modules")
@click.option("--backbone-lr", type=float, default=3e-5, help="LR for pretrained rt-detr")
@click.option("--weight-decay", type=float, default=0.01)
@click.option("--warmup-steps", type=int, default=500)
@click.option("--min-lr-ratio", type=float, default=0.05)
@click.option("--grad-clip", type=float, default=1.0)
# runtime
@click.option("--freeze-rtdetr", is_flag=True,
              help="freeze the pretrained rt-detr (train only new modules); default = full network trainable")
@click.option("--freeze-rtdetr-eval", is_flag=True,
              help="with --freeze-rtdetr, also put rt-detr in eval mode (freezes its BatchNorm stats + dropout)")
@click.option("--freeze-encoder", is_flag=True,
              help="Stage-2: freeze the whole H_box path (rtdetr + box_content_mlp + box_input_norm); "
                   "backbone auto-set to eval mode")
@click.option("--num-workers", type=int, default=8)
@click.option("--device", default="cuda" if torch.cuda.is_available() else "cpu")
@click.option("--no-amp", is_flag=True)
@click.option("--seed", type=int, default=42)
@click.option("--output-dir", type=click.Path(), default="./runs/v1")
@click.option("--resume", type=click.Path(), default=None,
              help="resume FULL training state (model+optimizer+scheduler+step)")
@click.option("--init-from", type=click.Path(), default=None,
              help="load ONLY model weights (fresh optimizer/scheduler/step); phase-2 from a phase-1 checkpoint")
@click.option("--init-encoder-from", type=click.Path(), default=None,
              help="load ONLY the shared box-encoder (rtdetr/box_content_mlp/box_input_norm) from a Phase-1 "
                   "checkpoint; decoder params stay fresh (Stage-2 init)")
@click.option("--eval-only", is_flag=True)
@click.option("--log-every", type=int, default=20)
# eval / generation
@click.option("--eval-steps", type=int, default=0,
              help="run eval+generation every N optimizer steps (0 = only at epoch end)")
@click.option("--num-eval-samples", type=int, default=8,
              help="how many eval samples to generate + store each eval")
@click.option("--max-gen-tokens", type=int, default=1024)
# smoke
@click.option("--smoke", is_flag=True,
              help="tiny random model + synthetic data; validates the loop on CPU")
def main(**kwargs):
    args = SimpleNamespace(**kwargs)

    if args.smoke:
        args.epochs = 2 if args.epochs == 20 else args.epochs
        args.batch_size, args.grad_accum, args.num_workers = 2, 2, 0
        args.warmup_steps, args.log_every = 2, 1
        args.eval_steps, args.num_eval_samples, args.max_gen_tokens = 4, 4, 24
        args.output_dir = "./runs/smoke"
    elif not args.eval_only and not (args.train_parquet and args.pdf_dir):
        raise click.UsageError("--train-parquet and --pdf-dir are required (or use --smoke)")
    if args.init_from and args.resume:
        raise click.UsageError("--init-from (weights only) and --resume (full state) are mutually exclusive")
    if args.init_encoder_from and (args.init_from or args.resume):
        raise click.UsageError("--init-encoder-from is mutually exclusive with --init-from and --resume")

    torch.manual_seed(args.seed)
    device = torch.device(args.device)
    print(f"device={device}  smoke={args.smoke}")

    model, cfg = build_model(args, device)
    if args.init_encoder_from:
        _init_encoder_from_checkpoint(model, args.init_encoder_from, device)
    if args.init_from:
        _init_from_checkpoint(model, args.init_from, device)
    train_loader, val_loader = build_dataloaders(args)
    trainer = CustomTrainer(model, train_loader, val_loader, cfg, args, device)

    if args.eval_only:
        trainer.eval_model(ckpt=args.resume)
    else:
        trainer.train_model()


if __name__ == "__main__":
    main()
