import torch
import torch.nn as nn
import torch.nn.functional as F
from time import time
from typing import Tuple
from tqdm import tqdm
import numpy as np
from sklearn.metrics import classification_report, recall_score, precision_score
from mlflow_utils import log_performance_metrics
import logging


class Trainer:
    """
    PyTorch Trainer Module for training and validating a model.

    This class manages the training process, including loss computation,
    optimizer updates, learning rate scheduling, and mixed precision training.
    """

    def __init__(self, device, config, label):
        self.config = config
        self.criterion = torch.nn.BCEWithLogitsLoss(reduction="mean").to(device)
        self.device = device
        self.LABELS_TO_USE = label

    def _train_epoch(self, model, optimizer, scaler, lr_scheduler, dataloader) -> float:
        """
        Train the model for a single epoch.
        Performs forward pass, computes loss, updates parameters, and supports mixed precision.
        """
        model.train()
        train_loss = []

        pbar = tqdm(total=len(dataloader))
        for batch in dataloader:
            optimizer.zero_grad()
            input_ids = batch[0].to(self.device)
            attention_mask = batch[1].to(self.device)
            batch_size = input_ids.size(0)

            with torch.autocast(device_type="cuda", dtype=torch.bfloat16,
                                enabled=self.config["training"]["mixed_precision"]):
                logits = model(input_ids, attention_mask)
                loss = self.criterion(logits, batch[2].to(self.device))

            scaler.scale(loss).backward()
            scaler.step(optimizer)
            scaler.update()

            train_loss.append(loss.item())
            pbar.update(batch_size)
            pbar.set_postfix(loss=loss.item())

            if self.config["training"]["use_lr_scheduler"]:
                lr_scheduler.step()

        pbar.close()
        return sum(train_loss) / len(train_loss)

    def _eval_model(self, model, dataloader):
        """
        Validates the model and computes evaluation metrics.
        Dynamically adjusts thresholds for recall (95%) and precision (95%).
        """
        model.eval()
        preds_list, labels_list, valid_loss_list = [], [], []

        pbar = tqdm(total=len(dataloader))
        for batch in dataloader:
            inputs = batch[0].to(self.device)
            attention_mask = batch[1].to(self.device)
            labels = batch[2]
            batch_size = inputs.size(0)

            with torch.no_grad():
                with torch.autocast(device_type="cuda", dtype=torch.bfloat16,
                                    enabled=self.config["training"]["mixed_precision"]):
                    logits = model(inputs, attention_mask).to(torch.float32)
                    loss = self.criterion(logits, labels.to(self.device))

                valid_loss_list.append(loss.item())
                pred_prob = torch.sigmoid(logits).detach().cpu().numpy()

            preds_list.extend(pred_prob)
            labels_list.extend(labels.numpy().astype(np.int8))
            pbar.update(batch_size)

        pbar.close()

        avg_val_loss = sum(valid_loss_list) / len(valid_loss_list)
        labels_list = np.array(labels_list)
        preds_list = np.array(preds_list)

        # Find best threshold for exact match accuracy
        logger.info("Finding Best Threshold for Exact Match")
        thresholds = np.linspace(0, 1, 100)
        best_threshold_dict = {}
        for thresh in tqdm(thresholds):
            predicted = (preds_list > thresh).astype(np.int8)
            best_threshold_dict[thresh] = np.sum(
                np.all(labels_list == predicted, axis=1)
            )

        exact_match_thresh, num_exact_match = max(best_threshold_dict.items(), key=lambda i: i[1])
        exact_match_percentage = num_exact_match / len(preds_list)

        # Find threshold at 95% Recall
        logger.info("Finding Best Threshold for High Recall setting (95% Recall)")
        for thresh in tqdm(np.arange(0.001, 0.25, 0.0005)):
            output_labels = 1 * (preds_list > thresh)
            recall = recall_score(labels_list, output_labels, average="micro")
            if recall > 0.95:
                break
        high_recall_report = classification_report(
            labels_list, output_labels, target_names=self.LABELS_TO_USE, output_dict=True
        )
        high_recall_report["threshold"] = thresh

        # Find threshold at 95% Precision
        logger.info("Finding Best Threshold for High Precision setting (95% Precision)")
        for thresh in tqdm(np.arange(0.5, 0.99, 0.005)):
            output_labels = 1 * (preds_list > thresh)
            precision = precision_score(labels_list, output_labels, average="micro")
            if precision > 0.95:
                break
        high_precision_report = classification_report(
            labels_list, output_labels, target_names=self.LABELS_TO_USE, output_dict=True
        )
        high_precision_report["threshold"] = thresh

        return avg_val_loss, high_recall_report, high_precision_report, exact_match_percentage, exact_match_thresh

    def test_model(self, model, dataloader, threshold, output_dict=False):
        """
        Validates and computes precision/recall using provided dataloader & threshold.
        """
        model.eval()
        preds_list, labels_list = [], []

        for batch in tqdm(dataloader):
            inputs = batch[0].to(self.device)
            attention_mask = batch[1].to(self.device)
            labels = batch[2]

            with torch.no_grad():
                logits = model(inputs, attention_mask)
                output = F.sigmoid(logits).detach().cpu().numpy()

            preds_list.extend(output)
            labels_list.extend(labels.numpy().astype(np.int8))

        labels_list = np.array(labels_list)
        preds_list = np.array(preds_list)
        output_labels = 1 * (preds_list > threshold)

        report = classification_report(
            labels_list, output_labels, target_names=self.LABELS_TO_USE, output_dict=output_dict
        )
        return report

    def train_model(self, model, optimizer, scaler, lr_scheduler,
                    train_dataloader, val_dataloader, start_epoch):
        """
        Full training loop with validation, early stopping, MLflow logging, and checkpointing.
        """
        rounds = 0
        best_score = 0

        EPOCHS = self.config["training"]["epochs"] + start_epoch
        EARLY_STOPPING_ROUNDS = self.config["training"]["early_stopping_rounds"]
        MODEL_OUTPUT_PATH = self.config["training"]["output_path"] + self.config["general"]["run_name"] + "/"

        for epoch in range(start_epoch, EPOCHS):
            logger.info(f"Epoch: {epoch + 1}/{EPOCHS}")
            start_time = time()

            train_loss = self._train_epoch(model, optimizer, scaler, lr_scheduler, train_dataloader)
            logger.info(f"Train Loss: {train_loss:.4f}")

            # Save model
            if self.config["model"]["save_classification_head_only"]:
                checkpoint_path = f"{MODEL_OUTPUT_PATH}label_attention_head_epoch_{epoch}.pth"
                torch.save(model.attention.state_dict(), checkpoint_path)
            else:
                checkpoint_path = f"{MODEL_OUTPUT_PATH}full_weights_epoch_{epoch}.pth"
                torch.save(model.orig_mod.state_dict(), checkpoint_path)

            logger.info("Model saved successfully")

            # Evaluate
            val_loss, val_report_hr, val_report_hp, exact_match_percentage, exact_match_thresh = \
                self._eval_model(model, val_dataloader)

            end_time = time()
            elapsed_time = (end_time - start_time) / 60

            logger.info(f"Valid Loss: {val_loss:.4f}")
            logger.info(f"Performance @ High Recall (95%): {val_report_hr['micro avg']['recall']:.4f}")
            logger.info(f"Performance @ High Precision (95%): {val_report_hp['micro avg']['precision']:.4f}")
            logger.info(f"Exact Match %: {exact_match_percentage:.4f} | Threshold: {exact_match_thresh:.3f}")
            logger.info(f"Time elapsed: {elapsed_time:.2f} min")

            log_performance_metrics(
                val_report_hr, val_report_hp, train_loss,
                exact_match_percentage, exact_match_thresh,
                elapsed_time, optimizer.param_groups[0]['lr'], epoch
            )

            # Early stopping
            current_score = exact_match_percentage
            if current_score > best_score:
                best_score = current_score
                rounds = 0
            else:
                rounds += 1

            if rounds >= EARLY_STOPPING_ROUNDS:
                logger.info("Early stopping triggered")
                break
