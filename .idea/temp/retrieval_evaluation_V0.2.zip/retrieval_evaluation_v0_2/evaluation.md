# Evaluation Metrics Specification V0.2

**Status: frozen framework contract**  
Ground-truth schema: **V0.1**; prediction schema: **V0.2**; evaluator: **V0.2**.

## 1. Core definitions

An evaluation **query instance** is `(audit_id, pdf_filename, category, query)`.

For a fixed query instance, consider all `N >= 1` chunks in that PDF. Let the model's scores sort them from highest to lowest, yielding grades `g_1 ... g_N` and binary flags `b_1 ... b_N`, where:

- `g_i ∈ {0,1,2,3}` = ground truth relevance grade.
- `b_i ∈ {0,1}` = **externally supplied** thresholded model prediction.
- `y_i = 1[g_i >= 1]` = binary ground truth.
- `R = sum_(i=1..N) y_i` = number of positive chunks anywhere in that PDF for the query.
- Requested cutoff `K ∈ {10,20,50,100}` by default; `K_eff = min(K,N)`.
- `H_K = sum_(i=1..K_eff) y_i` = number of actual positives in top K.

Ground truth labels:

| Label | Grade | Binary ground truth |
|---|---:|---:|
| `highly_relevant` | 3 | 1 |
| `relevant` | 2 | 1 |
| `less_relevant` | 1 | 1 |
| `not_relevant` | 0 | 0 |

A **positive query** satisfies `R > 0`. A **no-positive query** satisfies `R = 0` and therefore all of its chunks have grade 0.

**Grade ties:** any two chunks with the same ground-truth grade are equivalent in nDCG's gain function. No distinct ground-truth rank is assigned within a grade. **Score ties:** equal predicted numeric scores are ordered deterministically by ascending `chunk_id` (no random or fractional tie averaging).

## 2. Ranking metrics (positive queries only)

All six metrics below are **null** for `R=0`. Per-query scores on positive queries are always defined, with `0` allowed where the top K contains no positive evidence. An `all` summary row averages ranking scores **over positive queries only** (using non-null values).

### 2.1 nDCG@K (graded ranking quality)

```
gain(g) = 2^g - 1
DCG@K = sum_{i=1..K_eff} gain(g_i) / log2(i+1)
IDCG@K = DCG of the same PDF-query chunk grades sorted descending
nDCG@K = DCG@K / IDCG@K
```

Grade gains: 0→0, 1→1, 2→3, 3→7. `IDCG@K > 0` for `R > 0`. Reordering two equally graded chunks does not change nDCG. **Ranking uses numeric scores, not binary predictions**.

### 2.2 Standard Recall@K (coverage)

```
Recall@K = H_K / R
```

The maximum achievable value may be below 1 if `R > K_eff`. This is intentional and informative for cutoff selection.

### 2.3 Normalized Recall@K (capacity-adjusted coverage)

```
NormalizedRecall@K = H_K / min(K_eff, R)
```

This is 1 if the model retrieves the maximum possible number of positive chunks at this cutoff. It equals **Precision@K** when `R >= K_eff` and equals **standard Recall@K** when `R < K_eff`. Treat it as a complementary diagnostic, not an independent kind of ranking information.

### 2.4 Precision@K (positive density)

```
Precision@K = H_K / K_eff
```

`K_eff` is the actual number of chunks available to rank when `K > N`. For no-positive queries, although raw precision could mathematically be written as 0, **V0.2 stores `null` and excludes those queries from ranking aggregations** to keep ranking and rejection assessment separate. This reporting convention is documented deliberately.

### 2.5 AP@K and MAP@K (binary ranking consistency)

Let `P@i = (sum_{j=1..i} y_j)/i`.

```
AP@K(q) = [sum_{i=1..K_eff} P@i * y_i] / R
MAP@K = mean_q(AP@K(q)) over positive query instances
```

This is the **coverage-sensitive AP@K** variant with denominator `R` (all positives in the PDF). It is **not** divided by `min(K,R)`, and it is not interpolated AP. If `R > K_eff`, even perfect top-K placement cannot generally reach AP=1. `AP@K` is stored per query as `ap`; its aggregated mean is named `map`.

### 2.6 RR@K and MRR@K (first positive chunk)

```
r = first rank i <= K_eff with y_i = 1
RR@K(q) = 1/r, if such i exists; otherwise 0 when R > 0
MRR@K = mean_q(RR@K(q)) over positive query instances
```

A no-positive query has `rr=null`, not 0. For a positive query whose positives all appear below K, RR=0. The per-query column is `rr`; the aggregated mean is `mrr`.

## 3. Binary prediction metrics

These metrics evaluate **your supplied 0/1 prediction flags** for the **same top K chunks ordered by numeric score**. No threshold is chosen or applied by this script.

Define top-K confusion counts:

```
TP_K = number of top-K chunks with (y_i = 1, b_i = 1)
FP_K = number of top-K chunks with (y_i = 0, b_i = 1)
TN_K = number of top-K chunks with (y_i = 0, b_i = 0)
FN_K = number of top-K chunks with (y_i = 1, b_i = 0)
TP_K + FP_K + TN_K + FN_K = K_eff
```

### 3.1 No-positive queries only (`R=0`)

Every top-K chunk is negative (`y_i=0`), so only FP and TN occur.

```
FalseAlarm@K(q)       = 1[FP_K > 0]        # any false-positive chunk
CorrectRejection@K(q) = 1[FP_K = 0]        # all top-K flags are zero
FalsePositiveRate@K(q)= FP_K / K_eff       # fraction of top-K chunks flagged 1

FAR@K = mean_q(FalseAlarm@K(q)) over no-positive queries
CRR@K = mean_q(CorrectRejection@K(q)) over no-positive queries
FPR@K = mean_q(FalsePositiveRate@K(q)) over no-positive queries
```

`CRR@K = 1 - FAR@K` whenever the group has at least one no-positive query. FAR is a **query-level incidence rate**, while FPR is a **per-query fraction of incorrectly accepted chunks**. FPR is macro-averaged across no-positive queries, not calculated by pooling all negative chunks.

### 3.2 Positive queries only (`R>0`)

```
PositiveEvidenceHit@K(q) = 1[TP_K > 0]
PositiveEvidenceHitRate@K = mean_q(PositiveEvidenceHit@K(q))
```

This is a **true-positive hit**. Merely predicting some top-K chunk as positive is insufficient: the accepted chunk must have a positive ground-truth grade (1, 2, or 3).

There is no defined FAR/CRR/FPR for a positive query in V0.2, and no defined Positive Evidence Hit for a no-positive query. Corresponding per-query cells are `null`.

## 4. Aggregation and output

For each query instance, calculate its metric values at each K independently. For every metric `m`, group `G`, category `C`:

```
Aggregate(m, C, G, K) = mean({m(q,K) | q in (C,G), m(q,K) is not null})
```

If no query in the group has a defined metric, its aggregate is `null` (blank in CSV), and its `n_valid_<metric>` is 0.

Groups:

- `all` = all query instances. Metric-wise averages are over applicable queries, not a single common denominator.
- `positive` = query instances where `R>0`.
- `no_positive` = query instances where `R=0`.

Categories = five fixed categories + `overall` (union of all categories). **Overall means a direct equal-weight average across all query instances**; it is not the average of category means or document means. The same query name in a different document/category is a separate instance.

For the four default Ks, `summary.csv` has **72 rows** (`6 categories x 3 groups x 4 cutoffs`). There are `4 x Q` rows in `per_query.parquet`, where `Q` is the number of query instances.

**Output schema:**

- `metadata.json`: source paths/hashes, IDs, versions, provenance, K values, positive/no-positive counts, evaluation conventions, optional threshold notes.
- `summary.csv`: `(category, query_group, k)` plus counts, no-positive prevalence, per-metric valid counts, and ten aggregate metrics.
- `per_query.parquet`: one row per query-cutoff, including the query identity, query group, label counts, TP/FP/TN/FN, and ten per-query metric scores.

`n_positive_queries`, `n_no_positive_queries`, and `no_positive_rate` in a summary row refer to the **whole category**, independent of the `query_group` filter. `n_queries` tells you how many query instances are in the **specific row's group**.

## 5. Special cases

1. **Short PDF:** if `K > N`, use `K_eff=N` in all top-K formulas; do not penalize missing positions. A cutoff larger than N plateaus for that query. Report `n_short_pools` and `mean_effective_k`.
2. **All-negative query (`R=0`):** all six ranking metrics `null`; only CRR, FAR, FPR are defined.
3. **Positive query but no positives in top K:** ranking nDCG/Recall/NormalizedRecall/Precision/AP/RR are zero, not null; PositiveEvidenceHit can be 0 or 1, and will be 0 if no top-K actual positives exist.
4. **All tied ground-truth grades:** ideal ordering handles ties naturally; no within-label penalty. Score ties follow ascending chunk ID.
5. **Missing scores/labels/flags:** strict error. Unjudged does **not** imply negative.
6. **No queries in a category:** an empty category/group row is emitted, with zero counts and null metrics.
7. **Input files:** V0.1 ground truth has `chunk_id` + `labels`. V0.2 predictions have `chunk_id` + `labels` (score dict) + `binary_predictions` (flag dict). CSV JSON encoding or native Parquet nested maps supported.
8. **Duplicate run ID:** refuse to overwrite existing experiment results.
9. **Ranking vs binary:** score determines which chunks are in the top K. Binary prediction **does not alter the ranked list**, it only evaluates accepted/rejected evidence within those chunks.

## 6. Reproducible model comparison

Every experiment gets a separate run directory. Store `metadata.json`, `summary.csv`, and `per_query.parquet` together. Preserve SHA-256 hashes and threshold configuration notes. `compare_runs.py` checks shared ground truth, version, K values, label convention, MAP variant, and tie policy before combining summaries into a comparison CSV.

**Do not collapse ranking metrics and binary rejection metrics into one overall scalar** without a separately agreed weighting or operating requirement. The two dimensions reflect different behaviors.
