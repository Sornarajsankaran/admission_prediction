# Handoff inventory and implementation notes

## Directory map

| Path | Purpose |
|---|---|
| `README.md` | Entry point and winning command |
| `REPORT.md` | Full-record results, every sweep, numerical limitations |
| `docs/INSTALL.md` | Python/CUDA environment, online or air-gapped installation |
| `docs/REAL_DATA.md` | JSONL schema, token contract, score mapping, trained model use |
| `docs/executor_analysis.md` | Detailed native vLLM executor and attention review |
| `docs/design_review.md` | Exact caching derivation, RoPE, local masks, cache memory |
| `docs/EXPERIMENT_README.md` | Original experiment overview |
| `cached_model.py` | HF/native-vLLM-weight adapter and Variant B executor |
| `shared_attention.py` | Triton shared-document-KV attention kernel and reference |
| `bench_vllm_custom.py` | Native vLLM worker entry point via `LLM.apply_model` |
| `bench_cached.py` | Tile timing, CUDA graphs, full-data transfers and score export |
| `bench_vllm.py` | Stock full-attention cross-encoder baseline |
| `bench_hf.py` | Resident-input HF baseline |
| `prepare_data.py` | Rebuild the original synthetic workload/checkpoint |
| `prepare_real_data.py` | Convert one real record's JSONL inputs |
| `validate.py` | Dense masked oracle, invariance and numeric comparison |
| `verify_scores.py` | Compare first 200 original full-run saved scores |
| `check_portability.py` | Vary document lengths across graph replays, compare dense FP32 |
| `sweep.json`, `sweep_compile.json` | Tested custom-executor configurations |
| `best_config.json` | Three repeated full-workload winner configurations |
| `run_remaining.py` | Original sequential validation/baseline/full-run driver |
| `make_report.py` | Recreate report tables from original result files |
| `models/` | Original public weights and derived benchmark checkpoint |
| `data/` | Original synthetic JSONL, token tensors and length metadata |
| `results/` | Original logs, all measured JSON/JSONL, full score tensor |
| `vendor/` | Downloaded executor/backend source snapshots and provenance |
| `examples/` | Synthetic real-data schema example and handoff smoke-check outputs |
| `original_experiment_code/` | Frozen Python files used in the original experiment |
| `requirements.lock.txt` | Full pinned source Python environment |
| `setup.sh` | Create a target-machine virtual environment and install dependencies |
| `MANIFEST.sha256` | File integrity hashes for the handoff |

## Implementation flow

1. Tokenize query and document branches with the same tokenizer used in training.
2. Embed all queries and one document tile. Each document is paired with every query.
3. For each transformer layer, compute document Q/K/V once. Document attention sees
   only document tokens, so its states remain independent of all queries.
4. Each query branch has private Q/K/V and shares its document's K/V. A single joint
   softmax combines query and document attention; other query branches are invisible.
5. Global layers see every valid document key. Local layers enforce the original
   inclusive ±64 window; only the first 64 document keys can be visible to queries.
6. `joint` combines document/query projections and MLP work for efficient matrix
   operations, while attention remains separate. It discards each layer's document
   K/V after all query branches consume it. `cache` stores per-layer K/V for reuse;
   `hot` times only queries against an already-built cache.
7. For CLS pooling, compute only the final CLS receiver after generating all needed
   final-layer keys/values. For mean pooling, retain the valid document and query sums.
8. Export one scalar logit per document/query pair.

RoPE positions are expressed relative to the document origin: query token i has
position i minus the actual query length, document token j has position j. This
preserves the relative positions for every query length and enables reuse without
rotating document keys separately for each query. It is mathematically equivalent
for the default rotary scheme, but reduced-precision rounding is not bitwise equal.

## Changes made for this portable handoff

Original numerical/timing evidence is preserved in `results/`; no original timing
was replaced by a result from the packaging changes. Original scripts are retained
in `original_experiment_code/` as an audit snapshot. To reproduce those files exactly,
copy them over the package-root scripts in a separate checkout; they expect the
package-root data/models layout, so do not execute them inside the archive directory.

The top-level runnable version additionally provides:

- Configurable `--data` for the optimized runner.
- `--queries 0` and `--full-docs -1` for all rows/columns of a supplied dataset.
- Input-count/query-width checks and automatic output-directory creation.
- Updating document lengths for every tile and graph replay, with dynamic SDPA
  padding masks. Original equal-length FlashAttention computation is unchanged.
- Checkpoint-selected classifier activation in the native worker, rather than
  silently inheriting vLLM's hardcoded GELU; scalar-head validation.
- JSONL conversion that splits long inputs without discarding text and preserves IDs.
- A variable-length graph-vs-dense FP32 check and a native vLLM example run.

These changes address portability and input handling. The original 11,715 scores/sec
measurement belongs to the original equal-length L40S workload; real-data performance
must be measured on the target machine. The validation scripts use synthetic inputs
and are not a substitute for relevance evaluation with the trained checkpoint.

## Results interpretation

`results/vllm.jsonl` contains stock scheduler/API timings. `results/vllm_custom.jsonl`
contains resident-input tile microbenchmarks and full-record measurements. For
sustained throughput use the nested `full_workload` object, not the top-level tile
rate. `hot` excludes cache building and must not be used as end-to-end throughput.

`results/full_scores.pt` is the original `[5000,50]` float32 score matrix. All three
full runs produced finite scores. `results/full_score_validation.json` compares
200 saved optimized BF16 scores against dense BF16 and FP32 Variant B. Small FP32
factorization errors do not imply BF16 bitwise equality or validated ranking quality.

The winning baseline was compiled vLLM, 8192 token budget, 64 max sequences. The
winning optimized executor used 4 documents/tile, 50 queries, joint computation,
compilation and CUDA graphs. The two APIs have different scheduling/output-object
overheads; the 8.69× figure is an observed offline application-level speedup, not
an isolated attention-kernel speedup.

## Source attribution

The public model card in `models/bioclinical-base/README.md` states MIT licensing
for the model weights. Vendored vLLM/Hugging Face source files retain their own
copyright/license headers. Preserve those notices when redistributing source.
The package does not include third-party Python wheel binaries or an activated
virtual environment. It contains no credentials or real patient records.
