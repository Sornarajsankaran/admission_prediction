"""
CPU tests for the RL data path (RLDataset row filtering + rl_collate_fn).

No model / image processor / PDF needed: rl_collate_fn is tested on synthetic
per-sample dicts, and RLDataset's filtering is tested against a tiny pickled
DataFrame (its __getitem__, which needs PDFs, is intentionally not exercised).

Run:  python test_rl_data.py   (or: pytest test_rl_data.py)
"""

from __future__ import annotations

import os
import tempfile

import numpy as np
import torch

from backup_code.data import RLDataset, rl_collate_fn


def _sample(n_boxes: int, hw: int = 4):
    return {
        "pixel_values": torch.zeros(3, hw, hw),
        "ocr_boxes": torch.arange(n_boxes * 4, dtype=torch.float32).reshape(n_boxes, 4),
        "num_boxes": n_boxes,
        "df_idx": 100 + n_boxes,
    }


# --------------------------------------------------------------------------- #
# rl_collate_fn
# --------------------------------------------------------------------------- #
def test_collate_pads_to_max_boxes():
    out = rl_collate_fn([_sample(2), _sample(5), _sample(3)])
    assert out["pixel_values"].shape == (3, 3, 4, 4)
    assert out["ocr_boxes"].shape == (3, 5, 4)          # max N = 5
    assert out["box_mask"].shape == (3, 5)
    assert out["box_mask"].sum(dim=1).tolist() == [2, 5, 3]
    assert out["num_boxes"].tolist() == [2, 5, 3]


def test_collate_box_mask_marks_real_boxes():
    out = rl_collate_fn([_sample(2), _sample(4)])
    assert out["box_mask"][0].tolist() == [True, True, False, False]
    assert out["box_mask"][1].tolist() == [True, True, True, True]
    assert torch.allclose(out["ocr_boxes"][0, 2:], torch.zeros(2, 4))   # padded rows are zero


def test_collate_preserves_box_values():
    s = _sample(3)
    out = rl_collate_fn([s])
    assert torch.equal(out["ocr_boxes"][0, :3], s["ocr_boxes"])


def test_collate_num_boxes_matches_mask():
    out = rl_collate_fn([_sample(1), _sample(7), _sample(3)])
    assert torch.equal(out["num_boxes"], out["box_mask"].sum(dim=1).long())


def test_collate_df_idx_carried_through():
    out = rl_collate_fn([_sample(1), _sample(2)])
    assert out["df_idx"].tolist() == [101, 102]


# --------------------------------------------------------------------------- #
# RLDataset row filtering  (tiny pickled DataFrame, no PDFs touched)
# --------------------------------------------------------------------------- #
def _write_df(box_counts, path):
    import pandas as pd

    df = pd.DataFrame([
        {"file_name": "x.pdf", "page": 1, "ocr_bbox": np.zeros((n, 4), dtype=np.float32)}
        for n in box_counts
    ])
    df.to_pickle(path)


def test_dataset_filters_by_box_count():
    with tempfile.TemporaryDirectory() as d:
        p = os.path.join(d, "rows.pkl")
        _write_df([0, 1, 3, 50, 200], p)
        ds = RLDataset(p, pdf_dir=d, image_processor=None,
                       min_boxes=1, max_boxes=100, verbose=False)
        # drops n=0 (too few) and n=200 (too many) -> keeps 1, 3, 50
        assert len(ds) == 3


def test_dataset_keeps_all_when_unbounded():
    with tempfile.TemporaryDirectory() as d:
        p = os.path.join(d, "rows.pkl")
        _write_df([1, 3, 50, 200], p)
        ds = RLDataset(p, pdf_dir=d, image_processor=None,
                       min_boxes=1, max_boxes=None, verbose=False)
        assert len(ds) == 4


# --------------------------------------------------------------------------- #
if __name__ == "__main__":
    import sys

    tests = [v for k, v in sorted(globals().items())
             if k.startswith("test_") and callable(v)]
    failed = 0
    for fn in tests:
        try:
            fn()
            print(f"PASS  {fn.__name__}")
        except AssertionError as e:
            failed += 1
            print(f"FAIL  {fn.__name__}: {e}")
        except Exception as e:  # noqa: BLE001
            failed += 1
            print(f"ERROR {fn.__name__}: {type(e).__name__}: {e}")
    print(f"\n{len(tests) - failed}/{len(tests)} passed")
    sys.exit(1 if failed else 0)
