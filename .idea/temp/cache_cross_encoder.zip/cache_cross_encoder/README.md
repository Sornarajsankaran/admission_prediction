# Cached cross-encoder: offline handoff

Copy this entire directory to the target Linux GPU machine. It includes the code,
model weights/tokenizers, synthetic inputs, complete benchmark results and source
analysis. No file outside this directory is needed for model/data loading. Create
a fresh Python environment on the target machine; Python virtual environments and
GPU compilation caches are deliberately not copied.

**Measured result on one L40S:** tuned stock vLLM 1,348 scores/sec versus cached
Variant B 11,715 scores/sec, including document computation and input/output
transfers. One 250,000-pair record took 185.52 sec versus 21.34 sec: **8.69×**.
These are synthetic-workload results with public pretrained weights and an untrained
CLS/GELU scalar head. They are not clinical retrieval-quality measurements.

## Start here

1. [Installation and migration](docs/INSTALL.md)
2. [Run on your own records](docs/REAL_DATA.md)
3. [Measured results and numerical error](REPORT.md)
4. [vLLM executor source analysis](docs/executor_analysis.md)
5. [Caching derivation and attention kernel](docs/design_review.md)
6. [Experiment methodology and commands](docs/EXPERIMENT_README.md)
7. [File inventory and implementation notes](docs/HANDOFF.md)

## Setup and reproduce the winning run

From this directory on the target machine:

```bash
bash setup.sh
export HF_HUB_OFFLINE=1 TRANSFORMERS_OFFLINE=1
.venv/bin/python bench_vllm_custom.py \
  --model models/benchmark-cls --data data/tokenized.pt \
  --mode joint --tile 4 --queries 50 --compile-parts --graph \
  --full-docs 5000 --repeats 7 --iters 5 \
  --output runs/reproduction.jsonl --save-scores runs/scores.pt
```

The bundled weights are already downloaded. Setup requires package-index access
unless you supply a compatible wheelhouse; see the installation guide for offline
installation. Inference then requires no Hugging Face network access.

`runs/scores.pt` is a CPU float32 tensor `[document_count, query_count]` containing
raw scalar logits. Scores are document-major. The generated `mapping.json` links
rows and columns to your source IDs when using the real-data converter.

The best settings are hardware/workload dependent. `--tile 4` is the best measured
configuration on this L40S, not a guaranteed optimum elsewhere. Benchmark query
lengths average 35.48 tokens; each document has 256 content tokens plus 7 wrappers.

## Included model checkpoints

- `models/bioclinical-base/`: original public checkpoint and tokenizer, pinned revision.
- `models/benchmark-cls/`: same pretrained backbone with deterministic untrained
  scalar classification head, explicit CLS pooling and GELU; provenance included.

Use your trained Variant B checkpoint for meaningful relevance scores. Its
architecture, head, pooling, tokenizer and attention mask must match the runner.
See the real-data guide before swapping checkpoints.

## EmbeddingGemma 2 bi-encoder comparison

See [BIENCODER_REPORT.md](BIENCODER_REPORT.md) for measured initial-encoding and
cached-document search times on the same workload. Code: `bench_biencoder.py` and
`bench_biencoder_vllm.py`. The checkpoint and all raw outputs are included.
