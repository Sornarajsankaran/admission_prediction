# Run on real records

## Input contract

Prepare one JSONL file of raw chunk text for one medical record, and one JSONL file
of queries used against that record. Examples are under `examples/`.

Chunk row:

```json
{"record_id":"MR001","chunk_id":"page1-part1","text":"Raw chunk text goes here."}
```

Query row:

```json
{"query_id":"q001","icd_code":"I10","icd_code_description":"Essential hypertension","attribute":"diagnosis","keyterm":"hypertension"}
```

IDs are optional; row numbers are used when omitted. Do not add `[CLS]`, `[SEP]`,
`<QUERY>` or `<DOC>` to the input text. The converter adds the benchmark's wrappers:

```
[CLS] <QUERY> ICD code: CODE(DESCRIPTION)
attribute: ATTRIBUTE
 search keyterm: KEYTERM</QUERY>[SEP]<DOC>CHUNK</DOC>[SEP]
```

Special CLS/SEP token IDs are inserted explicitly. Document content is tokenized
independently from the tags. This matches the benchmark's authoritative token
construction; if training used different spacing or tokenizer boundaries, reproduce
that training pipeline instead. Do not assume textually similar templates tokenize
identically. First SEP belongs to the query.

## Convert, score, read

```bash
.venv/bin/python prepare_real_data.py \
  --chunks /data/MR001/chunks.jsonl --queries /data/MR001/queries.jsonl \
  --tokenizer models/benchmark-cls --output-dir inputs/MR001

.venv/bin/python bench_vllm_custom.py \
  --model models/benchmark-cls --data inputs/MR001/tokenized.pt \
  --queries 0 --full-docs -1 --mode joint --tile 4 \
  --doc-backend sdpa --compile-parts --graph \
  --output runs/MR001/timing.jsonl --save-scores runs/MR001/scores.pt
```

`--queries 0` means all queries; `--full-docs -1` means all documents. The converter
splits overlong source chunks into nonoverlapping pieces of at most 256 content
tokens. It never silently truncates document text. `mapping.json` retains source
chunk IDs and piece numbers. Empty chunks are rejected. The converter does not
perform OCR, page extraction, clinical sentence segmentation or overlap chunking.
If you already have trained tokenization/chunking, create `tokenized.pt` directly.

```python
import json, torch
scores = torch.load("runs/MR001/scores.pt", weights_only=True)
mapping = json.load(open("inputs/MR001/mapping.json"))
# scores[document_row, query_column] is the raw scalar logit.
# mapping['chunks'][document_row] and mapping['queries'][query_column] identify it.
top_rows = scores[:, 0].topk(min(10, scores.shape[0])).indices
```

These scores are not calibrated probabilities. Use the activation/threshold/ranking
procedure established with your trained checkpoint. The included benchmark head
has never been trained and cannot establish clinical relevance.

## Variable document lengths

The original speed result uses equally sized 263-token wrapped documents and
`--doc-backend flash`. Flash document attention in this prototype requires all
rows to occupy the full document tensor width. The runner rejects unequal lengths
instead of silently attending padding.

Use `--doc-backend sdpa` for general real chunks. Document lengths and masks update
for each tile, including CUDA graph replay. This preserves the asymmetric mask;
throughput can differ from the published FlashAttention result. For best throughput
with real records, bucket documents by exact token length, trim each bucket tensor
to that length, run FlashAttention per bucket, and restore original row order. Such
automatic bucket scheduler is not implemented in this package.

Right-pad query and document ID tensors with the tokenizer pad ID. Required keys:

| Key | Shape | Type |
|---|---|---|
| query_input_ids | `[Q, query_width]` | CPU int64 |
| query_lengths | `[Q]` | CPU int64, valid prefix length |
| doc_input_ids | `[D, doc_width]` | CPU int64 |
| doc_lengths | `[D]` | CPU int64, valid prefix length |
| pad_token_id | scalar | Python int |

The converter additionally writes boolean attention masks. Lengths must be positive
and within tensor widths. All queries in this file are evaluated against all docs.
The copied benchmark's synthetic default has 50 queries; do not omit `--queries 0`
when using a different number. No real text is sent to a service by this pipeline.

## Trained checkpoint compatibility

Use a local Hugging Face `ModernBertForSequenceClassification` checkpoint with its
correct tokenizer. Current optimized code supports the base dimensions: hidden
size 768, 12 heads, head size 64, GELU backbone MLP, one scalar output, unquantized
weights, and one GPU. CLS and mean pooling are implemented; final CLS pruning is
only used for CLS. The worker explicitly selects the checkpoint's classifier
activation because vLLM 0.33.0's native pooler otherwise hardcodes GELU.

The mask must match Variant B: query receivers see their private query plus doc;
doc receivers see only doc; local layers additionally use inclusive radius 64.
Default RoPE parameters from this ModernBERT checkpoint are supported. Different
rotary schemes or architecture changes need review before reuse.

Changing a checkpoint, dtype, head, tokenizer, query set, length distribution or
hardware requires numerical and throughput revalidation. BF16 is not bitwise
identical to dense execution; see REPORT.md. FP16 is selectable with
`--dtype float16` and had smaller error on the small synthetic check.

## Many records

Run one prepared dataset per record. The CLI loads one model per invocation; for
100 records this repeats initialization. A long-lived offline integration can
instantiate `LLM` once and call `run_in_worker` with a separate settings dictionary
per record, following `bench_vllm_custom.py`. The model object is reused, while
record-specific data and query branches remain separate. The published 100-record
time is a linear extrapolation of steady-state scoring, not a measurement of 100
CLI startups or concurrent records. Warmup/compilation should be amortized in a
long-lived process. Start with one worker per GPU; competing jobs invalidate the
reported throughput comparison.
