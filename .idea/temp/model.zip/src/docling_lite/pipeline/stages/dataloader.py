import pandas as pd
from pathlib import Path

from docling_lite.core.config import REQUIRED_COLUMNS_OCR_DF
from docling_lite.core.logging import log_function_calls, logger


class DataLoader:
    @staticmethod
    def _load_ocr_dataframe(ocr_df_path: Path) -> pd.DataFrame:
        try:
            file_format = ocr_df_path.suffix.lower()

            if file_format == ".parquet":
                ocr_df = pd.read_parquet(ocr_df_path)
            elif file_format == ".csv":
                ocr_df = pd.read_csv(ocr_df_path)
            else:
                raise ValueError(
                    f"Unsupported file format: {file_format}; "
                    "supported formats are .csv and .parquet."
                )

            ocr_df.columns = ocr_df.columns.str.lower()
            column_aliases = {
                "filename": "file_name",
                "pageno": "page",
                "text": "content",
            }
            ocr_df.rename(columns=column_aliases, inplace=True)

            required_columns = set(REQUIRED_COLUMNS_OCR_DF)
            missing_cols = required_columns - set(ocr_df.columns)
            if missing_cols:
                raise ValueError(
                    f"OCR DataFrame is missing required columns: {', '.join(missing_cols)}"
                )

            ocr_df = ocr_df.dropna(subset=sorted(required_columns)).reset_index(drop=True)
            ocr_df["page"] = ocr_df["page"].astype(int)

            if ocr_df.empty:
                raise ValueError("The OCR DataFrame loaded is empty.")

            return ocr_df

        except Exception as e:
            logger.error(f"Error loading OCR DataFrame: {e}")
            raise

    @staticmethod
    def _load_raster_index(raster_dir: Path) -> pd.DataFrame:
        index_path = raster_dir / "index.parquet"
        if not index_path.exists():
            raise FileNotFoundError(
                f"Raster index not found at {index_path}. "
                "Run `python -m docling_lite.cli.rasterize` first."
            )

        index_df = pd.read_parquet(index_path)
        index_df["page"] = index_df["page"].astype(int)
        index_df["image_path"] = index_df["image_path"].apply(
            lambda p: str(raster_dir / p)
        )
        return index_df

    @classmethod
    @log_function_calls(logger)
    def load(cls, ocr_df_path: Path, raster_dir: Path) -> pd.DataFrame:
        ocr_df = cls._load_ocr_dataframe(ocr_df_path)
        logger.info(f"Loaded OCR DataFrame, shape: {ocr_df.shape}")

        raster_index = cls._load_raster_index(raster_dir)
        logger.info(f"Loaded raster index, shape: {raster_index.shape}")

        merged = ocr_df.merge(
            raster_index,
            on=["file_name", "page"],
            how="inner",
            validate="one_to_one",
        )

        dropped = len(ocr_df) - len(merged)
        if dropped > 0:
            logger.warning(
                f"Dropped {dropped} OCR row(s) without a matching rasterized page."
            )

        if merged.empty:
            raise ValueError(
                "No rows after joining OCR df with raster index. "
                "Check that file_name/page values match between the two."
            )

        logger.info(
            f"Processing {len(merged)} pages from {merged['file_name'].nunique()} PDFs"
        )
        return merged
