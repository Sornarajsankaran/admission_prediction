from __future__ import annotations

import argparse
import logging
import math
from pathlib import Path
from typing import Dict, Tuple, TYPE_CHECKING

from src.utils import get_logger, get_token_ids, set_seed
from src.data.data_prep import stratified_split
from src.data.data_utils import clean_dataframe, dump_splits_with_metadata, read_raw_dataframe
from src.data.dataset import CustomDataset, get_collate_fn
from src.data.sampler import get_sampler
from src.model.model import Qwen3Reranker
from src.training.trainer import Trainer
from src.training.lr_range_test import LRRangeFinder

if TYPE_CHECKING:
    import pandas as pd
    from torch.utils.data import DataLoader
    from transformers import AutoTokenizer

LOGGER = get_logger("qwen_reranker.entrypoint")
PROJECT_ROOT = Path(__file__).resolve().parent


def load_config(config_path: str | Path) -> Dict:
    """Load a YAML configuration file."""
    import yaml

    path = Path(config_path)
    if not path.is_absolute():
        path = (PROJECT_ROOT / path).resolve()
    if not path.exists():
        raise FileNotFoundError(f"Config file not found at {path}")
    with path.open("r", encoding="utf-8") as handle:
        return yaml.safe_load(handle)


def to_absolute(path_str: str | Path) -> Path:
    """Resolve repository-relative paths to absolute Path objects."""
    path = Path(path_str)
    if path_str in {None, "None"}:
        raise ValueError("Path value is not set in the configuration.")
    if not path.is_absolute():
        path = (PROJECT_ROOT / path).resolve()
    return path


def resolve_device(config: Dict, override: str | None = None) -> "torch.device":
    """Resolve the torch.device to use, honoring overrides and availability."""
    import torch

    if override:
        return torch.device(override)
    device_str = config.get("general", {}).get("device", "cuda:0" if torch.cuda.is_available() else "cpu")
    try:
        return torch.device(device_str)
    except RuntimeError as err:
        LOGGER.warning("Invalid device '%s': %s. Falling back to CPU.", device_str, err)
        return torch.device("cpu")


def resolve_raw_data_path(config: Dict, explicit_path: str | None) -> Path:
    """Derive the raw parquet path from CLI args or the config."""
    data_cfg = config.get("data", {})
    if explicit_path:
        candidate = Path(explicit_path)
    elif "raw_data_path" in data_cfg:
        candidate = Path(data_cfg["raw_data_path"])
    else:
        raw_dir = Path(data_cfg.get("raw_data_dir", "./data/raw/"))
        if not raw_dir.is_absolute():
            raw_dir = (PROJECT_ROOT / raw_dir).resolve()
        parquet_files = sorted(raw_dir.glob("*.parquet"))
        if not parquet_files:
            raise FileNotFoundError(f"No parquet files found under {raw_dir}. Provide --raw-path.")
        candidate = parquet_files[0]
    if not candidate.is_absolute():
        candidate = (PROJECT_ROOT / candidate).resolve()
    if not candidate.exists():
        raise FileNotFoundError(f"Raw data parquet not found at {candidate}")
    return candidate


def prepare_tokenizer(config: Dict) -> AutoTokenizer:
    """Instantiate and configure the tokenizer."""
    from transformers import AutoTokenizer

    card = config["model"]["hugging_face_card"]
    tokenizer = AutoTokenizer.from_pretrained(card, use_fast=True)
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token
    tokenizer.padding_side = "left"
    return tokenizer


def prepare_model(config: Dict, tokenizer, device: "torch.device") -> Qwen3Reranker:
    """Create the reranker with resolved token ids."""
    true_id, false_id = get_token_ids(
        tokenizer,
        true_token=config["tokenizer"]["true_token"],
        false_token=config["tokenizer"]["false_token"],
    )
    model_config = dict(config)
    model_config["token_true_id"] = true_id
    model_config["token_false_id"] = false_id
    model = Qwen3Reranker(model_config)
    return model.to(device)


def load_processed_split(processed_dir: Path, split: str) -> pd.DataFrame:
    """Load a processed parquet split, ensuring it exists."""
    import pandas as pd

    path = processed_dir / f"{split}_df.parquet"
    if not path.exists():
        raise FileNotFoundError(f"Processed split '{split}' not found at {path}. Run 'build-splits' first.")
    return pd.read_parquet(path).reset_index(drop=True)


def prepare_dataloaders(
    config: Dict,
    tokenizer,
    train_df: "pd.DataFrame",
    val_df: "pd.DataFrame",
    device: "torch.device",
) -> Tuple["DataLoader", "DataLoader"]:
    """Construct DataLoaders plus the underlying samplers."""
    from torch.utils.data import DataLoader

    collate_fn = get_collate_fn(tokenizer, config)
    train_sampler, val_sampler = get_sampler(train_df.copy(), val_df.copy(), config)

    def _build_loader(df, sampler):
        kwargs = {
            "batch_sampler": sampler,
            "collate_fn": collate_fn,
            "num_workers": config["dataloader"]["n_workers"],
            "pin_memory": device.type == "cuda",
        }
        if kwargs["num_workers"] > 0 and "prefetch_factor" in config["dataloader"]:
            kwargs["prefetch_factor"] = config["dataloader"]["prefetch_factor"]
        return DataLoader(CustomDataset(df), **kwargs)

    return _build_loader(train_df, train_sampler), _build_loader(val_df, val_sampler)


def build_scheduler(optimizer, config: Dict, train_loader_len: int, grad_accum: int):
    """Optional linear-warmup decay scheduler."""
    import torch

    if not config["training"].get("use_lr_scheduler", False):
        return None
    total_epochs = config["training"]["epochs"]
    total_updates = math.ceil(train_loader_len / grad_accum) * total_epochs
    warmup_steps = config["training"].get("lr_warmup_steps", 0)

    def lr_lambda(step: int):
        if total_updates <= 0:
            return 1.0
        if step < warmup_steps:
            return float(step + 1) / max(1, warmup_steps)
        progress = (step - warmup_steps) / max(1, total_updates - warmup_steps)
        return max(0.0, 1.0 - progress)

    return torch.optim.lr_scheduler.LambdaLR(optimizer, lr_lambda)


def run_build_splits(args) -> None:
    config = load_config(args.config)
    set_seed(config["general"]["seed"])
    raw_path = resolve_raw_data_path(config, args.raw_path)
    LOGGER.info("Loading raw parquet from %s", raw_path)
    df = clean_dataframe(read_raw_dataframe(raw_path))
    strat_cols = config["data"]["stratified_columns"]
    LOGGER.info("Building stratified splits with columns: %s", strat_cols)
    train_df, val_df, test_df = stratified_split(
        df,
        val_size=config["data"]["val_size"],
        test_size=config["data"]["test_size"],
        stratified_cols=strat_cols,
    )
    processed_dir = to_absolute(config["data"]["processed_data_dir"])
    dump_splits_with_metadata(processed_dir, train_df, val_df, test_df, strat_cols)
    LOGGER.info(
        "Saved splits to %s | train=%d val=%d test=%d",
        processed_dir,
        len(train_df),
        len(val_df),
        len(test_df),
    )


def run_lr_range_test(args) -> None:
    config = load_config(args.config)
    set_seed(config["general"]["seed"])
    device = resolve_device(config, args.device)
    processed_dir = to_absolute(config["data"]["processed_data_dir"])
    train_df = load_processed_split(processed_dir, "train")
    tokenizer = prepare_tokenizer(config)
    train_loader, _ = prepare_dataloaders(config, tokenizer, train_df, train_df, device)

    import torch

    model = prepare_model(config, tokenizer, device)
    optimizer = torch.optim.AdamW(model.parameters(), lr=args.init_lr or config["training"]["learning_rate"])

    from torch.cuda.amp import GradScaler

    scaler = GradScaler(enabled=device.type == "cuda")
    criterion = torch.nn.BCEWithLogitsLoss()

    lr_finder = LRRangeFinder(model, optimizer, scaler, criterion, train_loader, device)
    lr_finder.find_lr(
        init_lr=args.init_lr,
        final_lr=args.final_lr,
        num_iter=args.num_iter,
    )
    if args.plot_path:
        output_path = Path(args.plot_path)
        if not output_path.is_absolute():
            output_path = (PROJECT_ROOT / output_path).resolve()
        lr_finder.plot_lr_vs_loss(save_path=output_path)
        LOGGER.info("Saved LR range plot to %s", output_path)
    else:
        lr_finder.plot_lr_vs_loss()


def run_training(args) -> None:
    config = load_config(args.config)
    set_seed(config["general"]["seed"])
    device = resolve_device(config, args.device)

    processed_dir = to_absolute(config["data"]["processed_data_dir"])
    train_df = load_processed_split(processed_dir, "train")
    val_df = load_processed_split(processed_dir, "val")

    tokenizer = prepare_tokenizer(config)
    train_loader, val_loader = prepare_dataloaders(config, tokenizer, train_df, val_df, device)

    import torch

    model = prepare_model(config, tokenizer, device)
    optimizer = torch.optim.AdamW(
        model.parameters(),
        lr=args.learning_rate or config["training"]["learning_rate"],
        weight_decay=config["training"].get("weight_decay", 0.01),
    )
    scheduler = build_scheduler(optimizer, config, len(train_loader), config["training"].get("grad_accum_steps", 1))

    output_root = to_absolute(config["training"]["output_path"])
    run_name = args.run_name or config.get("mlflow", {}).get("run_name", "default_run")
    output_dir = output_root / run_name

    metadata_path = processed_dir / "metadata.json"
    artifact_paths = [metadata_path] if metadata_path.exists() else []

    trainer = Trainer(
        model=model,
        optimizer=optimizer,
        train_loader=train_loader,
        val_loader=val_loader,
        device=device,
        num_epochs=args.epochs or config["training"]["epochs"],
        grad_accum_steps=config["training"].get("grad_accum_steps", 1),
        max_grad_norm=config["training"].get("max_grad_norm"),
        output_dir=output_dir,
        scheduler=scheduler,
        use_bf16=device.type == "cuda",
        artifact_paths=artifact_paths,
    )
    trainer.train_model()
    LOGGER.info("Training complete. Artifacts stored in %s", output_dir)


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Entry point for Qwen reranker workflows.")
    parser.add_argument("--config", default="src/config.yml", help="Path to YAML config.")
    parser.add_argument("--device", default=None, help="Override device string, e.g., cuda:0 or cpu.")

    subparsers = parser.add_subparsers(dest="command", required=True)

    split_parser = subparsers.add_parser("build-splits", help="Create train/val/test parquet splits.")
    split_parser.add_argument("--raw-path", default=None, help="Optional explicit raw parquet path.")
    split_parser.set_defaults(func=run_build_splits)

    lr_parser = subparsers.add_parser("lr-range-test", help="Run a learning-rate range finder.")
    lr_parser.add_argument("--init-lr", type=float, default=1e-7, help="Starting LR for the sweep.")
    lr_parser.add_argument("--final-lr", type=float, default=1.0, help="Maximum LR for the sweep.")
    lr_parser.add_argument("--num-iter", type=int, default=100, help="Number of iterations for the sweep.")
    lr_parser.add_argument("--plot-path", default=None, help="Optional path to save the LR curve plot.")
    lr_parser.set_defaults(func=run_lr_range_test)

    train_parser = subparsers.add_parser("train", help="Train the reranker model.")
    train_parser.add_argument("--run-name", default=None, help="Name of the training run (used for output dir).")
    train_parser.add_argument("--epochs", type=int, default=None, help="Override the number of epochs.")
    train_parser.add_argument("--learning-rate", type=float, default=None, help="Override base learning rate.")
    train_parser.set_defaults(func=run_training)

    return parser


def main():
    parser = build_parser()
    args = parser.parse_args()
    logging.basicConfig(level=logging.INFO, format="%(asctime)s | %(levelname)s | %(message)s")
    args.func(args)


if __name__ == "__main__":
    main()
