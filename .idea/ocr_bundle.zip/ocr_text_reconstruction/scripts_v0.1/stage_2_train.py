"""
Stage-2 training script: markdown formatter (class-based).
=========================================================

Trains :class:`OcrMarkdownFormatterModel` to insert markdown around blocks that are
handed to it in reading order. The decoder emits over a fixed vocab
``{specials, EMIT_NEXT}``; ``EMIT_NEXT`` places the cursor block (coverage + order
by construction), and the block about to be placed is fed as a per-step hint.

The shared box encoder (RT-DETR + box_content_mlp + box_input_norm) is loaded FROZEN
from a Phase-1 ordering checkpoint (``--init-encoder-from`` + ``--freeze-encoder``), so
the formatter trains against the exact H_box the order decoder uses.

`Stage2Trainer`:
    train_epoch   grad-accum + AMP + clip + schedule
    eval_epoch    teacher-forced token/emit/special accuracy  +  FREE-RUNNING
                  generate_markdown (given GOLD order) scored by edit-similarity /
                  exact-match vs the gold markdown token stream

Real run (GPU box):

    python stage_2_train.py \
        --train-parquet /data/train.parquet --test-parquet /data/test.parquet \
        --pdf-dir /data/pdfs --init-encoder-from ./runs/order_full/best.pt --freeze-encoder \
        --output-dir ./runs/md_frozen --epochs 15 --batch-size 16 --grad-accum 1 \
        --lr 3e-4 --eval-steps 0

CPU smoke test:

    python stage_2_train.py --smoke
"""

from __future__ import annotations

import json
import os
import sys
import time
from pathlib import Path
from types import SimpleNamespace

sys.path.insert(0, str(Path(__file__).resolve().parent))

import click
import numpy as np
import torch
from torch.utils.data import DataLoader, Dataset

import data
from modeling_ocr_reconstruction import OcrReconstructionConfig, OcrMarkdownFormatterModel
from train import (
    build_optimizer, build_scheduler, _init_from_checkpoint, _init_encoder_from_checkpoint,
)


# --------------------------------------------------------------------------- #
# Metrics helpers
# --------------------------------------------------------------------------- #
def edit_similarity(a: list[int], b: list[int]) -> float:
    """1 - normalized Levenshtein distance between two token-id sequences."""
    if not a and not b:
        return 1.0
    la, lb = len(a), len(b)
    if la == 0 or lb == 0:
        return 0.0
    prev = list(range(lb + 1))
    for i in range(1, la + 1):
        cur = [i] + [0] * lb
        ai = a[i - 1]
        for j in range(1, lb + 1):
            cost = 0 if ai == b[j - 1] else 1
            cur[j] = min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + cost)
        prev = cur
    return 1.0 - prev[lb] / max(la, lb)


def _clean_generated(ids, bos=0, eos=1, pad=2) -> list[int]:
    out = []
    for t in ids:
        if t == bos or t == pad:
            continue
        if t == eos:
            break
        out.append(t)
    return out


def _clean_labels(ids, eos=1, ignore=-100) -> list[int]:
    out = []
    for t in ids:
        if t == ignore:
            continue
        if t == eos:
            break
        out.append(t)
    return out


# --------------------------------------------------------------------------- #
# Synthetic dataset for --smoke
# --------------------------------------------------------------------------- #
class _SyntheticMarkdownDataset(Dataset):
    # Looked up by name, not written out: under v0.1's ids the old literal
    # [4, 5, 8, 11] silently means \n, space, ###, ###### rather than the
    # \n, space, #, | it claimed to be.
    SPECIALS = [data.SPECIAL_STR_TO_ID[t] for t in ("\n", " ", "#", "<TD>")]

    def __init__(self, n: int = 32, seed: int = 0):
        self.n, self.rng = n, torch.Generator().manual_seed(seed)

    def __len__(self):
        return self.n

    def __getitem__(self, idx):
        k = int(torch.randint(2, 7, (1,), generator=self.rng).item())
        seq = [0]  # BOS
        for _ in range(k):
            if torch.rand(1, generator=self.rng).item() < 0.6:
                s = self.SPECIALS[int(torch.randint(0, len(self.SPECIALS), (1,), generator=self.rng))]
                seq.append(s)
            seq.append(data.EMIT_NEXT_MODEL_ID)
        seq.append(1)  # EOS
        return {
            "pixel_values": torch.rand(3, 640, 640, generator=self.rng),
            "ocr_boxes": torch.rand(k, 4, generator=self.rng).sort(-1).values,
            "order": torch.randperm(k, generator=self.rng),
            "decoder_input_ids": torch.tensor(seq[:-1], dtype=torch.long),
            "labels": torch.tensor(seq[1:], dtype=torch.long),
        }


# --------------------------------------------------------------------------- #
# Construction
# --------------------------------------------------------------------------- #
def build_model(args, device):
    if args.smoke:
        from transformers import RTDetrV2Config, RTDetrV2Model

        rt = RTDetrV2Model(RTDetrV2Config(
            d_model=64, encoder_hidden_dim=64, decoder_in_channels=[64, 64, 64],
            encoder_ffn_dim=128, decoder_ffn_dim=128, decoder_layers=2,
            encoder_layers=1, num_denoising=0))
        cfg = OcrReconstructionConfig(d_model=64, num_markdown_layers=2, markdown_attention_heads=8,
                                      markdown_ffn_dim=128, content_mlp_hidden_dim=64, dropout=args.dropout)
        model = OcrMarkdownFormatterModel(cfg, rtdetr=rt, strict_transformers_version=False)
    else:
        cfg = OcrReconstructionConfig(backbone_name_or_path=args.backbone, dropout=args.dropout)
        model = OcrMarkdownFormatterModel(cfg)

    if args.freeze_encoder:
        model.freeze_box_encoder()
    return model.to(device), cfg


def build_dataloaders(args):
    if args.smoke:
        train_ds, val_ds = _SyntheticMarkdownDataset(32, seed=0), _SyntheticMarkdownDataset(8, seed=1)
    else:
        image_processor = data.load_image_processor(args.backbone)
        train_ds = data.MarkdownDataset(args.train_parquet, args.pdf_dir, image_processor,
                                        max_len=args.max_len, max_boxes=args.max_boxes)
        val_ds = (data.MarkdownDataset(args.test_parquet, args.pdf_dir, image_processor,
                                       max_len=args.max_len, max_boxes=args.max_boxes)
                  if args.test_parquet else None)

    train_loader = DataLoader(train_ds, batch_size=args.batch_size, shuffle=True,
                              collate_fn=data.md_collate_fn,
                              pin_memory=not args.smoke, drop_last=True,
                              **data.make_loader_kwargs(args.num_workers))
    val_loader = (DataLoader(val_ds, batch_size=args.batch_size, shuffle=False,
                             collate_fn=data.md_collate_fn,
                             **data.make_loader_kwargs(args.num_workers))
                  if val_ds is not None else None)
    return train_loader, val_loader


# --------------------------------------------------------------------------- #
# Trainer
# --------------------------------------------------------------------------- #
class Stage2Trainer:
    def __init__(self, model, train_loader, val_loader, model_cfg, args, device):
        self.model = model
        self.train_loader = train_loader
        self.val_loader = val_loader
        self.cfg = model_cfg
        self.args = args
        self.device = device

        self.steps_per_epoch = max(1, len(train_loader) // args.grad_accum)
        self.total_steps = self.steps_per_epoch * args.epochs
        self.optimizer = build_optimizer(model, args)
        self.scheduler = build_scheduler(self.optimizer, args, self.total_steps)
        self.use_amp = device.type == "cuda" and not args.no_amp
        self.scaler = torch.amp.GradScaler("cuda", enabled=self.use_amp)
        # frozen encoder must stay in eval mode (static BatchNorm/dropout -> deterministic H_box)
        self.encoder_eval = args.freeze_encoder

        self.step, self.start_epoch, self.best = 0, 0, -1.0  # best = max free-running edit-sim
        self.sample_dir = os.path.join(args.output_dir, "samples")
        os.makedirs(self.sample_dir, exist_ok=True)
        if args.resume:
            self._load(args.resume)

    def _autocast(self):
        return torch.amp.autocast(device_type=self.device.type, enabled=self.use_amp)

    def _to_device(self, batch):
        return {k: v.to(self.device, non_blocking=True) for k, v in batch.items()}

    def _trainable(self):
        return (p for p in self.model.parameters() if p.requires_grad)

    def _set_train_mode(self):
        self.model.train()
        if self.encoder_eval:
            self.model.rtdetr.eval()

    def train_epoch(self, epoch):
        self._set_train_mode()
        self.optimizer.zero_grad(set_to_none=True)
        running, t0 = 0.0, time.time()

        for i, batch in enumerate(self.train_loader):
            batch = self._to_device(batch)
            with self._autocast():
                out = self.model(**batch)
                loss = out.loss / self.args.grad_accum
            self.scaler.scale(loss).backward()
            running += float(out.loss.detach())

            if (i + 1) % self.args.grad_accum != 0:
                continue

            self.scaler.unscale_(self.optimizer)
            torch.nn.utils.clip_grad_norm_(self._trainable(), self.args.grad_clip)
            self.scaler.step(self.optimizer)
            self.scaler.update()
            self.scheduler.step()
            self.optimizer.zero_grad(set_to_none=True)
            self.step += 1

            if self.step % self.args.log_every == 0:
                avg = running / (self.args.grad_accum * self.args.log_every)
                ips = self.args.grad_accum * self.args.log_every / (time.time() - t0)
                print(f"epoch {epoch} step {self.step}/{self.total_steps} "
                      f"loss {avg:.4f} lr {self.scheduler.get_last_lr()[0]:.2e} {ips:.1f} it/s")
                running, t0 = 0.0, time.time()

            if (self.val_loader is not None and self.args.eval_steps
                    and self.step % self.args.eval_steps == 0):
                m = self.eval_epoch(tag=f"step{self.step}")
                self._print_eval(m)
                self._maybe_save_best(m["edit_sim"], epoch)

    @torch.no_grad()
    def eval_epoch(self, tag):
        self.model.eval()
        metrics = self._teacher_forced_metrics()
        metrics.update(self._free_running_metrics(tag))
        self._set_train_mode()
        return metrics

    @torch.no_grad()
    def _teacher_forced_metrics(self):
        tot_loss = tot = correct = 0
        emit_tot = emit_ok = spc_tot = spc_ok = 0
        EMIT = self.model.emit_next_id
        for batch in self.val_loader:
            batch = self._to_device(batch)
            with self._autocast():
                out = self.model(**batch)
            labels = batch["labels"]
            mask = labels != data.IGNORE_INDEX
            n = int(mask.sum())
            tot_loss += float(out.loss) * n
            pred = out.logits.argmax(-1)
            ok = (pred == labels) & mask
            correct += int(ok.sum()); tot += n
            is_emit, is_spc = mask & (labels == EMIT), mask & (labels < EMIT)
            emit_tot += int(is_emit.sum()); emit_ok += int((ok & is_emit).sum())
            spc_tot += int(is_spc.sum()); spc_ok += int((ok & is_spc).sum())
        return {
            "loss": tot_loss / max(tot, 1),
            "token_acc": correct / max(tot, 1),
            "emit_acc": emit_ok / max(emit_tot, 1),
            "special_acc": spc_ok / max(spc_tot, 1),
        }

    @torch.no_grad()
    def _free_running_metrics(self, tag):
        sim_sum = exact = n_pages = 0
        records, n_store = [], self.args.num_eval_samples
        for batch in self.val_loader:
            batch = self._to_device(batch)
            gen = self.model.generate_markdown(
                pixel_values=batch["pixel_values"], ocr_boxes=batch["ocr_boxes"],
                order=batch["order"], box_mask=batch["box_mask"],
                max_new_tokens=self.args.max_gen_tokens)
            for b in range(gen.size(0)):
                pred = _clean_generated(gen[b].tolist(), self.cfg.bos_token_id,
                                        self.cfg.eos_token_id, self.cfg.pad_token_id)
                gold = _clean_labels(batch["labels"][b].tolist(), self.cfg.eos_token_id,
                                     data.IGNORE_INDEX)
                sim_sum += edit_similarity(pred, gold)
                exact += int(pred == gold)
                n_pages += 1
                if len(records) < n_store:
                    records.append({"tag": tag, "step": self.step,
                                    "pred": data.render_sequence(gen[b].tolist(), self.cfg.num_special_tokens),
                                    "gold_ids": gold})
        path = os.path.join(self.sample_dir, f"{tag}.jsonl")
        with open(path, "w", encoding="utf-8") as f:
            for r in records:
                f.write(json.dumps(r, ensure_ascii=False) + "\n")
        d = max(n_pages, 1)
        return {"edit_sim": sim_sum / d, "exact_match": exact / d}

    def _print_eval(self, m):
        print(f"[eval@{self.step}] loss {m['loss']:.4f} token_acc {m['token_acc']:.3f} "
              f"emit_acc {m['emit_acc']:.3f} special_acc {m['special_acc']:.3f} | "
              f"FREE edit_sim {m['edit_sim']:.3f} exact {m['exact_match']:.3f}")

    def train_model(self):
        n_train = sum(p.numel() for p in self.model.parameters() if p.requires_grad)
        n_total = sum(p.numel() for p in self.model.parameters())
        print(f"trainable {n_train/1e6:.2f}M / {n_total/1e6:.2f}M | "
              f"steps/epoch {self.steps_per_epoch} | total {self.total_steps}")
        for epoch in range(self.start_epoch, self.args.epochs):
            self.train_epoch(epoch)
            if self.val_loader is not None:
                m = self.eval_epoch(tag=f"epoch{epoch}")
                self._print_eval(m)
                self._maybe_save_best(m["edit_sim"], epoch)
            self._save(os.path.join(self.args.output_dir, "last.pt"), epoch + 1)
        print("done.")

    @torch.no_grad()
    def eval_model(self, ckpt=None):
        if ckpt:
            self._load(ckpt)
        if self.val_loader is None:
            raise ValueError("eval_model requires a validation loader")
        m = self.eval_epoch(tag="eval_model")
        self._print_eval(m)
        return m

    def _maybe_save_best(self, edit_sim, epoch):
        if edit_sim > self.best:
            self.best = edit_sim
            self._save(os.path.join(self.args.output_dir, "best.pt"), epoch + 1)
            print(f"  saved best (edit_sim {self.best:.4f})")

    def _save(self, path, epoch):
        os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
        torch.save({"model": self.model.state_dict(), "optimizer": self.optimizer.state_dict(),
                    "scheduler": self.scheduler.state_dict(), "scaler": self.scaler.state_dict(),
                    "step": self.step, "epoch": epoch, "best": self.best}, path)

    def _load(self, path):
        ck = torch.load(path, map_location=self.device)
        self.model.load_state_dict(ck["model"])
        self.optimizer.load_state_dict(ck["optimizer"])
        self.scheduler.load_state_dict(ck["scheduler"])
        self.scaler.load_state_dict(ck["scaler"])
        self.step, self.start_epoch, self.best = ck["step"], ck["epoch"], ck["best"]
        print(f"resumed from {path} @ step {self.step}, epoch {self.start_epoch}")


# --------------------------------------------------------------------------- #
# CLI
# --------------------------------------------------------------------------- #
@click.command(context_settings={"show_default": True})
@click.option("--train-parquet", type=click.Path(), default=None)
@click.option("--test-parquet", type=click.Path(), default=None)
@click.option("--pdf-dir", type=click.Path(), default=None)
@click.option("--backbone", default="docling-project/docling-layout-heron")
@click.option("--max-len", type=int, default=2048)
@click.option("--max-boxes", type=int, default=None)
@click.option("--epochs", type=int, default=15)
@click.option("--batch-size", type=int, default=16)
@click.option("--grad-accum", type=int, default=1)
@click.option("--lr", type=float, default=3e-4, help="LR for new modules")
@click.option("--backbone-lr", type=float, default=3e-5, help="LR for rt-detr (unused when frozen)")
@click.option("--weight-decay", type=float, default=0.01)
@click.option("--warmup-steps", type=int, default=500)
@click.option("--min-lr-ratio", type=float, default=0.05)
@click.option("--grad-clip", type=float, default=1.0)
@click.option("--dropout", type=float, default=0.1)
@click.option("--freeze-encoder", is_flag=True, help="freeze the H_box path (Stage-2 default)")
@click.option("--init-encoder-from", type=click.Path(), default=None,
              help="load the shared box-encoder from a Phase-1 ordering checkpoint")
@click.option("--num-workers", type=int, default=8)
@click.option("--device", default="cuda" if torch.cuda.is_available() else "cpu")
@click.option("--no-amp", is_flag=True)
@click.option("--seed", type=int, default=42)
@click.option("--output-dir", type=click.Path(), default="./runs/md_frozen")
@click.option("--resume", type=click.Path(), default=None, help="resume FULL training state")
@click.option("--init-from", type=click.Path(), default=None, help="load ONLY model weights")
@click.option("--eval-only", is_flag=True)
@click.option("--log-every", type=int, default=20)
@click.option("--eval-steps", type=int, default=0, help="eval every N steps (0 = epoch end only)")
@click.option("--num-eval-samples", type=int, default=25)
@click.option("--max-gen-tokens", type=int, default=1024)
@click.option("--smoke", is_flag=True)
def main(**kwargs):
    args = SimpleNamespace(**kwargs)

    if args.smoke:
        args.epochs = 2 if args.epochs == 15 else args.epochs
        args.batch_size, args.grad_accum, args.num_workers = 2, 2, 0
        args.warmup_steps, args.log_every = 2, 1
        args.eval_steps, args.num_eval_samples, args.max_gen_tokens = 4, 4, 40
        args.output_dir = "./runs/md_smoke"
    elif not args.eval_only and not (args.train_parquet and args.pdf_dir):
        raise click.UsageError("--train-parquet and --pdf-dir are required (or use --smoke)")
    if args.init_encoder_from and (args.init_from or args.resume):
        raise click.UsageError("--init-encoder-from is mutually exclusive with --init-from and --resume")

    torch.manual_seed(args.seed)
    device = torch.device(args.device)
    print(f"device={device}  smoke={args.smoke}")

    model, cfg = build_model(args, device)
    if args.init_encoder_from:
        _init_encoder_from_checkpoint(model, args.init_encoder_from, device)
    if args.init_from:
        _init_from_checkpoint(model, args.init_from, device)
    train_loader, val_loader = build_dataloaders(args)
    trainer = Stage2Trainer(model, train_loader, val_loader, cfg, args, device)

    if args.eval_only:
        trainer.eval_model(ckpt=args.resume)
    else:
        trainer.train_model()


if __name__ == "__main__":
    main()
