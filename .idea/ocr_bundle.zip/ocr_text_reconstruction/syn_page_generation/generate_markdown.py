#!/usr/bin/env python3
"""
generate_markdown.py — convert every PDF page in a corpus to Markdown via one
or more vLLM endpoints, with page-level resume.

Design (work-stealing over heterogeneous endpoints):

    task list (resume-filtered) -> RasterPool (jpg) -> bounded page queue
        -> per-endpoint async worker pools, each sized to that endpoint's
           saturation concurrency (faster endpoints simply pull more pages)
        -> single writer appends results_*.jsonl (a written line IS the
           checkpoint; rerunning the same command resumes)

Usage:
    python generate_markdown.py --pdf-dir /data/pdfs --out-dir md_out \
        --endpoint http://l40s-1:8000/v1=192 \
        --endpoint http://l40s-2:8000/v1=192 \
        --endpoint http://a10:8000/v1=96 \
        --endpoint http://a10:8001/v1=96

Failure handling:
  - per-page errors (timeout / 5xx): retried --retries times with backoff,
    then recorded in failures_*.jsonl; failed pages are NOT marked done, so
    a rerun retries them
  - endpoint down (connection refused/reset): its in-flight pages migrate
    back to the queue for the other endpoints; a probe polls the endpoint
    and its workers rejoin when it recovers. The job only stalls if EVERY
    endpoint is down (status line shows DOWN) — Ctrl-C and rerun to resume.
  - Ctrl-C / crash: safe; rerun to resume from the results shards

Outputs (in --out-dir):
    manifest.jsonl     cached page counts per PDF (rebuilt incrementally)
    results_*.jsonl    one line per finished page: markdown + usage stats
    failures_*.jsonl   pages that exhausted retries, with the error
"""

from __future__ import annotations

import asyncio
import base64
import json
import threading
import time
import traceback
from collections import deque
from dataclasses import dataclass
from pathlib import Path
from urllib.parse import urlparse

import click
import httpx
import openai
import pymupdf
from openai import AsyncOpenAI

from raster_pool import RasterPool

DEFAULT_PROMPT = """Convert this document page to clean Markdown.
- Preserve the reading order, headings, lists, and tables.
- Use Markdown table syntax for tables.
- Transcribe all visible text exactly; do not summarize, translate, or add commentary.
- Output only the Markdown for the page, nothing else."""

PROBE_INTERVAL_S = 15


def build_messages(prompt: str, jpg: bytes) -> list[dict]:
    # Text first, image second: the instruction is identical across requests,
    # so vLLM's prefix cache computes it once for the whole job.
    b64 = base64.b64encode(jpg).decode()
    return [{
        "role": "user",
        "content": [
            {"type": "text", "text": prompt},
            {"type": "image_url",
             "image_url": {"url": f"data:image/jpeg;base64,{b64}"}},
        ],
    }]


# ----------------------------------------------------------------------------
# Task enumeration and resume
# ----------------------------------------------------------------------------

def load_manifest(pdf_dir: Path, out_dir: Path) -> dict[str, int]:
    """rel_posix_path -> page_count, cached in manifest.jsonl across runs."""
    manifest_path = out_dir / "manifest.jsonl"
    known: dict[str, int] = {}
    if manifest_path.exists():
        with manifest_path.open(encoding="utf-8-sig") as f:
            for line in f:
                try:
                    rec = json.loads(line)
                    known[rec["pdf"]] = rec["pages"]
                except (json.JSONDecodeError, KeyError):
                    continue  # torn last line from a crash

    on_disk = {p.relative_to(pdf_dir).as_posix(): p
               for p in sorted(pdf_dir.rglob("*.pdf"))}
    new = [rel for rel in on_disk if rel not in known]
    if new:
        click.echo(f"counting pages in {len(new)} new PDFs...")
        with manifest_path.open("a", encoding="utf-8") as f:
            for i, rel in enumerate(new, 1):
                try:
                    with pymupdf.open(on_disk[rel]) as d:
                        n = d.page_count
                except Exception as e:
                    click.echo(f"\n  skipping unreadable {rel}: {e}")
                    continue
                known[rel] = n
                f.write(json.dumps({"pdf": rel, "pages": n}) + "\n")
                if i % 200 == 0 or i == len(new):
                    click.echo(f"\r  {i}/{len(new)}", nl=False)
        click.echo()
    # ignore manifest entries whose files have vanished
    return {rel: n for rel, n in known.items() if rel in on_disk}


def load_done(out_dir: Path) -> set[tuple[str, int]]:
    done: set[tuple[str, int]] = set()
    for shard in sorted(out_dir.glob("results_*.jsonl")):
        with shard.open(encoding="utf-8-sig") as f:
            for line in f:
                try:
                    rec = json.loads(line)
                    done.add((rec["pdf"], rec["page_no"]))
                except (json.JSONDecodeError, KeyError):
                    continue  # torn last line from a crash
    return done


# ----------------------------------------------------------------------------
# Endpoints and workers
# ----------------------------------------------------------------------------

class EndpointDown(Exception):
    pass


@dataclass(slots=True)
class PageItem:
    rel: str
    page_no: int
    jpg: bytes


@dataclass(slots=True)
class Sampling:
    """Qwen3 non-thinking general-task defaults; see --help to override."""
    temperature: float
    top_p: float
    top_k: int
    min_p: float
    presence_penalty: float
    thinking: bool


class Endpoint:
    def __init__(self, url: str, concurrency: int, api_key: str,
                 timeout: float, model: str | None):
        self.url = url
        self.name = urlparse(url).netloc
        self.concurrency = concurrency
        self.model = model
        self.timeout = timeout
        self.http_client = httpx.AsyncClient(
            limits=httpx.Limits(max_connections=concurrency + 8,
                                max_keepalive_connections=concurrency + 8),
            timeout=httpx.Timeout(timeout, connect=30),
        )
        self.client = AsyncOpenAI(base_url=url, api_key=api_key,
                                  http_client=self.http_client, max_retries=0)
        self.ok = asyncio.Event()
        self.ok.set()
        self._probe_lock = asyncio.Lock()
        self.done = 0
        self.failed = 0
        self.in_flight = 0
        self.outages = 0
        self.requeues: set[asyncio.Task] = set()

    async def pause_and_probe(self) -> None:
        """First caller probes until the server answers; the rest wait."""
        self.ok.clear()
        async with self._probe_lock:
            if self.ok.is_set():
                return
            self.outages += 1
            click.echo(f"\n[{self.name}] connection lost, probing every "
                       f"{PROBE_INTERVAL_S}s...")
            while True:
                try:
                    await self.client.models.list()
                    break
                except Exception:
                    await asyncio.sleep(PROBE_INTERVAL_S)
            click.echo(f"\n[{self.name}] back up")
            self.ok.set()

    async def close(self) -> None:
        await self.http_client.aclose()


async def call_endpoint(ep: Endpoint, item: PageItem, prompt: str,
                        max_tokens: int, retries: int,
                        sampling: Sampling) -> dict:
    """One page -> result record. Raises EndpointDown on connection failure."""
    last_err = "unknown"
    for attempt in range(retries):
        t0 = time.perf_counter()
        try:
            resp = await ep.client.chat.completions.create(
                model=ep.model,
                messages=build_messages(prompt, item.jpg),
                max_tokens=max_tokens,
                temperature=sampling.temperature,
                top_p=sampling.top_p,
                presence_penalty=sampling.presence_penalty,
                extra_body={
                    "top_k": sampling.top_k,
                    "min_p": sampling.min_p,
                    "chat_template_kwargs":
                        {"enable_thinking": sampling.thinking},
                },
            )
            choice = resp.choices[0]
            return {
                "ok": True,
                "pdf": item.rel,
                "page_no": item.page_no,
                "markdown": choice.message.content,
                "finish_reason": choice.finish_reason,
                "prompt_tokens": resp.usage.prompt_tokens,
                "completion_tokens": resp.usage.completion_tokens,
                "latency_s": round(time.perf_counter() - t0, 2),
                "endpoint": ep.name,
            }
        except openai.APITimeoutError:
            last_err = f"timeout after {ep.timeout}s"
        except openai.APIConnectionError as e:
            raise EndpointDown() from e
        except openai.APIStatusError as e:
            last_err = f"HTTP {e.status_code}: {e}"[:300]
            if 400 <= e.status_code < 500 and e.status_code != 429:
                break  # malformed request; retrying cannot help
        except Exception as e:
            last_err = f"{type(e).__name__}: {e}"[:300]
        if attempt < retries - 1:
            await asyncio.sleep(min(60, 5 * 2 ** attempt))
    return {"ok": False, "pdf": item.rel, "page_no": item.page_no,
            "error": last_err, "endpoint": ep.name}


async def worker(ep: Endpoint, page_q: asyncio.Queue, result_q: asyncio.Queue,
                 prompt: str, max_tokens: int, retries: int,
                 sampling: Sampling) -> None:
    item: PageItem | None = None
    while True:
        await ep.ok.wait()
        if item is None:
            item = await page_q.get()
        ep.in_flight += 1
        try:
            rec = await call_endpoint(ep, item, prompt, max_tokens, retries,
                                      sampling)
        except EndpointDown:
            ep.in_flight -= 1
            # Migrate the page to the healthy endpoints. The put must be
            # detached: the producer keeps the queue full, so a blocking put
            # here would strand the page on this dead endpoint (and could
            # deadlock the fleet if every endpoint went down at once).
            t = asyncio.create_task(page_q.put(item))
            ep.requeues.add(t)
            t.add_done_callback(ep.requeues.discard)
            item = None
            await ep.pause_and_probe()
            continue
        ep.in_flight -= 1
        ep.done += rec["ok"]
        ep.failed += not rec["ok"]
        await result_q.put(rec)
        item = None


# ----------------------------------------------------------------------------
# Producer (rasterization thread), writer, status
# ----------------------------------------------------------------------------

def produce(tasks: list[tuple[str, int]], pdf_dir: Path, dpi: int,
            max_pixels: int | None, loop: asyncio.AbstractEventLoop,
            page_q: asyncio.Queue, result_q: asyncio.Queue) -> None:
    """Runs in a thread; blocks on the bounded queue -> flat memory."""
    abs_to_rel = {str(pdf_dir / rel): rel for rel in {r for r, _ in tasks}}
    abs_tasks = ((str(pdf_dir / rel), pno) for rel, pno in tasks)

    def submit(coro):
        asyncio.run_coroutine_threadsafe(coro, loop).result()

    try:
        with RasterPool() as pool:
            for batch in pool.iter_tasks(abs_tasks, batch_size=32, dpi=dpi,
                                         encode="jpg", max_pixels=max_pixels):
                for pg in batch:
                    rel = abs_to_rel[pg.pdf_path]
                    if pg.ok:
                        submit(page_q.put(PageItem(rel, pg.page_no, pg.jpg)))
                    else:
                        submit(result_q.put({
                            "ok": False, "pdf": rel, "page_no": pg.page_no,
                            "error": f"render: {pg.error}", "endpoint": "raster",
                        }))
    except Exception:
        click.echo("\nFATAL: rasterization producer crashed — the job will "
                   "stall; Ctrl-C and rerun to resume\n" + traceback.format_exc())


class Stats:
    def __init__(self, total: int):
        self.total = total
        self.remaining = total
        self.ok = 0
        self.failed = 0
        self.completions: deque[float] = deque(maxlen=200)
        self.done_event = asyncio.Event()
        self.t0 = time.time()

    @property
    def rate(self) -> float:
        if len(self.completions) < 2:
            return 0.0
        span = self.completions[-1] - self.completions[0]
        return (len(self.completions) - 1) / span if span > 0 else 0.0


async def writer_loop(result_q: asyncio.Queue, out_dir: Path,
                      stats: Stats) -> None:
    stamp = time.strftime("%Y%m%d_%H%M%S")
    res_f = (out_dir / f"results_{stamp}.jsonl").open("a", encoding="utf-8")
    fail_f = None
    try:
        while True:
            rec = await result_q.get()
            if rec.pop("ok"):
                res_f.write(json.dumps(rec, ensure_ascii=False) + "\n")
                res_f.flush()
                stats.ok += 1
            else:
                if fail_f is None:
                    fail_f = (out_dir / f"failures_{stamp}.jsonl").open(
                        "a", encoding="utf-8")
                fail_f.write(json.dumps(rec, ensure_ascii=False) + "\n")
                fail_f.flush()
                stats.failed += 1
            stats.completions.append(time.time())
            stats.remaining -= 1
            if stats.remaining <= 0:
                stats.done_event.set()
    finally:
        res_f.close()
        if fail_f is not None:
            fail_f.close()


async def status_loop(stats: Stats, endpoints: list[Endpoint],
                      page_q: asyncio.Queue, interval: float) -> None:
    while True:
        await asyncio.sleep(interval)
        done = stats.ok + stats.failed
        rate = stats.rate
        eta = f"{stats.remaining / rate / 3600:.1f}h" if rate else "?"
        ep_bits = " | ".join(
            f"{ep.name}{' DOWN' if not ep.ok.is_set() else ''} "
            f"{ep.in_flight}infl {ep.done}ok"
            for ep in endpoints)
        click.echo(f"{done}/{stats.total} | {rate:.2f} p/s | ETA {eta} | "
                   f"fail {stats.failed} | q {page_q.qsize()} | {ep_bits}")


# ----------------------------------------------------------------------------
# Orchestration
# ----------------------------------------------------------------------------

async def run_job(tasks: list[tuple[str, int]], pdf_dir: Path, out_dir: Path,
                  endpoint_specs: list[tuple[str, int]], model: str | None,
                  api_key: str, prompt: str, dpi: int, max_pixels: int | None,
                  max_tokens: int, sampling: Sampling, timeout: float,
                  retries: int, status_interval: float) -> Stats:
    endpoints = [Endpoint(url, conc, api_key, timeout, model)
                 for url, conc in endpoint_specs]
    for ep in endpoints:
        try:
            models = await ep.client.models.list()
        except Exception as e:
            raise click.ClickException(f"cannot reach {ep.url}: {e}")
        if ep.model is None:
            ep.model = models.data[0].id
        click.echo(f"  {ep.name}: model={ep.model} concurrency={ep.concurrency}")

    total_conc = sum(ep.concurrency for ep in endpoints)
    page_q: asyncio.Queue = asyncio.Queue(maxsize=2 * total_conc)
    result_q: asyncio.Queue = asyncio.Queue()
    stats = Stats(len(tasks))

    loop = asyncio.get_running_loop()
    threading.Thread(target=produce,
                     args=(tasks, pdf_dir, dpi, max_pixels, loop, page_q,
                           result_q),
                     daemon=True).start()

    workers = [asyncio.create_task(
                   worker(ep, page_q, result_q, prompt, max_tokens, retries,
                          sampling))
               for ep in endpoints for _ in range(ep.concurrency)]
    writer = asyncio.create_task(writer_loop(result_q, out_dir, stats))
    status = asyncio.create_task(
        status_loop(stats, endpoints, page_q, status_interval))

    await stats.done_event.wait()

    for t in (*workers, status, writer):
        t.cancel()
    await asyncio.gather(*workers, status, writer, return_exceptions=True)
    for ep in endpoints:
        await ep.close()
    return stats


def parse_endpoints(specs: tuple[str, ...]) -> list[tuple[str, int]]:
    out = []
    for spec in specs:
        url, sep, conc = spec.rpartition("=")
        if sep:
            out.append((url, int(conc)))
        else:
            out.append((spec, 128))
    return out


@click.command()
@click.option("--pdf-dir", type=click.Path(exists=True, file_okay=False, path_type=Path),
              required=True, help="Directory searched recursively for PDFs.")
@click.option("--out-dir", type=click.Path(file_okay=False, path_type=Path),
              required=True, help="Output dir; also holds the resume state.")
@click.option("--endpoint", "endpoints", multiple=True, required=True,
              help="vLLM endpoint as URL=CONCURRENCY (repeatable). "
                   "Bare URL defaults to concurrency 128.")
@click.option("--model", default=None,
              help="Served model name; default: auto-detect per endpoint.")
@click.option("--api-key", default="EMPTY", show_default=True)
@click.option("--prompt-file", type=click.Path(exists=True, dir_okay=False, path_type=Path),
              default=None, help="Text file overriding the built-in prompt.")
@click.option("--dpi", default=144, show_default=True)
@click.option("--max-pixels", default=2_359_296, show_default=True,
              help="Downscale any page render above this pixel area "
                   "(2.36M ~ 3K image tokens, ~150-dpi-equivalent for a "
                   "300-dpi A4 scan); 0 disables the cap.")
@click.option("--max-tokens", default=8192, show_default=True)
@click.option("--temperature", default=0.7, show_default=True,
              help="Qwen3 non-thinking general-task recommendation.")
@click.option("--top-p", default=0.8, show_default=True)
@click.option("--top-k", default=20, show_default=True)
@click.option("--min-p", default=0.0, show_default=True)
@click.option("--presence-penalty", default=1.5, show_default=True,
              help="Qwen recommends 1.5; consider 0 if verbatim repetition "
                   "(dense tables) looks degraded on a smoke run.")
@click.option("--thinking/--no-thinking", default=False, show_default=True,
              help="Sets enable_thinking in the chat template per request.")
@click.option("--timeout", default=900.0, show_default=True,
              help="Per-request timeout in seconds.")
@click.option("--retries", default=3, show_default=True,
              help="Attempts per page before it goes to failures_*.jsonl.")
@click.option("--status-interval", default=15.0, show_default=True)
def main(pdf_dir: Path, out_dir: Path, endpoints: tuple[str, ...],
         model: str | None, api_key: str, prompt_file: Path | None,
         dpi: int, max_pixels: int, max_tokens: int, temperature: float,
         top_p: float, top_k: int, min_p: float, presence_penalty: float,
         thinking: bool, timeout: float, retries: int,
         status_interval: float):
    """Generate per-page Markdown for a PDF corpus via vLLM endpoints."""
    out_dir.mkdir(parents=True, exist_ok=True)
    endpoint_specs = parse_endpoints(endpoints)
    prompt = (prompt_file.read_text(encoding="utf-8")
              if prompt_file else DEFAULT_PROMPT)

    manifest = load_manifest(pdf_dir, out_dir)
    total = sum(manifest.values())
    done = load_done(out_dir)
    tasks = [(rel, i) for rel, n in manifest.items()
             for i in range(n) if (rel, i) not in done]
    click.echo(f"{total} pages in corpus | {len(done)} already done | "
               f"{len(tasks)} to go")
    if not tasks:
        click.echo("nothing to do")
        return

    sampling = Sampling(temperature, top_p, top_k, min_p, presence_penalty,
                        thinking)
    click.echo(f"sampling: temp={temperature} top_p={top_p} top_k={top_k} "
               f"min_p={min_p} presence={presence_penalty} "
               f"thinking={thinking}")
    try:
        stats = asyncio.run(run_job(
            tasks, pdf_dir, out_dir, endpoint_specs, model, api_key, prompt,
            dpi, max_pixels or None, max_tokens, sampling, timeout, retries,
            status_interval))
    except KeyboardInterrupt:
        click.echo("\ninterrupted — progress is saved; "
                   "rerun the same command to resume")
        return

    hours = (time.time() - stats.t0) / 3600
    click.echo(f"\ndone: {stats.ok} pages ok, {stats.failed} failed "
               f"in {hours:.2f} h")
    if stats.failed:
        click.echo("failed pages are in failures_*.jsonl; "
                   "rerun the same command to retry them")


if __name__ == "__main__":
    main()
