import sys
import click
from pathlib import Path

from docling_lite.core.datamodels import Device, DType, JobConfig
from docling_lite.pipeline import ProcessingPipeline
from docling_lite.core.logging import logger

@click.command()
@click.option(
    "--ocr-df-path",
    type=click.Path(exists=True, dir_okay=False, path_type=Path),
    required=True,
)
@click.option(
    "--raster-dir",
    type=click.Path(exists=True, file_okay=False, path_type=Path),
    required=True,
    help="Directory produced by `docling_lite.cli.rasterize` (must contain index.parquet).",
)
@click.option(
    "--layout-batch-size",
    type=int,
    default=128,
)
@click.option(
    "--layout-model-path",
    type=str,
    required=True,
    help="Model path for layout detection. Can be a Hugging Face model or a local directory containing the model files.",
)
@click.option(
    "--table-batch-size",
    type=int,
    default = 64,
)
@click.option(
    "--table-model-path",
    type=str,
    required=True,
    help="Model path for table structure extraction. Can be a Hugging Face model or a local directory containing the model files.",
)
@click.option(
    "--device",
    type=click.Choice(Device, case_sensitive=False),
    default=Device.GPU,
)
@click.option(
    "--dtype",
    type=click.Choice(DType, case_sensitive=False),
    default=DType.FULL_FP_32,
)
@click.option(
    "--output-dir",
    type=click.Path(file_okay=False, path_type=Path),
    required=True,
)
@click.option(
    "--batch-name",
    type=str,
    required=True,
)

def main(
    ocr_df_path: Path,
    raster_dir: Path,
    layout_batch_size: int,
    layout_model_path: str,
    table_batch_size: int,
    table_model_path: str,
    device: Device,
    dtype: DType,
    output_dir: Path,
    batch_name: str,
):
    output_dir.mkdir(parents=True, exist_ok=True)

    try:

        job_config = JobConfig(
            ocr_df_path=ocr_df_path,
            raster_dir=raster_dir,
            layout_batch_size=layout_batch_size,
            layout_model_name_or_path=layout_model_path,
            table_batch_size=table_batch_size,
            table_model_name_or_path=table_model_path,
            device=device,
            dtype=dtype,
            output_dir=output_dir,
            batch_name=batch_name,
        )

        pipeline = ProcessingPipeline(job_config)
        success = pipeline.run()

        if not success:
            logger.error("Processing pipeline failed.")
            sys.exit(1)
        
        logger.success("Processing pipeline completed successfully.")
        sys.exit(0)

    except Exception as exc:
        logger.exception(f"CLI Failed : {exc}")
        sys.exit(1)

if __name__ == "__main__":
    main()

