import json,torch
from transformers import AutoModelForSequenceClassification
from validate import dense_inputs,metrics
from pathlib import Path
torch.set_num_threads(8)
data=torch.load('data/tokenized.pt',weights_only=True)
scores=torch.load('results/full_scores.pt',weights_only=True)[:4].cuda()
report={}
for dtype in [torch.bfloat16,torch.float32]:
 model=AutoModelForSequenceClassification.from_pretrained('models/benchmark-cls',dtype=dtype,attn_implementation='sdpa').eval().cuda()
 outputs=[]
 with torch.inference_mode():
  for i in range(0,200,16):
   inp,_=dense_inputs(data,list(range(i,min(i+16,200))),64,shift=False)
   outputs.append(model(**inp).logits.flatten())
 report[str(dtype)]=metrics(scores,torch.cat(outputs).reshape(4,50))
 del model;torch.cuda.empty_cache()
Path('results/full_score_validation.json').write_text(json.dumps(report,indent=2))
print(report)
