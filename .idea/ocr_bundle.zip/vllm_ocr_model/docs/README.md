# vllm_ocr_model documentation

This package serves the two-stage OCR reconstruction model (v0.1: RT-DETR box encoder →
reading-order decoder → markdown formatter) with vLLM. It takes PDFs plus their Textract
OCR results and writes markdown for every page, at roughly 30× the throughput of the
PyTorch implementation it was ported from.

| Document | Read it when you want to… |
|---|---|
| [usage.md](usage.md) | build the image, prepare inputs, run it, read the outputs |
| [architecture.md](architecture.md) | understand how the model was ported to vLLM and why it is shaped this way |
| [performance.md](performance.md) | see the benchmark numbers and the tuning history, or tune a new machine |
| [validation.md](validation.md) | know what was tested, how, and what still needs checking with the trained weights |
| [development.md](development.md) | change the code, upgrade vLLM, change the vocab, or troubleshoot |

## At a glance

- **Input:** a directory of PDFs, plus a Textract OCR dataframe with columns `file_name`,
  `page`, `content` and `line_cords`, and the training checkpoint(s).
- **Output:** one markdown file per page, `results.jsonl`, `results.parquet` and
  `summary.json`.
- **Run:**
  ```bash
  make build
  make run PDF_DIR=/data/pdfs OCR_DF=/data/textract.parquet MODEL=/models/best.pt OUT_DIR=/data/out
  ```
- **Throughput (1× L40S, bf16, ~300 OCR lines per page):**

  | Measurement | pages/s |
  |---|---:|
  | Model only | ~79.5 |
  | End to end, including PDF rendering | ~60–70 |
  | Original PyTorch `generate_end_to_end` | 2.36 |

- **Correctness:** in strict fp32 the reading order and markdown token stream match the
  PyTorch reference token for token, except at floating-point near-ties. The markdown text
  matches the training tokenizer's `decode` on 2,796/2,796 pages.
- **Not yet verified:** quality with the *trained* weights, which were not available during
  development (only random weights were used), and the Docker build itself. The
  development machine could not run Docker; `make selftest` covers both on the target host.

## History in one paragraph

The PyTorch model decoded one token per step for the whole batch, and its order decoder
had no KV cache, which gave about 2.4 pages/s. vLLM was chosen for continuous batching,
paged KV caches and CUDA graphs. vLLM gives a model no memory per request, and this model
needs a lot of per-page state: the page's box features, which boxes are already placed,
and the formatter's cursor. The port therefore stores all of that inside vLLM-managed KV
caches and reads it with small custom Triton kernels. Profiling then led through a series
of fixes, measured on 2 or 4 engine processes:

| Change | Result |
|---|---|
| Kernel replacing a 16 ms attention call | 6 → 7.7 pages/s |
| KV-cache groups reduced from 29 to 2 | → 12.5 pages/s |
| bf16 + wave admission | → 22 pages/s |
| Several engines sharing the GPU under CUDA MPS | → 45 pages/s |
| Thread pools pinned to fit the container's 15-core CPU quota | → 63 pages/s |
| Compiled encoder in chunks of 8 images | → 79.5 pages/s |

[performance.md](performance.md) has the full story.
