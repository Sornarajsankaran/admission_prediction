"""
Compare decoded outputs of two backends (json dumps from ``bench.py ... --dump``).

Reports, over pages: exact-match rate of the reading order and of the formatter
stream, where the first divergence happens, and normalized edit similarity (1.0 =
identical) -- the same metric the training scripts use for the formatter.

    python compare_outputs.py ref.json vllm.json
"""

from __future__ import annotations

import json

import click
import numpy as np


def edit_similarity(a, b) -> float:
    """1 - Levenshtein(a, b) / max(len); O(len^2) DP, fine for ~1k-token pages."""
    if not a and not b:
        return 1.0
    prev = list(range(len(b) + 1))
    for i, x in enumerate(a, 1):
        cur = [i] + [0] * len(b)
        for j, y in enumerate(b, 1):
            cur[j] = min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + (x != y))
        prev = cur
    return 1.0 - prev[-1] / max(len(a), len(b))


def first_diff(a, b):
    for i, (x, y) in enumerate(zip(a, b)):
        if x != y:
            return i
    return None if len(a) == len(b) else min(len(a), len(b))


@click.command()
@click.argument("ref_json")
@click.argument("other_json")
def main(ref_json, other_json):
    ref, other = json.load(open(ref_json)), json.load(open(other_json))
    n = min(len(ref), len(other))
    def strip_eos(x):  # capped pages end without EOS in the reference, with EOS in vLLM
        return x[:-1] if x and x[-1] == 1 else x

    rows = []
    for a, b in zip(ref[:n], other[:n]):
        a, b = dict(a, fmt=strip_eos(a["fmt"])), dict(b, fmt=strip_eos(b["fmt"]))
        rows.append({
            "order_exact": a["order"] == b["order"],
            "fmt_exact": a["fmt"] == b["fmt"],
            "order_first_diff_frac": (first_diff(a["order"], b["order"]) or len(a["order"])) / max(len(a["order"]), 1),
            "order_sim": edit_similarity(a["order"], b["order"]),
            "fmt_sim": edit_similarity(a["fmt"], b["fmt"]),
        })
    agg = {k: float(np.mean([r[k] for r in rows])) for k in rows[0]}
    print(json.dumps({"pages": n, **{k: round(v, 4) for k, v in agg.items()}}))


if __name__ == "__main__":
    main()
