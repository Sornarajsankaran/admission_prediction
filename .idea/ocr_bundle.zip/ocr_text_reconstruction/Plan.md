# OCR Layout Reconstruction Model Plan

## 1. Goal

The current OCR pipeline gives text lines along with their bounding boxes. If all OCR lines are simply concatenated using `\n`, the spatial structure of the document page is lost.

This causes issues for pages that contain:

- Tables
- Multi-column layouts
- Section headers
- Key-value fields
- Lists
- Paragraph groupings
- Visual alignment-based structure

The goal is to build a custom model that reconstructs the page into a Markdown-like structured representation while preserving the original layout and formatting.

The model should not generate raw text from scratch. Instead, it should predict:

1. The index of an OCR bounding box whose text should be copied.
2. Special Markdown/layout tokens used for formatting.

This makes the task a layout-aware pointer generation problem rather than a normal text generation problem.

---

## 2. Available Data

For each page, we have:

```python
page_image
ocr_boxes = (B, N, 4)  # x1, y1, x2, y2
ocr_texts = (B, N)     # text corresponding to each OCR box
```

Where:

- `B` is the batch size.
- `N` is the number of OCR-detected boxes/lines in a page.
- `4` represents the bounding box coordinates: `x1, y1, x2, y2`.

In addition, for around 20K pages, a strong VLM has generated Markdown text for each page. This VLM-generated Markdown will be used as pseudo-ground-truth for training the custom model.

---

## 3. Output Representation

The model output is a sequence of token IDs.

However, the output vocabulary is not a normal fixed text vocabulary. It is a combination of:

```text
Dynamic OCR box tokens + Fixed special Markdown tokens
```

For a given page, the dynamic vocabulary is:

```text
[OCR_BOX_0, OCR_BOX_1, OCR_BOX_2, ..., OCR_BOX_N-1]
```

The fixed special tokens include Markdown/layout tokens such as:

```text
#
##
###
|
-
*
:
.
,
(
)
\n
<PAD>
<BOS>
<EOS>
<UNK>
```

A conceptual output may look like:

```text
# OCR_BOX_3 \n OCR_BOX_4 \n | OCR_BOX_7 | OCR_BOX_8 | \n ...
```

During decoding:

- If the model predicts `OCR_BOX_3`, we copy the text from the third OCR box.
- If the model predicts `|`, `#`, or `\n`, we insert that formatting token directly.

So the model learns:

- Reading order
- Table structure
- Markdown formatting
- Section hierarchy
- Spatial grouping

It does not learn to generate OCR text itself.

---

## 4. Backbone Choice

Training this model from scratch is not feasible because the available pseudo-ground-truth dataset has only around 20K pages.

So the plan is to reuse a pretrained document-layout model as the backbone.

The proposed backbone is:

```text
Layout-Heron / RT-DETR-v2
```

Layout-Heron is useful because it is already trained for document layout detection. It takes a page image as input and predicts layout bounding boxes with layout labels such as table, title, paragraph, figure, list, etc.

Although its original task is different, it has already learned strong document-layout representations. This makes it a good starting point for our task.

---

## 5. Original DETR-style Architecture

A DETR-style object detection model works roughly as follows:

```text
Page Image
   ↓
CNN / visual backbone
   ↓
Transformer encoder
   ↓
Learned object queries
   ↓
Transformer decoder
   ↓
Class head + bounding box head
```

The learned object queries are static trainable vectors. They attend to the encoded image features and try to detect objects or layout regions.

The decoder output is then passed to:

1. A classification head to predict the object/layout class.
2. A bounding box regression head to predict the object coordinates.

For example, the original model may predict:

```text
box_1 → table
box_2 → title
box_3 → paragraph
```

---

## 6. Key Modification for Our Task

In the original DETR setup, object queries are learned static embeddings.

In our task, we already have OCR bounding boxes. Therefore, we do not need the model to discover boxes from scratch.

Instead of learned static object queries, we will use OCR-box-conditioned queries.

For each OCR box:

```python
bbox_i = [x1, y1, x2, y2]
```

We pass the coordinates through a small MLP:

```python
q_i = BBoxMLP(bbox_i)  # 4 → d_model
```

This converts every OCR bounding box into a query vector:

```python
ocr_queries = (B, N, d_model)
```

These OCR-box queries are passed into the RT-DETR-v2 decoder and cross-attend to the visual encoder features from the page image.

Conceptually:

```text
OCR bbox query
   attends to
page image encoder features
   produces
layout-aware OCR box representation
```

This gives one enriched hidden representation for every OCR box.

---

## 7. OCR Box Representation Module

After the OCR-box-conditioned queries attend to image features, we get:

```python
H_box = (B, N, d_model)
```

Each vector in `H_box` represents one OCR box, enriched with:

- Its coordinate information
- Local visual context
- Page-level layout context
- Nearby text/layout relationships
- Table/section/paragraph cues learned by the pretrained backbone

For example, the model may learn that:

- A line is inside a table header.
- A line belongs to a table cell.
- A line is a section heading.
- A line is part of a paragraph.
- A line is visually aligned with another line.
- A line should appear before or after another line in reading order.

This module acts as the OCR block encoder.

---

## 8. Autoregressive Markdown Decoder

The output sequence needs to be generated step by step. Therefore, on top of the OCR box representations, we add an autoregressive Transformer decoder.

The decoder receives previous output tokens and attends to `H_box`.

```text
Previous output tokens
        ↓
Autoregressive Transformer decoder
        ↓
Decoder hidden state at step t
        ↓
Pointer head + Markdown token head
```

At each decoding step, the decoder predicts either:

1. An OCR box index
2. A special Markdown token

This final decoder is responsible for learning the structured Markdown reconstruction sequence.

---

## 9. Final Prediction Head

At decoding step `t`, the autoregressive decoder produces a hidden state:

```python
h_t = (B, d_model)
```

From this hidden state, we compute two types of logits.

### 9.1 Pointer logits over OCR boxes

The model compares the current decoder hidden state with all OCR box representations:

```python
pointer_logits = h_t @ H_box.transpose(-1, -2)
```

Shape:

```python
(B, N)
```

These logits represent the score for copying each OCR box:

```text
OCR_BOX_0, OCR_BOX_1, ..., OCR_BOX_N-1
```

### 9.2 Special Markdown token logits

For fixed special tokens, we use a normal linear layer:

```python
special_logits = Linear(h_t)
```

Shape:

```python
(B, M)
```

Where `M` is the number of fixed Markdown/layout tokens.

### 9.3 Final dynamic vocabulary logits

The final logits are formed by concatenating pointer logits and special-token logits:

```python
final_logits = concat(pointer_logits, special_logits)
```

Shape:

```python
(B, N + M)
```

So for every page, the effective vocabulary is:

```text
N OCR box tokens + M fixed Markdown tokens
```

---

## 10. Training Target Creation

The VLM-generated Markdown text needs to be converted into a sequence of OCR box IDs and special tokens.

Example OCR blocks:

```python
0: "Patient Details"
1: "Name"
2: "Age"
3: "John"
4: "45"
```

Example VLM Markdown:

```markdown
# Patient Details

| Name | Age |
| John | 45 |
```

Converted training target:

```text
# OCR_BOX_0 \n \n | OCR_BOX_1 | OCR_BOX_2 | \n | OCR_BOX_3 | OCR_BOX_4 | <EOS>
```

Converted target IDs:

```python
[
  SPECIAL_HASH,
  BOX_0,
  SPECIAL_NEWLINE,
  SPECIAL_NEWLINE,
  SPECIAL_PIPE,
  BOX_1,
  SPECIAL_PIPE,
  BOX_2,
  SPECIAL_PIPE,
  SPECIAL_NEWLINE,
  SPECIAL_PIPE,
  BOX_3,
  SPECIAL_PIPE,
  BOX_4,
  SPECIAL_PIPE,
  EOS,
]
```

This alignment step is very important.

The target creation pipeline should support:

1. Exact matching between Markdown text spans and OCR text.
2. Fuzzy matching when VLM Markdown slightly differs from OCR text.
3. Markdown special-token extraction.
4. `<UNK>` fallback for unmatched text, if required.

---

## 11. Loss Function

For the first version, we can train using standard cross-entropy loss over the dynamic vocabulary.

```python
loss = CrossEntropyLoss(final_logits, target_ids)
```

Each target ID belongs to one of two groups:

```text
0 to N-1       → OCR box pointer token
N to N+M-1     → special Markdown token
```

This allows the model to learn:

```text
At this decoding step, should I copy OCR box 12 or emit "|"?
```

The first version can keep the loss simple. Additional losses can be explored later if needed.

---

## 12. Full Model Flow

```text
Input:
  - Page image
  - OCR boxes: (B, N, 4)

Step 1: Visual encoding
  - Pass page image through Layout-Heron / RT-DETR-v2 visual backbone
  - Get page-level visual encoder features

Step 2: OCR box query creation
  - Normalize OCR box coordinates
  - Pass each OCR box through BBoxMLP
  - Get OCR-box-conditioned queries: (B, N, d_model)

Step 3: OCR box representation extraction
  - Use OCR-box queries in the RT-DETR-v2 decoder
  - Cross-attend to visual encoder features
  - Get H_box: (B, N, d_model)

Step 4: Markdown sequence decoding
  - Use an autoregressive Transformer decoder
  - Decoder attends to H_box
  - Generate output sequence step by step

Step 5: Dynamic vocabulary prediction
  - Pointer head predicts OCR box index
  - Special-token head predicts Markdown token
  - Concatenate both logits
  - Train using cross-entropy
```

---

## 13. Implementation Phases

### Phase 1: Data preparation

- Collect page image, OCR boxes, and OCR text for each page.
- Collect VLM-generated Markdown for each page.
- Normalize bounding boxes to `[0, 1]` range.
- Define fixed Markdown special-token vocabulary.
- Build Markdown-to-pointer target conversion.
- Implement exact and fuzzy matching between VLM Markdown spans and OCR text.

### Phase 2: Backbone adaptation

- Load pretrained Layout-Heron / RT-DETR-v2 model.
- Identify the visual backbone and encoder outputs.
- Identify the decoder query input path.
- Replace or augment static object queries with OCR-box-conditioned queries.
- Add `BBoxMLP: 4 → d_model`.
- Verify that input OCR boxes produce `H_box = (B, N, d_model)`.

### Phase 3: Autoregressive decoder

- Add a Transformer decoder for Markdown sequence generation.
- Add embeddings for previous output tokens.
- Handle dynamic OCR-box tokens and fixed special tokens.
- Implement causal masking.
- Allow the decoder to attend to `H_box`.

### Phase 4: Output heads

- Implement pointer logits over OCR boxes.
- Implement special-token logits over fixed Markdown tokens.
- Concatenate logits into `(B, T, N + M)`.
- Mask invalid OCR positions for padded boxes.

### Phase 5: Training

- Train using cross-entropy over the dynamic vocabulary.
- Start by freezing most of the pretrained backbone.
- Train only the new modules first:
  - BBoxMLP
  - Autoregressive decoder
  - Pointer head
  - Special-token head
- Later unfreeze selected layers of the RT-DETR-v2 decoder/encoder if required.

### Phase 6: Evaluation

Evaluate both text quality and structure quality.

Possible metrics:

- Markdown exact match
- Token-level edit distance
- OCR box sequence accuracy
- Table reconstruction accuracy
- Reading-order accuracy
- Special-token accuracy
- Structural similarity between predicted Markdown and VLM Markdown

### Phase 7: Iteration

After the first working version, explore improvements such as:

- Adding OCR text embeddings along with bbox embeddings
- Adding layout-label embeddings from Layout-Heron predictions
- Adding row/column/table-specific auxiliary losses
- Improving target alignment quality
- Supporting hierarchical decoding for tables
- Fine-tuning more layers of the Layout-Heron / RT-DETR-v2 backbone

---

## 14. Initial Model Objective

The first version should focus on proving that the model can learn:

1. The correct reading order of OCR boxes.
2. Basic Markdown formatting.
3. Table-like structure using `|` and `\n`.
4. Section and heading structure using `#`, `##`, etc.
5. Copying OCR text through box-index prediction instead of text generation.

Once this works, the architecture can be expanded with more advanced layout-specific modules.

---

## 15. Core Idea Summary

The core idea is:

```text
Use Layout-Heron / RT-DETR-v2 as a pretrained visual-layout backbone.
Replace static DETR object queries with OCR-bbox-conditioned queries.
Use the resulting OCR box representations as memory for an autoregressive Markdown decoder.
Predict either an OCR box index or a Markdown special token at each decoding step.
```

This converts OCR layout reconstruction into a dynamic-vocabulary pointer generation problem.

The model does not need to learn text generation. It only needs to learn how to arrange and format already-detected OCR text blocks.

---

## 16. Reinforcement Learning Phase: Box Coverage (GRPO)

### 16.1 Why SFT (cross-entropy) is not enough

After supervised fine-tuning (Section 11, cross-entropy), evaluation showed a
specific failure: on its own free-running (greedy) decode, the model **drops OCR
boxes**. For example, a page with 120 input boxes may produce only ~100 in the
output.

The reason is exposure bias. Cross-entropy is teacher-forced: at every position
the model is fed the *correct* previous token, so each box is already supervised
at its forced position and the loss looks fine. Box drops only emerge when the
model decodes from its own predictions at inference. Fixing this needs a
**sequence-level objective** that scores the model's *own* rollout, not a
per-position teacher-forced loss.

The contract we want: **N boxes in → N boxes out**, with formatting.

### 16.2 Reward (`reward.py`)

The reward is computed purely from the model's rollout — **no gold Markdown
needed**:

```text
coverage       = distinct_boxes_emitted / N          # the thing we are fixing
duplicate_rate = (E - D) / E                          # E emitted, D distinct
reward         = w_cov * coverage - w_dup * duplicate_rate
```

It is maximised exactly when every box is emitted once and only once
(`D == E == N`). Coverage is trivial to compute because boxes are explicit
pointers — count distinct box ids emitted vs. N.

### 16.3 GRPO mechanism

GRPO (Group Relative Policy Optimization) fine-tunes the SFT checkpoint:

1. **Rollout** (`model.sample_decode`): a multinomial-sampling twin of
   `generate()` that records each token's log-prob under the temperature-1
   policy (temperature only drives exploration).
2. **Group**: each page is rolled out **K** times. The group's reward mean/std
   is the baseline — `advantage = (reward - mean) / std`. No value network.
3. **Update**: a PPO-style clipped surrogate, plus a **KL leash** to a frozen
   copy of the SFT model (the "anchor", k3 estimator). The leash is what keeps
   the policy from destroying formatting while chasing reward.
4. The policy is kept in **eval mode** (dropout off) so the sampled log-probs
   match the teacher-forced recompute (importance ratio ≈ 1 at init).

The RL dataset (`RLDataset`) feeds **all** boxes with no compaction — the same
distribution seen at inference — which also closes the train/inference mismatch
that existed in the SFT data path.

### 16.4 New components

| File | Addition |
| --- | --- |
| `reward.py` | coverage / duplicate reward (+ monitor helpers) |
| `modeling_ocr_reconstruction.py` | `sample_decode()` rollout |
| `data.py` | `RLDataset` + `rl_collate_fn` (all boxes, no targets) |
| `grpo_train.py` | `GRPOTrainer`, step-based click CLI, greedy-coverage eval |

Key knobs: `--pages-per-step` (P), `--group-size` (K), `--kl-beta`,
`--temperature`, `--clip-eps`, `--w-cov`, `--w-dup`, `--max-new-tokens`,
`--max-boxes`, `--steps`. Headline eval metric: **`frac_full`** = fraction of
pages where every box is present.

### 16.5 Result

GRPO substantially improved coverage:

```text
frac_full (pages with 100% box coverage): 37.5%  →  72%
```

The box-dropping problem is materially reduced.

### 16.6 Known issue: formatting-quality regression

The coverage gain came at a cost: **Markdown formatting quality degraded
noticeably**. This is the anticipated reward-hacking failure mode — with a
coverage-only reward, the policy is pushed to emit every box even at the expense
of reading order and structure, and the KL leash alone did not fully preserve
formatting quality.

### 16.7 Next step: add a Markdown-quality reward term

Extend the reward with a quality term so coverage cannot be bought with bad
formatting:

```text
reward = w_cov * coverage - w_dup * duplicate_rate + w_qual * quality
```

Candidate `quality` signals (to be decided):

1. **Geometry-based, no gold** — reading-order agreement (Kendall's τ between
   the emitted box order and a canonical column/top-to-bottom order), plus
   structure bonuses (large vertical gap → newline/heading, box-height → heading
   level, row/column alignment → table `|`).
2. **VLM pseudo-GT Markdown** (available for ~20K pages, Section 2/4) — sequence
   similarity / edit distance between the predicted box order and the gold
   order.
3. **VLM-as-judge**, run offline, to validate that the cheap proxy correlates
   with real quality.

Likely also retune `--kl-beta` upward. Detailed design TBD.
