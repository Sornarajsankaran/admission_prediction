# Architecture: how the model was ported to vLLM

## 1. The model being served

The v0.1 two-stage model (`ocr_text_reconstruction/scripts_v0.1/modeling_ocr_reconstruction.py`,
class `OcrTwoStageModel`):

```
page image (640x640) ─► RT-DETR-v2 (Heron) backbone + hybrid encoder
                              │ multi-scale features
OCR line boxes (K) ──► queries = boxes ──► deformable decoder ──► H_box  (K × 256)
                                                                    │
      Stage 1 — order decoder (6 layers, d=256, 8 heads)            │ cross-attention
        step t: input = norm(H_box[previous box]), pointer head     │
        = dot(state, pointer_key_proj(H_box)); already-placed       │
        boxes masked; exactly K steps  ─────────► reading order o_0..o_{K-1}
                                                                    │
      Stage 2 — markdown formatter (6 layers, d=256, 8 heads)       │ cross-attention
        vocab = 69 markdown specials + EMIT_NEXT                    │
        input = token + position + norm(H_box[o_cursor]) (hint)    │
        EMIT_NEXT places the block at the cursor and advances it;
        EOS masked until K blocks are placed, EMIT masked after ──► markdown token stream
```

Both decoders use `nn.TransformerDecoderLayer` (pre-norm, GELU). Output text is never
generated: each `EMIT_NEXT` copies an OCR line.

Sizes: encoder ~42M parameters, each decoder ~9.5M. At ~300 lines per page a page decodes
~300 order tokens and ~600–750 formatter tokens, so **~1,000 sequential decoder steps**.

## 2. Why the PyTorch version was slow

| Problem | Effect |
|---|---|
| Order decoder recomputed the whole prefix every step (no KV cache) | O(K²) per page |
| `generate_end_to_end` ran the encoder twice | 2× encoder cost |
| Static batches: a batch runs until its longest page finishes | GPU idles on short pages |
| d=256, 6 layers: each step is ~150 tiny kernels | launch-bound, not compute-bound |
| Host syncs every step (`finished.all()`, boolean indexing) | GPU pipeline stalls |

Result: 2.36 pages/s (fp32) and 2.38 (bf16 autocast). bf16 did not help because the
math was never the bottleneck.

## 3. Why vLLM is awkward for this model

vLLM gives continuous batching, a paged KV cache and CUDA graphs. But it assumes a model
is a pure function of (token ids, positions) plus attention KV caches, and this model
needs **per-page state** at every step:

| Needed each step | Where the reference keeps it |
|---|---|
| the page's H_box (box embeddings, pointer keys) | a Python tensor per batch |
| which boxes are already placed | a boolean mask updated each step |
| K (number of boxes) | `box_mask.sum()` |
| the formatter cursor and the box at the cursor | a counter + the predicted order |
| the formatter must not see order-stage tokens | separate sequences |

vLLM has no per-request tensors a model can own; requests move between batch rows,
get preempted and re-scheduled. Side tables keyed by request would break under
preemption. The design principle adopted:

> **All per-page state lives in vLLM-managed KV caches.** The model reads it back with
> (a) attention, where attention is the right operation, and (b) small custom Triton
> kernels that read the caches through vLLM's own block tables.

Anything vLLM stores, it also moves, preempts and restores correctly.

## 4. One request = one page = one token stream

Both stages run in **a single vLLM request**. The decoder token stream for a page with K
boxes:

```
ORD_BOS  BOX_o0 … BOX_o{K-1}  GAP … GAP  FMT_BOS  f_1 … f_T(=EOS)
└──────────── order stage ────────────┘  └── formatter stage ──┘
```

Token id layout (`config.py`, M = 69 specials):

| ids | token |
|---|---|
| `0 … M-1` | markdown specials (vocab.json order; bos=0, eos=1, pad=2, unk=3) |
| `M` | `EMIT_NEXT` |
| `M+1` | `ORD_BOS` (the decoder prompt) |
| `M+2` | `FMT_BOS` |
| `M+3` | `GAP` (alignment filler, §7) |
| `M+4+b` | `BOX_b`, b < 1024 |

Structural tokens are forced by the logits. `forward` returns the final masked logits
directly (`compute_logits` passes them through):
- order stage, positions < K: only unplaced real boxes are allowed;
- after K boxes: `GAP` until the next KV block boundary, then `FMT_BOS`;
- formatter stage: specials + `EMIT_NEXT`, with `EOS` masked until K blocks are placed
  and `EMIT_NEXT` masked after.

So every output is a valid permutation followed by a complete formatter stream, as in the
reference.

Greedy decoding is plain vLLM `temperature=0`. `SamplingParams` sets
`max_tokens = K + 64 + 1 + 2048`, stop on EOS, `detokenize=False` and `FINAL_ONLY` outputs.

## 5. The encoder as vLLM's multimodal encoder

- **Request format.** A page is one "image" multimodal item passed as a tensor dict:
  `{"pixel_values": uint8 (1,3,640,640), "ocr_boxes": float (1,K,4)}`. This needs
  `enable_mm_embeds=True` and a custom `MultiModalDataParser` that accepts the dict. The
  image is sent as **uint8**: the Heron processor only resizes and rescales, so
  `round(pixel_values × 255)` is lossless and 4× smaller than float32.
- **Encoder prompt.** It is K placeholder tokens (one per box), created by the
  `EncDecMultiModalProcessor` subclass with a dynamic `PromptReplacement`. So vLLM's
  cross-attention length equals K, and the model can read K from the cross-attention
  metadata's `seq_lens`.
- **No tokenizer.** The processor's `get_tokenizer()` returns `None` (the engine runs with
  `skip_tokenizer_init`). The profiling dummy inputs use token-id prompts.
- **`embed_multimodal`** runs the RT-DETR box encoder (`encoder.py`, a copy of the
  training code's `encode_boxes`, including its per-sample key-padding self-attention
  patch). It processes images in chunks of `encoder_max_batch=8` with channels-last
  layout and `torch.compile`d halves, and returns one row per box: H_box (K × 256).

## 6. Where the per-page state lives

Every attention layer is 8 heads × 32 dims. There are two layer types:

```
self-attention layers  (13)   order self_attn ×6, formatter self_attn ×6, state
cross-attention layers (13)   order cross_attn ×6, formatter cross_attn ×6, box_store
```

| Layer | Kind | Written | Holds | Read by |
|---|---|---|---|---|
| decoder `self_attn` / `cross_attn` | normal attention | by vLLM | the reference decoders' K/V | vLLM attention (exact port) |
| `box_store` | cross, write-only | on the page's first step | K = `pointer_key_proj(H_box)`, V = `norm(H_box)`, one row per box | `kernels.pointer_scores`, `kernels.gather_box_rows` |
| `state` | self, write-only | every step, for the current position | V channels `(box_id // 32, box_id % 32, is_box, is_emit)`; small integers, exact even in bf16 | `kernels.page_cursor`, `kernels.pointer_scores` |

The write-only layers are real vLLM `Attention`/`CrossAttention` modules, so vLLM
allocates, pages and frees their caches. The model writes them with the backend's
`do_kv_cache_update` and never runs attention on them.

**The kernels** (`kernels.py`, Triton; one query token per request per step always holds
here, because the prompt is one token and chunked prefill is off for encoder-decoder):
- `pointer_scores`: for each request, reads its box keys through the `box_store` block
  table and computes exact `q · key_j / √d`. It then scans the `state` cache for every
  box already placed and sets those scores, and all j ≥ K, to −∞. This is the reference
  pointer head with its used-box mask, computed exactly.
- `page_cursor`: counts `is_emit` over the request's positions (the formatter cursor) and
  reads the box id stored at position `cursor + 1` (the box placed at order step `cursor`).
  That box is the formatter's hint.
- `gather_box_rows`: reads `norm(H_box[b])` for one box per request. It serves the order
  stage's input embedding (previous box) and the formatter's hint (box at the cursor).

**K per page** is the `box_store` layer's cross-attention `seq_lens`.

## 7. Keeping the two stages apart in one sequence

Every token runs through **both** decoder stacks, and the phase (order vs formatter,
known from the token id) picks whose output counts. This keeps the forward free of
data-dependent control flow, so CUDA graphs capture it. Two problems follow, each solved
by manipulating attention metadata, not by masking tricks:

- **The unused stack must not pay.** `restrict_attention` hands a stack's layers a copy of
  their attention metadata in which requests in the *other* phase get `seq_len = 1`. Those
  rows read one KV entry instead of hundreds, and their output is discarded anyway. It is
  computed on-device, so it is captured in the CUDA graph. This halved attention traffic.
- **The formatter must not see order-stage positions.** In the reference the formatter is a
  separate sequence. Here, once the K boxes are placed, the logits force `GAP` tokens until
  the next KV block boundary (~16 tokens on average with block size 32), and then
  `FMT_BOS`. The formatter's self-attention layers then get a **block table shifted** past
  the order stage, plus shortened `seq_lens`, so they attend exactly over the formatter
  region. Formatter positions are `pos − fmt_start`, matching the reference.

## 8. Both stacks as one batched computation

Layer i of the order stack and layer i of the formatter stack have identical shapes. After
loading, `build_stacked()` makes each layer pair's dense parameters views of one
`(2, …)` tensor, with no copy. Each layer pair then runs as batched GEMMs (`baddbmm`) with
per-stack layer norms, and only the attention calls are per stack. These dense functions
and the logits assembly are `torch.compile`d (inductor) to fuse the elementwise work.
Parity with the reference was re-verified after this change.

## 9. Fitting vLLM's machinery

Things that had to be done for vLLM 0.23 specifically:

| Issue | Fix |
|---|---|
| vLLM needs a language-model submodule with `embed_input_ids` | decoder-side modules live under `self.decoder` (an `OcrDecoder`) |
| Attention layer names must contain exactly one integer | auxiliary layers are named `decoder.aux.0.<name>` |
| `max_model_len` comes from `max_position_embeddings` | config sets it to K_max + GAP + formatter length (3138); per-stage position tables are `stage_max_positions` |
| CUDA-graph capture uses `max_source_positions` as the dummy encoder length (fallback 32k overran the block tables) | config sets it to `max_boxes` |
| Triton attention sizes its split-softmax workspace from model-level `num_attention_heads`/`head_dim` | config declares the real per-layer maximum (8 × 32); a mismatch caused out-of-bounds writes |
| Per-step overhead grows with the number of KV-cache groups (29 at first) | all layers share one shape; exactly 13 self + 13 cross layers → 2 groups |
| CUDA graphs only apply to steps where no request is starting (encoder-decoder limitation) | *wave admission* in the runner (§10) |
| `ids` arrive as int32 | cast to int64 in the forward |
| fp32 mode: Triton dots default to TF32 | the plugin sets `TRITON_F32_DEFAULT=ieee` (no effect on bf16) |

**Plugin registration.** The `vllm.general_plugins` entry point (`ocr_vllm:register`)
does four things:
- registers the config with `AutoConfig`;
- registers the model with `ModelRegistry`;
- pins thread pools to one thread (see [performance.md](performance.md) §4);
- handles the `OCR_VLLM_STRICT_FP32` test switch.

It runs in every vLLM process.

## 10. The runner (`ocr-vllm-run`)

```
main process ── reads the OCR df, builds page jobs, converts the checkpoint (cached),
     │          starts the MPS daemon, starts workers, writes outputs
     │ job queue
     ▼
preprocess workers ×P (CPU) ── PyMuPDF render (zoom 2.0) → Heron processor → uint8 640×640
     │ page queue (bounded)
     ▼
engine processes ×E (GPU) ── one vLLM LLMEngine each; started one after another
     │                       (their memory profiling must not overlap)
     │   wave admission: add pages only when ≥ wave slots are free (or the engine is idle),
     │   so most steps have no starting page and run as CUDA graphs
     ▼ result queue: (row, reading order, formatter ids)
main process ── MarkdownDecoder → markdown files, results.jsonl, results.parquet, summary.json
```

- **Engines** are separate processes that share the GPU through **CUDA MPS**. Each
  engine's host-side scheduling overhead (~17 µs per page per step in vLLM) hides behind
  the other engines' GPU work.
- **Preprocess workers** are sized from the cgroup CPU quota:
  `min(8, quota − 2·engines − 1)`, at least 2.
- **`MarkdownDecoder`** (`decode.py`) re-implements the training tokenizer's `decode`:
  `EMIT_NEXT` → the OCR line at the cursor in the predicted order; `<COLSPAN>`/`<ROWSPAN>`
  runs fold into attributes; the same render table. It was verified identical on 2,796
  pages.

## 11. Checkpoint conversion (`convert.py`)

```
training state dict(s)
  → assemble: combined / order + formatter / encoder source
  → rename:   nn.TransformerDecoderLayer → DecoderLayer
              in_proj splits → qkv / cross_q / cross_kv; prefix decoder.*, encoder.*
  → dims:     d_model, layers, ffn, content MLP, stage positions and M, from tensor shapes
  → write:    config.json (bf16 by default; Heron RT-DETR config baked in from assets),
              generation_config.json, model.safetensors
```

Unused RT-DETR detection heads (`enc_output`, `enc_score_head`, `enc_bbox_head`) are
dropped, as in the reference, which never runs them.

## 12. File map

| File | Contents |
|---|---|
| `model.py` | processor classes, `DecoderLayer`, `restrict_attention`, stacked helpers, `OcrDecoder`, `OcrTwoStageForConditionalGeneration` |
| `kernels.py` | Triton kernels + `gather_box_rows` |
| `encoder.py` | RT-DETR box encoder (from training code), split into image and box halves |
| `config.py` | `OcrTwoStageConfig`, token-id layout |
| `engine.py` | `make_llm`, `page_request`, `sampling_params`, `split_output` |
| `inputs.py` | OCR df parsing, job building, `PageRasterizer` |
| `decode.py` | `MarkdownDecoder` |
| `convert.py` | checkpoint conversion (`ocr-vllm-convert`) |
| `runner.py` | orchestration (`ocr-vllm-run`) |
| `__init__.py` | vLLM plugin `register()` |
