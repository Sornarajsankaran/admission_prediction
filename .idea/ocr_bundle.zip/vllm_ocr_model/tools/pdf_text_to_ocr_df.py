"""
Build an OCR dataframe in the Textract layout from PDFs' embedded text layer.

For smoke tests without Textract output: one row per page with columns file_name, page
(1-based), content ('\\n' between lines, '\\t' between words) and line_cords
("x1,x2,y1,y2|..." normalized). Only born-digital PDFs have a text layer, and its lines
differ from Textract's -- do not use this to judge model quality.

    python3 tools/pdf_text_to_ocr_df.py --pdf-dir /data/pdfs --out /data/ocr.parquet
"""

import argparse
from pathlib import Path

import pandas as pd
import pymupdf


def page_rows(pdf: Path, root: Path):
    with pymupdf.open(pdf) as doc:
        for i, page in enumerate(doc):
            W, H = page.rect.width, page.rect.height
            lines, cords = [], []
            for block in page.get_text("dict")["blocks"]:
                for line in block.get("lines", []):
                    words = " ".join(s["text"] for s in line["spans"]).split()
                    if not words:
                        continue
                    x1, y1, x2, y2 = line["bbox"]
                    lines.append("\t".join(words))
                    cords.append(f"{x1 / W:.4f},{x2 / W:.4f},{y1 / H:.4f},{y2 / H:.4f}")
            yield {"file_name": str(pdf.relative_to(root)), "page": i + 1,
                   "content": "\n".join(lines), "line_cords": "|".join(cords)}


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--pdf-dir", required=True)
    ap.add_argument("--out", required=True, help=".parquet / .pkl / .csv")
    ap.add_argument("--max-pages", type=int, default=None)
    a = ap.parse_args()
    root = Path(a.pdf_dir)
    rows = [r for pdf in sorted(root.rglob("*.pdf")) for r in page_rows(pdf, root)]
    df = pd.DataFrame(rows[: a.max_pages])
    out = str(a.out)
    (df.to_parquet if out.endswith(".parquet") else df.to_pickle if out.endswith(".pkl") else df.to_csv)(out, **({"index": False} if out.endswith(".csv") else {}))
    print(f"wrote {out}: {len(df)} pages from {df.file_name.nunique()} PDFs")


if __name__ == "__main__":
    main()
