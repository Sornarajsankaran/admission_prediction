# EmbeddingGemma 2 bi-encoder benchmark

One NVIDIA L40S. Same 5000 synthetic chunk texts and 50 structured ICD queries as the earlier cross-encoder experiment: 250000 exact cosine similarities. Model `google/embeddinggemma-2`, pinned revision `f9972ac22e696a105c482202646979e33e4b5a1e`. BF16 text-only model (271002624 loaded parameters), 768-dimensional normalized embeddings.

## Full-record comparison

| Implementation | Seconds/record | Effective scores/sec | 100 records, extrapolated |
|---|---:|---:|---:|
| Stock compiled ModernBERT cross-encoder | 185.516 | 1348 | 309.2 min |
| Optimized Variant B, native vLLM worker | 21.341 | 11715 | 35.6 min |
| EmbeddingGemma 2 SentenceTransformers, batch 32 | 10.4581 | 23905 | 17.43 min |
| EmbeddingGemma 2 native vLLM, tokens=8192, seqs=64, compiled=True | 5.6417 | 44313 | 9.40 min |
| EmbeddingGemma 2 native vLLM, tokens=32768, seqs=256, compiled=True | 6.4878 | 38534 | 10.81 min |

Best measured bi-encoder full-record time: **5.6417 sec**, 3.78× faster than optimized Variant B and 32.88× faster than the stock cross-encoder. 100-record times are linear extrapolations; concurrent 100-record processing was not run.

All full runs encode all 5000 documents and 50 queries from scratch; only model weights/kernels are warm. Tokenization, normalization, all-pair similarity and CPU score output are included. Model load, initial warmup/compile, JSON parsing and disk saves are excluded. Previous cross-encoder timing excluded tokenization, whereas these bi-encoder runs include it. The APIs and models differ; speedups are application-level comparisons.

## SentenceTransformers timing breakdown

| Component | Median seconds |
|---|---:|
| query_encoding_seconds | 0.073006 |
| document_encoding_seconds | 10.357714 |
| similarity_and_cpu_output_seconds | 0.000624 |
| total_seconds | 10.458126 |

Model loading: 3.359 sec, recorded separately. Full-run times: [10.47211580676958, 10.431398335378617, 10.458125897683203].

## Cached embeddings

- Documents already on GPU: 50 queries plus all 250000 scores in **0.072286 sec** (SentenceTransformers).
- CPU-resident document embeddings, including GPU upload: **0.072670 sec**.
- Both query and document embeddings already exist: all-pair scoring plus CPU output in **0.000201 sec**.
- CPU float32 document cache: 5000 × 768 × 4 bytes = 15.36 MB (14.65 MiB). These times exclude reading embeddings from disk.
- Native vLLM cached documents: query tokenization/encoding and CPU similarity in **0.030169 sec**.
- Native vLLM cached documents: query tokenization/encoding and CPU similarity in **0.029689 sec**.

## Input construction and checks

Queries contain the same ICD code, description, attribute and keyword fields, with the model-specific prefix `task: search result | query: `. Documents use `title: none | text: `. ModernBERT CLS/SEP/XML wrappers are not inserted into Gemma inputs. The same chunk text is preserved without truncation or rechunking. The original 256-token cap referred to the ModernBERT tokenizer; Gemma retokenizes that text.

Actual prefixed/tokenized length statistics:
```json
{
  "document": {
    "min": 292,
    "mean": 300.2164,
    "max": 306,
    "total": 1501082
  },
  "query": {
    "min": 29,
    "mean": 35.12,
    "max": 41,
    "total": 1756
  }
}
```

All scores are finite, shape [5000, 50]. Maximum document unit-norm error after FP32 renormalization: 1.19e-07.
Native vLLM vs SentenceTransformers document-vector cosine agreement: mean 0.99993241, minimum 0.99985749. This checks implementation agreement, not retrieval quality.
Native vLLM vs SentenceTransformers document-vector cosine agreement: mean 0.99993253, minimum 0.99983346. This checks implementation agreement, not retrieval quality.

The dataset has no relevance labels. A bi-encoder cosine score and a trained cross-encoder relevance score can yield different rankings. These measurements establish runtime, not equal clinical retrieval accuracy.

## Batch-size sweep

| Batch | Documents/sec, 512-document pilot |
|---:|---:|
| 8 | 220.76817659975563 |
| 16 | 376.4206526099484 |
| 32 | 477.6702082112485 |
| 64 | 387.5768760675529 |
| 128 | 279.6713853079655 |
| 256 | 247.39856347253843 |

## Reproduce

Install the updated `requirements.lock.txt`, then from the handoff directory:
```bash
export HF_HUB_OFFLINE=1 TRANSFORMERS_OFFLINE=1
.venv/bin/python bench_biencoder.py
.venv/bin/python bench_biencoder_vllm.py
.venv/bin/python make_biencoder_report.py
```

The local model checkpoint, tokenizer, chat template and pooling/normalization configs are included under `models/embeddinggemma-2`. The scripts read `data/chunks.jsonl` and `data/queries.jsonl`. Embeddings, raw score matrices and all timings are saved under `results/biencoder`. The SentenceTransformers script supports alternate `--data-dir`, `--model` and `--output-dir`. Its input JSONL schema matches the bundled synthetic files and `prepare_real_data.py` source inputs.

Use BF16 or FP32. The model card advises against FP16. Only text is encoded; unused vision/audio modules are disabled. Native vLLM selects the same text-only configuration and computes mean-pooled normalized embeddings through its supported executor.

Primary source: https://huggingface.co/google/embeddinggemma-2
