import torch
from tqdm import tqdm
import matplotlib.pyplot as plt


class LRRangeFinder:
    def __init__(self, model, optimizer, scaler, criterion, train_loader, device, autocast_dtype=torch.bfloat16):
        self.model = model
        self.optimizer = optimizer
        self.scaler = scaler
        self.criterion = criterion
        self.train_loader = train_loader
        self.device = device
        self.lrs = []
        self.losses = []
        self.autocast_dtype = autocast_dtype

    def find_lr(self, init_lr=1e-7, final_lr=1, num_iter=100):
        lr = init_lr
        self.optimizer.param_groups[0]['lr'] = lr

        self.model.train()
        total_iters = min(num_iter, len(self.train_loader))
        progress = tqdm(enumerate(self.train_loader), total=total_iters, desc="LR range test")
        for step, batch in progress:
            if step >= num_iter:
                break
            self.optimizer.zero_grad()

            inputs, labels = batch
            input_ids = inputs["input_ids"].to(self.device)
            attention_mask = inputs["attention_mask"].to(self.device)
            labels = labels.to(self.device)

            autocast_enabled = self.device.type == "cuda"
            with torch.autocast(device_type=self.device.type, dtype=self.autocast_dtype, enabled=autocast_enabled):
                logits = self.model(input_ids=input_ids, attention_mask=attention_mask)
                logit_diff = logits[:, 1] - logits[:, 0]
                loss = self.criterion(logit_diff, labels.float())

            self.scaler.scale(loss).backward()
            self.scaler.step(self.optimizer)
            self.scaler.update()

            self.lrs.append(lr)
            self.losses.append(loss.item())

            lr *= (final_lr / init_lr) ** (1 / num_iter)
            self.optimizer.param_groups[0]['lr'] = lr
            progress.set_postfix({"loss": loss.item(), "lr": lr})

    def plot_lr_vs_loss(self, save_path=None):
        plt.figure()
        plt.plot(self.lrs, self.losses)
        plt.xscale('log')
        plt.xlabel('Learning Rate (log scale)')
        plt.ylabel('Loss')
        plt.title('LR Finder')
        if save_path:
            plt.savefig(save_path, bbox_inches='tight')
        else:
            plt.show()
        plt.close()
