# vLLM serving for the two-stage OCR reconstruction model

`ocr_vllm/` is a vLLM (0.23.0) plugin that serves `OcrTwoStageModel`
(`scripts_v0.1/modeling_ocr_reconstruction.py`): RT-DETR box encoder → order decoder →
markdown formatter, as **one vLLM request per page**.

## Results (L40S, pages with ~300 OCR boxes)

Workload: 2048 pages averaging 300 boxes, about 300 order tokens plus ~740 formatter tokens
per page (bf16), greedy. The weights are random (see "Test setup"), so only speed is
meaningful here, not output quality.

| Backend | pages/s | vs baseline |
|---|---:|---:|
| PyTorch reference `generate_end_to_end`, fp32, batch 32 | 2.36 | 1× |
| PyTorch reference, bf16 autocast, batch 32 | 2.38 | 1× |
| vLLM port, bf16, 1 engine (first version) | 28.5 | 12× |
| vLLM port, bf16, 2 engines + MPS (first version) | 45.6 | 19× |
| vLLM port, bf16, 3 engines × 256 pages + MPS, block size 32 (current) | 74.5 | 32× |
| vLLM port, bf16, 4 engines × 128 pages + MPS, block size 32 (current) | 78.5 | 33× |
| **vLLM port, bf16, 4 engines × 160 pages + MPS, block size 32 (current)** | **79.5** | **34×** |

### Tuning log (45.6 → 79.5 pages/s)

| Change | Result | Why |
|---|---|---|
| Box lookup by direct KV-cache row read (`gather_box_rows`) instead of attention; pointer keys and box vectors share one cache layer | 13 + 13 layers, 2 KV groups, no filler layers | Lookup attention read every box to fetch one |
| Encoder image backbone `torch.compile`d (static shape) | 2 engines: 45 → 50 | RT-DETR image half 3.8 → 1.6 ms/page |
| `RequestOutputKind.FINAL_ONLY` | (part of the above) | One output per page instead of one per step |
| **Pin thread pools to 1** (plugin `SINGLE_THREAD_ENV`) | 3 engines: 41 → 63 | The container has a **15.3-core cgroup quota**; engines' machine-sized OpenMP/BLAS/blake3 pools burst past it and cgroup throttling froze every thread |
| 3 → 4 engines under MPS | 65 | Once throttling was gone, more engines hid more of vLLM's per-step host overhead |
| Decoder dense parts `torch.compile`d, both stacks as batched GEMMs | 68 | Fewer, fused kernels (GPU now saturated) |
| KV block size 32 | 68 | Less block bookkeeping and narrower block tables (GAP tokens average ~16 per page) |
| **Encoder chunks of 8 images (was 16) + channels-last + compiled box half** | **79.5** | Chunks of 8 are faster per page (1.38 vs 1.58 ms) and waste no padding on waves of 40 |

Per-component (bf16, one engine, 256 pages): a decode step takes ~1.9 ms of GPU time, and
attention is ~55% of that at the KV memory-bandwidth limit. The encoder costs ~1.9 ms per
page. The next lossy lever would be an fp8 KV cache; speculative multi-token decoding needs
the trained checkpoint to evaluate.

**Correctness.** Strict fp32 (TF32 off, batch size 1, eager, NCHW): the formatter stream
matches the reference exactly on 12 of 12 dense pages, and the reading order matches
exactly on 11 of 12. On the 12th page the order diverges at step 147 of 389, where the
reference's top two candidates differ by 0.0004 nats on logits of about 1000. That is fp32
summation-order noise (stacked matmuls and layer norm versus the reference's separate
modules). It shows up here because this random checkpoint's pointer logits are scaled ×890
to look confident. bf16 moves the reference's own outputs by about as much as it moves the
vLLM port's (`compare_outputs.py`). **Re-check bf16 against fp32 on the trained checkpoint
before choosing a precision.**

## How it works

Per-page state lives only in vLLM-managed KV caches: no side tables and no custom
scheduler. That keeps it compatible with continuous batching, preemption and CUDA graphs.

- **Stream per page:** `ORD_BOS, BOX_o0 … BOX_o{K-1}, GAP…, FMT_BOS, f_1 … EOS`. The logits
  force every structural token, so the order is always a valid permutation and the
  formatter places exactly K blocks.
- **Encoder:** the RT-DETR box encoder is vLLM's multimodal encoder, with one output row
  per OCR box. Images are processed in chunks of `encoder_max_batch` to bound memory.
- **Pointer and box vectors:** a write-only cross-attention cache (`box_store`) holds
  `pointer_key_proj(H_box)` as K and `norm(H_box)` as V. Custom kernels (`pointer.py`) read
  it through the block table for exact pointer scores (placed boxes masked) and for the
  box embeddings.
- **Cursor, placed boxes, K:** a write-only "state" cache stores
  `(box_id // 32, box_id % 32, is_box, is_emit)` per position. These are small integers,
  exact in bf16. A second kernel computes the formatter cursor from them. K comes from
  vLLM's cross-attention sequence lengths.
- **Both decoder stacks run on every token** (no data-dependent control flow).
  `restrict_attention` gives the unused stack length-1 attention. GAP tokens align FMT_BOS
  to a KV block boundary, so the formatter reads only its own blocks.
- **Two KV-cache groups:** every attention layer is 8×32, split into 13 self-attention and
  13 cross-attention layers. vLLM's per-step overhead grows with the number of groups.
- **Compiled dense code:** the encoder halves (image: static shape; boxes: dynamic), both
  decoder stacks' dense parts as batched GEMMs, and the logits assembly are all
  `torch.compile`d. Attention calls stay outside the compiled code, and vLLM's CUDA graphs
  capture the whole step.

## Usage

```bash
source /workspace/envs/ocr-vllm/bin/activate          # vllm==0.23.0, transformers==4.57.6
pip install -e serving/                                # registers the plugin (entry point)

# 1. convert a trained OcrTwoStageModel checkpoint (torch.save'd {"state_dict", "config"})
python serving/convert_checkpoint.py --ckpt model.pt --out /models/ocr_vllm
#    bf16: set "dtype"/"torch_dtype"/"encoder_dtype" to "bfloat16" in config.json

# 2. offline inference
python - <<'PY'
from engine import make_llm, page_request, sampling_params, split_output, to_uint8
from ocr_vllm.config import OcrTwoStageConfig
cfg = OcrTwoStageConfig.from_pretrained("/models/ocr_vllm")
llm = make_llm("/models/ocr_vllm", max_num_seqs=256)
# pixel_values: Heron RTDetrImageProcessor output (3,640,640); boxes: (K,4) xyxy in [0,1]
out = llm.generate([page_request(to_uint8(pixel_values), boxes, cfg)], sampling_params(cfg, len(boxes)))
order, fmt_ids = split_output(out[0].outputs[0].token_ids, cfg)   # fmt_ids: reference model-compact ids
PY

# 3. benchmark / parity
python serving/bench.py vllm --pages bench_w300_2k.pt --model /models/ocr_vllm --max-num-seqs 512 --wave 64
python serving/bench.py reference --pages bench_w300.pt --batch-size 32 --limit 128
OCR_VLLM_STRICT_FP32=1 python serving/bench.py reference --pages bench_w300.pt --batch-size 1 --limit 12 --dump ref.json
OCR_VLLM_STRICT_FP32=1 python serving/bench.py vllm --pages bench_w300.pt --limit 12 --max-num-seqs 1 --dump vllm.json
python serving/compare_outputs.py ref.json vllm.json
```

**Admission in waves** (`bench.py --wave`, `run_in_waves`). vLLM's encoder-decoder support
uses CUDA graphs only for steps in which no page is starting. Submitting pages
continuously makes almost every step eager. Admitting 64 pages at a time raised throughput
from 18.3 to 22.5 pages/s in the earlier layout. An online server should put the same
policy in front of `AsyncLLM`.

**Several engines on one GPU (current best):** 4 engines, each with
`gpu_memory_utilization=0.21`, `max_num_seqs=160`, `block_size=32` and waves of 40, under
CUDA MPS (`nvidia-cuda-mps-control -d`). Without MPS the processes time-slice the GPU.
Check the container's CPU quota (`cat /sys/fs/cgroup/cpu.max`): the plugin pins thread
pools to one thread because bursts above the quota cause throttling.

## Test setup

- `build_test_set.py` (in the separate `ocr-tools` venv): RapidOCR (PP-OCRv6 on
  onnxruntime) over 12 public PDFs (arXiv, IRS, Census, Fed) produced 600 pages in the
  training parquet format (`ocr_bbox` as normalized xyxy, plus `ocr_text`).
- `build_checkpoint.py`: pretrained Heron encoder with random decoders, scaled and biased
  so that the median top-2 logit gap is 3 nats and the formatter emits ~2.5 tokens per
  box, i.e. realistic decode lengths and confident decisions.
- `prepare_bench_set.py`: pre-rasterized workloads, `w300` (resampled to a mean of 300
  boxes, with per-copy box jitter) and `mix` (the natural distribution).

## Limits and caveats

- The plugin depends on vLLM 0.23 internals: `impl.do_kv_cache_update`, the Triton
  attention metadata fields and KV-group behaviour. Pin the version and re-run the strict
  parity check before upgrading. vLLM ≥ 0.24 also requires transformers 5, and the
  RT-DETR self-attention patch was validated on 4.57.6.
- Each page must have 1 to `max_boxes` (1024) boxes, and the formatter stops at 2047
  tokens, the same cap as the reference's positional table.
- The Triton attention backend is required (fp32 support and cross-attention).
  `enable_mm_embeds=True` is needed because pages arrive as preprocessed tensor dicts.
