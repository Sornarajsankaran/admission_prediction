"""
OCR Text Reconstruction Model
=============================

Layout-aware pointer-generation model that reconstructs a Markdown-like
structured representation of a document page from:

  * the page image, and
  * a set of OCR bounding boxes (one per detected text line).

The model does NOT generate text. At every decoding step it predicts either:

  * a *pointer* to one of the OCR boxes (copy that box's text), or
  * a fixed Markdown / layout *special token* (``#``, ``|``, ``\\n``, ...).

Architecture (see plan.md sections 5-9):

    page image ──► RT-DETR-v2 backbone + hybrid encoder ──► multi-scale memory
                                                                   │
    ocr boxes ─► (cxcywh)                                          │
        ├─ content  : BBoxMLP(4 → d_model) ───────► query content │
        └─ position : box ───► reference_points ──► deformable ◄───┘
                                              RT-DETR-v2 decoder
                                                     │
                                                     ▼
                                            H_box: (B, N, d_model)
                                                     │  (memory)
    target tokens ─► autoregressive Markdown decoder ┘
                                                     │
                                                     ▼
                            pointer head  +  special-token head
                                                     │
                                                     ▼
                            logits over [special (M) | boxes (N)]

Why RT-DETR-v2 instead of vanilla DETR (plan.md section 5/6):
  * A "query" in RT-DETR-v2 is a *content vector* paired with a *reference box*
    in (cx, cy, w, h) form. We supply the OCR box directly as the reference box,
    so we never run the model's two-stage proposal / top-k selection.
  * The decoder cross-attention is *deformable*: each query samples image
    features around its own reference box. Feeding the OCR box as the reference
    means every query pools the visual features at that text line for free.
  * ``query_pos_head`` (pretrained) already maps box(4) -> d_model positional
    embeddings every layer; we additionally add a trained content MLP.

This file depends on the installed ``transformers`` package for the pretrained
RT-DETR-v2 modules (NOT on the local exploration copy under ``layout_heron/``).
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Optional

import torch
import torch.nn as nn
import torch.nn.functional as F

from transformers import RTDetrV2Config, RTDetrV2Model


# --------------------------------------------------------------------------- #
# Helpers
# --------------------------------------------------------------------------- #
def inverse_sigmoid(x: torch.Tensor, eps: float = 1e-5) -> torch.Tensor:
    """Inverse of sigmoid; the RT-DETR-v2 decoder applies ``sigmoid`` to the
    reference points internally, so we pre-apply its inverse."""
    x = x.clamp(min=0, max=1)
    x1 = x.clamp(min=eps)
    x2 = (1 - x).clamp(min=eps)
    return torch.log(x1 / x2)


def box_xyxy_to_cxcywh(boxes: torch.Tensor) -> torch.Tensor:
    """(..., 4) xyxy  ->  (..., 4) cxcywh. Coordinates are assumed normalized to [0, 1]."""
    x1, y1, x2, y2 = boxes.unbind(-1)
    cx = (x1 + x2) * 0.5
    cy = (y1 + y2) * 0.5
    w = (x2 - x1).clamp(min=0)
    h = (y2 - y1).clamp(min=0)
    return torch.stack((cx, cy, w, h), dim=-1)


class MLP(nn.Module):
    """Simple multi-layer perceptron with ReLU between hidden layers."""

    def __init__(self, input_dim: int, hidden_dim: int, output_dim: int, num_layers: int = 3):
        super().__init__()
        dims = [input_dim] + [hidden_dim] * (num_layers - 1) + [output_dim]
        self.layers = nn.ModuleList(nn.Linear(a, b) for a, b in zip(dims[:-1], dims[1:]))

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        for i, layer in enumerate(self.layers):
            x = F.relu(layer(x)) if i < len(self.layers) - 1 else layer(x)
        return x


def _rtdetr_self_attn_forward(
    self,
    hidden_states: torch.Tensor,
    attention_mask: Optional[torch.Tensor] = None,
    position_embeddings: Optional[torch.Tensor] = None,
    output_attentions: bool = False,
):
    """Drop-in replacement for ``RTDetrV2MultiheadAttention.forward`` (the decoder
    *query self-attention*) that accepts a **per-sample** additive mask.

    Why we need this: the stock module only supports a batch-shared 2D ``(N, N)``
    mask -- it does ``mask.expand(B, 1, *mask.size())`` then a strict size check,
    so a per-page key-padding mask ``(B, 1, 1, N)`` raises. But padding differs
    per page, so we must mask each sample's padded queries individually to stop
    real OCR-box queries from attending to padding (RT-DETR's decoder
    self-attention is *bidirectional*, so without this every padded query leaks
    into every real box's H_box, and the result depends on the batch's padding).

    This reproduces the stock attention exactly -- position embeddings added to
    q/k, value from the un-pos'd states, 1/sqrt(head_dim) scaling -- via SDPA,
    which broadcasts any additive float ``attn_mask``. Equivalent to the original
    path when ``attention_mask is None`` (all-zero mask == no mask).
    """
    batch_size, target_len, embed_dim = hidden_states.shape
    num_heads, head_dim = self.num_heads, self.head_dim

    q_in = self.with_pos_embed(hidden_states, position_embeddings)
    q = self.q_proj(q_in).view(batch_size, target_len, num_heads, head_dim).transpose(1, 2)
    k = self.k_proj(q_in).view(batch_size, target_len, num_heads, head_dim).transpose(1, 2)
    v = self.v_proj(hidden_states).view(batch_size, target_len, num_heads, head_dim).transpose(1, 2)

    attn_output = F.scaled_dot_product_attention(q, k, v, attn_mask=attention_mask)
    attn_output = attn_output.transpose(1, 2).reshape(batch_size, target_len, embed_dim)
    attn_output = self.out_proj(attn_output)
    # weights are never requested inside encode_boxes; return None to match the
    # (output, weights) contract the decoder layer unpacks.
    return attn_output, None


# ``_rtdetr_self_attn_forward`` reimplements RT-DETR-v2's decoder self-attention,
# so it is pinned to the transformers version it was validated against (bit-for-bit
# up to fp noise -- see test_box_self_attention_mask.py). If the installed version
# differs, the reimplementation may silently drift from the library's math.
_VALIDATED_TRANSFORMERS_VERSION = "4.57.6"


def _check_transformers_version() -> None:
    """Fail loudly at model construction if the installed transformers version is
    not the one the self-attention patch was validated against."""
    import transformers

    if transformers.__version__ != _VALIDATED_TRANSFORMERS_VERSION:
        raise RuntimeError(
            f"OcrTextReconstructionModel patches RT-DETR-v2's decoder self-attention "
            f"(_rtdetr_self_attn_forward), validated against transformers=="
            f"{_VALIDATED_TRANSFORMERS_VERSION}, but {transformers.__version__} is "
            f"installed. Run scripts/test_box_self_attention_mask.py with "
            f"strict_transformers_version=False: if the stock-equivalence test still "
            f"passes, bump _VALIDATED_TRANSFORMERS_VERSION to "
            f"'{transformers.__version__}'; if it fails, re-sync "
            f"_rtdetr_self_attn_forward with the new RTDetrV2MultiheadAttention.forward. "
            f"(Pass strict_transformers_version=False to bypass this check.)"
        )


# --------------------------------------------------------------------------- #
# Config
# --------------------------------------------------------------------------- #
@dataclass
class OcrReconstructionConfig:
    """Configuration for :class:`OcrTextReconstructionModel`.

    The token id convention used everywhere (logits, labels, generation) is
    **special-first**, which keeps ids independent of how many boxes are padded:

        id in [0, num_special_tokens)            -> special Markdown token
        id in [num_special_tokens, +N)           -> pointer to OCR box (id - num_special_tokens)

    so a target id for box ``i`` is ``num_special_tokens + i``.
    """

    # ---- pretrained RT-DETR-v2 backbone ----
    backbone_name_or_path: str = "docling-project/docling-layout-heron"
    d_model: int = 256  # must match the RT-DETR-v2 d_model

    # ---- OCR box query content MLP (trained from scratch) ----
    content_mlp_hidden_dim: int = 512
    content_mlp_num_layers: int = 3

    # ---- special / markdown vocabulary ----
    # Must match CustomTokenizerV3.SPECIAL_TOKENS: 17 specials at global ids
    # 10000..10016. In this model's compact space they map to [0, 17) via
    # model_special_id = tokenizer_global_id - 10000  (bos=0, eos=1, pad=2, unk=3).
    # NOTE: <unk> (id 3) is reserved but dropped from training labels, so it is
    # never a target; cross-entropy over the other specials naturally suppresses it.
    num_special_tokens: int = 17  # M  (size of the fixed markdown/layout vocab)
    bos_token_id: int = 0  # index WITHIN the special vocab ([0, num_special_tokens))
    eos_token_id: int = 1
    pad_token_id: int = 2
    unk_token_id: int = 3

    # ---- autoregressive markdown decoder (trained from scratch) ----
    # NOTE: these are the MARKDOWN decoder's hyperparams, distinct from the
    # pretrained RT-DETR-v2 deformable decoder (which keeps Heron's own config).
    num_markdown_layers: int = 6
    markdown_attention_heads: int = 8
    markdown_ffn_dim: int = 2048
    dropout: float = 0.1
    max_position_embeddings: int = 2048

    # ---- misc ----
    label_ignore_index: int = -100


# --------------------------------------------------------------------------- #
# Output container
# --------------------------------------------------------------------------- #
@dataclass
class OcrReconstructionOutput:
    loss: Optional[torch.Tensor] = None
    logits: Optional[torch.Tensor] = None          # (B, T, M + N)
    pointer_logits: Optional[torch.Tensor] = None  # (B, T, N)
    special_logits: Optional[torch.Tensor] = None  # (B, T, M)
    box_hidden_states: Optional[torch.Tensor] = None  # H_box: (B, N, d_model)


# --------------------------------------------------------------------------- #
# Shared RT-DETR-v2 box encoder
# --------------------------------------------------------------------------- #
class BoxEncoderMixin:
    """Shared RT-DETR-v2 box encoder: (image, OCR boxes) -> H_box (B, N, d_model).

    Both the Stage-2 markdown model (:class:`OcrTextReconstructionModel`) and the
    Stage-1 ordering model (:class:`OcrOrderingModel`) build the SAME box
    representations, so the encoder construction (``_init_box_encoder``), the
    freeze helpers, and the ``encode_boxes`` forward live here. Attribute names
    (``rtdetr`` / ``box_content_mlp`` / ``box_input_norm``) match the original
    inline setup, so existing checkpoints load with no key changes.
    """

    def _init_box_encoder(
        self,
        config: "OcrReconstructionConfig",
        rtdetr: Optional[RTDetrV2Model] = None,
        strict_transformers_version: bool = True,
    ):
        # The RT-DETR self-attention patch installed below is tied to a specific
        # transformers version; refuse to build on an unvalidated one unless the
        # caller (e.g. the equivalence test) explicitly opts out.
        if strict_transformers_version:
            _check_transformers_version()
        d = config.d_model

        # Pretrained RT-DETR-v2 (backbone + hybrid encoder + deformable decoder). We
        # use the head-less RTDetrV2Model so decoder.bbox_embed stays None -> reference
        # points stay pinned to the OCR boxes across all decoder layers.
        if rtdetr is None:
            # The Heron checkpoint is an RTDetrV2ForObjectDetection: weights are stored
            # under the `model.` prefix (+ detection heads). Load the OD model (exact
            # structural match) and take its `.model` submodule so every pretrained
            # weight loads (a bare RTDetrV2Model would silently random-init).
            from transformers import RTDetrV2ForObjectDetection

            detector = RTDetrV2ForObjectDetection.from_pretrained(config.backbone_name_or_path)
            rtdetr = detector.model
            # We do NOT refine boxes: drop the detection heads so reference points stay
            # pinned to the OCR boxes across layers.
            rtdetr.decoder.bbox_embed = None
            rtdetr.decoder.class_embed = None
        self.rtdetr = rtdetr
        assert rtdetr.config.d_model == d, (
            f"d_model mismatch: config={d} but RT-DETR-v2={rtdetr.config.d_model}"
        )

        # Patch each decoder layer's query self-attention so encode_boxes can pass a
        # per-sample key-padding mask (the stock module only accepts a batch-shared 2D
        # mask). Leaves the deformable cross-attention, weights and state_dict keys
        # untouched -- see _rtdetr_self_attn_forward.
        import types

        for _layer in self.rtdetr.decoder.layers:
            _layer.self_attn.forward = types.MethodType(_rtdetr_self_attn_forward, _layer.self_attn)

        # OCR box -> query content (trained from scratch). The pretrained query_pos_head
        # handles box -> positional embedding; this MLP gives each query an initial
        # content vector derived from its box.
        self.box_content_mlp = MLP(4, config.content_mlp_hidden_dim, d, config.content_mlp_num_layers)
        # normalize H_box when it is used as an autoregressive decoder input embedding
        self.box_input_norm = nn.LayerNorm(d)

    def freeze_rtdetr(self, freeze_decoder: bool = True):
        """Freeze ALL pretrained RT-DETR-v2 parameters (backbone, encoder, decoder,
        and the unused two-stage proposal heads). Set ``freeze_decoder=False`` to keep
        fine-tuning the deformable decoder while the rest stays frozen."""
        for p in self.rtdetr.parameters():
            p.requires_grad_(False)
        if not freeze_decoder:
            for p in self.rtdetr.decoder.parameters():
                p.requires_grad_(True)

    def unfreeze_rtdetr(self):
        for p in self.rtdetr.parameters():
            p.requires_grad_(True)

    def freeze_box_encoder(self):
        """Freeze the ENTIRE H_box-producing path: RT-DETR + box_content_mlp +
        box_input_norm. Stage-2 uses this so the markdown decoder trains against the
        exact same (frozen) H_box the Phase-1 order decoder relies on -- keeping both
        decoders on one shared box representation."""
        for module in (self.rtdetr, self.box_content_mlp, self.box_input_norm):
            for p in module.parameters():
                p.requires_grad_(False)

    # ------------------------------------------------------------------ #
    # image + OCR boxes -> H_box
    # ------------------------------------------------------------------ #
    def encode_boxes(
        self,
        pixel_values: torch.Tensor,
        ocr_boxes: torch.Tensor,
        box_mask: Optional[torch.Tensor] = None,
        pixel_mask: Optional[torch.Tensor] = None,
        boxes_are_xyxy: bool = True,
    ) -> torch.Tensor:
        """Run the RT-DETR-v2 backbone/encoder/decoder with OCR-box-conditioned
        queries and return ``H_box`` of shape ``(B, N, d_model)``.

        Args:
            pixel_values: (B, 3, H, W) preprocessed image (RTDetrImageProcessor).
            ocr_boxes:    (B, N, 4) box coordinates normalized to [0, 1].
            box_mask:     (B, N) bool, True for real boxes / False for padding.
            boxes_are_xyxy: if True, ``ocr_boxes`` is xyxy and converted to cxcywh.
        """
        rt = self.rtdetr
        device = pixel_values.device
        batch_size, _, height, width = pixel_values.shape

        boxes_cxcywh = box_xyxy_to_cxcywh(ocr_boxes) if boxes_are_xyxy else ocr_boxes
        # Padded boxes get a degenerate (0-size) box. Their own H_box row is
        # irrelevant (masked out of all downstream logits/losses), but they MUST
        # be masked out of the decoder's query self-attention below, otherwise
        # they contaminate every *real* box's H_box (self-attention is
        # bidirectional -> real queries attend to padding).

        # ---- backbone + hybrid encoder (replicates RTDetrV2Model.forward) ----
        if pixel_mask is None:
            pixel_mask = torch.ones((batch_size, height, width), device=device)
        features = rt.backbone(pixel_values, pixel_mask)
        proj_feats = [rt.encoder_input_proj[lvl](src) for lvl, (src, _m) in enumerate(features)]
        encoder_outputs = rt.encoder(proj_feats, return_dict=True)

        # ---- project encoder features to the decoder feature levels ----
        sources = [rt.decoder_input_proj[lvl](src) for lvl, src in enumerate(encoder_outputs[0])]
        if rt.config.num_feature_levels > len(sources):
            len_sources = len(sources)
            sources.append(rt.decoder_input_proj[len_sources](encoder_outputs[0])[-1])
            for i in range(len_sources + 1, rt.config.num_feature_levels):
                sources.append(rt.decoder_input_proj[i](encoder_outputs[0][-1]))

        # ---- flatten multi-scale features ----
        source_flatten, spatial_shapes_list = [], []
        spatial_shapes = torch.empty((len(sources), 2), device=device, dtype=torch.long)
        for lvl, source in enumerate(sources):
            h, w = source.shape[-2:]
            spatial_shapes[lvl, 0] = h
            spatial_shapes[lvl, 1] = w
            spatial_shapes_list.append((h, w))
            source_flatten.append(source.flatten(2).transpose(1, 2))
        source_flatten = torch.cat(source_flatten, 1)
        level_start_index = torch.cat(
            (spatial_shapes.new_zeros((1,)), spatial_shapes.prod(1).cumsum(0)[:-1])
        )

        # ---- OCR-box-conditioned queries ----
        # reference points (position pathway) -> drives pretrained query_pos_head
        # + deformable sampling. Decoder applies sigmoid internally.
        reference_points = inverse_sigmoid(boxes_cxcywh.to(source_flatten.dtype))
        # content pathway -> trained MLP
        target = self.box_content_mlp(boxes_cxcywh.to(source_flatten.dtype))

        # query self-attention key-padding mask (B, 1, 1, N): 0.0 for real boxes,
        # -inf for padding. RT-DETR threads ``encoder_attention_mask`` into the
        # decoder's self-attention only (not the deformable cross-attention).
        self_attn_mask = None
        if box_mask is not None:
            self_attn_mask = torch.zeros(
                batch_size, 1, 1, boxes_cxcywh.size(1),
                device=source_flatten.device, dtype=source_flatten.dtype,
            ).masked_fill_(~box_mask[:, None, None, :], float("-inf"))

        decoder_outputs = rt.decoder(
            inputs_embeds=target,
            encoder_hidden_states=source_flatten,
            encoder_attention_mask=self_attn_mask,
            reference_points=reference_points,
            spatial_shapes=spatial_shapes,
            spatial_shapes_list=spatial_shapes_list,
            level_start_index=level_start_index,
            return_dict=True,
        )
        return decoder_outputs.last_hidden_state  # H_box: (B, N, d_model)


# --------------------------------------------------------------------------- #
# Model
# --------------------------------------------------------------------------- #
class OcrTextReconstructionModel(BoxEncoderMixin, nn.Module):
    def __init__(
        self,
        config: OcrReconstructionConfig,
        rtdetr: Optional[RTDetrV2Model] = None,
        strict_transformers_version: bool = True,
    ):
        super().__init__()
        self.config = config
        d = config.d_model

        # ------------------------------------------------------------------ #
        # 1-2. Shared RT-DETR-v2 box encoder (backbone + hybrid encoder +
        #      deformable decoder, OCR-box content MLP, box_input_norm).
        #      See BoxEncoderMixin.
        # ------------------------------------------------------------------ #
        self._init_box_encoder(config, rtdetr, strict_transformers_version)

        # ------------------------------------------------------------------ #
        # 3. Autoregressive Markdown decoder (trained from scratch).
        # ------------------------------------------------------------------ #
        self.special_embedding = nn.Embedding(config.num_special_tokens, d)
        self.pos_embedding = nn.Parameter(torch.zeros(1, config.max_position_embeddings, d))
        self.embed_dropout = nn.Dropout(config.dropout)

        decoder_layer = nn.TransformerDecoderLayer(
            d_model=d,
            nhead=config.markdown_attention_heads,
            dim_feedforward=config.markdown_ffn_dim,
            dropout=config.dropout,
            activation="gelu",
            batch_first=True,
            norm_first=True,
        )
        self.markdown_decoder = nn.TransformerDecoder(decoder_layer, num_layers=config.num_markdown_layers)
        self.decoder_norm = nn.LayerNorm(d)

        # ------------------------------------------------------------------ #
        # 4. Output heads.
        # ------------------------------------------------------------------ #
        self.special_head = nn.Linear(d, config.num_special_tokens)  # M logits
        # Pointer head: project the RT-DETR box states (keys) into a pointer space,
        # then dot with the raw AR decoder state (query). Equivalent in capacity to
        # a query projection, but adapts the pretrained layout reps and lets the
        # projected keys be cached across decode steps. Leaves H_box's other roles
        # (cross-attn memory, input embeddings) untouched.
        self.pointer_key_proj = nn.Linear(d, d, bias=False)
        self.pointer_scale = 1.0 / math.sqrt(d)  # scaled dot product

        self._init_new_weights()

    # ------------------------------------------------------------------ #
    # init / freezing utilities
    # ------------------------------------------------------------------ #
    def _init_new_weights(self):
        nn.init.normal_(self.pos_embedding, std=0.02)
        nn.init.normal_(self.special_embedding.weight, std=0.02)
        nn.init.xavier_uniform_(self.pointer_key_proj.weight)

    # ------------------------------------------------------------------ #
    # Token embedding for the AR decoder (special-first id scheme)
    # ------------------------------------------------------------------ #
    def _embed_tokens(self, input_ids: torch.Tensor, box_hidden_states: torch.Tensor) -> torch.Tensor:
        """Map token ids to embeddings:
          * special token  -> learned special embedding
          * box pointer    -> the box's H_box vector (pointer-style input)
        """
        M = self.config.num_special_tokens
        is_box = input_ids >= M  # (B, T)

        special_ids = input_ids.clamp(max=M - 1)
        special_emb = self.special_embedding(special_ids)  # (B, T, d)

        box_ids = (input_ids - M).clamp(min=0)  # (B, T)
        normed_boxes = self.box_input_norm(box_hidden_states)  # (B, N, d)
        index = box_ids.unsqueeze(-1).expand(-1, -1, normed_boxes.size(-1))  # (B, T, d)
        box_emb = torch.gather(normed_boxes, 1, index)  # (B, T, d)

        return torch.where(is_box.unsqueeze(-1), box_emb, special_emb)

    # ------------------------------------------------------------------ #
    # Heads
    # ------------------------------------------------------------------ #
    def _compute_logits(self, hidden: torch.Tensor, box_hidden_states: torch.Tensor,
                        box_mask: Optional[torch.Tensor]):
        # pointer logits: project box states (keys), then dot with the decoder
        # state (query) -> score for copying each OCR box (plan 9.1)
        key = self.pointer_key_proj(box_hidden_states)  # (B, N, d)
        pointer_logits = torch.matmul(hidden, key.transpose(1, 2)) * self.pointer_scale
        if box_mask is not None:
            pointer_logits = pointer_logits.masked_fill(~box_mask.unsqueeze(1), float("-inf"))
        # special-token logits (plan 9.2)
        special_logits = self.special_head(hidden)
        # concat: [special (M) | boxes (N)]  (special-first id scheme)
        logits = torch.cat([special_logits, pointer_logits], dim=-1)
        return logits, pointer_logits, special_logits

    # ------------------------------------------------------------------ #
    # Forward (teacher forcing)
    # ------------------------------------------------------------------ #
    def forward(
        self,
        pixel_values: torch.Tensor,
        ocr_boxes: torch.Tensor,
        decoder_input_ids: torch.Tensor,
        box_mask: Optional[torch.Tensor] = None,
        labels: Optional[torch.Tensor] = None,
        pixel_mask: Optional[torch.Tensor] = None,
        boxes_are_xyxy: bool = True,
    ) -> OcrReconstructionOutput:
        """
        Args:
            pixel_values:      (B, 3, H, W) preprocessed page image.
            ocr_boxes:         (B, N, 4) normalized box coords.
            decoder_input_ids: (B, T) teacher-forcing input ids (BOS-prefixed),
                               using the special-first id scheme.
            box_mask:          (B, N) bool, True = real box.
            labels:            (B, T) target ids; positions to ignore = -100.
        """
        box_hidden_states = self.encode_boxes(
            pixel_values, ocr_boxes, box_mask=box_mask,
            pixel_mask=pixel_mask, boxes_are_xyxy=boxes_are_xyxy,
        )

        T = decoder_input_ids.size(1)
        tok_emb = self._embed_tokens(decoder_input_ids, box_hidden_states)
        x = self.embed_dropout(tok_emb + self.pos_embedding[:, :T])

        causal_mask = torch.triu(
            torch.full((T, T), float("-inf"), device=x.device), diagonal=1
        )
        memory_key_padding_mask = (~box_mask) if box_mask is not None else None

        hidden = self.markdown_decoder(
            tgt=x,
            memory=box_hidden_states,
            tgt_mask=causal_mask,
            memory_key_padding_mask=memory_key_padding_mask,
        )
        hidden = self.decoder_norm(hidden)

        logits, pointer_logits, special_logits = self._compute_logits(
            hidden, box_hidden_states, box_mask
        )

        loss = None
        if labels is not None:
            loss = F.cross_entropy(
                logits.reshape(-1, logits.size(-1)),
                labels.reshape(-1),
                ignore_index=self.config.label_ignore_index,
            )

        return OcrReconstructionOutput(
            loss=loss,
            logits=logits,
            pointer_logits=pointer_logits,
            special_logits=special_logits,
            box_hidden_states=box_hidden_states,
        )

    # ------------------------------------------------------------------ #
    # KV-cached single-token decoder step (Phase 2 optimisation)
    # ------------------------------------------------------------------ #
    def _precompute_cross_kv(
        self,
        h_box: torch.Tensor,
        box_mask: Optional[torch.Tensor],
    ) -> tuple[list[tuple[torch.Tensor, torch.Tensor]], Optional[torch.Tensor]]:
        """Precompute cross-attention K and V from H_box for all decoder layers.

        H_box is constant within one decode sequence, so these projections are
        computed once before the AR loop and reused at every step.

        Returns:
            cross_kv:   per-layer (K, V) each (B, N, d).
            cross_mask: additive attention mask (B, 1, 1, N) — 0.0 for valid
                        positions, -inf for padded. None when box_mask is None.
        """
        d = self.config.d_model
        cross_kv: list[tuple[torch.Tensor, torch.Tensor]] = []
        for layer in self.markdown_decoder.layers:
            mha = layer.multihead_attn
            w = mha.in_proj_weight   # (3d, d)
            b = mha.in_proj_bias     # (3d,) or None
            # cross-attn: key=value=h_box → K uses w[d:2d], V uses w[2d:3d]
            k = F.linear(h_box, w[d : 2 * d], b[d : 2 * d] if b is not None else None)
            v = F.linear(h_box, w[2 * d :],   b[2 * d :]   if b is not None else None)
            cross_kv.append((k, v))

        cross_mask: Optional[torch.Tensor] = None
        if box_mask is not None:
            # additive mask: 0.0 where valid, -inf where padded
            cross_mask = torch.zeros(
                h_box.size(0), 1, 1, h_box.size(1),
                device=h_box.device, dtype=h_box.dtype,
            ).masked_fill_(~box_mask[:, None, None, :], float("-inf"))

        return cross_kv, cross_mask

    def _ar_decode_step(
        self,
        x: torch.Tensor,
        self_kv: list,
        cross_kv: list[tuple[torch.Tensor, torch.Tensor]],
        cross_mask: Optional[torch.Tensor],
    ) -> tuple[torch.Tensor, list]:
        """Single-token incremental decoder step with KV caching.

        Produces the same output as ``decoder_norm(markdown_decoder(full_seq)[:, -1:])``
        for the last token, but runs in O(T) instead of O(T²) per step because
        the self-attention query is one token wide while keys/values span the cache.

        Args:
            x:          (B, 1, d) — new-token embedding with positional encoding.
            self_kv:    Per-layer self-attn cache; element i is None on the first
                        step, then a (K, V) pair each of shape (B, t, d).
            cross_kv:   Static per-layer (K, V) from _precompute_cross_kv.
            cross_mask: Additive cross-attn mask or None.

        Returns:
            hidden:     (B, 1, d) with decoder_norm applied, ready for _compute_logits.
            new_self_kv: Updated per-layer cache (each entry now shape (B, t+1, d)).
        """
        d   = self.config.d_model
        H   = self.config.markdown_attention_heads
        d_h = d // H
        B   = x.size(0)
        new_kv: list = []

        for i, layer in enumerate(self.markdown_decoder.layers):
            # ── pre-norm self-attention (KV cache grows each step) ────────
            x_n = layer.norm1(x)                                    # (B, 1, d)
            sa  = layer.self_attn
            w   = sa.in_proj_weight                                  # (3d, d)
            bsa = sa.in_proj_bias                                    # (3d,) or None

            q_sa  = F.linear(x_n, w[:d],        bsa[:d]        if bsa is not None else None)
            k_new = F.linear(x_n, w[d : 2 * d], bsa[d : 2 * d] if bsa is not None else None)
            v_new = F.linear(x_n, w[2 * d :],   bsa[2 * d :]   if bsa is not None else None)

            past = self_kv[i]
            if past is not None:
                k_all = torch.cat([past[0], k_new], dim=1)         # (B, t+1, d)
                v_all = torch.cat([past[1], v_new], dim=1)
            else:
                k_all, v_all = k_new, v_new                         # (B, 1, d) first step
            new_kv.append((k_all, v_all))

            T_kv = k_all.size(1)
            q_mh = q_sa.view(B, 1,    H, d_h).transpose(1, 2)     # (B,H,1,d_h)
            k_mh = k_all.view(B, T_kv, H, d_h).transpose(1, 2)    # (B,H,T,d_h)
            v_mh = v_all.view(B, T_kv, H, d_h).transpose(1, 2)

            sa_out = F.scaled_dot_product_attention(q_mh, k_mh, v_mh)  # (B,H,1,d_h)
            sa_out = sa_out.transpose(1, 2).contiguous().view(B, 1, d)
            sa_out = F.linear(sa_out, sa.out_proj.weight, sa.out_proj.bias)
            x = x + layer.dropout1(sa_out)

            # ── pre-norm cross-attention (K/V precomputed from H_box) ─────
            x_n  = layer.norm2(x)
            ca   = layer.multihead_attn
            w_ca = ca.in_proj_weight
            b_ca = ca.in_proj_bias

            q_ca = F.linear(x_n, w_ca[:d], b_ca[:d] if b_ca is not None else None)
            k_pre, v_pre = cross_kv[i]                              # (B, N, d)
            N = k_pre.size(1)

            q_mh = q_ca.view(B, 1, H, d_h).transpose(1, 2)        # (B,H,1,d_h)
            k_mh = k_pre.view(B, N, H, d_h).transpose(1, 2)       # (B,H,N,d_h)
            v_mh = v_pre.view(B, N, H, d_h).transpose(1, 2)

            ca_out = F.scaled_dot_product_attention(q_mh, k_mh, v_mh, attn_mask=cross_mask)
            ca_out = ca_out.transpose(1, 2).contiguous().view(B, 1, d)
            ca_out = F.linear(ca_out, ca.out_proj.weight, ca.out_proj.bias)
            x = x + layer.dropout2(ca_out)

            # ── pre-norm FFN ──────────────────────────────────────────────
            x_n = layer.norm3(x)
            ff  = layer.linear2(layer.dropout(layer.activation(layer.linear1(x_n))))
            x   = x + layer.dropout3(ff)

        return self.decoder_norm(x), new_kv

    # ------------------------------------------------------------------ #
    # Greedy autoregressive generation (eval / inference)
    # ------------------------------------------------------------------ #
    @torch.no_grad()
    def generate(
        self,
        pixel_values: torch.Tensor,
        ocr_boxes: torch.Tensor,
        box_mask: Optional[torch.Tensor] = None,
        pixel_mask: Optional[torch.Tensor] = None,
        boxes_are_xyxy: bool = True,
        max_new_tokens: int = 1024,
    ) -> torch.Tensor:
        """Greedy decoding. Returns (B, L) generated ids in the special-first
        scheme (including the BOS prefix), stopping each sequence at EOS."""
        self.eval()
        cfg = self.config
        device = pixel_values.device
        batch_size = pixel_values.size(0)

        box_hidden_states = self.encode_boxes(
            pixel_values, ocr_boxes, box_mask=box_mask,
            pixel_mask=pixel_mask, boxes_are_xyxy=boxes_are_xyxy,
        )
        cross_kv, cross_mask = self._precompute_cross_kv(box_hidden_states, box_mask)
        generated = torch.full((batch_size, 1), cfg.bos_token_id, dtype=torch.long, device=device)
        finished = torch.zeros(batch_size, dtype=torch.bool, device=device)
        self_kv: list = [None] * len(self.markdown_decoder.layers)

        for t in range(max_new_tokens):
            tok_emb = self._embed_tokens(generated[:, t:t + 1], box_hidden_states)
            x = tok_emb + self.pos_embedding[:, t:t + 1]
            hidden, self_kv = self._ar_decode_step(x, self_kv, cross_kv, cross_mask)
            logits, _, _ = self._compute_logits(hidden, box_hidden_states, box_mask)
            next_token = logits[:, -1].argmax(dim=-1)  # (B,)

            # once finished, keep emitting PAD
            next_token = torch.where(
                finished,
                torch.full_like(next_token, cfg.pad_token_id),
                next_token,
            )
            generated = torch.cat([generated, next_token.unsqueeze(1)], dim=1)
            finished = finished | (next_token == cfg.eos_token_id)
            if bool(finished.all()):
                break

        return generated

    # ------------------------------------------------------------------ #
    # Multinomial sampling rollout (RL / GRPO fine-tuning)
    # ------------------------------------------------------------------ #
    @torch.no_grad()
    def sample_decode(
        self,
        pixel_values: torch.Tensor,
        ocr_boxes: torch.Tensor,
        box_mask: Optional[torch.Tensor] = None,
        pixel_mask: Optional[torch.Tensor] = None,
        boxes_are_xyxy: bool = True,
        max_new_tokens: int = 1024,
        temperature: float = 1.0,
    ):
        """Sampling twin of :meth:`generate` for policy-gradient RL (GRPO).

        Each step samples a token from ``softmax(logits / temperature)`` and
        records that token's log-prob under the **temperature-1 policy**
        (``log_softmax(logits)``). Temperature therefore only drives exploration;
        the recorded log-prob is the one the policy is actually optimised on, so
        it matches a teacher-forced :meth:`forward` recompute (importance ratio
        ~= 1 at init, in eval mode with dropout off).

        Returns three tensors aligned to the generated columns (col 0 = BOS):
            sequences:    (B, S) sampled ids incl. the BOS prefix.
            old_logprobs: (B, S) log-prob of each sampled token; col 0 (BOS) and
                          post-<eos> pad columns are 0.0.
            valid_mask:   (B, S) bool, True for real actions up to and INCLUDING
                          the first <eos> (False at BOS and after eos).

        To align with a recompute, feed ``sequences[:, :-1]`` to :meth:`forward`
        and compare its per-token log-probs at ``sequences[:, 1:]`` against
        ``old_logprobs[:, 1:]`` over ``valid_mask[:, 1:]``.
        """
        self.eval()
        cfg = self.config
        device = pixel_values.device
        batch_size = pixel_values.size(0)

        box_hidden_states = self.encode_boxes(
            pixel_values, ocr_boxes, box_mask=box_mask,
            pixel_mask=pixel_mask, boxes_are_xyxy=boxes_are_xyxy,
        )
        cross_kv, cross_mask = self._precompute_cross_kv(box_hidden_states, box_mask)

        generated = torch.full((batch_size, 1), cfg.bos_token_id, dtype=torch.long, device=device)
        logprobs = torch.zeros((batch_size, 1), dtype=torch.float32, device=device)
        valid = torch.zeros((batch_size, 1), dtype=torch.bool, device=device)
        finished = torch.zeros(batch_size, dtype=torch.bool, device=device)
        self_kv: list = [None] * len(self.markdown_decoder.layers)

        for t in range(max_new_tokens):
            tok_emb = self._embed_tokens(generated[:, t:t + 1], box_hidden_states)
            x = tok_emb + self.pos_embedding[:, t:t + 1]
            hidden, self_kv = self._ar_decode_step(x, self_kv, cross_kv, cross_mask)
            logits, _, _ = self._compute_logits(hidden, box_hidden_states, box_mask)
            step_logits = logits[:, -1]                               # (B, V) temperature-1 logits

            policy_logprob = torch.log_softmax(step_logits, dim=-1)   # the optimised policy
            sample_probs = torch.softmax(step_logits / temperature, dim=-1)
            next_token = torch.multinomial(sample_probs, num_samples=1).squeeze(1)  # (B,)
            token_logprob = policy_logprob.gather(1, next_token.unsqueeze(1)).squeeze(1)  # (B,)

            col_valid = ~finished                                     # the <eos> action stays valid
            # once finished, force PAD and a zero (ignored) log-prob
            next_token = torch.where(finished, torch.full_like(next_token, cfg.pad_token_id), next_token)
            token_logprob = torch.where(col_valid, token_logprob, torch.zeros_like(token_logprob))

            generated = torch.cat([generated, next_token.unsqueeze(1)], dim=1)
            logprobs = torch.cat([logprobs, token_logprob.unsqueeze(1)], dim=1)
            valid = torch.cat([valid, col_valid.unsqueeze(1)], dim=1)

            finished = finished | (next_token == cfg.eos_token_id)
            if bool(finished.all()):
                break

        return generated, logprobs, valid


# --------------------------------------------------------------------------- #
# Stage-1 ordering model
# --------------------------------------------------------------------------- #
@dataclass
class OrderingOutput:
    loss: Optional[torch.Tensor] = None
    logits: Optional[torch.Tensor] = None             # (B, K, N) masked pointer logits
    box_hidden_states: Optional[torch.Tensor] = None  # H_box: (B, N, d_model)


class OcrOrderingModel(BoxEncoderMixin, nn.Module):
    """Stage-1 reading-order model: (image, OCR boxes) -> reading-order permutation.

    Reuses the shared RT-DETR box encoder (``H_box``), then an autoregressive
    *pointer* decoder that at each step points to the next box in reading order.
    Already-selected (and padded) boxes are masked out of the pointer logits, so
    every decode is a valid permutation by construction -- no EOS is needed and
    decoding runs exactly K (= number of real boxes) steps.

    The target ``order`` is the gold permutation over the compacted box indices
    (see ``data.build_order_example``); padded steps are ``label_ignore_index``.
    """

    def __init__(
        self,
        config: OcrReconstructionConfig,
        rtdetr: Optional[RTDetrV2Model] = None,
        strict_transformers_version: bool = True,
    ):
        super().__init__()
        self.config = config
        d = config.d_model

        # shared RT-DETR-v2 box encoder (rtdetr / box_content_mlp / box_input_norm)
        self._init_box_encoder(config, rtdetr, strict_transformers_version)

        # autoregressive pointer decoder (trained from scratch)
        self.order_bos = nn.Parameter(torch.zeros(1, 1, d))  # learned step-0 input
        self.pos_embedding = nn.Parameter(torch.zeros(1, config.max_position_embeddings, d))
        self.embed_dropout = nn.Dropout(config.dropout)

        decoder_layer = nn.TransformerDecoderLayer(
            d_model=d,
            nhead=config.markdown_attention_heads,
            dim_feedforward=config.markdown_ffn_dim,
            dropout=config.dropout,
            activation="gelu",
            batch_first=True,
            norm_first=True,
        )
        self.order_decoder = nn.TransformerDecoder(decoder_layer, num_layers=config.num_markdown_layers)
        self.decoder_norm = nn.LayerNorm(d)

        # pointer head: project box states (keys), dot with the decoder state (query)
        self.pointer_key_proj = nn.Linear(d, d, bias=False)
        self.pointer_scale = 1.0 / math.sqrt(d)

        self._init_new_weights()

    def _init_new_weights(self):
        nn.init.normal_(self.order_bos, std=0.02)
        nn.init.normal_(self.pos_embedding, std=0.02)
        nn.init.xavier_uniform_(self.pointer_key_proj.weight)

    # ------------------------------------------------------------------ #
    # helpers
    # ------------------------------------------------------------------ #
    def _teacher_forcing_inputs(self, order: torch.Tensor, box_hidden_states: torch.Tensor) -> torch.Tensor:
        """Build decoder inputs ``[BOS, Hbox[order[0]], ..., Hbox[order[K-2]]]``.

        Input at step t predicts ``order[t]``: step 0 sees the learned BOS; step
        t>0 sees the (normed) H_box of the box selected at step t-1. Padded order
        entries (ignore_index) are clamped to 0 for the gather -- they only feed
        padded steps, which are dropped from the loss.
        """
        B, K = order.shape
        d = self.config.d_model
        normed = self.box_input_norm(box_hidden_states)     # (B, N, d)
        order_valid = order.clamp(min=0)                    # (B, K)  ignore(-100) -> 0
        idx = order_valid.unsqueeze(-1).expand(-1, -1, d)   # (B, K, d)
        gathered = torch.gather(normed, 1, idx)             # (B, K, d) = Hbox[order[t]]
        bos = self.order_bos.expand(B, 1, d)
        return torch.cat([bos, gathered[:, :-1]], dim=1)    # (B, K, d)

    def _mask_pointer_logits(
        self, logits: torch.Tensor, order: torch.Tensor, box_mask: Optional[torch.Tensor]
    ) -> torch.Tensor:
        """Mask padded boxes and, per step, boxes already selected *before* that step
        (exclusive prefix of the gold order -- teacher forcing)."""
        B, K, N = logits.shape
        if box_mask is not None:
            logits = logits.masked_fill(~box_mask.unsqueeze(1), float("-inf"))     # (B,1,N)
        ignore = self.config.label_ignore_index
        order_valid = order.clamp(min=0)
        onehot = F.one_hot(order_valid, num_classes=N).to(logits.dtype)            # (B, K, N)
        onehot = onehot * (order != ignore).unsqueeze(-1).to(logits.dtype)         # zero padded steps
        used_before = torch.cumsum(onehot, dim=1) - onehot                         # exclusive prefix
        return logits.masked_fill(used_before > 0, float("-inf"))

    def _pointer_logits(self, hidden: torch.Tensor, box_hidden_states: torch.Tensor) -> torch.Tensor:
        key = self.pointer_key_proj(box_hidden_states)                            # (B, N, d)
        return torch.matmul(hidden, key.transpose(1, 2)) * self.pointer_scale     # (B, K, N)

    # ------------------------------------------------------------------ #
    # Forward (teacher forcing)
    # ------------------------------------------------------------------ #
    def forward(
        self,
        pixel_values: torch.Tensor,
        ocr_boxes: torch.Tensor,
        order: torch.Tensor,
        box_mask: Optional[torch.Tensor] = None,
        pixel_mask: Optional[torch.Tensor] = None,
        boxes_are_xyxy: bool = True,
    ) -> OrderingOutput:
        """
        Args:
            order: (B, K) gold reading-order permutation over compacted box indices;
                   padded steps = ``label_ignore_index``.
        """
        box_hidden_states = self.encode_boxes(
            pixel_values, ocr_boxes, box_mask=box_mask,
            pixel_mask=pixel_mask, boxes_are_xyxy=boxes_are_xyxy,
        )
        return self._decode_order(box_hidden_states, order, box_mask)

    def _decode_order(self, box_hidden_states, order, box_mask=None):
        """Order-decoder head given a precomputed H_box. Split out of ``forward`` so the
        Phase-3 combined model can share one encoder forward across both decoders."""
        K = order.size(1)
        inp = self._teacher_forcing_inputs(order, box_hidden_states)
        x = self.embed_dropout(inp + self.pos_embedding[:, :K])

        causal_mask = torch.triu(torch.full((K, K), float("-inf"), device=x.device), diagonal=1)
        memory_key_padding_mask = (~box_mask) if box_mask is not None else None
        hidden = self.order_decoder(
            tgt=x, memory=box_hidden_states,
            tgt_mask=causal_mask, memory_key_padding_mask=memory_key_padding_mask,
        )
        hidden = self.decoder_norm(hidden)

        logits = self._pointer_logits(hidden, box_hidden_states)
        logits = self._mask_pointer_logits(logits, order, box_mask)

        loss = None
        valid = order != self.config.label_ignore_index
        if valid.any():
            # only valid steps -> never an all -inf row, so cross-entropy is safe
            loss = F.cross_entropy(logits[valid], order[valid])

        return OrderingOutput(loss=loss, logits=logits, box_hidden_states=box_hidden_states)

    # ------------------------------------------------------------------ #
    # Free-running greedy decode (eval): exactly K steps, guaranteed permutation
    # ------------------------------------------------------------------ #
    @torch.no_grad()
    def generate_order(
        self,
        pixel_values: torch.Tensor,
        ocr_boxes: torch.Tensor,
        box_mask: Optional[torch.Tensor] = None,
        pixel_mask: Optional[torch.Tensor] = None,
        boxes_are_xyxy: bool = True,
    ):
        """Greedy free-running decode. Returns:
            pred_order: (B, K) predicted permutation (compacted box indices). For a
                        sample with ``n_real < K``, only the first ``n_real`` entries
                        are meaningful (later steps are forced and masked out).
            n_real:     (B,) number of real boxes per sample.
        """
        self.eval()
        device = pixel_values.device
        H = self.encode_boxes(
            pixel_values, ocr_boxes, box_mask=box_mask,
            pixel_mask=pixel_mask, boxes_are_xyxy=boxes_are_xyxy,
        )
        B, N, d = H.shape
        normed = self.box_input_norm(H)
        key = self.pointer_key_proj(H)
        mem_kpm = (~box_mask) if box_mask is not None else None

        n_real = (box_mask.sum(dim=1) if box_mask is not None
                  else torch.full((B,), N, device=device, dtype=torch.long))
        K = int(n_real.max())

        used = torch.zeros(B, N, dtype=torch.bool, device=device)
        if box_mask is not None:
            used = used | (~box_mask)                       # padded boxes never selectable
        inp = self.order_bos.expand(B, 1, d).clone()        # (B, 1, d); grows each step
        picks = []
        arange = torch.arange(B, device=device)
        for t in range(K):
            x = inp + self.pos_embedding[:, : t + 1]
            causal = torch.triu(torch.full((t + 1, t + 1), float("-inf"), device=device), diagonal=1)
            hidden = self.order_decoder(tgt=x, memory=H, tgt_mask=causal, memory_key_padding_mask=mem_kpm)
            hidden = self.decoder_norm(hidden)[:, -1]        # (B, d)
            logits = torch.matmul(hidden.unsqueeze(1), key.transpose(1, 2)).squeeze(1) * self.pointer_scale
            logits = logits.masked_fill(used, float("-inf"))
            nxt = logits.argmax(dim=-1)                      # (B,)
            picks.append(nxt)
            used[arange, nxt] = True
            nxt_emb = torch.gather(normed, 1, nxt.view(B, 1, 1).expand(-1, -1, d))
            inp = torch.cat([inp, nxt_emb], dim=1)

        pred_order = (torch.stack(picks, dim=1) if picks
                      else torch.zeros(B, 0, dtype=torch.long, device=device))
        return pred_order, n_real


# --------------------------------------------------------------------------- #
# Stage-2 markdown formatter (EMIT_NEXT + cursor conditioning)
# --------------------------------------------------------------------------- #
@dataclass
class MarkdownOutput:
    loss: Optional[torch.Tensor] = None
    logits: Optional[torch.Tensor] = None             # (B, T, num_special + 1)
    box_hidden_states: Optional[torch.Tensor] = None  # H_box: (B, N, d_model)


class OcrMarkdownFormatterModel(BoxEncoderMixin, nn.Module):
    """Stage-2 formatter: (image, boxes, reading-order) -> markdown.

    The decoder emits over a FIXED vocab ``{num_special specials, EMIT_NEXT}``.
    ``EMIT_NEXT`` places the current cursor block and advances -- there is no box
    pointer, so reading order and exactly-once coverage are guaranteed by
    construction. At every step the block *about to be placed* is added to the
    input as a hint (``H_ord[cursor]``), so the decoder formats for the upcoming
    block (e.g. ``#`` before a heading) without having to predict it.

    ``order`` (B, K) is the reading-order permutation over the compacted boxes:
    gold during Stage-2 training, the order decoder's output at full inference.
    """

    def __init__(
        self,
        config: OcrReconstructionConfig,
        rtdetr: Optional[RTDetrV2Model] = None,
        strict_transformers_version: bool = True,
    ):
        super().__init__()
        self.config = config
        d = config.d_model
        self._init_box_encoder(config, rtdetr, strict_transformers_version)

        self.emit_next_id = config.num_special_tokens          # id just past the specials
        self.vocab_size = config.num_special_tokens + 1        # specials + EMIT_NEXT

        self.token_embedding = nn.Embedding(self.vocab_size, d)
        self.pos_embedding = nn.Parameter(torch.zeros(1, config.max_position_embeddings, d))
        self.cursor_done = nn.Parameter(torch.zeros(1, 1, d))  # hint when cursor == K (all placed)
        self.embed_dropout = nn.Dropout(config.dropout)

        decoder_layer = nn.TransformerDecoderLayer(
            d_model=d,
            nhead=config.markdown_attention_heads,
            dim_feedforward=config.markdown_ffn_dim,
            dropout=config.dropout,
            activation="gelu",
            batch_first=True,
            norm_first=True,
        )
        self.markdown_decoder = nn.TransformerDecoder(decoder_layer, num_layers=config.num_markdown_layers)
        self.decoder_norm = nn.LayerNorm(d)
        self.head = nn.Linear(d, self.vocab_size)  # fixed (M+1) head; no pointer

        self._init_new_weights()

    def _init_new_weights(self):
        nn.init.normal_(self.token_embedding.weight, std=0.02)
        nn.init.normal_(self.pos_embedding, std=0.02)
        nn.init.normal_(self.cursor_done, std=0.02)

    # ------------------------------------------------------------------ #
    # cursor-block hint: H_ord[cursor] added to every input position
    # ------------------------------------------------------------------ #
    def _cursor_hints(self, input_ids, order, box_hidden_states, box_mask):
        """Per-position hint = the (normed) H_box of the block about to be placed.

        cursor[t] = inclusive count of EMIT_NEXT in ``input_ids[:t+1]``; when it
        reaches K (all blocks placed) the hint becomes the learned ``cursor_done``.
        """
        B, T = input_ids.shape
        d = self.config.d_model
        max_K = box_hidden_states.size(1)

        normed = self.box_input_norm(box_hidden_states)                 # (B, max_K, d)
        # reorder into reading order: H_ord[b, j] = normed[b, order[b, j]]
        # clamp(min=0) tolerates an IGNORE-padded order (combined model); padded rows are
        # never read (cursor <= K, done positions use cursor_done).
        order_idx = order.clamp(min=0).unsqueeze(-1).expand(-1, -1, d)
        H_ord = torch.gather(normed, 1, order_idx)                      # (B, max_K, d)

        cursor = torch.cumsum((input_ids == self.emit_next_id).long(), dim=1)   # (B, T), 0..K
        K_b = (box_mask.sum(1) if box_mask is not None
               else torch.full((B,), max_K, device=input_ids.device))           # (B,)
        done = cursor >= K_b.unsqueeze(1)                                        # (B, T)

        gather_idx = cursor.clamp(max=max_K - 1).unsqueeze(-1).expand(-1, -1, d)
        hint = torch.gather(H_ord, 1, gather_idx)                               # (B, T, d)
        return torch.where(done.unsqueeze(-1), self.cursor_done.to(hint.dtype), hint)

    # ------------------------------------------------------------------ #
    # Forward (teacher forcing)
    # ------------------------------------------------------------------ #
    def forward(
        self,
        pixel_values: torch.Tensor,
        ocr_boxes: torch.Tensor,
        decoder_input_ids: torch.Tensor,
        order: torch.Tensor,
        box_mask: Optional[torch.Tensor] = None,
        labels: Optional[torch.Tensor] = None,
        pixel_mask: Optional[torch.Tensor] = None,
        boxes_are_xyxy: bool = True,
    ) -> MarkdownOutput:
        box_hidden_states = self.encode_boxes(
            pixel_values, ocr_boxes, box_mask=box_mask,
            pixel_mask=pixel_mask, boxes_are_xyxy=boxes_are_xyxy,
        )
        return self._decode_markdown(box_hidden_states, decoder_input_ids, order, box_mask, labels)

    def _decode_markdown(self, box_hidden_states, decoder_input_ids, order, box_mask=None, labels=None):
        """Markdown-formatter head given a precomputed H_box. Split out of ``forward`` so
        the Phase-3 combined model can share one encoder forward across both decoders."""
        T = decoder_input_ids.size(1)
        hint = self._cursor_hints(decoder_input_ids, order, box_hidden_states, box_mask)
        tok = self.token_embedding(decoder_input_ids)
        x = self.embed_dropout(tok + self.pos_embedding[:, :T] + hint)

        causal_mask = torch.triu(torch.full((T, T), float("-inf"), device=x.device), diagonal=1)
        memory_key_padding_mask = (~box_mask) if box_mask is not None else None
        hidden = self.markdown_decoder(
            tgt=x, memory=box_hidden_states,
            tgt_mask=causal_mask, memory_key_padding_mask=memory_key_padding_mask,
        )
        hidden = self.decoder_norm(hidden)
        logits = self.head(hidden)

        loss = None
        if labels is not None:
            loss = F.cross_entropy(
                logits.reshape(-1, self.vocab_size), labels.reshape(-1),
                ignore_index=self.config.label_ignore_index,
            )
        return MarkdownOutput(loss=loss, logits=logits, box_hidden_states=box_hidden_states)

    # ------------------------------------------------------------------ #
    # KV-cached single-token decoder step (shared by greedy eval + GRPO sampling)
    # ------------------------------------------------------------------ #
    def _precompute_cross_kv(self, h_box, box_mask):
        """Precompute cross-attention K/V from H_box for every decoder layer.

        H_box is constant within a decode, so these projections are computed once
        before the AR loop and reused each step. Returns per-layer ``(K, V)`` and an
        additive cross-attn mask ``(B, 1, 1, N)`` (0 valid / -inf padded), or None."""
        d = self.config.d_model
        cross_kv = []
        for layer in self.markdown_decoder.layers:
            mha = layer.multihead_attn
            w, b = mha.in_proj_weight, mha.in_proj_bias
            k = F.linear(h_box, w[d : 2 * d], b[d : 2 * d] if b is not None else None)
            v = F.linear(h_box, w[2 * d :],   b[2 * d :]   if b is not None else None)
            cross_kv.append((k, v))
        cross_mask = None
        if box_mask is not None:
            cross_mask = torch.zeros(
                h_box.size(0), 1, 1, h_box.size(1), device=h_box.device, dtype=h_box.dtype,
            ).masked_fill_(~box_mask[:, None, None, :], float("-inf"))
        return cross_kv, cross_mask

    def _ar_decode_step(self, x, self_kv, cross_kv, cross_mask):
        """Single-token incremental decoder step with KV caching. Equivalent to
        ``decoder_norm(markdown_decoder(full_seq))[:, -1:]`` for the last token, but
        O(T) instead of O(T^2). ``x`` is (B, 1, d); returns (hidden (B,1,d), new_self_kv)."""
        d   = self.config.d_model
        H   = self.config.markdown_attention_heads
        d_h = d // H
        B   = x.size(0)
        new_kv = []
        for i, layer in enumerate(self.markdown_decoder.layers):
            # pre-norm self-attention (cache grows each step)
            x_n = layer.norm1(x)
            sa  = layer.self_attn
            w, bsa = sa.in_proj_weight, sa.in_proj_bias
            q_sa  = F.linear(x_n, w[:d],        bsa[:d]        if bsa is not None else None)
            k_new = F.linear(x_n, w[d : 2 * d], bsa[d : 2 * d] if bsa is not None else None)
            v_new = F.linear(x_n, w[2 * d :],   bsa[2 * d :]   if bsa is not None else None)
            past = self_kv[i]
            if past is not None:
                k_all = torch.cat([past[0], k_new], dim=1)
                v_all = torch.cat([past[1], v_new], dim=1)
            else:
                k_all, v_all = k_new, v_new
            new_kv.append((k_all, v_all))
            T_kv = k_all.size(1)
            q_mh = q_sa.view(B, 1,    H, d_h).transpose(1, 2)
            k_mh = k_all.view(B, T_kv, H, d_h).transpose(1, 2)
            v_mh = v_all.view(B, T_kv, H, d_h).transpose(1, 2)
            sa_out = F.scaled_dot_product_attention(q_mh, k_mh, v_mh)
            sa_out = sa_out.transpose(1, 2).contiguous().view(B, 1, d)
            sa_out = F.linear(sa_out, sa.out_proj.weight, sa.out_proj.bias)
            x = x + layer.dropout1(sa_out)
            # pre-norm cross-attention (K/V precomputed from H_box)
            x_n  = layer.norm2(x)
            ca   = layer.multihead_attn
            q_ca = F.linear(x_n, ca.in_proj_weight[:d], ca.in_proj_bias[:d] if ca.in_proj_bias is not None else None)
            k_pre, v_pre = cross_kv[i]
            N = k_pre.size(1)
            q_mh = q_ca.view(B, 1, H, d_h).transpose(1, 2)
            k_mh = k_pre.view(B, N, H, d_h).transpose(1, 2)
            v_mh = v_pre.view(B, N, H, d_h).transpose(1, 2)
            ca_out = F.scaled_dot_product_attention(q_mh, k_mh, v_mh, attn_mask=cross_mask)
            ca_out = ca_out.transpose(1, 2).contiguous().view(B, 1, d)
            ca_out = F.linear(ca_out, ca.out_proj.weight, ca.out_proj.bias)
            x = x + layer.dropout2(ca_out)
            # pre-norm FFN
            x_n = layer.norm3(x)
            x   = x + layer.dropout3(layer.linear2(layer.dropout(layer.activation(layer.linear1(x_n)))))
        return self.decoder_norm(x), new_kv

    # ------------------------------------------------------------------ #
    # Structural EMIT/EOS mask + cursor hint (single source of truth for
    # generation AND the GRPO log-prob recompute, so the two stay consistent)
    # ------------------------------------------------------------------ #
    def _reorder_normed(self, order, box_hidden_states):
        """H_ord[b, j] = box_input_norm(H_box)[b, order[b, j]] -- boxes in reading order."""
        d = self.config.d_model
        normed = self.box_input_norm(box_hidden_states)
        order_idx = order.clamp(min=0).unsqueeze(-1).expand(-1, -1, d)
        return torch.gather(normed, 1, order_idx)

    def _emit_eos_mask_full(self, input_ids, box_mask):
        """Additive (B, T, V) logit mask: at each position EMIT_NEXT is -inf once all K
        blocks are placed (cursor >= K), else EOS is -inf. cursor = inclusive cumsum of
        EMIT_NEXT over ``input_ids`` -- identical rule to the per-step generation mask."""
        B, T = input_ids.shape
        device = input_ids.device
        cursor = torch.cumsum((input_ids == self.emit_next_id).long(), dim=1)     # (B, T)
        K_b = (box_mask.sum(1) if box_mask is not None
               else torch.full((B,), 1 << 30, device=device))
        done = cursor >= K_b.unsqueeze(1)                                          # (B, T)
        mask = torch.zeros(B, T, self.vocab_size, device=device)
        neg = torch.full((B, T), float("-inf"), device=device)
        zero = torch.zeros(B, T, device=device)
        mask[..., self.emit_next_id] = torch.where(done, neg, zero)
        mask[..., self.config.eos_token_id] = torch.where(done, zero, neg)
        return mask

    # ------------------------------------------------------------------ #
    # KV-cached AR core: greedy (eval) and multinomial (GRPO) share one loop
    # ------------------------------------------------------------------ #
    def _ar_generate(self, box_hidden_states, order, box_mask=None,
                     max_new_tokens=1024, sample=False, temperature=1.0, debug_logits=None):
        """Autoregressive decode with KV cache. Returns ``(sequences, logprobs, valid)``:
            sequences (B, S) sampled ids incl. the BOS prefix,
            logprobs  (B, S) log-prob of each token under the temperature-1 policy
                      (0.0 at BOS col 0 and post-EOS pad columns),
            valid     (B, S) bool, True for real actions up to and INCLUDING the first EOS.
        Greedy (``sample=False``) reproduces the full-recompute generate_markdown exactly."""
        cfg = self.config
        device = box_hidden_states.device
        B, max_K, d = box_hidden_states.size(0), box_hidden_states.size(1), self.config.d_model
        emit_id, eos_id, pad_id, bos_id = self.emit_next_id, cfg.eos_token_id, cfg.pad_token_id, cfg.bos_token_id

        H_ord = self._reorder_normed(order, box_hidden_states)                     # (B, max_K, d)
        K_b = (box_mask.sum(1) if box_mask is not None
               else torch.full((B,), max_K, device=device, dtype=torch.long))
        cross_kv, cross_mask = self._precompute_cross_kv(box_hidden_states, box_mask)
        self_kv = [None] * len(self.markdown_decoder.layers)

        generated = torch.full((B, 1), bos_id, dtype=torch.long, device=device)
        logprobs = torch.zeros((B, 1), dtype=torch.float32, device=device)
        valid = torch.zeros((B, 1), dtype=torch.bool, device=device)
        cursor = torch.zeros(B, dtype=torch.long, device=device)
        finished = torch.zeros(B, dtype=torch.bool, device=device)

        for t in range(max_new_tokens):
            cur = generated[:, t]                                                  # (B,)
            cursor = cursor + (cur == emit_id).long()                              # emits incl. pos t
            done = cursor >= K_b
            gidx = cursor.clamp(max=max_K - 1).view(B, 1, 1).expand(-1, 1, d)
            hint = torch.where(done.view(B, 1, 1),
                               self.cursor_done.to(H_ord.dtype),
                               torch.gather(H_ord, 1, gidx))                        # (B, 1, d)
            x = self.token_embedding(cur).unsqueeze(1) + self.pos_embedding[:, t:t + 1] + hint
            hidden, self_kv = self._ar_decode_step(x, self_kv, cross_kv, cross_mask)
            logits = self.head(hidden[:, -1]).float()                              # (B, V)
            logits[done, emit_id] = float("-inf")                                  # no blocks left
            logits[~done, eos_id] = float("-inf")                                  # can't stop early

            if debug_logits is not None:                                           # instrumentation only
                debug_logits.append({"cursor": cursor.detach().clone(),            # (B,) blocks placed so far
                                     "done": done.detach().clone(),                # (B,) all blocks placed?
                                     "logits": logits.detach().clone()})           # (B, V) post-mask

            logp_all = torch.log_softmax(logits, dim=-1)                           # temperature-1 policy
            if sample:
                next_token = torch.multinomial(torch.softmax(logits / temperature, dim=-1), 1).squeeze(1)
            else:
                next_token = logits.argmax(-1)

            was_finished = finished
            chosen_lp = logp_all.gather(1, next_token.view(B, 1)).squeeze(1)
            chosen_lp = torch.where(was_finished, torch.zeros_like(chosen_lp), chosen_lp)
            next_token = torch.where(was_finished, torch.full_like(next_token, pad_id), next_token)

            generated = torch.cat([generated, next_token.view(B, 1)], dim=1)
            logprobs = torch.cat([logprobs, chosen_lp.view(B, 1)], dim=1)
            valid = torch.cat([valid, (~was_finished).view(B, 1)], dim=1)
            finished = finished | (next_token == eos_id)
            if bool(finished.all()):
                break

        return generated, logprobs, valid

    # ------------------------------------------------------------------ #
    # Free-running greedy decode (eval): exactly K EMIT_NEXTs then EOS
    # ------------------------------------------------------------------ #
    @torch.no_grad()
    def generate_markdown(
        self,
        pixel_values: torch.Tensor,
        ocr_boxes: torch.Tensor,
        order: torch.Tensor,
        box_mask: Optional[torch.Tensor] = None,
        pixel_mask: Optional[torch.Tensor] = None,
        boxes_are_xyxy: bool = True,
        max_new_tokens: int = 1024,
    ) -> torch.Tensor:
        """KV-cached greedy decode given a reading order. EMIT_NEXT masked once all blocks
        are placed, EOS masked until they are -> exactly K blocks, in order, then EOS."""
        self.eval()
        H_box = self.encode_boxes(
            pixel_values, ocr_boxes, box_mask=box_mask,
            pixel_mask=pixel_mask, boxes_are_xyxy=boxes_are_xyxy,
        )
        seq, _, _ = self._ar_generate(H_box, order, box_mask, max_new_tokens=max_new_tokens, sample=False)
        return seq

    # ------------------------------------------------------------------ #
    # Multinomial rollout (GRPO): KV-cached sampling with per-token log-probs
    # ------------------------------------------------------------------ #
    @torch.no_grad()
    def sample_markdown(
        self,
        pixel_values: torch.Tensor,
        ocr_boxes: torch.Tensor,
        order: torch.Tensor,
        box_mask: Optional[torch.Tensor] = None,
        pixel_mask: Optional[torch.Tensor] = None,
        boxes_are_xyxy: bool = True,
        max_new_tokens: int = 1024,
        temperature: float = 1.0,
    ):
        """Sampling twin of :meth:`generate_markdown` for GRPO. Returns
        ``(sequences, old_logprobs, valid)``. Pass a precomputed H_box to
        :meth:`_ar_generate` directly to encode once and share it across G rollouts."""
        self.eval()
        H_box = self.encode_boxes(
            pixel_values, ocr_boxes, box_mask=box_mask,
            pixel_mask=pixel_mask, boxes_are_xyxy=boxes_are_xyxy,
        )
        return self._ar_generate(H_box, order, box_mask, max_new_tokens=max_new_tokens,
                                 sample=True, temperature=temperature)

    @torch.no_grad()
    def debug_generate(
        self,
        pixel_values: torch.Tensor,
        ocr_boxes: torch.Tensor,
        order: torch.Tensor,
        box_mask: Optional[torch.Tensor] = None,
        pixel_mask: Optional[torch.Tensor] = None,
        boxes_are_xyxy: bool = True,
        max_new_tokens: int = 1024,
        sample: bool = False,
        temperature: float = 1.0,
    ):
        """Instrumented twin of :meth:`generate_markdown` / :meth:`sample_markdown`.

        Runs the SAME KV-cached loop but also captures, at every step, the post-mask
        logits + the cursor -- for debugging free-running pathologies (repetition loops,
        early EOS, a stuck cursor). Returns ``(sequences, records)`` where ``records`` is
        a per-step list of ``{'cursor': (B,), 'done': (B,), 'logits': (B, V)}``. Decoding
        is unaffected -- ``sample=False`` is the exact greedy path used at inference."""
        self.eval()
        H_box = self.encode_boxes(
            pixel_values, ocr_boxes, box_mask=box_mask,
            pixel_mask=pixel_mask, boxes_are_xyxy=boxes_are_xyxy,
        )
        records = []
        seq, _, _ = self._ar_generate(H_box, order, box_mask, max_new_tokens=max_new_tokens,
                                      sample=sample, temperature=temperature, debug_logits=records)
        return seq, records

    def token_logprobs(self, box_hidden_states, sequences, order, box_mask=None):
        """Teacher-forced per-token log-probs of ``sequences`` under the current policy,
        for the GRPO update. Predicts positions 1..S-1 from 0..S-2 and applies the SAME
        EMIT/EOS mask as sampling, so log-probs match the rollout (ratio ~= 1 at init).
        Grad-capable; call under ``eval()`` (dropout off) for consistency with sampling."""
        inp, tgt = sequences[:, :-1], sequences[:, 1:]
        logits = self._decode_markdown(box_hidden_states, inp, order, box_mask).logits.float()
        logits = logits + self._emit_eos_mask_full(inp, box_mask)
        logp = torch.log_softmax(logits, dim=-1)
        return logp.gather(-1, tgt.unsqueeze(-1)).squeeze(-1)                       # (B, S-1)


# --------------------------------------------------------------------------- #
# Phase-3 combined model (shared encoder, order + markdown heads)
# --------------------------------------------------------------------------- #
@dataclass
class TwoStageOutput:
    loss: Optional[torch.Tensor] = None            # w_order*order_loss + w_format*format_loss
    order_loss: Optional[torch.Tensor] = None      # detached, for logging
    format_loss: Optional[torch.Tensor] = None     # detached, for logging
    order_logits: Optional[torch.Tensor] = None    # (B, K, N)
    format_logits: Optional[torch.Tensor] = None   # (B, T, M+1)
    box_hidden_states: Optional[torch.Tensor] = None


class OcrTwoStageModel(nn.Module):
    """Phase-3 combined model: one shared box encoder feeding BOTH the order decoder and
    the markdown formatter, trained jointly with ``L = w_order*L_order + w_format*L_format``.

    The two sub-models share the encoder (``rtdetr`` / ``box_content_mlp`` /
    ``box_input_norm``) by reference, so ``encode_boxes`` runs once and both losses backprop
    into the same H_box -- which is what lets the encoder balance both tasks. (The tied
    encoder appears under both ``order.*`` and ``formatter.*`` in ``state_dict``; the values
    are identical and ``named_parameters`` de-duplicates them for the optimizer.)
    """

    def __init__(
        self,
        config: OcrReconstructionConfig,
        rtdetr: Optional[RTDetrV2Model] = None,
        strict_transformers_version: bool = True,
        w_order: float = 1.0,
        w_format: float = 1.0,
    ):
        super().__init__()
        self.config = config
        self.order = OcrOrderingModel(
            config, rtdetr=rtdetr, strict_transformers_version=strict_transformers_version)
        # share the SAME encoder objects with the formatter (one set of weights, one H_box)
        self.formatter = OcrMarkdownFormatterModel(
            config, rtdetr=self.order.rtdetr, strict_transformers_version=False)
        self.formatter.box_content_mlp = self.order.box_content_mlp
        self.formatter.box_input_norm = self.order.box_input_norm
        self.w_order, self.w_format = w_order, w_format

    def encode_boxes(self, *args, **kwargs):
        return self.order.encode_boxes(*args, **kwargs)

    def forward(
        self,
        pixel_values: torch.Tensor,
        ocr_boxes: torch.Tensor,
        order: torch.Tensor,             # 0-padded -> format cursor
        order_label: torch.Tensor,       # IGNORE-padded -> order-decoder loss
        decoder_input_ids: torch.Tensor,
        labels: torch.Tensor,
        box_mask: Optional[torch.Tensor] = None,
        pixel_mask: Optional[torch.Tensor] = None,
        boxes_are_xyxy: bool = True,
    ) -> TwoStageOutput:
        H = self.order.encode_boxes(
            pixel_values, ocr_boxes, box_mask=box_mask,
            pixel_mask=pixel_mask, boxes_are_xyxy=boxes_are_xyxy,
        )
        o = self.order._decode_order(H, order_label, box_mask)
        f = self.formatter._decode_markdown(H, decoder_input_ids, order, box_mask, labels)

        loss = None
        if o.loss is not None and f.loss is not None:
            loss = self.w_order * o.loss + self.w_format * f.loss
        return TwoStageOutput(
            loss=loss,
            order_loss=(o.loss.detach() if o.loss is not None else None),
            format_loss=(f.loss.detach() if f.loss is not None else None),
            order_logits=o.logits, format_logits=f.logits, box_hidden_states=H,
        )

    # -- end-to-end inference: order decoder -> its predicted order -> formatter -- #
    @torch.no_grad()
    def generate_end_to_end(self, pixel_values, ocr_boxes, box_mask=None,
                            pixel_mask=None, boxes_are_xyxy=True, max_new_tokens=1024):
        """Full pipeline with the order decoder's OWN predicted order (double-encodes;
        eval-only). Returns (generated_markdown_ids, pred_order, n_real)."""
        pred_order, n_real = self.order.generate_order(
            pixel_values, ocr_boxes, box_mask=box_mask,
            pixel_mask=pixel_mask, boxes_are_xyxy=boxes_are_xyxy)
        gen = self.formatter.generate_markdown(
            pixel_values, ocr_boxes, pred_order, box_mask=box_mask,
            pixel_mask=pixel_mask, boxes_are_xyxy=boxes_are_xyxy, max_new_tokens=max_new_tokens)
        return gen, pred_order, n_real


__all__ = [
    "OcrReconstructionConfig",
    "OcrReconstructionOutput",
    "OcrTextReconstructionModel",
    "OrderingOutput",
    "OcrOrderingModel",
    "MarkdownOutput",
    "OcrMarkdownFormatterModel",
    "TwoStageOutput",
    "OcrTwoStageModel",
    "box_xyxy_to_cxcywh",
    "inverse_sigmoid",
    "MLP",
]
