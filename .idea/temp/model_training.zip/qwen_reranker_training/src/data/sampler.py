from torch.utils.data import Sampler
import torch
import random
import numpy as np
import pickle
from transformers import AutoTokenizer
from tqdm import tqdm
tqdm.pandas()
import logging

logger = logging.getLogger(__name__)


class CustomBatchSampler(Sampler):
    def __init__(self, dataframe, batch_size, shuffle=True, drop_last=False):
        self.indices = list(dataframe.index)
        self.batch_size = batch_size
        self.drop_last = drop_last
        self.shuffle = shuffle
        self.n_records = len(dataframe)

    def __iter__(self):
        indices = self.indices.copy()
        if self.shuffle:
            np.random.shuffle(indices)

        batches = []
        for i in range(0, len(indices), self.batch_size):
            batch = indices[i:i + self.batch_size]
            if len(batch) == self.batch_size or not self.drop_last:
                batches.append(batch)

        return iter(batches)

    def __len__(self):
        if self.drop_last:
            return self.n_records // self.batch_size
        else:
            return self.n_records


class FixedBatchGroupByLenSampler(Sampler):
    def __init__(self, df, batch_size, config):
        self.n_records = len(df)
        self.batch_size = batch_size

        if "n_tokens" not in df.columns:
            logger.info("Computing token lengths...")
            tokenizer = AutoTokenizer.from_pretrained(config["model"]["hugging_face_card"])
            
            prefix_tokens = config['tokenizer']['prefix']
            suffix_tokens = config['tokenizer']['suffix']
            I_Q_D_pairs = df.progress_apply(
                lambda row: f"<Instruct>: {row['instruction']}\n<Query>: {row['query']}\n<Document>: {row['doc']}", axis=1).tolist()
           
            df['prompt'] = prefix_tokens + I_Q_D_pairs + suffix_tokens 

            df["n_tokens"] = df["prompt"].progress_apply(
                lambda text: len(tokenizer(text)["input_ids"])
            )

        self.sorted_idx_lst = list(df.sort_values("n_tokens").index)

    def __len__(self):
        return self.n_records

    def __iter__(self):
        sorted_idx_lst = self.sorted_idx_lst.copy()
        total = len(sorted_idx_lst)

        while total > 0:
            if self.batch_size >= total:
                start_idx = 0
                end_idx = total
            else:
                random_idx = random.randrange(total - self.batch_size + 1)
                start_idx = random_idx
                end_idx = random_idx + self.batch_size

            sampled_indexes = sorted_idx_lst[start_idx:end_idx]
            del sorted_idx_lst[start_idx:end_idx]
            total = len(sorted_idx_lst)

            yield sampled_indexes


class DynamicBatchGroupByLengthSampler(Sampler):
    def __init__(self, df, dynamic_batch_size_dict, config):
        self.n_records = len(df)
        self.dynamic_batch_size_dict = dynamic_batch_size_dict

        if "n_tokens" not in df.columns:
            logger.info("Computing token lengths...")
            tokenizer = AutoTokenizer.from_pretrained(config["tokenizer"]["tokenizer_name"])
            
            prefix_tokens = config['tokenizer']['prefix']
            suffix_tokens = config['tokenizer']['suffix']
            I_Q_D_pairs = df.progress_apply(
                lambda row: f"<Instruct>: {row['instruction']}\n<Query>: {row['query']}\n<Document>: {row['doc']}", axis=1).tolist()
           
            df['prompt'] = prefix_tokens + I_Q_D_pairs + suffix_tokens 

            df["n_tokens"] = df["prompt"].progress_apply(
                lambda text: len(tokenizer(text)["input_ids"])
            )


        self.idx_seq_len_lst = list(
            zip(df.sort_values("n_tokens").index, df.sort_values("n_tokens")["n_tokens"])
        )

    def _get_batch_size(self, seq_len):
        for seq_len_range, batch_size in self.dynamic_batch_size_dict.items():
            if seq_len <= seq_len_range:
                return batch_size
        return min(self.dynamic_batch_size_dict.values())

    def __len__(self):
        return self.n_records

    def __iter__(self):
        idx_seq_len_lst = self.idx_seq_len_lst.copy()
        min_batch_size = min(self.dynamic_batch_size_dict.values())
        total = len(idx_seq_len_lst)

        while total > 0:
            if min_batch_size >= total:
                start_idx = 0
                end_idx = total
            else:
                random_idx = random.randrange(min_batch_size, total)
                batch_size = self._get_batch_size(idx_seq_len_lst[random_idx][1])
                start_idx = random_idx
                end_idx = max(0, random_idx - batch_size)

            sampled_values = idx_seq_len_lst[start_idx:end_idx]
            sampled_indexes = [x[0] for x in sampled_values]

            del idx_seq_len_lst[start_idx:end_idx]
            total = len(idx_seq_len_lst)

            yield sampled_indexes


def get_sampler(train_df, val_df, config):
    """
    This function is used to get the sampler specified in the Config file.
    Args:
        config (Dict[str, Union[int, str]]): Config dictionary containing all the params & hyperparams.
    Returns:
        train_sampler, val_sampler
    """

    if config["dataloader"]["sampler"] == "group_by_length":
        if config["dataloader"]["batching_type"] == "dynamic":
            dynamic_batch_dict = pickle.load(open(config["dataloader"]["dynamic_batch_size_dict_path"], "rb"))
            train_sampler = DynamicBatchGroupByLengthSampler(train_df, dynamic_batch_dict, config)
            val_sampler = DynamicBatchGroupByLengthSampler(val_df, dynamic_batch_dict, config)

        elif config["dataloader"]["batching_type"] == "fixed":
            train_sampler = FixedBatchGroupByLenSampler(train_df, config["dataloader"]["batch_size_train"], config)
            val_sampler = FixedBatchGroupByLenSampler(val_df, config["dataloader"]["batch_size_val"], config)

        else:
            raise ValueError("Invalid batching_type. Only supports 'fixed' and 'dynamic'.")

    else:
        if config["dataloader"]["batching_type"] != "fixed":
            assert config["dataloader"]["batching_type"] == "fixed", \
                "Dynamic Batching is only supported in GroupByLength sampler."

        train_sampler = CustomBatchSampler(train_df, config["dataloader"]["batch_size_train"], shuffle=True)
        val_sampler = CustomBatchSampler(val_df, config["dataloader"]["batch_size_val"], shuffle=False)

    return train_sampler, val_sampler
