# Usage

## 1. Requirements

| | |
|---|---|
| GPU | NVIDIA, ≥ 24 GB (defaults tuned on a 48 GB L40S) |
| Driver | ≥ 580 for the default base image (CUDA 13). For 575–579 build with `BASE_IMAGE=vllm/vllm-openai:v0.23.0-cu129` |
| Docker | with the NVIDIA container toolkit (`docker run --gpus` must work) |
| Disk | ~25 GB for the image, plus a cache directory (~1 GB) |
| Network | only for `make build` (base image and pip packages); running is fully offline |

## 2. Build

```bash
cd vllm_ocr_model
make build                                   # -> vllm-ocr-model:latest
make build BASE_IMAGE=vllm/vllm-openai:v0.23.0-cu129 TAG=cu129   # older drivers
```

The build runs the CPU unit tests at the end, so a broken dependency fails the build
rather than a later run.

**Hosts without internet or registry access:** build on a machine that has both, then:

```bash
make save                                    # -> vllm-ocr-model-latest.tar.gz
# copy the tarball and this directory to the target host, then there:
make load
```

## 3. First run on a new host: the self-test

```bash
make selftest PDF_DIR=/data/some_pdfs MODEL=/models/stage3/best.pt
```

This builds the image and takes up to 20 pages from born-digital PDFs in `PDF_DIR`. It
builds a Textract-layout OCR dataframe from their embedded text layer and runs the
container on those pages with one engine. It fails unless every page comes back `ok`. The
output goes to `./selftest/out`.

It exercises the whole plumbing: the Docker build, GPU access, checkpoint conversion,
engine start, rendering, decoding and output writing. It does **not** measure quality,
because text-layer lines differ from Textract lines.

## 4. Inputs

### 4.1 PDF directory (`PDF_DIR` / `--pdf-dir`)

Any directory, searched recursively for `*.pdf` (case-insensitive). The directory is
mounted read-only.

### 4.2 Textract OCR dataframe (`OCR_DF` / `--ocr-df`)

A pandas dataframe saved as `.parquet`, `.pkl`/`.pickle`, `.csv` or `.jsonl`/`.json`. It
has one row per page, and **the rows are the work list**: only pages that appear in the
dataframe are processed.

| column | type | meaning |
|---|---|---|
| `file_name` | str | the PDF, matched against `pdf-dir` by (1) relative path, (2) base name, (3) base name + `.pdf` |
| `page` | int | page number, **1-based** by default (as in training: `doc[page - 1]`); `--page-base 0` if 0-based |
| `content` | str | the page's OCR text: lines separated by `\n`, words within a line by `\t` |
| `line_cords` | str | one bounding box per line, separated by `\|`. Each box is `x1,x2,y1,y2`, normalized to [0, 1] |

Example row:

```text
file_name   invoice_0042.pdf
page        1
content     "INVOICE\nBill\tTo:\tACME\tCorp\nTotal\tDue\t$1,250.00"
line_cords  "0.40,0.60,0.05,0.08|0.10,0.45,0.15,0.18|0.60,0.90,0.80,0.83"
```

How the dataframe is interpreted:
- `line_cords` are **x1, x2, y1, y2**, and they are reordered to `(x1, y1), (x2, y2)` (xyxy),
  the layout the model was trained on. Swapped corners are fixed, and values are clipped
  to [0, 1].
- Line *i* of `content` is paired with box *i* of `line_cords`. The model's box pointers
  index this list, so the pairing must be exact. If the line count differs from the box
  count, the page is skipped with status `line_box_mismatch` rather than guessed.
- Tabs inside a line become spaces in the markdown.
- Pages with no lines are skipped (`no_lines`), as are pages with more than `--max-boxes`
  lines (default 1024, the model's limit; `too_many_boxes`).
- If the same `(file_name, page)` appears again, only the first row is processed and later
  rows get `duplicate_row`.

### 4.3 Model (`MODEL`, or `ORDER_CKPT` + `FORMATTER_CKPT`)

These are the `torch.save` files the v0.1 training scripts write. Either the bare state
dict or `{"model": state_dict, ...}` (as the trainers save it) works.

| You have | Pass |
|---|---|
| a stage-3 combined checkpoint (keys `order.*`, `formatter.*`) | `MODEL=/path/best.pt` |
| a stage-1 order checkpoint + a stage-2 or stage-4 (GRPO) formatter | `ORDER_CKPT=... FORMATTER_CKPT=...` |
| a stage-3 checkpoint + a newer formatter (e.g. GRPO) | `MODEL=... FORMATTER_CKPT=...` (the formatter replaces the combined one's) |
| an already converted model directory | `MODEL=/path/to/converted_dir` |

- **Shared encoder:** the RT-DETR box encoder is taken from the order checkpoint, as in
  `stage_3_train._init_two_stage`. Add `RUN_ARGS="--encoder-from formatter"` to take it
  from the formatter checkpoint instead.
- **Conversion:** on the first run the checkpoint(s) are converted to a vLLM model
  directory and cached in `CACHE_DIR` (keyed by path, size, mtime and options), so later
  runs reuse it. The training checkpoints carry no config, so every dimension is inferred
  from tensor shapes. The one exception is the decoder attention-head count (default 8;
  `--decoder-heads` if you changed it).
- **Vocab:** the markdown vocab is `src/ocr_vllm/assets/vocab.json`, copied from
  `scripts_v0.1/vocab.json`. If you retrain with a different vocab, replace that file and
  rebuild.

## 5. Running

```bash
make run PDF_DIR=/data/pdfs OCR_DF=/data/textract.parquet MODEL=/models/best.pt OUT_DIR=/data/out
make run PDF_DIR=... OCR_DF=... ORDER_CKPT=/m/order.pt FORMATTER_CKPT=/m/grpo.pt OUT_DIR=...
make run ... RUN_ARGS="--engines 2 --limit 500"      # any runner flag via RUN_ARGS
make run ... GPU=1                                    # pick the GPU (default 0)
```

`make run` mounts each input's parent directory read-only, `OUT_DIR` read-write, and
`CACHE_DIR` (default `./.cache`) at `/cache`. It passes `--gpus` and `--ipc=host`.

The equivalent plain `docker run`:

```bash
docker run --rm --gpus '"device=0"' --ipc=host \
  -v /data/pdfs:/data/pdfs:ro \
  -v /data:/mnt/ocr:ro \
  -v /models:/mnt/model:ro \
  -v /data/out:/data/out \
  -v $PWD/.cache:/cache \
  vllm-ocr-model:latest \
  --pdf-dir /data/pdfs --ocr-df /mnt/ocr/textract.parquet \
  --model /mnt/model/best.pt --out-dir /data/out
```

Other targets:

| target | what it does |
|---|---|
| `make shell` | bash inside the image (with the cache mounted) |
| `make test` | CPU unit tests inside the image |
| `docker run --rm vllm-ocr-model --help` | every runner flag |
| `docker run --rm --entrypoint ocr-vllm-convert vllm-ocr-model --help` | the standalone checkpoint converter |

### 5.1 Runner flags

| flag | default | meaning |
|---|---|---|
| `--pdf-dir` | required | PDF directory |
| `--ocr-df` | required | Textract OCR dataframe |
| `--out-dir` | required | output directory |
| `--model` | | combined checkpoint or converted dir |
| `--order-ckpt` / `--formatter-ckpt` | | split checkpoints |
| `--encoder-from` | `order` | which checkpoint supplies the RT-DETR encoder |
| `--dtype` | `bfloat16` | `float32` is closer to the training-time numerics but slower |
| `--decoder-heads` | 8 | attention heads of the decoders (not inferable from weights) |
| `--max-boxes` | 1024 | pages with more lines are skipped (the model's limit is 1024) |
| `--page-base` | 1 | numbering of the `page` column |
| `--limit N` | | only the first N rows |
| `--save-order` | off | store each page's predicted reading order in `results.jsonl` |
| `--save-tokens` | off | store each page's raw formatter token ids in `results.jsonl` |
| `--cache-dir` | `/cache` | converted model + compile caches |
| `--engines` | 4 | vLLM engine processes sharing the GPU |
| `--max-seqs` | 160 | pages in flight per engine |
| `--wave` | 40 | pages admitted to an engine at a time |
| `--gpu-memory` | 0.86 | GPU memory fraction for all engines together |
| `--block-size` | 32 | vLLM KV-cache block size |
| `--preprocess-workers` | from the CPU quota | PDF rendering processes |
| `--raster-zoom` | 2.0 | PDF render scale (training used 2.0) |
| `--mps` | `auto` | CUDA MPS daemon: `auto` = on when `--engines > 1` |

Suggested settings per GPU (starting points; tune with [performance.md](performance.md)):

| GPU | flags |
|---|---|
| 48 GB (L40S, A6000) | defaults |
| 80 GB (A100/H100) | `--engines 4 --max-seqs 256` (not measured) |
| 24 GB (L4, A10) | `--engines 2 --max-seqs 128` (not measured) |

## 6. Outputs

```
OUT_DIR/
  markdown/<pdf name without .pdf>/page_0001.md   one file per page with status ok
  results.jsonl       one line per dataframe row, written as pages finish
  results.parquet     file_name, page, status, markdown (in dataframe row order)
  summary.json        status counts, throughput, settings
```

`results.jsonl` fields: `file_name`, `page`, `status`, `num_lines`, and for `ok` pages
`markdown_path` and `num_tokens`. With the save flags it also has `reading_order` (box
indices = line numbers) and `formatter_ids`, plus `error` for failures.

**Page statuses**

| status | meaning | action |
|---|---|---|
| `ok` | markdown written | |
| `missing_pdf` | `file_name` not found under `pdf-dir` | check names / paths |
| `no_lines` | empty `content` | nothing to reconstruct |
| `line_box_mismatch` | number of `\n` lines ≠ number of `\|` boxes | fix the OCR export |
| `bad_cords` | a box is not four comma-separated numbers | fix the OCR export |
| `too_many_boxes` | more than `--max-boxes` lines | the model supports ≤ 1024 |
| `duplicate_row` | same file and page as an earlier row | |
| `page_out_of_range` | the page number doesn't exist in the PDF | check `--page-base` |
| `render_error` | PyMuPDF could not render the page | see `error` |
| `engine_error` | the engine rejected or failed the page | see `error` and the log |
| `not_processed` | the run ended before this page (e.g. an engine crashed) | see the log |

**`summary.json`**

| field | meaning |
|---|---|
| `pages_per_s` | pages ok ÷ time since the first engine was ready (includes the sequential engine startup) |
| `pages_per_s_all_engines` | rate after every engine was ready (steady state) |
| `engines_ready` | engines that came up; fewer than `engines` means one failed or the job finished first |

**Markdown format.** It is what the model emits: markdown with HTML tables (`<table>`,
`<tr>`, `<td colspan="2">`, …), lists, headings and emphasis tags. The text comes verbatim
from the OCR lines, since the model never generates text. Figures and images appear as
`<<-------IMG----->>` / `<<-------FIGURE----->>` placeholders, as in the training data.

The process exits 0 when every page was either processed or skipped for a known reason,
and 1 if any page is `not_processed`.

## 7. Running without Docker

On a machine with the same stack (Python 3.12, a CUDA 13 driver):

```bash
python -m venv venv && . venv/bin/activate
pip install vllm==0.23.0 -r requirements.txt
pip install .
ocr-vllm-run --pdf-dir ... --ocr-df ... --model ... --out-dir ... --cache-dir ./.cache
```

Set `OMP_NUM_THREADS=1 RAYON_NUM_THREADS=1` in the environment, as the image does (the
plugin also enforces it), and `HF_HUB_OFFLINE=1` if the machine has no internet.
