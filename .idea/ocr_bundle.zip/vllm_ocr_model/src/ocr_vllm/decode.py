"""Formatter token stream -> markdown / HTML text.

Mirrors ``CustomTokenizer.decode`` from the training code (scripts_v0.1/tokenizer.py)
without its matching dependencies: EMIT_NEXT places the OCR line at the current reading-
order cursor, specials render through the same table, and repeated ``<COLSPAN>`` /
``<ROWSPAN>`` fold into ``colspan=`` / ``rowspan=`` on the tag that opened them.
"""

from __future__ import annotations

import json
from pathlib import Path

DEFAULT_VOCAB = Path(__file__).with_name("assets") / "vocab.json"

_TOKEN_RENDER = {
    "<IMG>": "<<-------IMG----->>",
    "<FIGURE>": "<<-------FIGURE----->>",
    "<PICTURE>": "<<-------PICTURE----->>",
    "<INPUT_CHECKED>": '<input type="checkbox" checked>',
    "<INPUT_UNCHECKED>": '<input type="checkbox">',
    "<BR>": "<br>",
    "<BR/>": "<br>",
}
_CONTROL_TOKENS = ("<bos>", "<eos>", "<pad>", "<unk>")
# tags that may be followed by <COLSPAN>/<ROWSPAN> (tokenizer._TAG_TO_VOCAB values)
_OPENABLE = {"TABLE", "TR", "TD", "TH", "THEAD", "TBODY", "TFOOT", "CAPTION", "UL", "OL", "LI",
             "SPAN", "SMALL", "SUP", "SUB", "B", "STRONG", "I"}


def _render_token(token: str) -> str:
    if token in _TOKEN_RENDER:
        return _TOKEN_RENDER[token]
    if token.startswith("</") and token.endswith(">"):
        return f"</{token[2:-1].lower()}>"
    if token.startswith("<") and token.endswith(">") and token not in _CONTROL_TOKENS:
        return f"<{token[1:-1].lower()}>"
    return token


class MarkdownDecoder:
    def __init__(self, vocab_path: str | Path = DEFAULT_VOCAB):
        tokens: dict[str, int] = json.loads(Path(vocab_path).read_text(encoding="utf-8"))["tokens"]
        base = min(tokens.values())
        self.num_special = max(tokens.values()) - base + 1
        self.id_to_token = {i - base: t for t, i in tokens.items()}
        self.openable = {f"<{t}>" for t in _OPENABLE if f"<{t}>" in tokens}

    def decode(self, order: list[int], fmt_ids: list[int], lines: list[str]) -> str:
        """order: box index per reading-order step; fmt_ids: model-compact formatter ids
        (EMIT_NEXT = num_special); lines: OCR text per box."""
        emit = self.num_special
        parts: list[str] = []
        pending: str | None = None
        colspan = rowspan = 0
        cursor = 0

        def flush():
            nonlocal pending, colspan, rowspan
            if pending is None:
                return
            attrs = (f' colspan="{colspan}"' if colspan >= 2 else "") + \
                    (f' rowspan="{rowspan}"' if rowspan >= 2 else "")
            parts.append(f"<{pending.lower()}{attrs}>")
            pending, colspan, rowspan = None, 0, 0

        for t in fmt_ids:
            if t == emit:
                if cursor < len(order) and 0 <= order[cursor] < len(lines):
                    flush()
                    parts.append(lines[order[cursor]])
                cursor += 1
                continue
            token = self.id_to_token.get(t)
            if token is None:
                continue
            if token in ("<COLSPAN>", "<ROWSPAN>"):
                if pending is not None:
                    if token == "<COLSPAN>":
                        colspan += 1
                    else:
                        rowspan += 1
                continue
            flush()
            if token == "<eos>":
                break
            if token in ("<bos>", "<pad>", "<unk>"):
                continue
            if token in self.openable:
                pending = token[1:-1]
                continue
            parts.append(_render_token(token))
        flush()
        return "".join(parts)
