#!/usr/bin/env python3
"""Retrieval Evaluation V0.2. See README.md and evaluation.md for the metric contract."""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import re
from collections import defaultdict
from datetime import datetime, timezone
from pathlib import Path
from statistics import mean
from typing import Any, Mapping

VERSION = "V0.2"
CATEGORIES = (
    "code_resolver", "signs_and_symptoms", "therapeutic_treatment",
    "diagnostic_procedure", "clinical_evaluation",
)
GRADES = {"not_relevant": 0, "less_relevant": 1, "relevant": 2, "highly_relevant": 3}
POSITIVE_LABELS = ("less_relevant", "relevant", "highly_relevant")
DEFAULT_KS = (10, 20, 50, 100)
QUERY_GROUPS = ("all", "positive", "no_positive")

RANKING_METRICS = ("ndcg", "recall", "normalized_recall", "precision", "ap", "rr")
BINARY_METRICS = (
    "correct_rejection_at_k", "false_alarm_at_k",
    "false_positive_rate_at_k", "positive_evidence_hit_at_k",
)
PER_QUERY_COLUMNS = (
    "audit_id", "pdf_filename", "category", "query", "query_group", "k", "effective_k",
    "n_chunks", "n_positive", "n_negative", "n_highly_relevant", "n_relevant",
    "n_less_relevant", "n_not_relevant", "n_positive_at_k", "n_predicted_positive_at_k",
    "tp_at_k", "fp_at_k", "tn_at_k", "fn_at_k", "n_score_ties",
    *RANKING_METRICS, *BINARY_METRICS,
)
SUMMARY_METRICS = (
    "ndcg", "recall", "normalized_recall", "precision", "map", "mrr",
    "correct_rejection_rate", "false_alarm_rate", "false_positive_rate",
    "positive_evidence_hit_rate",
)
QUERY_TO_SUMMARY_METRIC = {
    "ndcg": "ndcg", "recall": "recall", "normalized_recall": "normalized_recall",
    "precision": "precision", "map": "ap", "mrr": "rr",
    "correct_rejection_rate": "correct_rejection_at_k",
    "false_alarm_rate": "false_alarm_at_k",
    "false_positive_rate": "false_positive_rate_at_k",
    "positive_evidence_hit_rate": "positive_evidence_hit_at_k",
}
SUMMARY_COLUMNS = (
    "category", "query_group", "k", "n_queries", "n_category_queries", "n_documents",
    "n_positive_queries", "n_no_positive_queries", "no_positive_rate",
    "n_short_pools", "mean_effective_k",
    *(f"n_valid_{name}" for name in SUMMARY_METRICS),
    *SUMMARY_METRICS,
)


class EvaluationError(ValueError):
    """Invalid input or inconsistent evaluation configuration."""


def parse_chunk_id(chunk_id: Any) -> tuple[str, str]:
    """Extract document key (audit_id, pdf_filename); retain original chunk ID for sorting."""
    if not isinstance(chunk_id, str) or not chunk_id.strip():
        raise EvaluationError(f"Invalid chunk_id: {chunk_id!r}")
    try:
        audit_id, suffix = chunk_id.split(":", 1)
        filename, page, chunk = suffix.rsplit(":", 2)
        if not audit_id or not filename or not page.isdecimal() or not chunk.isdecimal():
            raise ValueError("empty segment or invalid numeric identifier")
    except ValueError as exc:
        raise EvaluationError(
            f"Invalid chunk_id {chunk_id!r}; expected "
            "audit_id:pdf_filename:page_number:chunk_number"
        ) from exc
    return audit_id, filename


def to_mapping(value: Any, location: str) -> dict[str, Any]:
    """Accept CSV JSON strings, native dicts, and Arrow map pair-list representations."""
    if isinstance(value, str):
        try:
            # Reject duplicate object keys: silently overwriting labels changes the benchmark.
            def no_duplicates(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
                result: dict[str, Any] = {}
                for k, v in pairs:
                    if k in result:
                        raise EvaluationError(f"{location}: duplicate JSON key {k!r}")
                    result[k] = v
                return result
            value = json.loads(value, object_pairs_hook=no_duplicates)
        except json.JSONDecodeError as exc:
            raise EvaluationError(f"{location}: invalid JSON: {exc}") from exc
    if isinstance(value, Mapping):
        result = dict(value)
    elif isinstance(value, (list, tuple)):
        result = {}
        for item in value:
            if not isinstance(item, (tuple, list)) or len(item) != 2:
                raise EvaluationError(f"{location}: invalid Arrow map pair {item!r}")
            k, v = item
            if k in result:
                raise EvaluationError(f"{location}: duplicate map key {k!r}")
            result[k] = v
    else:
        raise EvaluationError(f"{location}: expected a dictionary or JSON object")
    if any(not isinstance(k, str) or not k.strip() for k in result):
        raise EvaluationError(f"{location}: keys must be non-empty strings")
    return result


def flatten(value: Any, kind: str, location: str) -> dict[tuple[str, str], int | float]:
    outer = to_mapping(value, location)
    flattened: dict[tuple[str, str], int | float] = {}
    for category, query_data in outer.items():
        if category not in CATEGORIES:
            raise EvaluationError(f"{location}: unknown category {category!r}; allowed: {CATEGORIES}")
        for query, val in to_mapping(query_data, f"{location}/{category}").items():
            loc = f"{location}/{category}/{query}"
            if kind == "ground_truth":
                if not isinstance(val, str) or val not in GRADES:
                    raise EvaluationError(f"{loc}: invalid label {val!r}; allowed: {tuple(GRADES)}")
                result: int | float = GRADES[val]
            elif kind == "score":
                if isinstance(val, bool) or not isinstance(val, (float, int)):
                    raise EvaluationError(f"{loc}: score must be numeric, got {val!r}")
                if not math.isfinite(float(val)):
                    raise EvaluationError(f"{loc}: score must be finite, got {val!r}")
                result = float(val)
            elif kind == "binary":
                if type(val) is not int or val not in (0, 1):
                    raise EvaluationError(f"{loc}: binary prediction must be integer 0 or 1, got {val!r}")
                result = val
            else:
                raise AssertionError(f"Unexpected kind {kind!r}")
            flattened[(category, query)] = result
    return flattened


def read_rows(path: Path, required_cols: tuple[str, ...]) -> list[dict[str, Any]]:
    if not path.is_file():
        raise EvaluationError(f"Input not found: {path}")
    if path.suffix.lower() == ".csv":
        with path.open(encoding="utf-8-sig", newline="") as stream:
            reader = csv.DictReader(stream)
            if reader.fieldnames is None or len(reader.fieldnames) != len(set(reader.fieldnames)):
                raise EvaluationError(f"{path}: missing or duplicate CSV header")
            if set(reader.fieldnames) != set(required_cols):
                raise EvaluationError(
                    f"{path}: expected exactly {required_cols}, got {reader.fieldnames}"
                )
            rows = list(reader)
            if any(None in r or any(v is None for v in r.values()) for r in rows):
                raise EvaluationError(f"{path}: malformed CSV row or missing field")
            return rows
    if path.suffix.lower() == ".parquet":
        try:
            import pyarrow.parquet as pq
        except ImportError as exc:
            raise EvaluationError("Parquet I/O requires pyarrow: pip install -r requirements.txt") from exc
        table = pq.read_table(path)
        if len(table.column_names) != len(set(table.column_names)) or set(table.column_names) != set(required_cols):
            raise EvaluationError(f"{path}: expected exactly {required_cols}, got {table.column_names}")
        return table.to_pylist()
    raise EvaluationError(f"{path}: expected .csv or .parquet")


def load_dataset(path: Path, kind: str) -> dict[tuple[str, str], dict[str, Any]]:
    columns = ("chunk_id", "labels") if kind == "ground_truth" else (
        "chunk_id", "labels", "binary_predictions"
    )
    rows = read_rows(path, columns)
    if not rows:
        raise EvaluationError(f"{path}: empty input file")
    documents: dict[tuple[str, str], dict[str, Any]] = defaultdict(dict)
    for idx, row in enumerate(rows, start=2):
        cid = row["chunk_id"]
        doc = parse_chunk_id(cid)
        if cid in documents[doc]:
            raise EvaluationError(f"{path}: duplicate chunk_id {cid!r}")
        if kind == "ground_truth":
            value = flatten(row["labels"], "ground_truth", f"{path.name}:row{idx}:labels")
        else:
            score = flatten(row["labels"], "score", f"{path.name}:row{idx}:labels")
            binary = flatten(row["binary_predictions"], "binary", f"{path.name}:row{idx}:binary_predictions")
            if score.keys() != binary.keys():
                missing = sorted(score.keys() - binary.keys())[:3]
                extra = sorted(binary.keys() - score.keys())[:3]
                raise EvaluationError(
                    f"{path}: chunk {cid}: binary/score keys disagree; "
                    f"missing binary={missing}, unexpected binary={extra}"
                )
            value = {"scores": score, "binary": binary}
        documents[doc][cid] = value
    return dict(documents)


def prepare_queries(ground: dict, prediction: dict) -> list[tuple[str, str, str, str, list[tuple[str, int, float, int]]]]:
    if ground.keys() != prediction.keys():
        raise EvaluationError(
            f"Document mismatch: missing={sorted(ground.keys() - prediction.keys())[:3]}, "
            f"extra={sorted(prediction.keys() - ground.keys())[:3]}"
        )
    tasks: list[tuple[str, str, str, str, list[tuple[str, int, float, int]]]] = []
    for (audit_id, pdf_filename), gt_chunks in sorted(ground.items()):
        pred_chunks = prediction[(audit_id, pdf_filename)]
        if gt_chunks.keys() != pred_chunks.keys():
            raise EvaluationError(
                f"Document {(audit_id, pdf_filename)!r}: chunk IDs mismatch; "
                f"missing={sorted(gt_chunks.keys() - pred_chunks.keys())[:3]}, "
                f"extra={sorted(pred_chunks.keys() - gt_chunks.keys())[:3]}"
            )
        keys = set().union(*(values.keys() for values in gt_chunks.values()))
        if not keys:
            raise EvaluationError(f"Document {(audit_id, pdf_filename)!r}: no queries")
        for cid in sorted(gt_chunks):
            gt_keys = set(gt_chunks[cid])
            score_keys = set(pred_chunks[cid]["scores"])
            if gt_keys != keys:
                raise EvaluationError(
                    f"Incomplete ground truth for {cid}: missing keys={sorted(keys - gt_keys)[:4]}; "
                    "every chunk in a PDF must have labels for every query of that PDF"
                )
            if score_keys != keys:
                raise EvaluationError(
                    f"Prediction keys mismatch for {cid}: missing={sorted(keys - score_keys)[:4]}; "
                    f"extra={sorted(score_keys - keys)[:4]}"
                )
        for category, query in sorted(keys, key=lambda x: (CATEGORIES.index(x[0]), x[1])):
            entries = [
                (cid, int(gt_chunks[cid][(category, query)]),
                 float(pred_chunks[cid]["scores"][(category, query)]),
                 int(pred_chunks[cid]["binary"][(category, query)]))
                for cid in sorted(gt_chunks)
            ]
            tasks.append((audit_id, pdf_filename, category, query, entries))
    return tasks


def dcg(grades: list[int]) -> float:
    return sum((2 ** grade - 1) / math.log2(i + 2) for i, grade in enumerate(grades))


def evaluate_query(
    audit_id: str, pdf_filename: str, category: str, query: str,
    entries: list[tuple[str, int, float, int]], ks: tuple[int, ...] = DEFAULT_KS,
) -> list[dict[str, Any]]:
    """Compute per-query ranking and binary metrics at each K."""
    if not entries:
        raise EvaluationError("Cannot evaluate a query with no candidate chunks")
    ranked = sorted(entries, key=lambda e: (-e[2], e[0]))
    grades = [e[1] for e in ranked]
    n = len(ranked)
    r = sum(grade >= 1 for grade in grades)
    query_group = "positive" if r else "no_positive"
    counts = {grade: grades.count(grade) for grade in range(4)}
    ideal = sorted(grades, reverse=True)
    # Number of tied elements beyond the first occurrence for each equal score.
    tied = n - len({e[2] for e in ranked})
    results: list[dict[str, Any]] = []
    for k in ks:
        k_eff = min(k, n)
        top = ranked[:k_eff]
        top_grades = grades[:k_eff]
        hits = sum(g >= 1 for g in top_grades)
        tp = sum(g >= 1 and binary == 1 for _, g, _, binary in top)
        fp = sum(g == 0 and binary == 1 for _, g, _, binary in top)
        fn = sum(g >= 1 and binary == 0 for _, g, _, binary in top)
        tn = sum(g == 0 and binary == 0 for _, g, _, binary in top)
        assert tp + fp + fn + tn == k_eff
        accumulated_precision = 0.0
        found = 0
        first_positive_rank = None
        for rank, (_, grade, _, _) in enumerate(top, start=1):
            if grade >= 1:
                found += 1
                accumulated_precision += found / rank
                if first_positive_rank is None:
                    first_positive_rank = rank
        idcg = dcg(ideal[:k_eff])
        result = {
            "audit_id": audit_id, "pdf_filename": pdf_filename,
            "category": category, "query": query, "query_group": query_group,
            "k": k, "effective_k": k_eff, "n_chunks": n, "n_positive": r,
            "n_negative": counts[0], "n_highly_relevant": counts[3],
            "n_relevant": counts[2], "n_less_relevant": counts[1],
            "n_not_relevant": counts[0], "n_positive_at_k": hits,
            "n_predicted_positive_at_k": tp + fp,
            "tp_at_k": tp, "fp_at_k": fp, "tn_at_k": tn, "fn_at_k": fn,
            "n_score_ties": tied,
            # Ranking metrics: deliberately defined only for positive queries.
            "ndcg": dcg(top_grades) / idcg if r else None,
            "recall": hits / r if r else None,
            "normalized_recall": hits / min(k_eff, r) if r else None,
            "precision": hits / k_eff if r else None,
            "ap": accumulated_precision / r if r else None,
            "rr": (1 / first_positive_rank if first_positive_rank else 0.0) if r else None,
            # A no-positive query triggers a false alarm if ANY top-K chunk is predicted 1.
            "correct_rejection_at_k": int(fp == 0) if not r else None,
            "false_alarm_at_k": int(fp > 0) if not r else None,
            "false_positive_rate_at_k": fp / k_eff if not r else None,
            "positive_evidence_hit_at_k": int(tp > 0) if r else None,
        }
        results.append(result)
    return results


def aggregate(rows: list[dict[str, Any]], ks: tuple[int, ...]) -> list[dict[str, Any]]:
    grouped: dict[tuple[str, str, int], list[dict[str, Any]]] = defaultdict(list)
    category_rows: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for row in rows:
        for category in (row["category"], "overall"):
            for group in ("all", row["query_group"]):
                grouped[(category, group, row["k"])].append(row)
            # Just one per query instance (not four cutoffs).
            if row["k"] == ks[0]:
                category_rows[category].append(row)

    def average(items: list[dict], key: str) -> float | None:
        vals = [r[key] for r in items if r[key] is not None]
        return mean(vals) if vals else None

    summary: list[dict[str, Any]] = []
    for category in (*CATEGORIES, "overall"):
        base = category_rows[category]
        n_base = len(base)
        n_no_pos = sum(row["query_group"] == "no_positive" for row in base)
        n_pos = n_base - n_no_pos
        for group in QUERY_GROUPS:
            for k in ks:
                subset = grouped[(category, group, k)]
                row = {
                    "category": category, "query_group": group, "k": k,
                    "n_queries": len(subset), "n_category_queries": n_base,
                    "n_documents": len({(x["audit_id"], x["pdf_filename"]) for x in subset}),
                    "n_positive_queries": n_pos, "n_no_positive_queries": n_no_pos,
                    "no_positive_rate": n_no_pos / n_base if n_base else None,
                    "n_short_pools": sum(x["effective_k"] < k for x in subset),
                    "mean_effective_k": average(subset, "effective_k"),
                }
                for metric, per_query_name in QUERY_TO_SUMMARY_METRIC.items():
                    row[f"n_valid_{metric}"] = sum(x[per_query_name] is not None for x in subset)
                    row[metric] = average(subset, per_query_name)
                summary.append(row)
    return summary


def validate_ks(ks: tuple[int, ...]) -> None:
    if not ks or any(type(k) is not int or k <= 0 for k in ks) or len(set(ks)) != len(ks):
        raise EvaluationError("Cutoffs must be distinct positive integers")


def evaluate_files(
    ground_truth: Path, predictions: Path, ks: tuple[int, ...] = DEFAULT_KS,
) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    validate_ks(ks)
    gt = load_dataset(ground_truth, "ground_truth")
    pred = load_dataset(predictions, "prediction")
    tasks = prepare_queries(gt, pred)
    per_query = [
        result for audit, pdf, category, query, entries in tasks
        for result in evaluate_query(audit, pdf, category, query, entries, ks)
    ]
    return per_query, aggregate(per_query, ks)


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def write_csv(path: Path, rows: list[dict[str, Any]], columns: tuple[str, ...]) -> None:
    with path.open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=columns, extrasaction="raise")
        writer.writeheader()
        writer.writerows(rows)


def write_parquet(path: Path, rows: list[dict[str, Any]]) -> None:
    try:
        import pyarrow as pa
        import pyarrow.parquet as pq
    except ImportError as exc:
        raise EvaluationError(
            "Writing Parquet requires pyarrow: pip install -r requirements.txt; "
            "for a CSV-only trial, use --per-query-format csv"
        ) from exc
    int_columns = {
        "k", "effective_k", "n_chunks", "n_positive", "n_negative",
        "n_highly_relevant", "n_relevant", "n_less_relevant", "n_not_relevant",
        "n_positive_at_k", "n_predicted_positive_at_k", "tp_at_k", "fp_at_k",
        "tn_at_k", "fn_at_k", "n_score_ties",
        "correct_rejection_at_k", "false_alarm_at_k", "positive_evidence_hit_at_k",
    }
    fields = [
        pa.field(col, pa.int64() if col in int_columns else
                 pa.float64() if col in RANKING_METRICS or col in BINARY_METRICS else
                 pa.string())
        for col in PER_QUERY_COLUMNS
    ]
    schema = pa.schema(fields)
    pq.write_table(pa.Table.from_pylist(rows, schema=schema), path, compression="zstd")


def run(
    ground_truth: Path, predictions: Path, *, run_id: str, model_id: str | None = None,
    output_dir: Path = Path("evaluation_results"), ks: tuple[int, ...] = DEFAULT_KS,
    per_query_format: str = "parquet", threshold_notes: str | None = None,
) -> Path:
    if not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_.-]*", run_id) or run_id in (".", ".."):
        raise EvaluationError("--run-id must contain only letters, digits, underscores, dots, hyphens")
    if per_query_format not in ("parquet", "csv"):
        raise EvaluationError("--per-query-format must be parquet or csv")
    validate_ks(ks)
    if per_query_format == "parquet":
        try:
            import pyarrow  # noqa: F401
        except ImportError as exc:
            raise EvaluationError("Parquet output needs pyarrow; install requirements.txt") from exc
    out = output_dir / run_id
    if out.exists():
        raise EvaluationError(f"Run already exists; refusing to overwrite: {out}")
    per_query, summary = evaluate_files(ground_truth, predictions, ks)
    # Validate full calculation before making output directory.
    n_query_instances = len(per_query) // len(ks)
    base_query_rows = [r for r in per_query if r["k"] == ks[0]]
    num_positive = sum(r["query_group"] == "positive" for r in base_query_rows)
    num_no_positive = n_query_instances - num_positive
    metadata = {
        "evaluation_version": VERSION,
        "ground_truth_schema_version": "V0.1", "prediction_schema_version": "V0.2",
        "run_id": run_id, "model_id": model_id or run_id,
        "evaluated_at_utc": datetime.now(timezone.utc).isoformat(),
        "ground_truth": str(ground_truth.resolve()), "ground_truth_sha256": sha256(ground_truth),
        "predictions": str(predictions.resolve()), "predictions_sha256": sha256(predictions),
        "k_values": list(ks), "categories": list(CATEGORIES),
        "positive_labels": list(POSITIVE_LABELS), "negative_labels": ["not_relevant"],
        "gain": "2^grade-1", "ap_denominator": "total_positive_chunks_in_document_query",
        "short_pool_policy": "effective_k=min(requested_k,number_of_chunks)",
        "score_ties": "descending_score_then_ascending_chunk_id",
        "thresholding": "external; binary_predictions consumed as supplied",
        "threshold_notes": threshold_notes,
        "strict_full_coverage": True,
        "undefined_metric_policy": "null; aggregate using non-null per-query values",
        "ranking_metrics_on_no_positive_queries": "null (including precision and rr)",
        "aggregation": "unweighted_macro_average_over_document_query_instances",
        "overall_group_metric_policy": "non-null across applicable group only",
        "n_query_instances": n_query_instances,
        "n_positive_queries": num_positive,
        "n_no_positive_queries": num_no_positive,
        "no_positive_rate": num_no_positive / n_query_instances if n_query_instances else None,
        "n_documents": len({(r["audit_id"], r["pdf_filename"]) for r in base_query_rows}),
        "summary_file": "summary.csv", "per_query_file": f"per_query.{per_query_format}",
    }
    out.mkdir(parents=True, exist_ok=False)
    try:
        write_csv(out / "summary.csv", summary, SUMMARY_COLUMNS)
        if per_query_format == "parquet":
            write_parquet(out / "per_query.parquet", per_query)
        else:
            write_csv(out / "per_query.csv", per_query, PER_QUERY_COLUMNS)
        (out / "metadata.json").write_text(json.dumps(metadata, indent=2) + "\n", encoding="utf-8")
    except Exception:
        # Don't leave a confusing partial run after a failed write.
        import shutil
        shutil.rmtree(out)
        raise
    return out


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--ground-truth", required=True, type=Path)
    parser.add_argument("--predictions", required=True, type=Path)
    parser.add_argument("--run-id", required=True)
    parser.add_argument("--model-id", default=None)
    parser.add_argument("--output-dir", type=Path, default=Path("evaluation_results"))
    parser.add_argument("--ks", default="10,20,50,100")
    parser.add_argument("--per-query-format", choices=("parquet", "csv"), default="parquet")
    parser.add_argument("--threshold-notes", default=None,
                        help="Optional provenance text for your externally chosen threshold")
    args = parser.parse_args(argv)
    try:
        try:
            ks = tuple(int(v.strip()) for v in args.ks.split(","))
        except ValueError as exc:
            raise EvaluationError("--ks must be comma-separated positive integers") from exc
        path = run(args.ground_truth, args.predictions, run_id=args.run_id,
                   model_id=args.model_id, output_dir=args.output_dir, ks=ks,
                   per_query_format=args.per_query_format, threshold_notes=args.threshold_notes)
        print(f"Completed evaluation: {path}")
        return 0
    except (EvaluationError, OSError) as exc:
        parser.exit(2, f"Evaluation error: {exc}\n")


if __name__ == "__main__":
    raise SystemExit(main())
