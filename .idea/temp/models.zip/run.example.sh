#!/usr/bin/env bash
PYTHONPATH=src python -m docling_lite.cli.main \
  --ocr-df-path "../sample_data/ocr_df.parquet" \
  --pdf-dir "../sample_data/pdfs" \
  --layout-batch-size 1 \
  --layout-model-path "docling-project/docling-layout-heron" \
  --table-batch-size 1 \
  --table-model-path "../models/tableformer_v2" \
  --device cpu \
  --dtype full_fp_32 \
  --output-dir "../smoke_runs/sample_data_manual_run" \
  --batch-name "sample_data_manual_run"


# python -m docling_lite.cli.main --ocr-df-path "../sample_data/ocr_df.parquet" --pdf-dir "../sample_data/pdfs" --layout-batch-size 1 --layout-model-path "docling-project/docling-layout-heron" --table-batch-size 1 --table-model-path "../models/tableformer_v2" --device cpu --dtype full_fp_32 --output-dir "../smoke_runs/sample_data_manual_run" --batch-name "sample_data_manual_run"

