"""
Inference for the OCR Text Reconstruction model.
================================================

Given a page image + its OCR boxes/texts, greedily decode the Markdown-like
reconstruction. The model emits ids in the model-compact scheme:

    id <  num_special (17)  -> special markdown token  (data.SPECIAL_ID_TO_STR)
    id >= num_special       -> pointer to box (id - 17) -> copy ocr_texts[id - 17]

IMPORTANT: at inference there is NO compaction. Feed every OCR box you have, in
the SAME order as ocr_texts, with boxes normalized to [0, 1] xyxy (exactly how
training data was normalized). A predicted pointer indexes directly into that list.

Note (v1 behavior): the model was trained only on boxes that appear in the target
(no "skip" supervision), so at inference it tends to place every box it is given;
junk boxes (page numbers, running headers) may get included.
"""

from __future__ import annotations

import torch

import backup_code.data as data
from backup_code.modeling_ocr_reconstruction import OcrReconstructionConfig, OcrTextReconstructionModel


def load_model(ckpt_path: str, device, backbone: str = "docling-project/docling-layout-heron"):
    """Build the architecture (loads Heron for correct shapes) then overwrite with
    the trained checkpoint. Point ``backbone`` at a local dir to avoid re-downloading."""
    cfg = OcrReconstructionConfig(backbone_name_or_path=backbone)
    model = OcrTextReconstructionModel(cfg).to(device).eval()
    ck = torch.load(ckpt_path, map_location=device)
    state = ck["model"] if isinstance(ck, dict) and "model" in ck else ck
    info = model.load_state_dict(state, strict=False)
    if info.missing_keys or info.unexpected_keys:
        print(f"load_state_dict: missing {len(info.missing_keys)}, "
              f"unexpected {len(info.unexpected_keys)}")
    return model, cfg


def decode_to_markdown(model_ids, ocr_texts, num_special: int = data.NUM_SPECIAL_TOKENS) -> str:
    """Turn a model-compact id sequence into Markdown text, substituting box
    pointers with their OCR line text. Stops at <eos>; skips <bos>/<pad>."""
    out = []
    for m in model_ids:
        m = int(m)
        if m < num_special:
            if m == 1:           # <eos>
                break
            if m in (0, 2):      # <bos>, <pad>
                continue
            out.append(data.SPECIAL_ID_TO_STR.get(m, ""))
        else:
            idx = m - num_special
            if 0 <= idx < len(ocr_texts):
                out.append(ocr_texts[idx])
    return "".join(out)


@torch.no_grad()
def reconstruct(model, image, ocr_boxes_xyxy_norm, ocr_texts, image_processor,
                device, max_new_tokens: int = 1024) -> str:
    """
    Args:
        image:               PIL.Image (page).
        ocr_boxes_xyxy_norm: (N, 4) list/array, x1,y1,x2,y2 normalized to [0,1].
        ocr_texts:           list of N strings, SAME order as the boxes.
    """
    pixel_values = image_processor(images=image, return_tensors="pt")["pixel_values"].to(device)
    boxes = torch.as_tensor(ocr_boxes_xyxy_norm, dtype=torch.float32, device=device).unsqueeze(0)  # (1,N,4)
    box_mask = torch.ones(1, boxes.size(1), dtype=torch.bool, device=device)

    ids = model.generate(
        pixel_values=pixel_values, ocr_boxes=boxes, box_mask=box_mask,
        boxes_are_xyxy=True, max_new_tokens=max_new_tokens,
    )
    return decode_to_markdown(ids[0].tolist(), ocr_texts)


if __name__ == "__main__":
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    model, cfg = load_model("runs/v1/best.pt", device)
    image_processor = data.load_image_processor()

    # ---- get a page image (PyMuPDF example; any PIL RGB image works) ----
    import fitz

    doc = fitz.open("example.pdf")
    page = doc[0]
    image = data.rasterize_page(page, zoom=2.0)

    # ---- your OCR output for this page ----
    # boxes normalized to [0,1] xyxy, in the SAME order as ocr_texts
    ocr_boxes = [
        [0.10, 0.05, 0.90, 0.09],
        [0.10, 0.12, 0.45, 0.15],
        [0.55, 0.12, 0.90, 0.15],
    ]
    ocr_texts = ["Patient Details", "Name: John", "Age: 45"]

    markdown = reconstruct(model, image, ocr_boxes, ocr_texts, image_processor, device)
    print(markdown)
