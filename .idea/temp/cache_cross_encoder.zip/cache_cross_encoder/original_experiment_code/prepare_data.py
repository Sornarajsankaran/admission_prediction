#!/usr/bin/env python3
"""Reproducible synthetic clinical cross-encoder workload and shared timing model.

This dataset is synthetic, contains no real patients, and has no relevance labels.
The public checkpoint is MLM-only. The derived CLS/GELU scoring model is for
performance and numerical equivalence experiments, not medical quality testing.
"""
from __future__ import annotations

import argparse
import json
import random
import shutil
from pathlib import Path

import torch
from huggingface_hub import snapshot_download
from transformers import AutoConfig, AutoModelForSequenceClassification, AutoTokenizer

MODEL_ID = "thomas-sounack/BioClinical-ModernBERT-base"
MODEL_REVISION = "c3648aa87af95837c809e6f0c5f85d08160db437"
SEED = 20261112

# Codes and descriptions are synthetic search inputs, not a coding reference.
CONDITIONS = [
    ("E11.9", "Type 2 diabetes mellitus without complications", "diabetes"),
    ("I10", "Essential hypertension", "hypertension"),
    ("I50.9", "Heart failure unspecified", "heart failure"),
    ("J44.9", "Chronic obstructive pulmonary disease unspecified", "COPD"),
    ("N18.3", "Chronic kidney disease stage 3", "chronic kidney disease"),
    ("I48.91", "Unspecified atrial fibrillation", "atrial fibrillation"),
    ("E78.5", "Hyperlipidemia unspecified", "hyperlipidemia"),
    ("D64.9", "Anemia unspecified", "anemia"),
    ("J45.909", "Unspecified asthma uncomplicated", "asthma"),
    ("F32.A", "Depression unspecified", "depression"),
    ("I25.10", "Atherosclerotic heart disease", "coronary artery disease"),
    ("E03.9", "Hypothyroidism unspecified", "hypothyroidism"),
    ("G47.33", "Obstructive sleep apnea", "sleep apnea"),
    ("K21.9", "Gastroesophageal reflux disease without esophagitis", "reflux"),
    ("M81.0", "Age related osteoporosis without current fracture", "osteoporosis"),
    ("I63.9", "Cerebral infarction unspecified", "stroke"),
    ("G20", "Parkinson disease", "Parkinson disease"),
    ("E66.9", "Obesity unspecified", "obesity"),
    ("F41.9", "Anxiety disorder unspecified", "anxiety"),
    ("M19.90", "Unspecified osteoarthritis unspecified site", "osteoarthritis"),
    ("N40.0", "Benign prostatic hyperplasia", "prostatic hyperplasia"),
    ("K76.0", "Fatty liver", "fatty liver"),
    ("B18.2", "Chronic viral hepatitis C", "hepatitis C"),
    ("G40.909", "Epilepsy unspecified", "seizure disorder"),
    ("I73.9", "Peripheral vascular disease unspecified", "peripheral vascular disease"),
]


def save_json(path: Path, value) -> None:
    path.write_text(json.dumps(value, indent=2) + "\n")


def summarize(values):
    values = torch.as_tensor(values, dtype=torch.float32)
    return {"min": int(values.min()), "mean": float(values.mean()),
            "p50": float(values.median()), "max": int(values.max())}


def prepare(root: Path, chunks: int, query_width: int, skip_download: bool) -> None:
    torch.set_num_threads(8)
    random.seed(SEED)
    torch.manual_seed(SEED)
    base = root / "models" / "bioclinical-base"
    model_dir = root / "models" / "benchmark-cls"
    data_dir = root / "data"
    data_dir.mkdir(parents=True, exist_ok=True)
    if not skip_download:
        snapshot_download(MODEL_ID, revision=MODEL_REVISION, local_dir=str(base), allow_patterns=["*.json", "*.safetensors", "*.txt", "README.md"])
    tokenizer = AutoTokenizer.from_pretrained(base)
    encode = lambda s: tokenizer.encode(s, add_special_tokens=False)
    prefix, suffix = encode("<DOC>"), encode("</DOC>") + [tokenizer.sep_token_id]
    docs, raw_lengths, doc_records = [], [], []
    attributes = ["diagnosis", "treatment and monitoring"]
    queries, query_records = [], []
    for code, description, keyterm in CONDITIONS:
        for attribute in attributes:
            text = f"<QUERY> ICD code: {code}({description})\nattribute: {attribute}\n search keyterm: {keyterm}</QUERY>"
            ids = [tokenizer.cls_token_id] + encode(text) + [tokenizer.sep_token_id]
            if len(ids) > query_width:
                raise ValueError(f"Query requires {len(ids)} tokens but width is {query_width}")
            query_records.append({"query_id": len(queries), "icd_code": code,
                                  "icd_code_description": description, "attribute": attribute,
                                  "keyterm": keyterm, "text": f"[CLS] {text}[SEP]",
                                  "token_count": len(ids)})
            queries.append(ids)

    for i in range(chunks):
        code, description, keyterm = CONDITIONS[i % len(CONDITIONS)]
        second = CONDITIONS[(i * 7 + 3) % len(CONDITIONS)][2]
        age = 28 + (i * 13) % 65
        page, part = divmod(i, 5)
        # Every chunk contains a unique synthetic note identifier before truncation.
        note = (
            f"Synthetic record MR0001 page {page + 1} chunk {part + 1} note {i:06d}. "
            f"The patient is {age} years old and is seen for follow up of {keyterm}. "
            f"Past medical history includes {second}. "
            f"Blood pressure {110 + i % 47}/{60 + i % 29} mmHg, pulse {55 + i % 45}, "
            f"respiratory rate {12 + i % 9}, oxygen saturation {94 + i % 6} percent. "
            f"The clinical assessment documents {description.lower()}. "
            "Medication reconciliation was completed. Symptoms are reviewed with the patient. "
            "No acute distress is observed. The lungs are clear to auscultation. "
            "The abdomen is soft and nontender. Relevant laboratory results and prior imaging were reviewed. "
            "The care team discussed treatment adherence, home monitoring, and return precautions. "
            "Follow up is planned after repeat laboratory testing. "
        )
        # Sizing is performed on content tokens before document delimiters are added.
        raw = encode(note * 3)[:256]
        assert len(raw) == 256
        ids = prefix + raw + suffix
        docs.append(ids)
        raw_lengths.append(len(raw))
        doc_records.append({"record_id": "MR0001", "page": page + 1, "chunk": part + 1,
                            "chunk_id": i, "text": tokenizer.decode(raw),
                            "raw_token_count": len(raw), "wrapped_token_count": len(ids)})

    def padded(seqs, width):
        out = torch.full((len(seqs), width), tokenizer.pad_token_id, dtype=torch.long)
        mask = torch.zeros((len(seqs), width), dtype=torch.bool)
        for row, values in enumerate(seqs):
            out[row, :len(values)] = torch.tensor(values)
            mask[row, :len(values)] = True
        return out, mask

    doc_width = max(map(len, docs))
    query_ids, query_mask = padded(queries, query_width)
    doc_ids, doc_mask = padded(docs, doc_width)
    payload = {
        "query_input_ids": query_ids, "query_attention_mask": query_mask,
        "doc_input_ids": doc_ids, "doc_attention_mask": doc_mask,
        "query_lengths": query_mask.sum(1), "doc_lengths": doc_mask.sum(1),
        "raw_doc_lengths": torch.tensor(raw_lengths), "seed": SEED,
        "pad_token_id": tokenizer.pad_token_id,
    }
    torch.save(payload, data_dir / "tokenized.pt")
    for name, rows in [("queries", query_records), ("chunks", doc_records)]:
        with (data_dir / f"{name}.jsonl").open("w") as fh:
            for row in rows:
                fh.write(json.dumps(row) + "\n")
    metadata = {
        "seed": SEED, "model_id": MODEL_ID, "model_revision": MODEL_REVISION, "synthetic": True,
        "records": 1, "pages": (chunks + 4) // 5, "chunks": chunks,
        "queries": len(queries), "pairs": chunks * len(queries),
        "query_tensor_width": query_width, "doc_tensor_width": doc_width,
        "query_length": summarize(payload["query_lengths"]),
        "raw_document_length": summarize(raw_lengths),
        "wrapped_document_length": summarize(payload["doc_lengths"]),
        "tokenization": "Encode query, document delimiters and 256-token content independently; add tokenizer CLS/SEP IDs explicitly. Exact ID tensors are authoritative.",
        "padding": "Query right padding is masked; position IDs for documents must start at the REAL query length to reproduce unpadded user prompts. Fixed-slot experiments must be explicitly identified.",
        "clinical_relevance": "Entirely synthetic workload; no labels and no medical coding or quality validation.",
    }
    save_json(data_dir / "metadata.json", metadata)
    print("DATA_READY", json.dumps(metadata), flush=True)

    if not (model_dir / "model.safetensors").exists():
        cfg = AutoConfig.from_pretrained(base)
        original = json.loads((base / "config.json").read_text())
        cfg.num_labels = 1
        cfg.classifier_pooling = "cls"
        cfg.classifier_activation = "gelu"
        cfg.problem_type = "regression"
        cfg.architectures = ["ModernBertForSequenceClassification"]
        torch.manual_seed(SEED)
        model = AutoModelForSequenceClassification.from_pretrained(base, config=cfg, dtype=torch.float32)
        # Reinitialize both scoring layers deterministically. They are never trained.
        torch.manual_seed(SEED)
        model.head.apply(model._init_weights)
        model.classifier.apply(model._init_weights)
        model.eval()
        model.save_pretrained(model_dir)
        tokenizer.save_pretrained(model_dir)
        save_json(model_dir / "source_config.json", original)
        save_json(model_dir / "benchmark_provenance.json", {
            "source": MODEL_ID, "source_revision": MODEL_REVISION, "seed": SEED, "purpose": "throughput and kernel parity only",
            "changes": {"architectures": cfg.architectures, "num_labels": 1,
                        "classifier_pooling": "cls", "classifier_activation": "gelu",
                        "head": "deterministically initialized untrained prediction and output head"},
            "original_classifier_pooling": original["classifier_pooling"],
            "original_classifier_activation": original["classifier_activation"],
            "backbone": "public pretrained backbone copied without training",
        })
    print("MODEL_READY", str(model_dir), flush=True)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, default=Path(__file__).resolve().parent)
    parser.add_argument("--chunks", type=int, default=5000)
    parser.add_argument("--query-width", type=int, default=64)
    parser.add_argument("--skip-download", action="store_true")
    args = parser.parse_args()
    prepare(args.root, args.chunks, args.query_width, args.skip_download)
