"""
Unit tests for reward.py  (pure, CPU-only -- no model / PDF needed).

Run either with pytest:      pytest test_reward.py
or standalone (no pytest):   python test_reward.py
"""

from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "scripts"))

import torch

import reward
from reward import (
    batch_coverage_dup,
    batch_rewards,
    compute_reward,
    coverage_dup,
    extract_box_ids,
)

M = reward.M            # 17
BOS, EOS, PAD = reward.BOS_ID, reward.EOS_ID, reward.PAD_ID


def box(i: int) -> int:
    """Token id for box index ``i`` in the special-first scheme."""
    return M + i


def approx(a: float, b: float, tol: float = 1e-6) -> None:
    assert abs(a - b) <= tol, f"expected {b}, got {a}"


# --------------------------------------------------------------------------- #
# extract_box_ids
# --------------------------------------------------------------------------- #
def test_extract_basic():
    seq = [BOS, box(0), box(1), box(2), EOS]
    assert extract_box_ids(seq, num_boxes=3) == [0, 1, 2]


def test_extract_stops_at_eos():
    # box(1) sits AFTER eos and must be ignored
    seq = [BOS, box(0), EOS, box(1)]
    assert extract_box_ids(seq, num_boxes=2) == [0]


def test_extract_skips_specials():
    # 8 = '#', 4 = '\n' -> skipped, only the box pointers survive
    seq = [BOS, 8, box(0), 4, box(1), 8, EOS]
    assert extract_box_ids(seq, num_boxes=2) == [0, 1]


def test_extract_drops_out_of_range():
    # box(5) indexes box 5 which does not exist when N = 2 -> dropped
    seq = [BOS, box(0), box(5), box(1), EOS]
    assert extract_box_ids(seq, num_boxes=2) == [0, 1]


def test_extract_keeps_duplicates_in_order():
    seq = [BOS, box(0), box(1), box(1), box(2), EOS]
    assert extract_box_ids(seq, num_boxes=3) == [0, 1, 1, 2]


# --------------------------------------------------------------------------- #
# coverage_dup
# --------------------------------------------------------------------------- #
def test_coverage_perfect():
    cov, dup = coverage_dup([0, 1, 2], num_boxes=3)
    approx(cov, 1.0)
    approx(dup, 0.0)


def test_coverage_missing():
    cov, dup = coverage_dup([0, 1, 2], num_boxes=4)
    approx(cov, 0.75)
    approx(dup, 0.0)


def test_coverage_with_duplicates():
    cov, dup = coverage_dup([0, 1, 1, 2], num_boxes=3)  # D=3, E=4
    approx(cov, 1.0)
    approx(dup, 0.25)


def test_coverage_empty():
    cov, dup = coverage_dup([], num_boxes=3)
    approx(cov, 0.0)
    approx(dup, 0.0)


def test_coverage_degenerate_no_boxes():
    cov, dup = coverage_dup([], num_boxes=0)
    approx(cov, 0.0)
    approx(dup, 0.0)


# --------------------------------------------------------------------------- #
# compute_reward
# --------------------------------------------------------------------------- #
def test_reward_perfect_is_w_cov():
    approx(compute_reward([0, 1, 2], 3), 1.0)


def test_reward_missing_box():
    approx(compute_reward([0, 1, 2], 4), 0.75)


def test_reward_duplicate_penalised():
    # coverage 1.0, dup_rate 0.25 -> 1.0 - 0.5*0.25
    approx(compute_reward([0, 1, 1, 2], 3), 0.875)


def test_reward_dup_weight_scales():
    approx(compute_reward([0, 0], 1, w_cov=1.0, w_dup=0.5), 0.75)   # cov1, dup0.5
    approx(compute_reward([0, 0], 1, w_cov=1.0, w_dup=1.0), 0.50)


def test_reward_empty_is_zero():
    approx(compute_reward([], 3), 0.0)


def test_reward_order_invariant():
    approx(compute_reward([0, 1, 2], 3), compute_reward([2, 0, 1], 3))


def test_reward_degenerate_no_boxes():
    approx(compute_reward([], 0), 0.0)


# --------------------------------------------------------------------------- #
# batch_rewards / batch_coverage_dup  (per-row N comes from box_mask)
# --------------------------------------------------------------------------- #
def _batch_fixture():
    # Three rows, padded to L=6 with PAD; box_mask gives each row its own N.
    seqs = torch.tensor([
        [BOS, box(0), box(1), box(2), EOS, PAD],   # N=3 perfect            -> 1.0
        [BOS, box(0), box(1), box(2), EOS, PAD],   # N=4 missing box 3      -> 0.75
        [BOS, box(0), box(3), box(1), EOS, PAD],   # N=2, box(3) out-of-rng -> 1.0
    ])
    box_mask = torch.tensor([
        [True,  True,  True,  False],
        [True,  True,  True,  True],
        [True,  True,  False, False],
    ])
    return seqs, box_mask


def test_batch_rewards_tensor_input():
    seqs, box_mask = _batch_fixture()
    r = batch_rewards(seqs, box_mask)
    assert torch.allclose(r, torch.tensor([1.0, 0.75, 1.0]))


def test_batch_rewards_list_input_matches_tensor():
    seqs, box_mask = _batch_fixture()
    r_tensor = batch_rewards(seqs, box_mask)
    r_list = batch_rewards(seqs.tolist(), box_mask)
    assert torch.allclose(r_tensor, r_list)


def test_batch_rewards_device_follows_mask():
    seqs, box_mask = _batch_fixture()
    r = batch_rewards(seqs, box_mask)
    assert r.device == box_mask.device


def test_batch_coverage_dup():
    seqs, box_mask = _batch_fixture()
    cov, dup = batch_coverage_dup(seqs, box_mask)
    assert torch.allclose(cov, torch.tensor([1.0, 0.75, 1.0]))
    assert torch.allclose(dup, torch.tensor([0.0, 0.0, 0.0]))


# --------------------------------------------------------------------------- #
# Standalone runner (so it works on the CPU box without pytest installed)
# --------------------------------------------------------------------------- #
if __name__ == "__main__":
    import sys

    tests = [v for k, v in sorted(globals().items())
             if k.startswith("test_") and callable(v)]
    failed = 0
    for fn in tests:
        try:
            fn()
            print(f"PASS  {fn.__name__}")
        except AssertionError as e:
            failed += 1
            print(f"FAIL  {fn.__name__}: {e}")
    print(f"\n{len(tests) - failed}/{len(tests)} passed")
    sys.exit(1 if failed else 0)
