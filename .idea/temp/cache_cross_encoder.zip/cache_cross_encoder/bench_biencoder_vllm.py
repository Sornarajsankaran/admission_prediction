"""Native vLLM EmbeddingGemma 2 offline bi-encoder benchmark."""
import os
os.environ.setdefault('VLLM_ENABLE_V1_MULTIPROCESSING','0')
os.environ.setdefault('OMP_NUM_THREADS','8')
import argparse,json,time,statistics
from pathlib import Path
import torch
from vllm import LLM
ROOT=Path(__file__).resolve().parent

def main():
 p=argparse.ArgumentParser();p.add_argument('--tokens',type=int,default=8192);p.add_argument('--seqs',type=int,default=64);p.add_argument('--eager',action='store_true');a=p.parse_args()
 torch.set_num_threads(8)
 # vLLM0.33 defaults to a128-token tile for256-d attention, which exceeds
 # L40S shared memory. Cap the process-local tile; attention math is unchanged.
 import vllm.v1.attention.ops.triton_prefill_attention as prefill
 original_block_size=prefill.get_block_size
 prefill.get_block_size=lambda dtype:min(64,original_block_size(dtype))
 docs=['title: none | text: '+json.loads(x)['text'] for x in (ROOT/'data/chunks.jsonl').read_text().splitlines()]
 queries=[json.loads(x)for x in (ROOT/'data/queries.jsonl').read_text().splitlines()]
 qs=[f"task: search result | query: ICD code: {q['icd_code']}({q['icd_code_description']})\nattribute: {q['attribute']}\n search keyterm: {q['keyterm']}"for q in queries]
 start=time.perf_counter()
 llm=LLM(model=str(ROOT/'models/embeddinggemma-2'),runner='pooling',dtype='bfloat16',hf_overrides={'vision_config':None,'audio_config':None},max_model_len=1024,max_num_batched_tokens=a.tokens,max_num_seqs=a.seqs,enable_prefix_caching=False,enforce_eager=a.eager,seed=42,disable_log_stats=True)
 load=time.perf_counter()-start
 def encode(texts):
  return torch.nn.functional.normalize(torch.tensor([x.outputs.embedding for x in llm.embed(texts,use_tqdm=False)],dtype=torch.float32),dim=-1)
 encode(docs[:128]);encode(qs)
 runs=[]
 for _ in range(3):
  start=time.perf_counter();qe=encode(qs);qsec=time.perf_counter()-start
  t=time.perf_counter();de=encode(docs);dsec=time.perf_counter()-t
  t=time.perf_counter();scores=de@qe.T;ssec=time.perf_counter()-t
  total=time.perf_counter()-start
  runs.append(dict(total_seconds=total,query_seconds=qsec,document_seconds=dsec,similarity_seconds=ssec));print('FULL',runs[-1],flush=True)
 cached=[]
 for _ in range(5):
  t=time.perf_counter();qe=encode(qs);scores=de@qe.T;cached.append(time.perf_counter()-t)
 result=dict(engine='native_vllm',triton_prefill_tile_cap=64,token_budget=a.tokens,max_sequences=a.seqs,compiled=not a.eager,load_seconds=load,runs=runs,median_total_seconds=statistics.median(x['total_seconds']for x in runs),cached_document_seconds=cached,documents=5000,queries=50,pairs=250000,dimension=de.shape[1],finite=bool(scores.isfinite().all()),includes='API tokenization, scheduler, GPU embedding, CPU embedding delivery, FP32 normalization and CPU matrix multiplication',excludes='load, warmup, JSON parsing, disk output')
 baseline=torch.load(ROOT/'results/biencoder/embeddings_and_scores.pt',weights_only=True)
 result['sentence_transformers_embedding_cosine_mean']=torch.nn.functional.cosine_similarity(de,baseline['document_embeddings']).mean().item()
 result['sentence_transformers_embedding_cosine_min']=torch.nn.functional.cosine_similarity(de,baseline['document_embeddings']).min().item()
 out=ROOT/'results/biencoder';out.mkdir(exist_ok=True)
 with (out/'vllm.jsonl').open('a')as f:f.write(json.dumps(result)+'\n')
 torch.save(dict(document_embeddings=de,query_embeddings=qe,scores=scores),out/f'vllm_embeddings_{a.tokens}_{not a.eager}.pt')
 print(json.dumps(result),flush=True)
if __name__=='__main__':main()
