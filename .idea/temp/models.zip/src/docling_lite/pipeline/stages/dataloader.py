import fitz
import pandas as pd
from pathlib import Path
from typing import Dict, Tuple

from docling_lite.core.config import REQUIRED_COLUMNS_OCR_DF
from docling_lite.core.logging import log_function_calls, logger


class DataLoader:
    @staticmethod
    def _load_ocr_dataframe(ocr_df_path: Path) -> pd.DataFrame:
        try:
            file_format = ocr_df_path.suffix.lower()

            if file_format == ".parquet":
                ocr_df = pd.read_parquet(ocr_df_path)
            elif file_format == ".csv":
                ocr_df = pd.read_csv(ocr_df_path)
            else:
                raise ValueError(
                    f"Unsupported file format: {file_format}; "
                    "supported formats are .csv and .parquet."
                )

            # Standardize column names
            ocr_df.columns = ocr_df.columns.str.lower()
            column_aliases = {
                "filename": "file_name",
                "pageno": "page",
                "text": "content",
            }
            ocr_df.rename(columns=column_aliases, inplace=True)

            required_columns = set(REQUIRED_COLUMNS_OCR_DF)
            missing_cols = required_columns - set(ocr_df.columns)
            if missing_cols:
                raise ValueError(
                    f"OCR DataFrame is missing required columns: {', '.join(missing_cols)}"
                )

            ocr_df = ocr_df.dropna(subset=sorted(required_columns)).reset_index(drop=True)
            ocr_df["page"] = ocr_df["page"].astype(int)

            if ocr_df.empty:
                raise ValueError("The OCR DataFrame loaded is empty.")

            return ocr_df

        except Exception as e:
            logger.error(f"Error loading OCR DataFrame: {e}")
            raise

    @staticmethod
    def _load_pdf_files(pdf_dir: Path, unique_files) -> Dict:
        try:
            unique_files = set(unique_files)
            all_pdf_paths = list(pdf_dir.rglob("*.pdf"))

            required_pdf_paths = list(
                filter(lambda path: path.name in unique_files, all_pdf_paths)
            )
            if not required_pdf_paths:
                raise ValueError(f"No PDF files found in directory: {pdf_dir}")

            found_pdf_names = {path.name for path in required_pdf_paths}
            missing_pdfs = unique_files - found_pdf_names
            if missing_pdfs:
                logger.debug(
                    f"Missing pdfs for the following files : {', '.join(missing_pdfs)}"
                )

            pdfs = {path.name: fitz.open(path) for path in required_pdf_paths}
            return pdfs

        except Exception as e:
            logger.error(f"Error loading PDF files from {pdf_dir}: {e}")
            raise

    @classmethod
    @log_function_calls(logger)
    def load(cls, ocr_df_path: Path, pdf_dir: Path) -> Tuple[pd.DataFrame, Dict]:
        ocr_df = cls._load_ocr_dataframe(ocr_df_path)
        logger.info(f"Loaded OCR DataFrame, shape: {ocr_df.shape}")

        unique_files = ocr_df["file_name"].unique()
        logger.debug(f"Unique files in OCR DataFrame: {len(unique_files)}")

        pdfs = cls._load_pdf_files(pdf_dir, unique_files)
        logger.info(f"Loaded PDF files, Count: {len(pdfs)}")

        ocr_df = ocr_df[ocr_df["file_name"].isin(list(pdfs.keys()))].reset_index(drop=True)
        logger.info(f"Processing {len(ocr_df)} pages from {len(pdfs)} PDFs")

        return ocr_df, pdfs