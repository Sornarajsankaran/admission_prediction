"""
Generator for the OCR Text Reconstruction architecture diagram.

Defines the layout ONCE as a list of neutral "shape" dicts, then emits:
  * an editable Excalidraw scene  (.excalidraw)  -- the deliverable
  * a crisp preview SVG           (.svg)          -- for visual QA only

The Excalidraw file regenerates the hand-drawn (rough.js) look natively and
stays fully editable in excalidraw.com.
"""
import json, random, html, math

random.seed(7)
TS = 1710000000000

# ---- palette (matches the rough diagram) ----
BLACK  = "#1e1e1e"
BROWN  = "#846358"
GRAY   = "#e9ecef"   # processing blocks
GREEN  = "#b2f2bb"   # H_box tensors
PINK   = "#ffc9c9"   # OCR box inputs
YELLOW = "#ffec99"   # special / vocab
ORANGE = "#ffd8a8"   # hidden state vector
BLUE   = "#a5d8ff"   # encoder memory
LGREEN = "#ebfbee"
LPINK  = "#fff0f6"
WHITE  = "#ffffff"
TRANS  = "transparent"
ORANGETXT = "#f08c00"

shapes = []   # neutral shape list

def _id():
    return "".join(random.choice("abcdefghijklmnopqrstuvwxyzABCDEF0123456789") for _ in range(16))

def rect(x, y, w, h, fill=GRAY, stroke=BLACK, rounded=True, sw=2, dashed=False, group=None):
    s = dict(kind="rect", x=x, y=y, w=w, h=h, fill=fill, stroke=stroke,
             rounded=rounded, sw=sw, dashed=dashed, group=group, id=_id())
    shapes.append(s); return s

def line(x1, y1, x2, y2, stroke=BROWN, sw=1, group=None):
    s = dict(kind="line", x1=x1, y1=y1, x2=x2, y2=y2, stroke=stroke, sw=sw, group=group, id=_id())
    shapes.append(s); return s

def text(t, cx, cy, size=20, color=BLACK, align="center", bold=False):
    s = dict(kind="text", t=t, cx=cx, cy=cy, size=size, color=color, align=align, id=_id())
    shapes.append(s); return s

def arrow(pts, stroke=BLACK, sw=2, dashed=False, head_end=True, head_start=False, group=None):
    s = dict(kind="arrow", pts=pts, stroke=stroke, sw=sw, dashed=dashed,
             head_end=head_end, head_start=head_start, group=group, id=_id())
    shapes.append(s); return s

def grid(x, y, w, h, rows, cols, fill, stroke=BLACK, cell_stroke=BROWN, group=None):
    """A tensor drawn as a rows x cols grid."""
    rect(x, y, w, h, fill=fill, stroke=stroke, rounded=False, sw=2, group=group)
    for r in range(1, rows):
        yy = y + h * r / rows
        line(x, yy, x + w, yy, stroke=cell_stroke, sw=1, group=group)
    for c in range(1, cols):
        xx = x + w * c / cols
        line(xx, y, xx, y + h, stroke=cell_stroke, sw=1, group=group)

def stack(x, y, w, h, n=3, off=9, fill=BLUE, group=None):
    """Overlapping rects to imply a multi-scale feature pyramid (back to front)."""
    for i in range(n - 1, -1, -1):
        rect(x + i * off, y + i * off, w, h, fill=fill, stroke=BLACK, rounded=False, sw=2, group=group)

# convenience anchors on a rect
def top(s):    return (s["x"] + s["w"] / 2, s["y"])
def bot(s):    return (s["x"] + s["w"] / 2, s["y"] + s["h"])
def left(s):   return (s["x"], s["y"] + s["h"] / 2)
def right(s):  return (s["x"] + s["w"], s["y"] + s["h"] / 2)
def center(s): return (s["x"] + s["w"] / 2, s["y"] + s["h"] / 2)

# ============================================================= LAYOUT
# x grows right, y grows down.

IMX = 480          # image lane center (inside RT-DETR frame)
OCX = 140          # ocr-box query lane center (left of frame, the trained adapters)
ARX = 1140         # AR decoder column center
BW  = 250          # standard block width

# =============================== RT-DETR-v2 frame + title
rect(300, 560, 430, 600, fill=TRANS, stroke=BROWN, rounded=True, sw=2, dashed=True)
text("RT-DETR-v2  (pretrained vision stack)", 515, 586, size=21, color=BROWN)

# image lane blocks (bottom -> top)
page = rect(IMX-95, 1180, 190, 100, fill=WHITE, rounded=False, sw=2)
text("PAGE\nIMAGE", *center(page), size=22)

backbone = rect(IMX-BW/2, 1010, BW, 110, fill=GRAY)
text("Conv Backbone\n(ResNet)", *center(backbone), size=22)

encoder = rect(IMX-BW/2, 830, BW, 110, fill=GRAY)
text("Hybrid Encoder\n(multi-scale)", *center(encoder), size=22)

# multi-scale memory pyramid to the right of the encoder
memx, memy = 620, 800
stack(memx, memy, 70, 70, n=3, off=9, fill=BLUE)
text("multi-scale\nmemory", memx+34, memy+104, size=16)

decoder = rect(330, 620, 300, 130, fill=GRAY)
text("Deformable Decoder\n(box-conditioned queries)", *center(decoder), size=20)

# ---- OCR box query lane (left, trained-from-scratch adapters) ----
gx, gy = 40, 1150
grid(gx, gy, 200, 120, rows=5, cols=4, fill=PINK)
ocr = dict(x=gx, y=gy, w=200, h=120)
text("OCR boxes", OCX, gy-24, size=20)
text("(N, 4)  cx, cy, w, h", OCX, gy+142, size=17)

content_mlp = rect(30, 1010, 220, 100, fill=GRAY)
text("Box Content MLP\n(4 -> d_model)", *center(content_mlp), size=19)

refpts = rect(30, 838, 220, 92, fill=GRAY)
text("Reference points\n(box position)", *center(refpts), size=19)

# H_box output (green) just above the frame -- the box/query interface
hbx, hby, hbw, hbh = 360, 430, 240, 96
grid(hbx, hby, hbw, hbh, rows=4, cols=6, fill=GREEN)
hbox = dict(x=hbx, y=hby, w=hbw, h=hbh)
text("H_box", 480, 406, size=22)
text("(N, d_model)", 480, hby+hbh+22, size=17)

# =============================== AR Markdown decoder column
rect(895, 560, 490, 640, fill=TRANS, stroke=BROWN, rounded=True, sw=2, dashed=True)
text("Autoregressive Markdown Decoder  (trained from scratch)", ARX, 586, size=21, color=BROWN)

# decoder input ids (BOS at t=0)
inp = rect(1030, 1080, 220, 90, fill=YELLOW, rounded=False)
text("decoder_input_ids\n<BOS> ...  (t = 0)", *center(inp), size=18)

# token embedding
emb = rect(925, 900, 430, 130, fill=GRAY)
text("Token Embedding", ARX, 930, size=21)
text("special id -> special embed   |   box id -> gather H_box", ARX, 962, size=15)
text("+  positional embedding", ARX, 992, size=15)

# transformer decoder (6 layers)
tdec = rect(980, 630, 320, 200, fill=GRAY)
text("Transformer Decoder\n(6 layers)\ncausal self-attn + cross-attn", *center(tdec), size=20)

# hidden state (1, d_model)
hidw = 300
hid = rect(990, 500, hidw, 60, fill=ORANGE, rounded=False)
for c in range(1, 8):
    line(990 + hidw*c/8, 500, 990 + hidw*c/8, 560, stroke=BROWN, sw=1)
text("decoder hidden state  (1, d_model)", ARX, 478, size=17, color=ORANGETXT)

# =============================== two heads
# special / vocab head
sph = rect(810, 350, 250, 96, fill=GRAY)
text("Special-token Head\nLinear(d -> M)", *center(sph), size=18)
sp_logits = rect(810, 250, 250, 46, fill=YELLOW, rounded=False)
for c in range(1, 6):
    line(810 + 250*c/6, 250, 810 + 250*c/6, 296, stroke=BROWN, sw=1)
text("special logits (1, M)", 935, 230, size=15)

# pointer head
pph = rect(1220, 350, 250, 96, fill=GRAY)
text("Pointer Head\nscore = q . proj(H_box)", *center(pph), size=17)
pt_logits = rect(1220, 250, 250, 46, fill=GREEN, rounded=False)
for c in range(1, 6):
    line(1220 + 250*c/6, 250, 1220 + 250*c/6, 296, stroke=BROWN, sw=1)
text("pointer logits (1, N)", 1345, 230, size=15)

# concat logits  (special-first: left half special, right half boxes)
cw = 470
cx0 = ARX - cw/2
split = cx0 + cw*0.45
rect(cx0, 150, cw*0.45, 52, fill=YELLOW, rounded=False, sw=0)
rect(split, 150, cw*0.55, 52, fill=GREEN, rounded=False, sw=0)
rect(cx0, 150, cw, 52, fill=TRANS, rounded=False, sw=2)
line(split, 150, split, 202, stroke=BLACK, sw=2)
concat = dict(x=cx0, y=150, w=cw, h=52)
text("logits = [ special (M) | boxes (N) ]   special-first", ARX, 128, size=16)
text("M", cx0 + cw*0.225, 176, size=16)
text("N", cx0 + cw*0.725, 176, size=16)

# argmax + predicted token
argmax = rect(1050, 55, 180, 56, fill=GRAY)
text("Argmax / Sample", *center(argmax), size=18)
pred = rect(1320, 55, 210, 56, fill=LGREEN)
text("Predicted token", *center(pred), size=18)

# ============================================================= ARROWS
A = arrow
# --- image lane (bottom -> top) ---
A([top(page), (IMX, 1120)])
A([top(backbone), bot(encoder)])
A([(605, 885), (652, 828)])          # encoder -> multi-scale memory
A([(652, 806), (560, 750)])          # memory -> deformable decoder
A([top(decoder), (IMX, hby+hbh)])    # decoder -> H_box

# --- ocr-box query lane -> decoder (two pathways) ---
A([(OCX, gy), (OCX, 1110)])                    # boxes -> content MLP
A([(90, gy), (20, gy), (20, 884), (30, 884)])  # boxes -> reference points (routed left)
A([(250, 1055), (330, 720)])                   # content MLP -> decoder (query content)
A([(250, 884), (330, 655)])                    # reference points -> decoder (position)

# --- H_box -> AR transformer decoder as cross-attn memory ---
A([right(hbox), (980, 730)])
text("K, V  (cross-attn memory)", 790, 706, size=17)

# --- AR column (bottom -> top) ---
A([top(inp), bot(emb)])
A([top(emb), bot(tdec)])
A([top(tdec), bot(hid)])
A([(1100, 500), bot(sph)])           # hidden -> special head
A([(1180, 500), bot(pph)])           # hidden -> pointer head
A([top(sph), bot(sp_logits)])
A([top(pph), bot(pt_logits)])
A([top(sp_logits), (cx0 + cw*0.22, 202)])   # special logits -> concat (left half)
A([top(pt_logits), (cx0 + cw*0.72, 202)])   # pointer logits -> concat (right half)
A([top(concat), bot(argmax)])
A([right(argmax), left(pred)])

# --- autoregressive feedback: predicted token -> next input ---
fb_x = 1580
A([right(pred), (fb_x, 83), (fb_x, 1125), (1250, 1125)], dashed=True, sw=2, stroke=BROWN)
text("autoregressive\nfeedback  (t -> t+1)", fb_x + 20, 600, size=16, color=BROWN, align="left")

# =============================================================
# title
text("OCR Text Reconstruction  —  Layout-aware Pointer-Generator", 820, 24, size=30)

# ============================================================= EMIT EXCALIDRAW
def est_w(t, size):
    return max(len(l) for l in t.split("\n")) * size * 0.55
def est_h(t, size):
    return len(t.split("\n")) * size * 1.25

def base(el):
    el.update(dict(angle=0, opacity=100, groupIds=[], frameId=None, seed=random.randint(1, 2**31),
                   version=1, versionNonce=random.randint(1, 2**31), isDeleted=False,
                   boundElements=None, updated=TS, link=None, locked=False))
    return el

def to_excalidraw():
    els = []
    for s in shapes:
        k = s["kind"]
        if k == "rect":
            els.append(base(dict(id=s["id"], type="rectangle", x=s["x"], y=s["y"], width=s["w"], height=s["h"],
                strokeColor=s["stroke"], backgroundColor=s["fill"], fillStyle="solid",
                strokeWidth=s["sw"] if s["sw"] else 1, strokeStyle="dashed" if s["dashed"] else "solid",
                roughness=1, roundness={"type": 3} if s["rounded"] else None)))
            if s["sw"] == 0:
                els[-1]["strokeColor"] = "transparent"
        elif k == "line":
            els.append(base(dict(id=s["id"], type="line", x=s["x1"], y=s["y1"],
                width=s["x2"]-s["x1"], height=s["y2"]-s["y1"],
                strokeColor=s["stroke"], backgroundColor="transparent", fillStyle="solid",
                strokeWidth=s["sw"], strokeStyle="solid", roughness=0, roundness=None,
                points=[[0, 0], [s["x2"]-s["x1"], s["y2"]-s["y1"]]], lastCommittedPoint=None,
                startBinding=None, endBinding=None, startArrowhead=None, endArrowhead=None)))
        elif k == "arrow":
            pts = s["pts"]
            x0, y0 = pts[0]
            rel = [[px-x0, py-y0] for px, py in pts]
            xs = [p[0] for p in rel]; ys = [p[1] for p in rel]
            els.append(base(dict(id=s["id"], type="arrow", x=x0, y=y0,
                width=max(xs)-min(xs), height=max(ys)-min(ys),
                strokeColor=s["stroke"], backgroundColor="transparent", fillStyle="solid",
                strokeWidth=s["sw"], strokeStyle="dashed" if s["dashed"] else "solid",
                roughness=1, roundness={"type": 2}, points=rel, lastCommittedPoint=None,
                startBinding=None, endBinding=None,
                startArrowhead="arrow" if s["head_start"] else None,
                endArrowhead="arrow" if s["head_end"] else None)))
        elif k == "text":
            w = est_w(s["t"], s["size"]); h = est_h(s["t"], s["size"])
            if s["align"] == "left":
                x = s["cx"]
            else:
                x = s["cx"] - w/2
            y = s["cy"] - h/2
            els.append(base(dict(id=s["id"], type="text", x=x, y=y, width=w, height=h,
                strokeColor=s["color"], backgroundColor="transparent", fillStyle="solid",
                strokeWidth=1, strokeStyle="solid", roughness=1, roundness=None,
                text=s["t"], fontSize=s["size"], fontFamily=1,
                textAlign=s["align"] if s["align"] != "left" else "left",
                verticalAlign="top", containerId=None, originalText=s["t"],
                autoResize=True, lineHeight=1.25)))
    return dict(type="excalidraw", version=2, source="https://excalidraw.com", elements=els,
                appState=dict(gridSize=None, viewBackgroundColor="#ffffff"), files={})

# ============================================================= EMIT PREVIEW SVG
def svg_escape(t): return html.escape(t)

def to_svg():
    W, H = 1820, 1360
    out = [f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="-20 -20 {W} {H}" width="{W}" height="{H}" font-family="Segoe UI, sans-serif">',
           f'<rect x="-20" y="-20" width="{W}" height="{H}" fill="#ffffff"/>',
           '<defs><marker id="ah" markerWidth="10" markerHeight="10" refX="8" refY="3" orient="auto" markerUnits="strokeWidth"><path d="M0,0 L8,3 L0,6 z" fill="#1e1e1e"/></marker>'
           '<marker id="ahb" markerWidth="10" markerHeight="10" refX="8" refY="3" orient="auto" markerUnits="strokeWidth"><path d="M0,0 L8,3 L0,6 z" fill="#846358"/></marker></defs>']
    for s in shapes:
        k = s["kind"]
        if k == "rect":
            rx = 12 if s["rounded"] else 0
            fill = "none" if s["fill"] == "transparent" else s["fill"]
            sw = s["sw"]
            stroke = "none" if sw == 0 else s["stroke"]
            dash = ' stroke-dasharray="8 6"' if s["dashed"] else ""
            out.append(f'<rect x="{s["x"]}" y="{s["y"]}" width="{s["w"]}" height="{s["h"]}" rx="{rx}" fill="{fill}" stroke="{stroke}" stroke-width="{sw}"{dash}/>')
        elif k == "line":
            out.append(f'<line x1="{s["x1"]}" y1="{s["y1"]}" x2="{s["x2"]}" y2="{s["y2"]}" stroke="{s["stroke"]}" stroke-width="{s["sw"]}"/>')
        elif k == "arrow":
            pts = s["pts"]
            d = "M " + " L ".join(f"{x},{y}" for x, y in pts)
            dash = ' stroke-dasharray="9 6"' if s["dashed"] else ""
            mk = "ahb" if s["stroke"] == BROWN else "ah"
            end = f' marker-end="url(#{mk})"' if s["head_end"] else ""
            out.append(f'<path d="{d}" fill="none" stroke="{s["stroke"]}" stroke-width="{s["sw"]}"{dash}{end}/>')
        elif k == "text":
            anchor = {"center": "middle", "left": "start"}[s["align"]]
            lines = s["t"].split("\n")
            n = len(lines)
            for i, ln in enumerate(lines):
                yy = s["cy"] - (n-1)*s["size"]*0.6 + i*s["size"]*1.2 + s["size"]*0.35
                xx = s["cx"]
                out.append(f'<text x="{xx}" y="{yy}" font-size="{s["size"]}" fill="{s["color"]}" text-anchor="{anchor}">{svg_escape(ln)}</text>')
    out.append("</svg>")
    return "\n".join(out)

if __name__ == "__main__":
    import sys
    outdir = sys.argv[1] if len(sys.argv) > 1 else "."
    with open(outdir + "/ocr_reconstruction_v0_model_architecture.excalidraw", "w", encoding="utf-8") as f:
        json.dump(to_excalidraw(), f, indent=2)
    with open(outdir + "/preview.svg", "w", encoding="utf-8") as f:
        f.write(to_svg())
    print("wrote excalidraw + preview.svg;  #elements =", len(shapes))
