import io
import fitz
from PIL import Image


def rasterize_page(
    page: fitz.Page,
    dpi: int = 72,
    force_rasterize: bool = True,
    prefer_largest_embedded: bool = True,
) -> Image.Image:
    doc = page.parent
    if doc is None:
        raise ValueError("The page is not attached to a document.")

    if not force_rasterize:
        try:
            image_list = page.get_images(full=True)
            if image_list:
                chosen = (
                    max(image_list, key=lambda img: img[2] * img[3])
                    if prefer_largest_embedded
                    else image_list[0]
                )
                extracted = doc.extract_image(chosen[0])
                if extracted and "image" in extracted:
                    pil_image = Image.open(io.BytesIO(extracted["image"]))
                    pil_image.load()
                    return pil_image
        except Exception:
            pass

    zoom = dpi / 72.0
    pix = page.get_pixmap(matrix=fitz.Matrix(zoom, zoom))
    return Image.frombytes("RGB", (pix.width, pix.height), pix.samples)
