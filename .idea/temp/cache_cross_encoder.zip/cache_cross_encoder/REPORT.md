# Measured throughput report

Hardware: one NVIDIA L40S. Workload: 5000 distinct 263-token wrapped documents × 50 queries (30–41 tokens), 250000 scores. All GPU jobs ran sequentially. Public weights plus shared untrained CLS/GELU head; no retrieval-quality claim.

## Full-record measurements

| Implementation | Scores/sec | Seconds/250k | 100 records, extrapolated |
|---|---:|---:|---:|
| Tuned stock vLLM API | 1,348 | 185.52 | 309.2 min |
| Custom native vLLM worker, cache construction included | 11,715 | 21.34 | 35.6 min |

Observed wall-time speedup: **8.69×**. Custom full-run seconds: [21.341, 21.173, 21.351]. Baseline full-run seconds: [184.71959087485448, 186.31225232873112].

The custom worker uses a grouped offline execution API and avoids per-pair scheduler/output-object overhead. This ratio therefore includes both reuse and execution/API changes; it is not an isolated attention-kernel speedup. All custom full runs include token H2D, document computation, query computation, classifier and score D2H. Model initialization, warmup/compilation and tokenization are excluded. 100-record times are linear extrapolations, not an executed concurrent 100-record benchmark.

## Stock vLLM sweeps

| Pairs | Token budget | Max sequences | Compiled | Scores/sec |
|---:|---:|---:|---|---:|
|10000|32768|128|False|1126|
|10000|65536|256|False|1098|
|10000|4096|32|False|1156|
|10000|4096|32|True|1414|
|10000|8192|64|False|1302|
|10000|8192|64|True|1424|
|10000|16384|64|False|1200|
|10000|16384|64|True|1340|
|250000|8192|64|True|1348|

## Custom native vLLM executor sweeps

| Mode | Docs/tile | Compile | Graph | Scores/sec | Peak allocated GiB |
|---|---:|---|---|---:|---:|
|stream|1|False|False|2536|0.36|
|stream|4|False|False|6558|0.53|
|stream|16|False|False|4730|1.23|
|joint|1|False|False|3992|0.37|
|joint|4|False|False|6537|0.58|
|joint|16|False|False|4101|1.42|
|cache|1|False|False|2525|0.37|
|cache|4|False|False|6143|0.56|
|cache|16|False|False|4737|1.33|
|hot|1|False|False|4647|0.37|
|hot|4|False|False|7657|0.56|
|hot|16|False|False|5096|1.33|
|joint|1|False|True|7377|0.31|
|joint|4|False|True|6831|0.32|
|joint|16|False|True|4128|0.33|
|joint|32|False|True|3977|0.34|
|joint|1|True|True|11623|0.31|
|joint|2|True|True|10534|0.32|
|joint|4|True|True|12223|0.33|
|joint|8|True|True|10093|0.34|
|stream|1|True|True|9957|0.35|
|stream|2|True|True|11004|0.35|
|stream|4|True|True|10811|0.36|
|stream|8|True|True|10637|0.37|

`hot` excludes cache construction; all other modes include document work. `joint` combines document/query projections and MLP operations while retaining isolated attention. These tile timings exclude input/output transfers and are microbenchmarks.

## HF baseline, resident-input forward only

| Mode | Batch | Scores/sec |
|---|---:|---:|
|eager|16|1042|
|eager|32|933|
|eager|64|696|
|eager|128|611|
|eager|256|596|
|cuda_graph|16|1091|
|cuda_graph|32|955|
|cuda_graph|64|709|
|cuda_graph|128|616|
|cuda_graph|256|597|

## Numerical checks

Correctness is measured against the dense **Variant B mask**, not the full cross-encoder baseline: those intentionally use different attention graphs. FP32 dense-vs-factorized maximum score difference was below 8e-6 on the eight-score validation set. Document invariance and unrelated-query mutation tests passed.

| Precision | Triton+Flash joint vs dense absolute positions, max abs score error |
|---|---:|
|bf16|0.028564|
|fp16|0.004333|

Actual saved scores from the winning compiled native worker, first 200 pairs:
```json
{
  "torch.bfloat16": {
    "max_abs": 0.0516357421875,
    "rms": 0.020116504281759262,
    "cosine": 0.9764890074729919,
    "reference_abs_max": 0.259765625,
    "shape": [
      4,
      50
    ]
  },
  "torch.float32": {
    "max_abs": 0.03950636088848114,
    "rms": 0.014711923897266388,
    "cosine": 0.9875825643539429,
    "reference_abs_max": 0.24386590719223022,
    "shape": [
      4,
      50
    ]
  }
}
```

Floating point factorization, RoPE coordinate shifts and kernel reduction orders introduce differences, especially BF16. This is mathematical mask equivalence, not bitwise equivalence. Trained checkpoint relevance/ranking validation is still required. FP16 reduced error on the small validation set but was not used for the main BF16 throughput comparison.

## Implementation and limits

See README.md for reproduction commands and supported inputs, docs/executor_analysis.md for the downloaded executor analysis, and docs/design_review.md for the caching derivation. The optimized code executes in a native vLLM worker via LLM.apply_model, reusing native model weights. It bypasses the stock per-pair scheduler; HTTP serving and scheduler-level persistent caching are not implemented. This report gives the best measured configuration in these sweeps, not a proven maximum across all hardware or kernels.
