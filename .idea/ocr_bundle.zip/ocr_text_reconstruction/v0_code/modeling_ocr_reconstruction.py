"""
OCR Text Reconstruction Model
=============================

Layout-aware pointer-generation model that reconstructs a Markdown-like
structured representation of a document page from:

  * the page image, and
  * a set of OCR bounding boxes (one per detected text line).

The model does NOT generate text. At every decoding step it predicts either:

  * a *pointer* to one of the OCR boxes (copy that box's text), or
  * a fixed Markdown / layout *special token* (``#``, ``|``, ``\\n``, ...).

Architecture (see plan.md sections 5-9):

    page image ──► RT-DETR-v2 backbone + hybrid encoder ──► multi-scale memory
                                                                   │
    ocr boxes ─► (cxcywh)                                          │
        ├─ content  : BBoxMLP(4 → d_model) ───────► query content │
        └─ position : box ───► reference_points ──► deformable ◄───┘
                                              RT-DETR-v2 decoder
                                                     │
                                                     ▼
                                            H_box: (B, N, d_model)
                                                     │  (memory)
    target tokens ─► autoregressive Markdown decoder ┘
                                                     │
                                                     ▼
                            pointer head  +  special-token head
                                                     │
                                                     ▼
                            logits over [special (M) | boxes (N)]

Why RT-DETR-v2 instead of vanilla DETR (plan.md section 5/6):
  * A "query" in RT-DETR-v2 is a *content vector* paired with a *reference box*
    in (cx, cy, w, h) form. We supply the OCR box directly as the reference box,
    so we never run the model's two-stage proposal / top-k selection.
  * The decoder cross-attention is *deformable*: each query samples image
    features around its own reference box. Feeding the OCR box as the reference
    means every query pools the visual features at that text line for free.
  * ``query_pos_head`` (pretrained) already maps box(4) -> d_model positional
    embeddings every layer; we additionally add a trained content MLP.

This file depends on the installed ``transformers`` package for the pretrained
RT-DETR-v2 modules (NOT on the local exploration copy under ``layout_heron/``).
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Optional

import torch
import torch.nn as nn
import torch.nn.functional as F

from transformers import RTDetrV2Config, RTDetrV2Model


# --------------------------------------------------------------------------- #
# Helpers
# --------------------------------------------------------------------------- #
def inverse_sigmoid(x: torch.Tensor, eps: float = 1e-5) -> torch.Tensor:
    """Inverse of sigmoid; the RT-DETR-v2 decoder applies ``sigmoid`` to the
    reference points internally, so we pre-apply its inverse."""
    x = x.clamp(min=0, max=1)
    x1 = x.clamp(min=eps)
    x2 = (1 - x).clamp(min=eps)
    return torch.log(x1 / x2)


def box_xyxy_to_cxcywh(boxes: torch.Tensor) -> torch.Tensor:
    """(..., 4) xyxy  ->  (..., 4) cxcywh. Coordinates are assumed normalized to [0, 1]."""
    x1, y1, x2, y2 = boxes.unbind(-1)
    cx = (x1 + x2) * 0.5
    cy = (y1 + y2) * 0.5
    w = (x2 - x1).clamp(min=0)
    h = (y2 - y1).clamp(min=0)
    return torch.stack((cx, cy, w, h), dim=-1)


class MLP(nn.Module):
    """Simple multi-layer perceptron with ReLU between hidden layers."""

    def __init__(self, input_dim: int, hidden_dim: int, output_dim: int, num_layers: int = 3):
        super().__init__()
        dims = [input_dim] + [hidden_dim] * (num_layers - 1) + [output_dim]
        self.layers = nn.ModuleList(nn.Linear(a, b) for a, b in zip(dims[:-1], dims[1:]))

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        for i, layer in enumerate(self.layers):
            x = F.relu(layer(x)) if i < len(self.layers) - 1 else layer(x)
        return x


# --------------------------------------------------------------------------- #
# Config
# --------------------------------------------------------------------------- #
@dataclass
class OcrReconstructionConfig:
    """Configuration for :class:`OcrTextReconstructionModel`.

    The token id convention used everywhere (logits, labels, generation) is
    **special-first**, which keeps ids independent of how many boxes are padded:

        id in [0, num_special_tokens)            -> special Markdown token
        id in [num_special_tokens, +N)           -> pointer to OCR box (id - num_special_tokens)

    so a target id for box ``i`` is ``num_special_tokens + i``.
    """

    # ---- pretrained RT-DETR-v2 backbone ----
    backbone_name_or_path: str = "docling-project/docling-layout-heron"
    d_model: int = 256  # must match the RT-DETR-v2 d_model

    # ---- OCR box query content MLP (trained from scratch) ----
    content_mlp_hidden_dim: int = 512
    content_mlp_num_layers: int = 3

    # ---- special / markdown vocabulary ----
    # Must match CustomTokenizerV3.SPECIAL_TOKENS: 17 specials at global ids
    # 10000..10016. In this model's compact space they map to [0, 17) via
    # model_special_id = tokenizer_global_id - 10000  (bos=0, eos=1, pad=2, unk=3).
    # NOTE: <unk> (id 3) is reserved but dropped from training labels, so it is
    # never a target; cross-entropy over the other specials naturally suppresses it.
    num_special_tokens: int = 17  # M  (size of the fixed markdown/layout vocab)
    bos_token_id: int = 0  # index WITHIN the special vocab ([0, num_special_tokens))
    eos_token_id: int = 1
    pad_token_id: int = 2
    unk_token_id: int = 3

    # ---- autoregressive markdown decoder (trained from scratch) ----
    # NOTE: these are the MARKDOWN decoder's hyperparams, distinct from the
    # pretrained RT-DETR-v2 deformable decoder (which keeps Heron's own config).
    num_markdown_layers: int = 6
    markdown_attention_heads: int = 8
    markdown_ffn_dim: int = 2048
    dropout: float = 0.1
    max_position_embeddings: int = 2048

    # ---- misc ----
    label_ignore_index: int = -100


# --------------------------------------------------------------------------- #
# Output container
# --------------------------------------------------------------------------- #
@dataclass
class OcrReconstructionOutput:
    loss: Optional[torch.Tensor] = None
    logits: Optional[torch.Tensor] = None          # (B, T, M + N)
    pointer_logits: Optional[torch.Tensor] = None  # (B, T, N)
    special_logits: Optional[torch.Tensor] = None  # (B, T, M)
    box_hidden_states: Optional[torch.Tensor] = None  # H_box: (B, N, d_model)


# --------------------------------------------------------------------------- #
# Model
# --------------------------------------------------------------------------- #
class OcrTextReconstructionModel(nn.Module):
    def __init__(self, config: OcrReconstructionConfig, rtdetr: Optional[RTDetrV2Model] = None):
        super().__init__()
        self.config = config
        d = config.d_model

        # ------------------------------------------------------------------ #
        # 1. Pretrained RT-DETR-v2 (backbone + hybrid encoder + deformable
        #    decoder). We use the *head-less* RTDetrV2Model so that
        #    ``decoder.bbox_embed`` stays None -> reference points stay pinned
        #    to the OCR boxes across all decoder layers (no box refinement).
        # ------------------------------------------------------------------ #
        if rtdetr is None:
            # The Heron checkpoint is an RTDetrV2ForObjectDetection: its weights are
            # stored under the `model.` prefix (+ detection heads). Loading it into a
            # bare RTDetrV2Model mismatches that prefix and silently RANDOM-INITs the
            # backbone/encoder/decoder. So load the OD model (exact structural match)
            # and take its `.model` submodule -- this loads every pretrained weight.
            from transformers import RTDetrV2ForObjectDetection

            detector = RTDetrV2ForObjectDetection.from_pretrained(config.backbone_name_or_path)
            rtdetr = detector.model
            # We do NOT refine boxes: drop the detection heads the OD wired into the
            # decoder so reference points stay pinned to the OCR boxes across layers.
            rtdetr.decoder.bbox_embed = None
            rtdetr.decoder.class_embed = None
        self.rtdetr = rtdetr
        assert rtdetr.config.d_model == d, (
            f"d_model mismatch: config={d} but RT-DETR-v2={rtdetr.config.d_model}"
        )

        # ------------------------------------------------------------------ #
        # 2. OCR box -> query content (trained from scratch). The pretrained
        #    query_pos_head handles box -> positional embedding; this MLP gives
        #    each query an initial *content* vector derived from its box.
        # ------------------------------------------------------------------ #
        self.box_content_mlp = MLP(4, config.content_mlp_hidden_dim, d, config.content_mlp_num_layers)

        # ------------------------------------------------------------------ #
        # 3. Autoregressive Markdown decoder (trained from scratch).
        # ------------------------------------------------------------------ #
        self.special_embedding = nn.Embedding(config.num_special_tokens, d)
        self.pos_embedding = nn.Parameter(torch.zeros(1, config.max_position_embeddings, d))
        self.box_input_norm = nn.LayerNorm(d)  # normalize H_box when used as decoder input embedding
        self.embed_dropout = nn.Dropout(config.dropout)

        decoder_layer = nn.TransformerDecoderLayer(
            d_model=d,
            nhead=config.markdown_attention_heads,
            dim_feedforward=config.markdown_ffn_dim,
            dropout=config.dropout,
            activation="gelu",
            batch_first=True,
            norm_first=True,
        )
        self.markdown_decoder = nn.TransformerDecoder(decoder_layer, num_layers=config.num_markdown_layers)
        self.decoder_norm = nn.LayerNorm(d)

        # ------------------------------------------------------------------ #
        # 4. Output heads.
        # ------------------------------------------------------------------ #
        self.special_head = nn.Linear(d, config.num_special_tokens)  # M logits
        # Pointer head: project the RT-DETR box states (keys) into a pointer space,
        # then dot with the raw AR decoder state (query). Equivalent in capacity to
        # a query projection, but adapts the pretrained layout reps and lets the
        # projected keys be cached across decode steps. Leaves H_box's other roles
        # (cross-attn memory, input embeddings) untouched.
        self.pointer_key_proj = nn.Linear(d, d, bias=False)
        self.pointer_scale = 1.0 / math.sqrt(d)  # scaled dot product

        self._init_new_weights()

    # ------------------------------------------------------------------ #
    # init / freezing utilities
    # ------------------------------------------------------------------ #
    def _init_new_weights(self):
        nn.init.normal_(self.pos_embedding, std=0.02)
        nn.init.normal_(self.special_embedding.weight, std=0.02)
        nn.init.xavier_uniform_(self.pointer_key_proj.weight)

    def freeze_rtdetr(self, freeze_decoder: bool = True):
        """Freeze ALL pretrained RT-DETR-v2 parameters (backbone, encoder, decoder,
        and the unused two-stage proposal heads enc_output/enc_score_head/enc_bbox_head).
        Set ``freeze_decoder=False`` to keep fine-tuning the deformable decoder while
        the rest stays frozen."""
        for p in self.rtdetr.parameters():
            p.requires_grad_(False)
        if not freeze_decoder:
            for p in self.rtdetr.decoder.parameters():
                p.requires_grad_(True)

    def unfreeze_rtdetr(self):
        for p in self.rtdetr.parameters():
            p.requires_grad_(True)

    # ------------------------------------------------------------------ #
    # Step 1-3: image + OCR boxes -> H_box
    # ------------------------------------------------------------------ #
    def encode_boxes(
        self,
        pixel_values: torch.Tensor,
        ocr_boxes: torch.Tensor,
        box_mask: Optional[torch.Tensor] = None,
        pixel_mask: Optional[torch.Tensor] = None,
        boxes_are_xyxy: bool = True,
    ) -> torch.Tensor:
        """Run the RT-DETR-v2 backbone/encoder/decoder with OCR-box-conditioned
        queries and return ``H_box`` of shape ``(B, N, d_model)``.

        Args:
            pixel_values: (B, 3, H, W) preprocessed image (RTDetrImageProcessor).
            ocr_boxes:    (B, N, 4) box coordinates normalized to [0, 1].
            box_mask:     (B, N) bool, True for real boxes / False for padding.
            boxes_are_xyxy: if True, ``ocr_boxes`` is xyxy and converted to cxcywh.
        """
        rt = self.rtdetr
        device = pixel_values.device
        batch_size, _, height, width = pixel_values.shape

        boxes_cxcywh = box_xyxy_to_cxcywh(ocr_boxes) if boxes_are_xyxy else ocr_boxes
        # Padded boxes get a degenerate (0-size) box; they are masked out of all
        # downstream logits/losses, so their H_box value is irrelevant.

        # ---- backbone + hybrid encoder (replicates RTDetrV2Model.forward) ----
        if pixel_mask is None:
            pixel_mask = torch.ones((batch_size, height, width), device=device)
        features = rt.backbone(pixel_values, pixel_mask)
        proj_feats = [rt.encoder_input_proj[lvl](src) for lvl, (src, _m) in enumerate(features)]
        encoder_outputs = rt.encoder(proj_feats, return_dict=True)

        # ---- project encoder features to the decoder feature levels ----
        sources = [rt.decoder_input_proj[lvl](src) for lvl, src in enumerate(encoder_outputs[0])]
        if rt.config.num_feature_levels > len(sources):
            len_sources = len(sources)
            sources.append(rt.decoder_input_proj[len_sources](encoder_outputs[0])[-1])
            for i in range(len_sources + 1, rt.config.num_feature_levels):
                sources.append(rt.decoder_input_proj[i](encoder_outputs[0][-1]))

        # ---- flatten multi-scale features ----
        source_flatten, spatial_shapes_list = [], []
        spatial_shapes = torch.empty((len(sources), 2), device=device, dtype=torch.long)
        for lvl, source in enumerate(sources):
            h, w = source.shape[-2:]
            spatial_shapes[lvl, 0] = h
            spatial_shapes[lvl, 1] = w
            spatial_shapes_list.append((h, w))
            source_flatten.append(source.flatten(2).transpose(1, 2))
        source_flatten = torch.cat(source_flatten, 1)
        level_start_index = torch.cat(
            (spatial_shapes.new_zeros((1,)), spatial_shapes.prod(1).cumsum(0)[:-1])
        )

        # ---- OCR-box-conditioned queries ----
        # reference points (position pathway) -> drives pretrained query_pos_head
        # + deformable sampling. Decoder applies sigmoid internally.
        reference_points = inverse_sigmoid(boxes_cxcywh.to(source_flatten.dtype))
        # content pathway -> trained MLP
        target = self.box_content_mlp(boxes_cxcywh.to(source_flatten.dtype))

        decoder_outputs = rt.decoder(
            inputs_embeds=target,
            encoder_hidden_states=source_flatten,
            encoder_attention_mask=None,
            reference_points=reference_points,
            spatial_shapes=spatial_shapes,
            spatial_shapes_list=spatial_shapes_list,
            level_start_index=level_start_index,
            return_dict=True,
        )
        return decoder_outputs.last_hidden_state  # H_box: (B, N, d_model)

    # ------------------------------------------------------------------ #
    # Token embedding for the AR decoder (special-first id scheme)
    # ------------------------------------------------------------------ #
    def _embed_tokens(self, input_ids: torch.Tensor, box_hidden_states: torch.Tensor) -> torch.Tensor:
        """Map token ids to embeddings:
          * special token  -> learned special embedding
          * box pointer    -> the box's H_box vector (pointer-style input)
        """
        M = self.config.num_special_tokens
        is_box = input_ids >= M  # (B, T)

        special_ids = input_ids.clamp(max=M - 1)
        special_emb = self.special_embedding(special_ids)  # (B, T, d)

        box_ids = (input_ids - M).clamp(min=0)  # (B, T)
        normed_boxes = self.box_input_norm(box_hidden_states)  # (B, N, d)
        index = box_ids.unsqueeze(-1).expand(-1, -1, normed_boxes.size(-1))  # (B, T, d)
        box_emb = torch.gather(normed_boxes, 1, index)  # (B, T, d)

        return torch.where(is_box.unsqueeze(-1), box_emb, special_emb)

    # ------------------------------------------------------------------ #
    # Heads
    # ------------------------------------------------------------------ #
    def _compute_logits(self, hidden: torch.Tensor, box_hidden_states: torch.Tensor,
                        box_mask: Optional[torch.Tensor]):
        # pointer logits: project box states (keys), then dot with the decoder
        # state (query) -> score for copying each OCR box (plan 9.1)
        key = self.pointer_key_proj(box_hidden_states)  # (B, N, d)
        pointer_logits = torch.matmul(hidden, key.transpose(1, 2)) * self.pointer_scale
        if box_mask is not None:
            pointer_logits = pointer_logits.masked_fill(~box_mask.unsqueeze(1), float("-inf"))
        # special-token logits (plan 9.2)
        special_logits = self.special_head(hidden)
        # concat: [special (M) | boxes (N)]  (special-first id scheme)
        logits = torch.cat([special_logits, pointer_logits], dim=-1)
        return logits, pointer_logits, special_logits

    # ------------------------------------------------------------------ #
    # Forward (teacher forcing)
    # ------------------------------------------------------------------ #
    def forward(
        self,
        pixel_values: torch.Tensor,
        ocr_boxes: torch.Tensor,
        decoder_input_ids: torch.Tensor,
        box_mask: Optional[torch.Tensor] = None,
        labels: Optional[torch.Tensor] = None,
        pixel_mask: Optional[torch.Tensor] = None,
        boxes_are_xyxy: bool = True,
    ) -> OcrReconstructionOutput:
        """
        Args:
            pixel_values:      (B, 3, H, W) preprocessed page image.
            ocr_boxes:         (B, N, 4) normalized box coords.
            decoder_input_ids: (B, T) teacher-forcing input ids (BOS-prefixed),
                               using the special-first id scheme.
            box_mask:          (B, N) bool, True = real box.
            labels:            (B, T) target ids; positions to ignore = -100.
        """
        box_hidden_states = self.encode_boxes(
            pixel_values, ocr_boxes, box_mask=box_mask,
            pixel_mask=pixel_mask, boxes_are_xyxy=boxes_are_xyxy,
        )

        T = decoder_input_ids.size(1)
        tok_emb = self._embed_tokens(decoder_input_ids, box_hidden_states)
        x = self.embed_dropout(tok_emb + self.pos_embedding[:, :T])

        causal_mask = torch.triu(
            torch.full((T, T), float("-inf"), device=x.device), diagonal=1
        )
        memory_key_padding_mask = (~box_mask) if box_mask is not None else None

        hidden = self.markdown_decoder(
            tgt=x,
            memory=box_hidden_states,
            tgt_mask=causal_mask,
            memory_key_padding_mask=memory_key_padding_mask,
        )
        hidden = self.decoder_norm(hidden)

        logits, pointer_logits, special_logits = self._compute_logits(
            hidden, box_hidden_states, box_mask
        )

        loss = None
        if labels is not None:
            loss = F.cross_entropy(
                logits.reshape(-1, logits.size(-1)),
                labels.reshape(-1),
                ignore_index=self.config.label_ignore_index,
            )

        return OcrReconstructionOutput(
            loss=loss,
            logits=logits,
            pointer_logits=pointer_logits,
            special_logits=special_logits,
            box_hidden_states=box_hidden_states,
        )

    # ------------------------------------------------------------------ #
    # Greedy autoregressive generation (eval / inference)
    # ------------------------------------------------------------------ #
    @torch.no_grad()
    def generate(
        self,
        pixel_values: torch.Tensor,
        ocr_boxes: torch.Tensor,
        box_mask: Optional[torch.Tensor] = None,
        pixel_mask: Optional[torch.Tensor] = None,
        boxes_are_xyxy: bool = True,
        max_new_tokens: int = 1024,
    ) -> torch.Tensor:
        """Greedy decoding. Returns (B, L) generated ids in the special-first
        scheme (including the BOS prefix), stopping each sequence at EOS."""
        self.eval()
        cfg = self.config
        device = pixel_values.device
        batch_size = pixel_values.size(0)

        box_hidden_states = self.encode_boxes(
            pixel_values, ocr_boxes, box_mask=box_mask,
            pixel_mask=pixel_mask, boxes_are_xyxy=boxes_are_xyxy,
        )
        memory_key_padding_mask = (~box_mask) if box_mask is not None else None

        generated = torch.full((batch_size, 1), cfg.bos_token_id, dtype=torch.long, device=device)
        finished = torch.zeros(batch_size, dtype=torch.bool, device=device)

        for _ in range(max_new_tokens):
            T = generated.size(1)
            tok_emb = self._embed_tokens(generated, box_hidden_states)
            x = tok_emb + self.pos_embedding[:, :T]
            causal_mask = torch.triu(
                torch.full((T, T), float("-inf"), device=device), diagonal=1
            )
            hidden = self.markdown_decoder(
                tgt=x,
                memory=box_hidden_states,
                tgt_mask=causal_mask,
                memory_key_padding_mask=memory_key_padding_mask,
            )
            hidden = self.decoder_norm(hidden[:, -1:])  # last step only
            logits, _, _ = self._compute_logits(hidden, box_hidden_states, box_mask)
            next_token = logits[:, -1].argmax(dim=-1)  # (B,)

            # once finished, keep emitting PAD
            next_token = torch.where(
                finished,
                torch.full_like(next_token, cfg.pad_token_id),
                next_token,
            )
            generated = torch.cat([generated, next_token.unsqueeze(1)], dim=1)
            finished = finished | (next_token == cfg.eos_token_id)
            if bool(finished.all()):
                break

        return generated

    # ------------------------------------------------------------------ #
    # Multinomial sampling rollout (RL / GRPO fine-tuning)
    # ------------------------------------------------------------------ #
    @torch.no_grad()
    def sample_decode(
        self,
        pixel_values: torch.Tensor,
        ocr_boxes: torch.Tensor,
        box_mask: Optional[torch.Tensor] = None,
        pixel_mask: Optional[torch.Tensor] = None,
        boxes_are_xyxy: bool = True,
        max_new_tokens: int = 1024,
        temperature: float = 1.0,
    ):
        """Sampling twin of :meth:`generate` for policy-gradient RL (GRPO).

        Each step samples a token from ``softmax(logits / temperature)`` and
        records that token's log-prob under the **temperature-1 policy**
        (``log_softmax(logits)``). Temperature therefore only drives exploration;
        the recorded log-prob is the one the policy is actually optimised on, so
        it matches a teacher-forced :meth:`forward` recompute (importance ratio
        ~= 1 at init, in eval mode with dropout off).

        Returns three tensors aligned to the generated columns (col 0 = BOS):
            sequences:    (B, S) sampled ids incl. the BOS prefix.
            old_logprobs: (B, S) log-prob of each sampled token; col 0 (BOS) and
                          post-<eos> pad columns are 0.0.
            valid_mask:   (B, S) bool, True for real actions up to and INCLUDING
                          the first <eos> (False at BOS and after eos).

        To align with a recompute, feed ``sequences[:, :-1]`` to :meth:`forward`
        and compare its per-token log-probs at ``sequences[:, 1:]`` against
        ``old_logprobs[:, 1:]`` over ``valid_mask[:, 1:]``.
        """
        self.eval()
        cfg = self.config
        device = pixel_values.device
        batch_size = pixel_values.size(0)

        box_hidden_states = self.encode_boxes(
            pixel_values, ocr_boxes, box_mask=box_mask,
            pixel_mask=pixel_mask, boxes_are_xyxy=boxes_are_xyxy,
        )
        memory_key_padding_mask = (~box_mask) if box_mask is not None else None

        generated = torch.full((batch_size, 1), cfg.bos_token_id, dtype=torch.long, device=device)
        logprobs = torch.zeros((batch_size, 1), dtype=torch.float32, device=device)
        valid = torch.zeros((batch_size, 1), dtype=torch.bool, device=device)
        finished = torch.zeros(batch_size, dtype=torch.bool, device=device)

        for _ in range(max_new_tokens):
            T = generated.size(1)
            tok_emb = self._embed_tokens(generated, box_hidden_states)
            x = tok_emb + self.pos_embedding[:, :T]
            causal_mask = torch.triu(
                torch.full((T, T), float("-inf"), device=device), diagonal=1
            )
            hidden = self.markdown_decoder(
                tgt=x,
                memory=box_hidden_states,
                tgt_mask=causal_mask,
                memory_key_padding_mask=memory_key_padding_mask,
            )
            hidden = self.decoder_norm(hidden[:, -1:])  # last step only
            logits, _, _ = self._compute_logits(hidden, box_hidden_states, box_mask)
            step_logits = logits[:, -1]                               # (B, V) temperature-1 logits

            policy_logprob = torch.log_softmax(step_logits, dim=-1)   # the optimised policy
            sample_probs = torch.softmax(step_logits / temperature, dim=-1)
            next_token = torch.multinomial(sample_probs, num_samples=1).squeeze(1)  # (B,)
            token_logprob = policy_logprob.gather(1, next_token.unsqueeze(1)).squeeze(1)  # (B,)

            col_valid = ~finished                                     # the <eos> action stays valid
            # once finished, force PAD and a zero (ignored) log-prob
            next_token = torch.where(finished, torch.full_like(next_token, cfg.pad_token_id), next_token)
            token_logprob = torch.where(col_valid, token_logprob, torch.zeros_like(token_logprob))

            generated = torch.cat([generated, next_token.unsqueeze(1)], dim=1)
            logprobs = torch.cat([logprobs, token_logprob.unsqueeze(1)], dim=1)
            valid = torch.cat([valid, col_valid.unsqueeze(1)], dim=1)

            finished = finished | (next_token == cfg.eos_token_id)
            if bool(finished.all()):
                break

        return generated, logprobs, valid


__all__ = [
    "OcrReconstructionConfig",
    "OcrReconstructionOutput",
    "OcrTextReconstructionModel",
    "box_xyxy_to_cxcywh",
    "inverse_sigmoid",
    "MLP",
]
