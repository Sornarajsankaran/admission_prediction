"""
Throughput benchmark: reference PyTorch pipeline vs the vLLM port.
==================================================================

Inputs are pre-rasterized workloads from ``prepare_bench_set.py`` (uint8 640x640 +
boxes), so only model time is measured. Both backends decode greedily with identical
weights.

    # reference: OcrTwoStageModel.generate_end_to_end, static batches
    python bench.py reference --pages /workspace/datasets/ocr_bench/bench_w300.pt --batch-size 32 --limit 128

    # vLLM offline engine
    python bench.py vllm --pages /workspace/datasets/ocr_bench/bench_w300.pt --model /workspace/models/ocr_vllm
"""

from __future__ import annotations

import json
import time
from pathlib import Path

import click
import numpy as np
import torch


def _report(name: str, n_pages: int, seconds: float, order_tokens: int, fmt_tokens: int, extra: dict):
    res = {
        "backend": name, "pages": n_pages, "seconds": round(seconds, 2),
        "pages_per_s": round(n_pages / seconds, 2),
        "decode_tokens_per_s": round((order_tokens + fmt_tokens) / seconds, 1),
        "mean_order_tokens": round(order_tokens / n_pages, 1),
        "mean_format_tokens": round(fmt_tokens / n_pages, 1),
        **extra,
    }
    print(json.dumps(res))
    return res


@click.group()
def cli():
    pass


@cli.command()
@click.option("--pages", "pages_path", required=True)
@click.option("--ckpt", default="/workspace/models/ocr_twostage_random/model.pt")
@click.option("--batch-size", default=32, show_default=True)
@click.option("--limit", default=128, show_default=True)
@click.option("--dtype", type=click.Choice(["fp32", "bf16"]), default="fp32", show_default=True,
              help="bf16 = torch.autocast around generate_end_to_end")
@click.option("--sort/--no-sort", default=False, show_default=True,
              help="sort pages by box count before batching (reduces padding waste)")
@click.option("--dump", default=None, help="write generated ids to this json")
def reference(pages_path, ckpt, batch_size, limit, dtype, sort, dump):
    import os

    from common import load_model

    if os.environ.get("OCR_VLLM_STRICT_FP32") == "1":            # parity runs: no TF32 anywhere
        torch.backends.cudnn.allow_tf32 = False

    items = torch.load(pages_path, weights_only=False)[:limit]
    if sort:
        items = sorted(items, key=lambda it: len(it["boxes"]))
    model = load_model(Path(ckpt))
    use_amp = dtype == "bf16"

    def run(batch):
        B = len(batch)
        K = max(len(it["boxes"]) for it in batch)
        px = torch.stack([it["pixels"] for it in batch]).cuda().float() / 255.0
        bx = torch.zeros(B, K, 4, device="cuda")
        mk = torch.zeros(B, K, dtype=torch.bool, device="cuda")
        for i, it in enumerate(batch):
            bx[i, : len(it["boxes"])] = it["boxes"].cuda()
            mk[i, : len(it["boxes"])] = True
        with torch.autocast("cuda", dtype=torch.bfloat16, enabled=use_amp):
            gen, order, n_real = model.generate_end_to_end(px, bx, box_mask=mk, max_new_tokens=2047)
        return gen, order, n_real

    run(items[:batch_size])                                           # warmup
    torch.cuda.synchronize()
    t0 = time.perf_counter()
    order_tok = fmt_tok = 0
    outputs = []
    for i in range(0, len(items), batch_size):
        gen, order, n_real = run(items[i:i + batch_size])
        body = gen[:, 1:]
        order_tok += int(n_real.sum()) + len(n_real)                   # + FMT_BOS, like vLLM
        eos = (body == 1).long()
        fmt_tok += int(((torch.cumsum(eos, 1) - eos) == 0).sum())      # up to and incl. EOS
        if dump:
            for b in range(len(n_real)):
                row = body[b].tolist()
                outputs.append({"order": order[b, : n_real[b]].tolist(),
                                "fmt": row[: row.index(1) + 1] if 1 in row else row})
    torch.cuda.synchronize()
    dt = time.perf_counter() - t0
    if dump:
        json.dump(outputs, open(dump, "w"))
    _report(f"reference-{dtype}", len(items), dt, order_tok, fmt_tok,
            {"batch_size": batch_size, "sorted": sort})


@cli.command()
@click.option("--pages", "pages_path", required=True)
@click.option("--model", "model_dir", default="/workspace/models/ocr_vllm")
@click.option("--limit", default=None, type=int)
@click.option("--max-num-seqs", default=256, show_default=True)
@click.option("--max-num-batched-tokens", default=32768, show_default=True)
@click.option("--gpu-memory-utilization", default=0.85, show_default=True)
@click.option("--eager", is_flag=True)
@click.option("--wave", default=0, show_default=True,
              help="admit new pages only in groups of this size (0 = submit all at once)")
@click.option("--dump", default=None, help="write generated ids to this json")
@click.option("--block-size", default=None, type=int, help="KV cache block size (vLLM default 16)")
@click.option("--sync-start", default=None,
              help="multi-engine runs: touch <path>.ready.<pid> after warmup, wait for <path>")
def vllm(pages_path, model_dir, limit, max_num_seqs, max_num_batched_tokens,
         gpu_memory_utilization, eager, wave, dump, sync_start, block_size):
    from engine import make_llm, page_request, sampling_params, split_output
    from ocr_vllm.config import OcrTwoStageConfig

    items = torch.load(pages_path, weights_only=False)
    if limit:
        items = items[:limit]
    cfg = OcrTwoStageConfig.from_pretrained(model_dir)
    llm = make_llm(model_dir, max_num_seqs=max_num_seqs, max_num_batched_tokens=max_num_batched_tokens,
                   gpu_memory_utilization=gpu_memory_utilization, enforce_eager=eager,
                   cudagraph_mode=None if eager else "FULL_DECODE_ONLY",
                   **({"block_size": block_size} if block_size else {}))
    reqs = [page_request(it["pixels"], it["boxes"], cfg) for it in items]
    params = [sampling_params(cfg, len(it["boxes"])) for it in items]

    llm.generate(reqs[:8], params[:8], use_tqdm=False)                # warmup
    if sync_start:
        import os
        Path(f"{Path(sync_start).parent}/ready.{os.getpid()}").touch()
        while not Path(sync_start).exists():
            time.sleep(0.05)
    t0 = time.perf_counter()
    if wave:
        outs = run_in_waves(llm.llm_engine, reqs, params, max_num_seqs, wave)
    else:
        outs = llm.generate(reqs, params, use_tqdm=False)
    dt = time.perf_counter() - t0

    order_tok = fmt_tok = 0
    dumped = []
    for it, o in zip(items, outs):
        order, fmt = split_output(o.outputs[0].token_ids, cfg)
        order_tok += len(order) + 1
        fmt_tok += len(fmt)
        if sorted(order) != list(range(len(it["boxes"]))):
            print(f"WARNING: invalid order for {it['file_name']} p{it['page']}")
        dumped.append({"order": order, "fmt": fmt})
    if dump:
        json.dump(dumped, open(dump, "w"))
    _report("vllm", len(items), dt, order_tok, fmt_tok,
            {"max_num_seqs": max_num_seqs, "eager": eager,
             "encoder_dtype": cfg.encoder_dtype, "model": model_dir})


def run_in_waves(engine, reqs, params, max_running: int, wave: int):
    """Drive the engine directly, admitting pages ``wave`` at a time.

    vLLM runs a step with CUDA graphs only when no page in the batch is starting (its
    encoder-decoder support captures decode-only graphs). Submitting everything at once
    means some page finishes and a new one starts on almost every step, so nearly every
    step runs eagerly. Topping the batch up in waves keeps most steps on the graph path.
    """
    results, next_i, in_flight = {}, 0, 0
    while len(results) < len(reqs):
        if next_i < len(reqs) and (in_flight == 0 or max_running - in_flight >= wave):
            n = min(max_running - in_flight, len(reqs) - next_i)
            for i in range(next_i, next_i + n):
                engine.add_request(str(i), reqs[i], params[i])
            next_i += n
            in_flight += n
        for out in engine.step():
            if out.finished:
                results[int(out.request_id)] = out
                in_flight -= 1
    return [results[i] for i in range(len(reqs))]


if __name__ == "__main__":
    cli()
