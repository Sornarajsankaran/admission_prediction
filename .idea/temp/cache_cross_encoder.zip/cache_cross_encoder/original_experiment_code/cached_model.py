"""Exact, tiled ModernBERT Variant B executor (single GPU, unquantized).

Uses either HF or native vLLM executor weights without copying them. Documents
are query-independent at every layer. Query branches remain separate. Positions
are expressed relative to the first document token, so one document cache works
for different query lengths. Local windows are preserved.
"""
from dataclasses import dataclass
import torch
import torch.nn.functional as F


def rotate(x, cos, sin):
    a, b = x.float().chunk(2, dim=-1)
    return (x.float() * cos + torch.cat((-b, a), -1) * sin).to(x.dtype)


def pre(h, nw, nb, w, bias, cos, sin, eps):
    if nw is not None:
        h = F.layer_norm(h, (h.shape[-1],), nw, nb, eps)
    z = F.linear(h, w, bias).view(*h.shape[:-1], 3, 12, 64)
    q, k, v = z.unbind(-3)
    return rotate(q, cos, sin), rotate(k, cos, sin), v


def post(h, a, aw, ab, nw, nb, wi, bi, wo, bo, eps):
    h = h + F.linear(a.reshape_as(h), aw, ab)
    z = F.layer_norm(h, (h.shape[-1],), nw, nb, eps)
    u, g = F.linear(z, wi, bi).chunk(2, -1)
    return h + F.linear(F.gelu(u) * g, wo, bo)


@dataclass
class DocCache:
    kv: list
    lengths: torch.Tensor
    final_sum: torch.Tensor | None = None


class CachedModernBert:
    def __init__(self, model, backend="triton", compile_parts=False,
                 trim_local=True, last_cls=True, doc_backend="flash"):
        self.source = model
        self.config = model.config
        self.base = model.model
        self.layers = (self.base.layers if hasattr(self.base, "layers") else
                       self.base.encoder_layer.layers)
        self.head = model.head if hasattr(model, "head") else model.pooling
        self.backend = backend
        self.doc_backend = doc_backend
        self.trim_local = trim_local
        self.last_cls = last_cls and self.config.classifier_pooling == "cls"
        self.eps = self.config.norm_eps
        assert self.config.hidden_size == 768 and self.config.num_attention_heads == 12
        assert self.config.hidden_activation == "gelu"
        assert self.config.classifier_pooling in ("cls", "mean")
        self.pre = torch.compile(pre, fullgraph=True) if compile_parts else pre
        self.post = torch.compile(post, fullgraph=True) if compile_parts else post
        self._metadata = {}

    def window(self, i):
        return self.config.sliding_window if self.config.layer_types[i] == "sliding_attention" else -1

    def emb(self, ids):
        e = self.base.embeddings
        return e.norm(e.tok_embeddings(ids))

    def rope(self, positions, dtype, window):
        kind = "sliding_attention" if window >= 0 else "full_attention"
        theta = self.config.rope_parameters[kind]["rope_theta"]
        inv = 1. / (theta ** (torch.arange(0, 64, 2, device=positions.device).float()/64))
        f = positions.float()[..., None] * inv
        f = torch.cat((f, f), -1)
        # Match HF's reduced precision sin/cos contract before its fp32 multiply.
        return f.cos().to(dtype).unsqueeze(-2), f.sin().to(dtype).unsqueeze(-2)

    def metadata(self, qids, qlens, dids, dlens):
        # Tensors are immutable for one experiment shape; no data-dependent work
        # is hidden in the timed forward or CUDA graph.
        B, D = dids.shape
        R, Q = qids.shape
        dtype = self.base.embeddings.tok_embeddings.weight.dtype
        qp = torch.arange(Q, device=qids.device)[None, :] - qlens[:, None]
        dp = torch.arange(D, device=dids.device)[None, :]
        ropes = {}
        for w in (-1, self.config.sliding_window):
            qc, qs = self.rope(qp, dtype, w)
            dc, ds = self.rope(dp, dtype, w)
            ropes[w] = (qc[None], qs[None], dc, ds)
        pos = torch.arange(D, device=dids.device)
        valid = pos[None, :] < dlens[:, None]
        masks = {-1: valid[:, None, None, :]}
        masks[self.config.sliding_window] = (valid[:, None, None, :] &
             ((pos[:, None]-pos[None, :]).abs() <= self.config.sliding_window)[None, None])
        cu = torch.arange(B+1, device=dids.device, dtype=torch.int32) * D
        return {"ropes": ropes, "masks": masks, "cu": cu, "qlens": qlens, "dlens": dlens}

    def proj(self, layer, h, cos, sin):
        n, a = layer.attn_norm, layer.attn.Wqkv
        return self.pre(h, getattr(n,"weight",None), getattr(n,"bias",None),
                        a.weight, a.bias, cos, sin, self.eps)

    def finish(self, layer, h, attn):
        a, n, m = layer.attn.Wo, layer.mlp_norm, layer.mlp
        return self.post(h, attn, a.weight, a.bias, n.weight, n.bias,
                         m.Wi.weight, m.Wi.bias, m.Wo.weight, m.Wo.bias, self.eps)

    def doc_attn(self, q, k, v, window, meta):
        B,D,H,K=q.shape
        if self.doc_backend == "flash":
            from vllm.vllm_flash_attn import flash_attn_varlen_func
            # Synthetic documents have equal length. For variable lengths use
            # SDPA or pack documents and provide the actual cumulative lengths.
            return flash_attn_varlen_func(q.reshape(-1,H,K), k.reshape(-1,H,K),
                v.reshape(-1,H,K), D, meta["cu"], D, meta["cu"],
                causal=False, window_size=[window,window], fa_version=2).view(B,D,H,K)
        return F.scaled_dot_product_attention(q.transpose(1,2), k.transpose(1,2),
            v.transpose(1,2), attn_mask=meta["masks"][window]).transpose(1,2)

    def query_attn(self, q, k, v, dk, dv, window, meta):
        if self.backend == "triton":
            from shared_attention import shared_attention
            return shared_attention(q, k, v, dk, dv,
                query_lengths=meta["qlens"], doc_lengths=meta["dlens"], window=window)
        B,R,M,H,K=q.shape
        Q=k.shape[2]; D=dk.shape[1]
        keys=torch.cat((k,dk[:,None].expand(-1,R,-1,-1,-1)),2)
        vals=torch.cat((v,dv[:,None].expand(-1,R,-1,-1,-1)),2)
        qp=torch.arange(M,device=q.device)
        kp=torch.arange(Q,device=q.device)
        dp=torch.arange(D,device=q.device)
        qm=kp[None,None,:]<meta["qlens"][:,None,None]
        qm=qm.expand(R,M,Q)
        dm=(dp[None,None,:]<meta["dlens"][:,None,None]).expand(B,M,D)
        mask=torch.cat((qm[None].expand(B,-1,-1,-1),dm[:,None].expand(-1,R,-1,-1)),-1)
        if window>=0:
            qlocal=(qp[:,None]-kp[None,:]).abs()<=window
            dlocal=(qp[None,:,None]-meta["qlens"][:,None,None]-dp[None,None,:]).abs()<=window
            mask=mask & torch.cat((qlocal[None].expand(R,-1,-1),dlocal),-1)[None]
        ans=F.scaled_dot_product_attention(q.permute(0,1,3,2,4).reshape(B*R,H,M,K),
             keys.permute(0,1,3,2,4).reshape(B*R,H,Q+D,K),
             vals.permute(0,1,3,2,4).reshape(B*R,H,Q+D,K),
             attn_mask=mask.reshape(B*R,1,M,Q+D))
        return ans.reshape(B,R,H,M,K).permute(0,1,3,2,4)

    def logits(self, qh, qlens, dh_sum=None, dlens=None):
        qh=self.base.final_norm(qh)
        if self.config.classifier_pooling == "cls":
            pooled=qh[:,:,0]
        else:
            mask=torch.arange(qh.shape[2],device=qh.device)[None,:]<qlens[:,None]
            pooled=(qh*mask[None,:,:,None]).sum(2)
            pooled=(pooled+dh_sum[:,None])/(qlens[None,:,None]+dlens[:,None,None])
        pooled=pooled.to(self.head.dense.weight.dtype)
        pooled=self.head.norm(self.head.act(self.head.dense(pooled)))
        return self.source.classifier(pooled).squeeze(-1)

    def build_cache(self, dids, meta):
        dh=self.emb(dids); cache=[]
        for i,layer in enumerate(self.layers):
            w=self.window(i); _,_,dc,ds=meta["ropes"][w]
            dq,dk,dv=self.proj(layer,dh,dc,ds)
            n=min(w,dk.shape[1]) if self.trim_local and w>=0 else dk.shape[1]
            cache.append((dk[:,:n].contiguous(),dv[:,:n].contiguous()))
            if i<len(self.layers)-1 or self.config.classifier_pooling=="mean":
                dh=self.finish(layer,dh,self.doc_attn(dq,dk,dv,w,meta))
        dsum=None
        if self.config.classifier_pooling=="mean":
            dh=self.base.final_norm(dh)
            dm=torch.arange(dh.shape[1],device=dh.device)[None,:]<meta["dlens"][:,None]
            dsum=(dh*dm[:,:,None]).sum(1)
        return DocCache(cache,meta["dlens"],dsum)

    def query_cached(self, qids, cache, meta):
        B=cache.lengths.shape[0]
        qh=self.emb(qids)[None]
        for i,layer in enumerate(self.layers):
            w=self.window(i); qc,qs,_,_=meta["ropes"][w]
            q,k,v=self.proj(layer,qh,qc,qs)
            if i==0:
                q,k,v=(x.expand(B,-1,-1,-1,-1) for x in (q,k,v))
                qh=qh.expand(B,-1,-1,-1)
            if self.last_cls and i==len(self.layers)-1:
                q=q[:,:,:1]; qh=qh[:,:,:1]
            dk,dv=cache.kv[i]
            qh=self.finish(layer,qh,self.query_attn(q,k,v,dk,dv,w,meta))
        return self.logits(qh,meta["qlens"],cache.final_sum,cache.lengths)

    def stream(self, qids, dids, meta):
        B=dids.shape[0]
        dh=self.emb(dids)
        qh=self.emb(qids)[None]
        for i,layer in enumerate(self.layers):
            w=self.window(i); qc,qs,dc,ds=meta["ropes"][w]
            dq,dk,dv=self.proj(layer,dh,dc,ds)
            q,k,v=self.proj(layer,qh,qc,qs)
            if i==0:
                q,k,v=(x.expand(B,-1,-1,-1,-1) for x in (q,k,v))
                qh=qh.expand(B,-1,-1,-1)
            if self.last_cls and i==len(self.layers)-1:
                q=q[:,:,:1]; qh=qh[:,:,:1]
            n=min(w,dk.shape[1]) if self.trim_local and w>=0 else dk.shape[1]
            qh=self.finish(layer,qh,self.query_attn(q,k,v,dk[:,:n],dv[:,:n],w,meta))
            if i<len(self.layers)-1 or self.config.classifier_pooling=="mean":
                dh=self.finish(layer,dh,self.doc_attn(dq,dk,dv,w,meta))
        dsum=None
        if self.config.classifier_pooling=="mean":
            dh=self.base.final_norm(dh)
            dm=torch.arange(dh.shape[1],device=dh.device)[None,:]<meta["dlens"][:,None]
            dsum=(dh*dm[:,:,None]).sum(1)
        return self.logits(qh,meta["qlens"],dsum,meta["dlens"])

    def prepare_joint_metadata(self, meta):
        """Cache shape-static rotary tensors before timing/capture."""
        if "joint_ropes" not in meta:
            joint = {}
            for w, (qc, qs, dc, ds) in meta["ropes"].items():
                # [1,R,Q,1,K] -> [1,R*Q,1,K], then invariant document positions.
                joint[w] = (
                    torch.cat((qc.flatten(1,2), dc), dim=1),
                    torch.cat((qs.flatten(1,2), ds), dim=1),
                )
            meta["joint_ropes"] = joint
        return meta

    def stream_joint(self, qids, dids, meta):
        """Encode all query branches and documents with joint dense operations.

        Each layer uses one projection GEMM and one output/MLP path over the
        combined tokens. Attention is still split: every query sees only its
        private query keys plus the shared document; documents see documents.
        Metadata preparation is memoized and should precede timed execution.
        Supports CLS and mean pooling, including exact final CLS-only output.
        """
        self.prepare_joint_metadata(meta)
        B, D = dids.shape
        R, Q = qids.shape
        RQ = R * Q
        dh = self.emb(dids)
        qh = self.emb(qids).reshape(1, RQ, -1).expand(B, -1, -1)
        h = torch.cat((qh, dh), dim=1)
        for i, layer in enumerate(self.layers):
            w = self.window(i)
            cos, sin = meta["joint_ropes"][w]
            aq, ak, av = self.proj(layer, h, cos, sin)
            q = aq[:, :RQ].reshape(B, R, Q, 12, 64)
            k = ak[:, :RQ].reshape(B, R, Q, 12, 64)
            v = av[:, :RQ].reshape(B, R, Q, 12, 64)
            dq, dk, dv = aq[:, RQ:], ak[:, RQ:], av[:, RQ:]
            n = min(w, D) if self.trim_local and w >= 0 else D

            # No later layer consumes document outputs at the final CLS layer.
            if i == len(self.layers) - 1 and self.config.classifier_pooling == "cls":
                qh = h[:, :RQ].reshape(B, R, Q, -1)
                if self.last_cls:
                    q, qh = q[:, :, :1], qh[:, :, :1]
                qa = self.query_attn(q, k, v, dk[:, :n], dv[:, :n], w, meta)
                qh = self.finish(layer, qh, qa)
                return self.logits(qh, meta["qlens"])

            qa = self.query_attn(q, k, v, dk[:, :n], dv[:, :n], w, meta)
            da = self.doc_attn(dq, dk, dv, w, meta)
            attention = torch.cat((qa.reshape(B, RQ, 12, 64), da), dim=1)
            h = self.finish(layer, h, attention)

        # Mean pooling includes each query's private final states and the shared
        # document sum, with the original valid-token denominator.
        qh = h[:, :RQ].reshape(B, R, Q, -1)
        dh = self.base.final_norm(h[:, RQ:])
        valid = torch.arange(D, device=dh.device)[None, :] < meta["dlens"][:, None]
        dsum = (dh * valid[:, :, None]).sum(1)
        return self.logits(qh, meta["qlens"], dsum, meta["dlens"])
