import fitz
import pandas as pd
import pyarrow.parquet as pq
from concurrent.futures import ProcessPoolExecutor, as_completed
from pathlib import Path
from PIL import Image
from tqdm import tqdm
from typing import Optional

from docling_lite.core.config import (
    LAYOUT_DPI,
    RASTER_JPEG_QUALITY,
    RASTER_WORKERS,
)
from docling_lite.core.logging import log_function_calls, logger


def _rasterize_pdf(args):
    pdf_path_str, pages, raster_dir_str, dpi, jpeg_quality = args
    pdf_path = Path(pdf_path_str)
    raster_dir = Path(raster_dir_str)

    rows = []
    errors = []

    doc = fitz.open(pdf_path)
    try:
        if pages is None:
            pages = list(range(doc.page_count))

        zoom = dpi / 72.0
        matrix = fitz.Matrix(zoom, zoom)

        for page_no in pages:
            try:
                rel_path = Path("images") / pdf_path.stem / f"p{page_no:04d}.jpg"
                abs_path = raster_dir / rel_path

                page = doc.load_page(page_no)
                page_rect = page.rect
                page_w_pt = float(page_rect.width)
                page_h_pt = float(page_rect.height)

                if abs_path.exists():
                    with Image.open(abs_path) as img:
                        image_w, image_h = img.size
                else:
                    pix = page.get_pixmap(matrix=matrix)
                    image_w, image_h = pix.width, pix.height
                    abs_path.parent.mkdir(parents=True, exist_ok=True)
                    pil = Image.frombytes("RGB", (image_w, image_h), pix.samples)
                    pil.save(abs_path, format="JPEG", quality=jpeg_quality)

                rows.append(
                    {
                        "file_name": pdf_path.name,
                        "page": page_no,
                        "image_path": rel_path.as_posix(),
                        "image_width": image_w,
                        "image_height": image_h,
                        "page_width_pt": page_w_pt,
                        "page_height_pt": page_h_pt,
                        "dpi": dpi,
                    }
                )
            except Exception as e:
                errors.append((pdf_path.name, page_no, repr(e)))
    finally:
        doc.close()

    return rows, errors


class PdfRasterizer:
    def __init__(
        self,
        dpi: int = LAYOUT_DPI,
        jpeg_quality: int = RASTER_JPEG_QUALITY,
        workers: int = RASTER_WORKERS,
    ):
        self.dpi = int(dpi)
        self.jpeg_quality = int(jpeg_quality)
        self.workers = int(workers)

    @staticmethod
    def _load_ocr_pages(ocr_df_path: Path) -> dict[str, list[int]]:
        suffix = ocr_df_path.suffix.lower()
        column_aliases = {"filename": "file_name", "pageno": "page"}

        if suffix == ".parquet":
            actual_cols = pq.read_schema(ocr_df_path).names
            col_map = {c.lower(): c for c in actual_cols}
            wanted = [
                col_map[c]
                for c in ("file_name", "filename", "page", "pageno")
                if c in col_map
            ]
            df = pd.read_parquet(ocr_df_path, columns=wanted)
        elif suffix == ".csv":
            df = pd.read_csv(ocr_df_path)
        else:
            raise ValueError(f"Unsupported OCR df format: {suffix}")

        df.columns = df.columns.str.lower()
        df.rename(columns=column_aliases, inplace=True)

        if "file_name" not in df.columns or "page" not in df.columns:
            raise ValueError(
                "OCR df must contain 'file_name' (or 'filename') and "
                "'page' (or 'pageno') columns."
            )

        df = df.dropna(subset=["file_name", "page"])
        df["page"] = df["page"].astype(int)

        return {
            name: sorted(set(group["page"].tolist()))
            for name, group in df.groupby("file_name")
        }

    def _build_work_list(
        self, pdf_dir: Path, ocr_df_path: Optional[Path]
    ) -> list[tuple[Path, Optional[list[int]]]]:
        all_pdfs = list(pdf_dir.rglob("*.pdf"))
        pdf_by_name = {p.name: p for p in all_pdfs}

        if ocr_df_path is None:
            return [(path, None) for path in all_pdfs]

        pages_by_name = self._load_ocr_pages(ocr_df_path)
        work: list[tuple[Path, Optional[list[int]]]] = []
        missing: list[str] = []
        for fname, pages in pages_by_name.items():
            if fname in pdf_by_name:
                work.append((pdf_by_name[fname], pages))
            else:
                missing.append(fname)
        if missing:
            logger.warning(
                f"OCR df references {len(missing)} PDFs not found in {pdf_dir} "
                f"(first few: {missing[:5]})"
            )
        return work

    @log_function_calls(logger)
    def rasterize(
        self,
        pdf_dir: Path,
        raster_dir: Path,
        ocr_df_path: Optional[Path] = None,
    ) -> pd.DataFrame:
        raster_dir.mkdir(parents=True, exist_ok=True)
        (raster_dir / "images").mkdir(exist_ok=True)

        work_list = self._build_work_list(pdf_dir, ocr_df_path)
        if not work_list:
            raise ValueError(f"No PDFs to rasterize in {pdf_dir}.")

        known_pages = sum(len(p) for _, p in work_list if p is not None)
        unknown_pdfs = sum(1 for _, p in work_list if p is None)
        total_estimate = known_pages if unknown_pdfs == 0 else None

        logger.info(
            f"Rasterizing {len(work_list)} PDFs at DPI={self.dpi}, "
            f"JPEG quality={self.jpeg_quality}, workers={self.workers}"
        )

        worker_args = [
            (str(p), pages, str(raster_dir), self.dpi, self.jpeg_quality)
            for p, pages in work_list
        ]

        all_rows: list[dict] = []
        all_errors: list[tuple[str, int, str]] = []

        with ProcessPoolExecutor(max_workers=self.workers) as executor:
            futures = {
                executor.submit(_rasterize_pdf, args): args[0]
                for args in worker_args
            }
            with tqdm(total=total_estimate, desc="Rasterizing", unit="page") as pbar:
                for future in as_completed(futures):
                    pdf_path = futures[future]
                    try:
                        rows, errors = future.result()
                        all_rows.extend(rows)
                        all_errors.extend(errors)
                        pbar.update(len(rows))
                    except Exception as e:
                        logger.error(f"Worker failed for {pdf_path}: {e}")

        if all_errors:
            logger.warning(
                f"Encountered {len(all_errors)} per-page errors "
                f"(first few: {all_errors[:3]})"
            )

        if not all_rows:
            raise RuntimeError("Rasterization produced no output.")

        index_df = (
            pd.DataFrame(all_rows)
            .sort_values(["file_name", "page"])
            .reset_index(drop=True)
        )
        index_path = raster_dir / "index.parquet"
        index_df.to_parquet(index_path, index=False)
        logger.success(
            f"Wrote {len(index_df)} index rows to {index_path}"
        )
        return index_df
