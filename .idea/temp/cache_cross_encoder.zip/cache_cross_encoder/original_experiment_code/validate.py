#!/usr/bin/env python3
"""Dense HF numerical oracle for cached, asymmetric ModernBERT execution.

Verifies cache equivalence against Variant B, not against the full-attention
baseline (they intentionally implement different attention graphs).
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path

import torch
import torch.nn.functional as F
from transformers import AutoModelForSequenceClassification

from bench_hf import pack_pairs
from cached_model import CachedModernBert


def metrics(a, b):
    a, b = a.detach().float(), b.detach().float()
    error = a - b
    return {"max_abs": error.abs().max().item(), "rms": error.square().mean().sqrt().item(),
            "cosine": F.cosine_similarity(a.flatten(), b.flatten(), dim=0).item(),
            "reference_abs_max": b.abs().max().item(),
            "shape": list(a.shape)}


def dense_inputs(data, pair_indices, window, shift=False, variant_b=True):
    inputs, qlens = pack_pairs(data, pair_indices)
    ids, valid = inputs["input_ids"], inputs["attention_mask"]
    n, width = ids.shape
    pos = torch.arange(width, device=ids.device)
    mask = valid[:, None, None, :].expand(n, 1, width, width)
    if variant_b:
        query_receiver = pos[None, :, None] < qlens[:, None, None]
        document_key = pos[None, None, :] >= qlens[:, None, None]
        mask = mask & (query_receiver | document_key)[:, None]
    local = (pos[:, None] - pos[None, :]).abs() <= window
    inputs["attention_mask"] = {"full_attention": mask, "sliding_attention": mask & local[None, None]}
    inputs["position_ids"] = pos[None].expand(n, -1) - (qlens[:, None] if shift else 0)
    return inputs, qlens


@torch.inference_mode()
def run_dtype(args, data, dtype_name):
    dtype = {"fp32": torch.float32, "bf16": torch.bfloat16, "fp16": torch.float16}[dtype_name]
    model = AutoModelForSequenceClassification.from_pretrained(
        args.model, dtype=dtype, attn_implementation="sdpa").eval().to("cuda")
    qi = torch.tensor([0, 2, 5, 27])
    di = torch.tensor([0, 19])
    pair_ids = (di[:, None] * 50 + qi[None]).flatten()
    qlens = data["query_lengths"][qi].to("cuda")
    qids = data["query_input_ids"][qi, :int(qlens.max())].to("cuda")
    dids = data["doc_input_ids"][di].to("cuda")
    dlens = data["doc_lengths"][di].to("cuda")
    shifted_in, _ = dense_inputs(data, pair_ids, model.config.sliding_window, shift=True)
    absolute_in, _ = dense_inputs(data, pair_ids, model.config.sliding_window, shift=False)
    dense_shifted = model(**shifted_in).logits.reshape(len(di), len(qi))
    dense_absolute = model(**absolute_in).logits.reshape(len(di), len(qi))
    results = {"position_shift_vs_absolute": metrics(dense_shifted, dense_absolute)}
    engines = ["sdpa"] if dtype == torch.float32 else ["sdpa", "triton"]
    saved_outputs = {}
    for engine in engines:
        wrapper = CachedModernBert(model, backend=engine, compile_parts=False,
                                   trim_local=True, last_cls=True, doc_backend="sdpa")
        meta = wrapper.metadata(qids, qlens, dids, dlens)
        cached = wrapper.build_cache(dids, meta)
        out_cache = wrapper.query_cached(qids, cached, meta)
        out_stream = wrapper.stream(qids, dids, meta)
        saved_outputs[engine] = out_cache
        joint = wrapper.stream_joint(qids, dids, meta)
        row = {"joint_vs_dense_shifted": metrics(joint, dense_shifted), "joint_vs_stream": metrics(joint,out_stream), "cached_vs_dense_shifted": metrics(out_cache, dense_shifted),
               "cached_vs_dense_absolute": metrics(out_cache, dense_absolute),
               "stream_vs_dense_shifted": metrics(out_stream, dense_shifted),
               "cache_vs_stream": metrics(out_cache, out_stream)}
        # Removing or changing an unrelated query branch cannot affect other scores.
        singles = []
        for r in range(len(qi)):
            single_meta = wrapper.metadata(qids[r:r+1], qlens[r:r+1], dids, dlens)
            singles.append(wrapper.query_cached(qids[r:r+1], cached, single_meta))
        row["query_batch_vs_individual"] = metrics(out_cache, torch.cat(singles, 1))
        altered = qids.clone()
        altered[0, 1:qlens[0]-1] = torch.flip(altered[0, 1:qlens[0]-1], dims=[0])
        altered_out = wrapper.query_cached(altered, cached, meta)
        row["unrelated_query_mutation"] = metrics(out_cache[:, 1:], altered_out[:, 1:])
        row["mutated_query_max_score_change"] = (out_cache[:, 0] - altered_out[:, 0]).abs().max().item()
        # Final CLS-only projection and local document-prefix trimming are exact.
        wrapper.last_cls = False
        no_cls_prune = wrapper.query_cached(qids, cached, meta)
        row["final_cls_pruning"] = metrics(out_cache, no_cls_prune)
        if dtype != torch.float32:
            wrapper.doc_backend = "flash"
            wrapper.last_cls = True
            flash_joint = wrapper.stream_joint(qids, dids, meta)
            row["flash_joint_vs_dense_absolute"] = metrics(flash_joint, dense_absolute)
        results[engine] = row
        if dtype == torch.float32:
            torch.testing.assert_close(out_cache, dense_shifted, atol=5e-5, rtol=5e-5)
            torch.testing.assert_close(out_cache, out_stream, atol=5e-5, rtol=5e-5)
            torch.testing.assert_close(out_cache, torch.cat(singles, 1), atol=5e-5, rtol=5e-5)
    if "triton" in saved_outputs:
        results["triton_vs_sdpa"] = metrics(saved_outputs["triton"], saved_outputs["sdpa"])
    # Two inputs differ in query content only. All document states must match.
    doc_in, doc_qlens = dense_inputs(data, [0, 0], model.config.sliding_window, shift=True)
    length = int(doc_qlens[0])
    doc_in["input_ids"][1, 1:length-1] = torch.flip(doc_in["input_ids"][1, 1:length-1], dims=[0])
    hidden = model.model(**doc_in).last_hidden_state
    results["document_query_invariance"] = metrics(hidden[0, length:], hidden[1, length:])
    torch.testing.assert_close(hidden[0, length:], hidden[1, length:], atol=0, rtol=0)
    results["logits"] = {"dense_shifted": dense_shifted.float().cpu().tolist(),
                         "dense_absolute": dense_absolute.float().cpu().tolist(),
                         "cached": {k: v.float().cpu().tolist() for k, v in saved_outputs.items()}}
    results["query_ids"] = qi.tolist()
    results["document_ids"] = di.tolist()
    results["query_lengths"] = qlens.cpu().tolist()
    del model
    torch.cuda.empty_cache()
    return results


def main(args):
    torch.set_num_threads(8)
    torch.backends.cuda.matmul.allow_tf32 = False
    torch.set_float32_matmul_precision("highest")
    data = torch.load(Path(__file__).resolve().parent / "data/tokenized.pt", weights_only=True)
    report = {"description": "Dense asymmetric HF attention with preserved local windows compared to factorized shared document-KV executor", "model": args.model, "results": {}}
    for dtype in args.dtypes:
        result = run_dtype(args, data, dtype)
        report["results"][dtype] = result
        Path(args.output).write_text(json.dumps(report, indent=2) + "\n")
        print(json.dumps({"dtype": dtype, "results": result}), flush=True)


if __name__ == "__main__":
    p = argparse.ArgumentParser()
    root = Path(__file__).resolve().parent
    p.add_argument("--model", default=str(root / "models/benchmark-cls"))
    p.add_argument("--dtypes", nargs="+", choices=["fp32", "bf16", "fp16"], default=["fp32", "bf16"])
    p.add_argument("--output", default=str(root / "results/correctness.json"))
    main(p.parse_args())
