"""Convert one record's raw chunks and queries into portable benchmark tensors."""
import argparse,json
from pathlib import Path
import torch
from transformers import AutoTokenizer

def read(path):
    return [json.loads(line) for line in Path(path).read_text().splitlines() if line.strip()]

def main():
    p=argparse.ArgumentParser()
    p.add_argument('--chunks',required=True)
    p.add_argument('--queries',required=True)
    p.add_argument('--tokenizer',default=str(Path(__file__).parent/'models/benchmark-cls'))
    p.add_argument('--output-dir',required=True)
    p.add_argument('--max-content-tokens',type=int,default=256)
    a=p.parse_args()
    if a.max_content_tokens<1:raise ValueError('max-content-tokens must be positive')
    chunks,queries=read(a.chunks),read(a.queries)
    if not chunks or not queries:raise ValueError('Both inputs must be nonempty')
    records={str(c['record_id']) for c in chunks if 'record_id' in c}
    if len(records)>1:raise ValueError('Use one medical record per input dataset')
    tok=AutoTokenizer.from_pretrained(a.tokenizer,local_files_only=True)
    def encode(s):return tok.encode(s,add_special_tokens=False)
    docs=[]; mapping=[]; query_ids=[]; qmapping=[]
    for i,c in enumerate(chunks):
        raw=encode(c['text'])
        if not raw:raise ValueError(f'Empty chunk at row {i}')
        # Split overlong source chunks; never silently discard text.
        for part,start in enumerate(range(0,len(raw),a.max_content_tokens)):
            ids=encode('<DOC>')+raw[start:start+a.max_content_tokens]+encode('</DOC>')+[tok.sep_token_id]
            docs.append(ids)
            mapping.append({'row':len(docs)-1,'chunk_id':c.get('chunk_id',i),'part':part,'record_id':c.get('record_id')})
    for i,q in enumerate(queries):
        body=f"<QUERY> ICD code: {q['icd_code']}({q['icd_code_description']})\nattribute: {q['attribute']}\n search keyterm: {q['keyterm']}</QUERY>"
        ids=[tok.cls_token_id]+encode(body)+[tok.sep_token_id]
        if tok.sep_token_id in ids[:-1]:raise ValueError('Embedded separator in query changes the first-SEP contract')
        query_ids.append(ids);qmapping.append({'column':i,'query_id':q.get('query_id',i)})
    def pad(rows):
        lengths=torch.tensor([len(x) for x in rows])
        out=torch.full((len(rows),int(lengths.max())),tok.pad_token_id,dtype=torch.long)
        for i,ids in enumerate(rows):out[i,:len(ids)]=torch.tensor(ids)
        return out,lengths,torch.arange(out.shape[1])[None,:]<lengths[:,None]
    qi,ql,qm=pad(query_ids);di,dl,dm=pad(docs)
    out=Path(a.output_dir);out.mkdir(parents=True,exist_ok=True)
    torch.save(dict(query_input_ids=qi,query_lengths=ql,query_attention_mask=qm,
                    doc_input_ids=di,doc_lengths=dl,doc_attention_mask=dm,pad_token_id=tok.pad_token_id),out/'tokenized.pt')
    metadata={'chunks':mapping,'queries':qmapping,'score_layout':'[chunk row, query column], raw scalar logits',
              'num_documents':len(docs),'num_queries':len(queries),'pairs':len(docs)*len(queries),
              'doc_width':di.shape[1],'query_width':qi.shape[1],
              'equal_doc_lengths':bool((dl==dl[0]).all()),'tokenizer':a.tokenizer}
    (out/'mapping.json').write_text(json.dumps(metadata,indent=2)+'\n')
    print(json.dumps({k:v for k,v in metadata.items() if k not in ['chunks','queries']},indent=2))
if __name__=='__main__':main()
