import json,statistics
from pathlib import Path
def rows(p):return [json.loads(x) for x in Path(p).read_text().splitlines()]
v=rows('results/vllm.jsonl');c=rows('results/vllm_custom.jsonl')
full=[x for x in v if x['num_pairs']==250000]
cf=[x for x in c if 'full_workload'in x]
s=['# Measured throughput report','', 'Hardware: one NVIDIA L40S. Workload:5000 distinct263-token wrapped documents ×50 queries (30–41 tokens),250000 scores. All GPU jobs ran sequentially. Public weights plus shared untrained CLS/GELU head; no retrieval-quality claim.','']
if full and cf:
 b=max(full,key=lambda x:x['pairs_per_second']);t=statistics.median([x['full_workload']['seconds']for x in cf]);rate=250000/t
 s += ['## Full-record measurements','', '| Implementation | Scores/sec | Seconds/250k | 100 records, extrapolated |','|---|---:|---:|---:|',f"| Tuned stock vLLM API | {b['pairs_per_second']:,.0f} | {b['median_seconds']:.2f} | {b['median_seconds']*100/60:.1f} min |",f'| Custom native vLLM worker, cache construction included | {rate:,.0f} | {t:.2f} | {t*100/60:.1f} min |','',f"Observed wall-time speedup: **{b['median_seconds']/t:.2f}×**. Custom full-run seconds: {[round(x['full_workload']['seconds'],3)for x in cf]}. Baseline full-run seconds: {b['seconds']}.",'','The custom worker uses a grouped offline execution API and avoids per-pair scheduler/output-object overhead. This ratio therefore includes both reuse and execution/API changes; it is not an isolated attention-kernel speedup. All custom full runs include token H2D, document computation, query computation, classifier and score D2H. Model initialization, warmup/compilation and tokenization are excluded.100-record times are linear extrapolations, not an executed concurrent100-record benchmark.','']
s+=['## Stock vLLM sweeps','', '| Pairs | Token budget | Max sequences | Compiled | Scores/sec |','|---:|---:|---:|---|---:|']
for x in v:
 if x.get('pilot_only') or x.get('head_dtype')!='bfloat16':continue
 s.append(f"|{x['num_pairs']}|{x['max_num_batched_tokens']}|{x['max_num_seqs']}|{x['compiled']}|{x['pairs_per_second']:.0f}|")
s+=['','## Custom native vLLM executor sweeps','', '| Mode | Docs/tile | Compile | Graph | Scores/sec | Peak allocated GiB |','|---|---:|---|---|---:|---:|']
for x in c:
 if 'full_workload'in x:continue
 s.append(f"|{x['mode']}|{x['tile']}|{x['compile_parts']}|{x['cuda_graph']}|{x['pairs_per_second']:.0f}|{x['peak_allocated_gib']:.2f}|")
s+=['','`hot` excludes cache construction; all other modes include document work. `joint` combines document/query projections and MLP operations while retaining isolated attention. These tile timings exclude input/output transfers and are microbenchmarks.','', '## HF baseline, resident-input forward only','', '| Mode | Batch | Scores/sec |','|---|---:|---:|']
for p in ['results/hf_baseline.json','results/hf_graph.json']:
 x=json.loads(Path(p).read_text())
 for y in x['results']:s.append(f"|{x['mode']}|{y['batch_size']}|{y['pairs_per_second']:.0f}|")
s+=['','## Numerical checks','', 'Correctness is measured against the dense **Variant B mask**, not the full cross-encoder baseline: those intentionally use different attention graphs. FP32 dense-vs-factorized maximum score difference was below8e-6 on the eight-score validation set. Document invariance and unrelated-query mutation tests passed.','', '| Precision | Triton+Flash joint vs dense absolute positions, max abs score error |','|---|---:|']
x=json.loads(Path('results/correctness.json').read_text())
for d,r in x['results'].items():
 if 'triton'in r:s.append(f"|{d}|{r['triton']['flash_joint_vs_dense_absolute']['max_abs']:.6f}|")
p=Path('results/full_score_validation.json')
if p.exists():s+=['','Actual saved scores from the winning compiled native worker, first200 pairs:', '```json',p.read_text(),'```']
s+=['','Floating point factorization, RoPE coordinate shifts and kernel reduction orders introduce differences, especially BF16. This is mathematical mask equivalence, not bitwise equivalence. Trained checkpoint relevance/ranking validation is still required. FP16 reduced error on the small validation set but was not used for the main BF16 throughput comparison.','', '## Implementation and limits','', 'See README.md for reproduction commands and supported inputs, docs/executor_analysis.md for the downloaded executor analysis, and docs/design_review.md for the caching derivation. The optimized code executes in a native vLLM worker via LLM.apply_model, reusing native model weights. It bypasses the stock per-pair scheduler; HTTP serving and scheduler-level persistent caching are not implemented. This report gives the best measured configuration in these sweeps, not a proven maximum across all hardware or kernels.']
Path('REPORT.md').write_text('\n'.join(s)+'\n')
