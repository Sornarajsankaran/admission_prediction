"""
GRPO fine-tuning for the OCR Text Reconstruction model.
=======================================================

Reinforcement-learning fine-tune of an SFT checkpoint so the model stops
dropping OCR boxes. Reward = coverage - duplicates (see reward.py); formatting
is held in place by a KL leash to the frozen SFT reference model.

One optimizer step (GRPO):
    1. take P pages, replicate each K times                    -> P*K rollouts
    2. sample_decode each rollout (record old log-probs)
    3. reward each rollout (coverage / duplicates)
    4. group-normalize rewards within each page's K samples    -> advantages
    5. recompute log-probs with grad (policy) and without (reference)
    6. loss = clipped surrogate + kl_beta * KL(policy || reference)

The policy is kept in eval() throughout (dropout off) so the sampled log-probs
match the teacher-forced recompute -- the importance ratio starts at ~1.

Real run (GPU box, init from an SFT checkpoint):

    python grpo_train.py \
        --train-parquet /data/train_data.parquet --pdf-dir /data/pdfs \
        --init-from ./runs/v2/best.pt --output-dir ./runs/grpo \
        --pages-per-step 4 --group-size 8 --kl-beta 0.04 --lr 1e-6 \
        --steps 2000 --eval-every 100

CPU smoke test (tiny random model + synthetic data; validates the whole loop):

    python grpo_train.py --smoke
"""

from __future__ import annotations

import os
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from collections import defaultdict
from copy import deepcopy
from types import SimpleNamespace

import click
import torch
from loguru import logger
from torch.utils.data import DataLoader, Dataset

import data
import reward
from modeling_ocr_reconstruction import OcrReconstructionConfig, OcrTextReconstructionModel


# --------------------------------------------------------------------------- #
# Synthetic RL dataset for --smoke (mirrors RLDataset's per-item dict)
# --------------------------------------------------------------------------- #
class _SyntheticRLDataset(Dataset):
    def __init__(self, n: int = 16, seed: int = 0):
        self.n, self.rng = n, torch.Generator().manual_seed(seed)

    def __len__(self):
        return self.n

    def __getitem__(self, idx):
        k = int(torch.randint(3, 9, (1,), generator=self.rng).item())
        boxes = torch.rand(k, 4, generator=self.rng).sort(-1).values
        return {
            "pixel_values": torch.rand(3, 640, 640, generator=self.rng),
            "ocr_boxes": boxes,
            "num_boxes": k,
            "df_idx": idx,
        }


# --------------------------------------------------------------------------- #
# Core RL math (module-level so they are unit-testable)
# --------------------------------------------------------------------------- #
def group_advantages(rewards: torch.Tensor, group_size: int, eps: float = 1e-6) -> torch.Tensor:
    """Group-relative advantages: normalize each page's K rewards to mean 0 / std 1.
    A group whose K rewards are all equal yields zero advantage (nothing to learn)."""
    r = rewards.view(-1, group_size)
    adv = (r - r.mean(dim=1, keepdim=True)) / (r.std(dim=1, keepdim=True) + eps)
    return adv.reshape(-1)


def sequence_logprobs(model, pixel_values, ocr_boxes, box_mask, sequences) -> torch.Tensor:
    """Per-token log-prob of ``sequences`` under ``model`` via a teacher-forced pass.
    Feeds ``sequences[:, :-1]`` and gathers at ``sequences[:, 1:]`` -> (B, S-1).
    Grad flows iff caller leaves it enabled (policy) or not (reference, no_grad)."""
    out = model.forward(pixel_values, ocr_boxes,
                        decoder_input_ids=sequences[:, :-1], box_mask=box_mask)
    logp = torch.log_softmax(out.logits, dim=-1)
    actions = sequences[:, 1:]
    return logp.gather(-1, actions.unsqueeze(-1)).squeeze(-1)


# --------------------------------------------------------------------------- #
# Construction helpers
# --------------------------------------------------------------------------- #
def _load_weights(model, path, device):
    ck = torch.load(path, map_location=device)
    state = ck["model"] if isinstance(ck, dict) and "model" in ck else ck
    info = model.load_state_dict(state, strict=False)
    logger.info(
        f"init-from {path}: loaded weights "
        f"(missing {len(info.missing_keys)}, unexpected {len(info.unexpected_keys)})"
    )


def build_model(args, device):
    if args.smoke:
        from transformers import RTDetrV2Config, RTDetrV2Model

        rt = RTDetrV2Model(RTDetrV2Config(
            d_model=64, encoder_hidden_dim=64, decoder_in_channels=[64, 64, 64],
            encoder_ffn_dim=128, decoder_ffn_dim=128, decoder_layers=2,
            encoder_layers=1, num_denoising=0))
        cfg = OcrReconstructionConfig(d_model=64, num_markdown_layers=2,
                                      markdown_attention_heads=8, markdown_ffn_dim=128,
                                      content_mlp_hidden_dim=64)
        model = OcrTextReconstructionModel(cfg, rtdetr=rt)
    else:
        cfg = OcrReconstructionConfig(backbone_name_or_path=args.backbone)
        model = OcrTextReconstructionModel(cfg)
        _load_weights(model, args.init_from, device)

    if args.freeze_rtdetr:
        model.freeze_rtdetr(freeze_decoder=True)
    return model.to(device), cfg


def build_reference(policy, device):
    """Frozen snapshot of the SFT policy -- the KL leash. Weights-only, no grad."""
    ref = deepcopy(policy).to(device)
    ref.eval()
    for p in ref.parameters():
        p.requires_grad_(False)
    return ref


def build_optimizer(model, args):
    """Two LR tiers: pretrained rt-detr (--backbone-lr) vs new modules (--lr)."""
    def no_decay(name, p):
        return (p.ndim <= 1 or "norm" in name.lower()
                or "embedding" in name.lower() or "pos_embedding" in name)

    buckets = {("rtdetr", True): [], ("rtdetr", False): [],
               ("new", True): [], ("new", False): []}
    for name, p in model.named_parameters():
        if not p.requires_grad:
            continue
        section = "rtdetr" if name.startswith("rtdetr.") else "new"
        buckets[(section, no_decay(name, p))].append(p)

    lr_map = {"rtdetr": args.backbone_lr, "new": args.lr}
    groups = [{"params": ps, "lr": lr_map[sec], "weight_decay": 0.0 if nd else args.weight_decay}
              for (sec, nd), ps in buckets.items() if ps]
    return torch.optim.AdamW(groups, betas=(0.9, 0.999), eps=1e-8)


def build_dataloader(args):
    if args.smoke:
        ds = _SyntheticRLDataset(16, seed=0)
    else:
        image_processor = data.load_image_processor(args.backbone)
        ds = data.RLDataset(args.train_parquet, args.pdf_dir, image_processor,
                            min_boxes=args.min_boxes, max_boxes=args.max_boxes)
    return DataLoader(ds, batch_size=args.pages_per_step, shuffle=True,
                      num_workers=args.num_workers, collate_fn=data.rl_collate_fn,
                      pin_memory=not args.smoke, drop_last=True)


# --------------------------------------------------------------------------- #
# Trainer
# --------------------------------------------------------------------------- #
class GRPOTrainer:
    def __init__(self, policy, reference, loader, model_cfg, args, device):
        self.policy = policy
        self.reference = reference
        self.loader = loader
        self.cfg = model_cfg
        self.args = args
        self.device = device
        self.optimizer = build_optimizer(policy, args)
        self.step = 0
        os.makedirs(args.output_dir, exist_ok=True)

    # ---- utilities -------------------------------------------------------- #
    def _to_device(self, batch):
        return {k: v.to(self.device, non_blocking=True) for k, v in batch.items()}

    def _infinite(self):
        while True:
            for batch in self.loader:
                yield batch

    # ---- one GRPO micro-batch -------------------------------------------- #
    def train_step(self, batch, scale: float):
        args, K = self.args, self.args.group_size
        batch = self._to_device(batch)

        # replicate each page K times -> a group of rollouts per page
        pv = batch["pixel_values"].repeat_interleave(K, dim=0)
        boxes = batch["ocr_boxes"].repeat_interleave(K, dim=0)
        mask = batch["box_mask"].repeat_interleave(K, dim=0)

        # 1. rollout (no grad inside sample_decode)
        seq, old_lp, valid = self.policy.sample_decode(
            pv, boxes, box_mask=mask,
            temperature=args.temperature, max_new_tokens=args.max_new_tokens)

        # 2. reward + group-normalized advantage
        rewards = reward.batch_rewards(seq, mask, w_cov=args.w_cov, w_dup=args.w_dup)
        adv = group_advantages(rewards, K).unsqueeze(1)              # (B, 1)

        # 3. log-probs: policy (grad) + reference (no grad), both eval-mode
        new_lp = sequence_logprobs(self.policy, pv, boxes, mask, seq)    # (B, S-1)
        with torch.no_grad():
            ref_lp = sequence_logprobs(self.reference, pv, boxes, mask, seq)

        old = old_lp[:, 1:]
        vmask = valid[:, 1:].float()

        # 4. clipped surrogate (ratio ~= 1 at init -> proper group-baseline PG)
        ratio = torch.exp(new_lp - old)
        surrogate = -torch.min(ratio * adv,
                               torch.clamp(ratio, 1 - args.clip_eps, 1 + args.clip_eps) * adv)

        # 5. KL(policy || reference), k3 estimator (>= 0) -- the leash
        r = ref_lp - new_lp
        kl = torch.exp(r) - r - 1.0

        loss_tok = surrogate + args.kl_beta * kl
        denom = vmask.sum().clamp(min=1.0)
        loss = (loss_tok * vmask).sum() / denom

        (loss * scale).backward()

        cov, dup = reward.batch_coverage_dup(seq, mask)
        return {
            "loss": float(loss.detach()),
            "reward": float(rewards.mean()),
            "coverage": float(cov.mean()),
            "dup": float(dup.mean()),
            "kl": float((kl.detach() * vmask).sum() / denom),
            "ratio": float((ratio.detach() * vmask).sum() / denom),
        }

    # ---- loop ------------------------------------------------------------- #
    def train_model(self):
        # eval mode throughout: dropout off keeps sampled & recomputed log-probs aligned
        self.policy.eval()
        self.reference.eval()
        n_train = sum(p.numel() for p in self.policy.parameters() if p.requires_grad)
        logger.info(
            f"trainable {n_train / 1e6:.2f}M | pages/step {self.args.pages_per_step} "
            f"x K {self.args.group_size} = {self.args.pages_per_step * self.args.group_size} "
            f"rollouts/micro-batch | grad-accum {self.args.grad_accum}"
        )

        data_iter = self._infinite()
        self.optimizer.zero_grad(set_to_none=True)
        agg, micro = defaultdict(float), 0
        t0 = t_train_start = time.time()

        while self.step < self.args.steps:
            stats = self.train_step(next(data_iter), scale=1.0 / self.args.grad_accum)
            for k, v in stats.items():
                agg[k] += v
            micro += 1
            if micro % self.args.grad_accum:
                continue

            torch.nn.utils.clip_grad_norm_(
                (p for p in self.policy.parameters() if p.requires_grad), self.args.grad_clip)
            self.optimizer.step()
            self.optimizer.zero_grad(set_to_none=True)
            self.step += 1

            if self.step % self.args.log_every == 0:
                n = self.args.grad_accum * self.args.log_every
                now = time.time()
                ips = n / (now - t0)
                elapsed = now - t_train_start
                remaining = self.args.steps - self.step
                eta_s = (elapsed / self.step) * remaining if self.step > 0 else 0
                eta_str = time.strftime("%H:%M:%S", time.gmtime(eta_s))
                logger.info(
                    f"step {self.step}/{self.args.steps} | "
                    f"loss {agg['loss'] / n:+.4f} | reward {agg['reward'] / n:.3f} | "
                    f"cov {agg['coverage'] / n:.3f} | dup {agg['dup'] / n:.3f} | "
                    f"kl {agg['kl'] / n:.4f} | ratio {agg['ratio'] / n:.3f} | "
                    f"{ips:.2f} it/s | ETA {eta_str}"
                )
                agg, t0 = defaultdict(float), now

            if self.args.eval_every and self.step % self.args.eval_every == 0:
                m = self.evaluate()
                logger.info(
                    f"[eval@{self.step}] greedy_coverage {m['greedy_coverage']:.3f} | "
                    f"frac_full {m['frac_full']:.3f} | greedy_dup {m['greedy_dup']:.3f}"
                )

            if self.args.save_every and self.step % self.args.save_every == 0:
                self._save(os.path.join(self.args.output_dir, f"step{self.step}.pt"))

        self._save(os.path.join(self.args.output_dir, "policy_final.pt"))
        total_time = time.strftime("%H:%M:%S", time.gmtime(time.time() - t_train_start))
        logger.info(f"training complete — {self.args.steps} steps in {total_time}")

    @torch.no_grad()
    def evaluate(self):
        """Greedy decode coverage -- the metric we actually care about. ``frac_full``
        is the fraction of pages where every box is present (the N-in/N-out goal)."""
        self.policy.eval()
        covs, dups = [], []
        for i, batch in enumerate(self.loader):
            if i >= self.args.eval_batches:
                break
            batch = self._to_device(batch)
            gen = self.policy.generate(
                pixel_values=batch["pixel_values"], ocr_boxes=batch["ocr_boxes"],
                box_mask=batch["box_mask"], max_new_tokens=self.args.max_new_tokens)
            cov, dup = reward.batch_coverage_dup(gen, batch["box_mask"])
            covs.append(cov)
            dups.append(dup)
        cov = torch.cat(covs) if covs else torch.zeros(1)
        dup = torch.cat(dups) if dups else torch.zeros(1)
        return {
            "greedy_coverage": float(cov.mean()),
            "greedy_dup": float(dup.mean()),
            "frac_full": float((cov >= 1.0).float().mean()),
        }

    def _save(self, path):
        torch.save({"model": self.policy.state_dict(), "step": self.step}, path)
        logger.info(f"saved checkpoint → {path}")


# --------------------------------------------------------------------------- #
# CLI (click)
# --------------------------------------------------------------------------- #
@click.command(context_settings={"show_default": True})
# data
@click.option("--train-parquet", type=click.Path(), default=None)
@click.option("--pdf-dir", type=click.Path(), default=None)
@click.option("--backbone", default="docling-project/docling-layout-heron")
@click.option("--min-boxes", type=int, default=1)
@click.option("--max-boxes", type=int, default=None, help="drop pages with more boxes (caps rollout cost)")
# init
@click.option("--init-from", type=click.Path(), default=None,
              help="SFT checkpoint to start RL from (REQUIRED unless --smoke)")
# GRPO
@click.option("--pages-per-step", type=int, default=4, help="P: distinct pages per micro-batch")
@click.option("--group-size", type=int, default=8, help="K: rollouts sampled per page")
@click.option("--temperature", type=float, default=1.0)
@click.option("--kl-beta", type=float, default=0.04, help="strength of the KL leash to the SFT model")
@click.option("--clip-eps", type=float, default=0.2)
@click.option("--w-cov", type=float, default=1.0, help="coverage reward weight")
@click.option("--w-dup", type=float, default=0.5, help="duplicate penalty weight")
@click.option("--max-new-tokens", type=int, default=512)
# optim
@click.option("--lr", type=float, default=1e-6, help="LR for new modules")
@click.option("--backbone-lr", type=float, default=1e-6, help="LR for pretrained rt-detr")
@click.option("--weight-decay", type=float, default=0.0)
@click.option("--grad-accum", type=int, default=1)
@click.option("--grad-clip", type=float, default=1.0)
@click.option("--steps", type=int, default=2000, help="total optimizer steps")
@click.option("--freeze-rtdetr", is_flag=True, help="train only the new modules")
# runtime
@click.option("--num-workers", type=int, default=4)
@click.option("--device", default="cuda" if torch.cuda.is_available() else "cpu")
@click.option("--seed", type=int, default=42)
@click.option("--output-dir", type=click.Path(), default="./runs/grpo")
@click.option("--log-every", type=int, default=10)
@click.option("--eval-every", type=int, default=100, help="greedy-coverage eval every N steps (0 = off)")
@click.option("--eval-batches", type=int, default=8)
@click.option("--save-every", type=int, default=500, help="0 = only final save")
# smoke
@click.option("--smoke", is_flag=True, help="tiny random model + synthetic data; validates the loop on CPU")
def main(**kwargs):
    args = SimpleNamespace(**kwargs)

    if args.smoke:
        args.device = "cpu"
        args.steps = 3
        args.pages_per_step, args.group_size, args.grad_accum = 2, 4, 1
        args.max_new_tokens, args.num_workers = 16, 0
        args.log_every, args.eval_every, args.eval_batches, args.save_every = 1, 2, 1, 2
        args.output_dir = "./runs/grpo_smoke"
    elif not args.init_from:
        raise click.UsageError("--init-from (an SFT checkpoint) is required, or use --smoke")
    elif not (args.train_parquet and args.pdf_dir):
        raise click.UsageError("--train-parquet and --pdf-dir are required (or use --smoke)")

    os.makedirs(args.output_dir, exist_ok=True)
    log_path = os.path.join(args.output_dir, "train.log")
    logger.remove()
    logger.add(sys.stderr, format="<green>{time:YYYY-MM-DD HH:mm:ss}</green> | <level>{level: <8}</level> | {message}")
    logger.add(log_path, format="{time:YYYY-MM-DD HH:mm:ss} | {level: <8} | {message}", rotation="50 MB", encoding="utf-8")
    logger.info(f"logging to {log_path}")

    torch.manual_seed(args.seed)
    device = torch.device(args.device)

    policy, cfg = build_model(args, device)
    reference = build_reference(policy, device)
    loader = build_dataloader(args)

    trainer = GRPOTrainer(policy, reference, loader, cfg, args, device)
    trainer.train_model()


if __name__ == "__main__":
    main()
