"""EmbeddingGemma 2 text bi-encoder: encode unique inputs then exact cosine scores."""
import argparse,json,time,statistics
from pathlib import Path
import torch
from sentence_transformers import SentenceTransformer
ROOT=Path(__file__).resolve().parent

def sync_time(fn):
    torch.cuda.synchronize();start=time.perf_counter();out=fn();torch.cuda.synchronize()
    return time.perf_counter()-start,out

def main():
    p=argparse.ArgumentParser()
    p.add_argument('--model',default=str(ROOT/'models/embeddinggemma-2'))
    p.add_argument('--data-dir',type=Path,default=ROOT/'data')
    p.add_argument('--output-dir',type=Path,default=ROOT/'results/biencoder')
    p.add_argument('--batches',type=int,nargs='+',default=[8,16,32,64,128,256])
    p.add_argument('--pilot-docs',type=int,default=512)
    p.add_argument('--repeats',type=int,default=3)
    a=p.parse_args();a.output_dir.mkdir(parents=True,exist_ok=True)
    torch.set_num_threads(8);torch.manual_seed(20261112)
    chunks=[json.loads(x) for x in (a.data_dir/'chunks.jsonl').read_text().splitlines()]
    queries=[json.loads(x) for x in (a.data_dir/'queries.jsonl').read_text().splitlines()]
    docs=[x['text'] for x in chunks]
    qs=[f"ICD code: {q['icd_code']}({q['icd_code_description']})\nattribute: {q['attribute']}\n search keyterm: {q['keyterm']}" for q in queries]
    start=time.perf_counter()
    model=SentenceTransformer(a.model,device='cuda',model_kwargs={'dtype':torch.bfloat16,'attn_implementation':'sdpa'},config_kwargs={'vision_config':None,'audio_config':None},local_files_only=True)
    load_s=time.perf_counter()-start
    print('MODEL_LOADED',load_s,flush=True)
    def enc(texts,batch,prompt):
        return torch.nn.functional.normalize(model.encode(texts,batch_size=batch,prompt_name=prompt,convert_to_tensor=True,normalize_embeddings=True,show_progress_bar=False).float(),dim=-1)
    # Preserve the same text chunks. Retokenizing them with Gemma changes token counts.
    tokenizer=model.tokenizer
    lengths={}
    for name,texts,prompt in [('document',docs,'Document'),('query',qs,'SearchQuery')]:
        ids=tokenizer([model.prompts[prompt]+x for x in texts],padding=False,truncation=False)['input_ids']
        l=[len(x) for x in ids];lengths[name]={'min':min(l),'mean':statistics.mean(l),'max':max(l),'total':sum(l)}
        if max(l)>model.max_seq_length:raise ValueError('Input would be truncated')
    enc(docs[:32],16,'Document');enc(qs[:4],4,'SearchQuery')
    pilots=[]
    for batch in a.batches:
        samples=[]
        try:
            for _ in range(2):
                sec,_=sync_time(lambda:enc(docs[:a.pilot_docs],batch,'Document'));samples.append(sec)
            row={'batch':batch,'documents':min(a.pilot_docs,len(docs)),'seconds':samples,'median_seconds':statistics.median(samples),'documents_per_second':min(a.pilot_docs,len(docs))/statistics.median(samples)}
        except torch.cuda.OutOfMemoryError:
            row={'batch':batch,'error':'CUDA OOM'};torch.cuda.empty_cache()
        pilots.append(row);print('PILOT',json.dumps(row),flush=True)
    best=max((x for x in pilots if 'error'not in x),key=lambda x:x['documents_per_second'])['batch']
    runs=[]
    for repeat in range(a.repeats):
        torch.cuda.synchronize();start=time.perf_counter()
        qsec,qemb=sync_time(lambda:enc(qs,min(best,len(qs)),'SearchQuery'))
        dsec,demb=sync_time(lambda:enc(docs,best,'Document'))
        def score():return (demb@qemb.T).cpu()
        ssec,scores=sync_time(score)
        total=time.perf_counter()-start
        if not bool(torch.isfinite(scores).all()) or not bool(torch.isfinite(demb).all()):raise RuntimeError('Nonfinite embeddings/scores')
        row={'repeat':repeat,'query_encoding_seconds':qsec,'document_encoding_seconds':dsec,'similarity_and_cpu_output_seconds':ssec,'total_seconds':total,'documents_per_second':len(docs)/dsec,'effective_pairs_per_second':len(docs)*len(qs)/total}
        runs.append(row);print('FULL',json.dumps(row),flush=True)
    cached=[]
    for _ in range(5):
        torch.cuda.synchronize();start=time.perf_counter()
        qe=enc(qs,min(best,len(qs)),'SearchQuery');sc=(demb@qe.T).cpu();torch.cuda.synchronize()
        cached.append(time.perf_counter()-start)
    # Also measure exact all-pair scoring alone after both embedding sets exist.
    score_only=[]
    for _ in range(10):
        sec,_=sync_time(lambda:(demb@qemb.T).cpu());score_only.append(sec)
    cpu_demb=demb.cpu()
    cached_upload=[]
    for _ in range(5):
        sec,_=sync_time(lambda:((cpu_demb.cuda()@enc(qs,min(best,len(qs)),'SearchQuery').T).cpu()))
        cached_upload.append(sec)
    result={'model':a.model,'source_revision':json.loads(Path(a.model,'source_revision.json').read_text()),'gpu':torch.cuda.get_device_name(),'dtype':'bfloat16 backbone; float32 normalized output and scoring','attention':'HF SDPA','text_only':True,'embedding_dimension':demb.shape[1],'parameters_loaded':sum(x.numel()for x in model.parameters()),'query_prompt':model.prompts['SearchQuery'],'document_prompt':model.prompts['Document'],'documents':len(docs),'queries':len(qs),'pairs':len(docs)*len(qs),'token_lengths':lengths,'model_load_seconds':load_s,'best_batch':best,'pilots':pilots,'full_runs':runs,'median_total_seconds':statistics.median(x['total_seconds']for x in runs),'cached_documents_gpu_seconds':cached,'cached_documents_cpu_with_upload_seconds':cached_upload,'score_only_seconds':score_only,'normalization_error_max':float((demb.norm(dim=-1)-1).abs().max()),'includes':'input tokenization, GPU encoding of all unique documents and queries, normalization, exact all-pair cosine matrix, score transfer to CPU','excludes':'model load, first warmup/autotune, input JSON parsing, disk save','score_shape':list(scores.shape),'finite':True}
    (a.output_dir/'benchmark.json').write_text(json.dumps(result,indent=2)+'\n')
    torch.save({'document_embeddings':demb.cpu(),'query_embeddings':qemb.cpu(),'scores':scores},a.output_dir/'embeddings_and_scores.pt')
    print('RESULT',json.dumps(result),flush=True)
if __name__=='__main__':main()
