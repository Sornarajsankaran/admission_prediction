from docling_core.types.doc import DocItemLabel


# OCR dataframe schema
REQUIRED_COLUMNS_OCR_DF = {"file_name", "page", "content", "line_cord", "word_cord"}
LINE_SEPARATOR = "\n"
WORD_SEPARATOR = "\t"
LINE_COORDS_SEPARATOR = "|"
WORD_COORDS_SEPARATOR = "|"

# Rasterization
LAYOUT_DPI = 216
TABLE_DPI = 216

# Layout detection
LAYOUT_MODEL_CONFIG = {
    "model_name_or_path": "docling-project/docling-layout-heron",
    "attn_implementation": None,
    "torch_compile": False,
    "threshold": 0.6,
}

LAYOUT_POSTPROCESS_CONFIG = {
    "keep_empty_clusters": False,
    "skip_cell_assignment": False,
    "create_orphan_clusters": True,
}

# Table structure extraction
TABLE_MODEL_CONFIG = {
    "image_size": 448,
    "max_length": 512,
    "mean": [0.485, 0.456, 0.406],
    "std": [0.229, 0.224, 0.225],
}

TABLE_LABELS = {DocItemLabel.TABLE, DocItemLabel.DOCUMENT_INDEX}
OTSL_CELL_TOKENS = {"fcel", "ecel", "ched", "rhed", "srow"}
OTSL_SKIP_TOKENS = {"<pad>", "[UNK]", "<start>", "<end>"}

# Reading order
READING_ORDER_CONFIG = {
    "list_item_infer_enumerated": True,
}

# Result writing
RESULTS_DF_FILE_TYPE = "parquet"
DOCLING_DOCUMENT_FILE_TYPE = "yaml"
COLUMNS_TO_SAVE = [
    "file_name",
    "page",
    "content",
    "line_cord",
    "word_cord",
    "page_markdown",
]
