#!/usr/bin/env python3
"""Pretokenized Hugging Face ModernBERT cross-encoder throughput baseline."""
from __future__ import annotations

import argparse
import json
import statistics
import time
from pathlib import Path

import torch
from transformers import AutoModelForSequenceClassification


def pack_pairs(data, pair_indices, device="cuda"):
    """Exact unpadded [query,document] order followed by right padding.

    Pair ordering is document-major: doc0 q0..q49, doc1 q0..q49, ...
    This setup is outside microbenchmark timing; IDs are GPU resident there.
    """
    pair_indices = torch.as_tensor(pair_indices, dtype=torch.long, device="cpu")
    count_queries = data["query_input_ids"].shape[0]
    qi = pair_indices % count_queries
    di = (pair_indices // count_queries) % data["doc_input_ids"].shape[0]
    ql = data["query_lengths"][qi]
    dl = data["doc_lengths"][di]
    width = int((ql + dl).max())
    pos = torch.arange(width)[None].expand(len(qi), -1)
    qids = data["query_input_ids"][qi]
    dids = data["doc_input_ids"][di]
    ids = torch.where(pos < ql[:, None],
                      qids.gather(1, pos.clamp(max=qids.shape[1] - 1)),
                      dids.gather(1, (pos - ql[:, None]).clamp(min=0, max=dids.shape[1] - 1)))
    mask = pos < (ql + dl)[:, None]
    ids = ids.masked_fill(~mask, data["pad_token_id"])
    return {"input_ids": ids.to(device), "attention_mask": mask.to(device)}, ql.to(device)


def measure(call, repeats, iters, warmup):
    for _ in range(warmup):
        call()
    torch.cuda.synchronize()
    times = []
    for _ in range(repeats):
        torch.cuda.synchronize()
        start = time.perf_counter()
        for _ in range(iters):
            call()
        torch.cuda.synchronize()
        times.append((time.perf_counter() - start) / iters)
    return times


@torch.inference_mode()
def main(args):
    torch.set_num_threads(8)
    torch.backends.cuda.matmul.allow_tf32 = False
    torch.set_float32_matmul_precision("highest")
    root = Path(__file__).resolve().parent
    data = torch.load(root / "data/tokenized.pt", weights_only=True)
    dtype = {"bf16": torch.bfloat16, "fp16": torch.float16, "fp32": torch.float32}[args.dtype]
    model = AutoModelForSequenceClassification.from_pretrained(
        args.model, dtype=dtype, attn_implementation="sdpa").eval().to("cuda")
    inputs, _ = pack_pairs(data, torch.arange(50))
    logits = model(**inputs).logits[:, 0].float().cpu().tolist()
    (root / "results" / f"hf_logits_{args.dtype}.json").write_text(json.dumps({
        "model": args.model, "dtype": args.dtype, "attention": "baseline bidirectional",
        "position_ids": "absolute starting at 0", "document_id": 0,
        "query_ids": list(range(50)), "logits": logits}, indent=2) + "\n")
    native_path = root / "results/vllm_logits.json"
    if native_path.exists() and args.dtype == "bf16":
        native = json.loads(native_path.read_text())
        native_logits = torch.tensor(native["logits"]).float().flatten()
        hf_logits = torch.tensor(logits).float().flatten()
        if native_logits.shape == hf_logits.shape:
            error = native_logits - hf_logits
            parity = {"comparison": "native vLLM BF16-head baseline vs HF BF16 SDPA baseline",
                      "pairs": len(logits), "max_abs": error.abs().max().item(),
                      "rms": error.square().mean().sqrt().item(),
                      "cosine": torch.nn.functional.cosine_similarity(native_logits, hf_logits, dim=0).item(),
                      "native_file": str(native_path), "native_metadata": {k: v for k, v in native.items() if k != "logits"}}
            (root / "results/correctness_vllm.json").write_text(json.dumps(parity, indent=2) + "\n")
            print("VLLM_PARITY", json.dumps({k: v for k, v in parity.items() if k != "native_metadata"}), flush=True)
    if args.logits_only:
        print("LOGITS_READY", flush=True)
        return
    call_model = torch.compile(model, fullgraph=False) if args.compile else model
    results = []
    for b in args.batch_sizes:
        inputs, _ = pack_pairs(data, torch.arange(b))
        torch.cuda.empty_cache()
        torch.cuda.reset_peak_memory_stats()
        try:
            if args.cuda_graph:
                stream = torch.cuda.Stream()
                stream.wait_stream(torch.cuda.current_stream())
                with torch.cuda.stream(stream):
                    for _ in range(3):
                        static_output = call_model(**inputs).logits
                torch.cuda.current_stream().wait_stream(stream)
                graph = torch.cuda.CUDAGraph()
                with torch.cuda.graph(graph):
                    static_output = call_model(**inputs).logits
                call = graph.replay
            else:
                call = lambda: call_model(**inputs).logits
            times = measure(call, args.repeats, args.iters, args.warmup)
            row = {"batch_size": b, "sequence_width": inputs["input_ids"].shape[1],
                   "median_batch_seconds": statistics.median(times),
                   "repeat_batch_seconds": times,
                   "pairs_per_second": b / statistics.median(times),
                   "peak_allocated_gib": torch.cuda.max_memory_allocated() / 2**30,
                   "peak_reserved_gib": torch.cuda.max_memory_reserved() / 2**30}
            results.append(row)
            print(json.dumps(row), flush=True)
            if args.cuda_graph:
                del graph, static_output
        except torch.cuda.OutOfMemoryError as exc:
            results.append({"batch_size": b, "error": str(exc)})
            torch.cuda.empty_cache()
            print(f"OOM batch={b}", flush=True)
    report = {"engine": "huggingface", "model": args.model, "dtype": args.dtype,
              "attention": "SDPA bidirectional full cross encoder",
              "mode": "cuda_graph" if args.cuda_graph else "compiled" if args.compile else "eager",
              "timing_scope": "GPU resident pretokenized inputs, model forward and synchronization; excludes tokenization, CPU transfer, model loading, warmup, compilation and graph capture",
              "warmup": args.warmup, "iterations_per_repeat": args.iters, "repeats": args.repeats,
              "gpu": torch.cuda.get_device_name(), "results": results}
    Path(args.output).write_text(json.dumps(report, indent=2) + "\n")


if __name__ == "__main__":
    p = argparse.ArgumentParser()
    root = Path(__file__).resolve().parent
    p.add_argument("--model", default=str(root / "models/benchmark-cls"))
    p.add_argument("--batch-sizes", nargs="+", type=int, default=[16,32,64,128,256])
    p.add_argument("--dtype", choices=["bf16", "fp16", "fp32"], default="bf16")
    p.add_argument("--iters", type=int, default=5)
    p.add_argument("--warmup", type=int, default=3)
    p.add_argument("--repeats", type=int, default=3)
    p.add_argument("--compile", action="store_true")
    p.add_argument("--cuda-graph", action="store_true")
    p.add_argument("--logits-only", action="store_true")
    p.add_argument("--output", default=str(root / "results/hf_baseline.json"))
    main(p.parse_args())
