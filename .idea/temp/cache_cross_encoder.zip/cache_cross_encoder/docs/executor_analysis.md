# ModernBERT executor and exact reusable document attention

This analysis uses the installed **vLLM 0.33.0**, **Transformers 5.20.2**, and
**PyTorch 2.14.0** sources. The installed executor and its encoder attention
backend are copied into `vendor/*-vllm-0.33.0.py`; upstream `main` snapshots and
GitHub blob hashes are also retained. The installed package, rather than a
moving documentation page, defines the measured behavior.

## Architecture actually downloaded

The public [BioClinical ModernBERT config](https://huggingface.co/thomas-sounack/BioClinical-ModernBERT-base/blob/main/config.json)
declares a masked language model, not the user's fine-tuned relevance classifier.
It has 22 layers, hidden width 768, 12 attention heads of width 64, intermediate
width 1,152, and a 50,368-token vocabulary. Layers 0, 3, 6, 9, 12, 15, 18 and 21
use global attention; the other 14 layers use local attention. Global RoPE uses
theta 160,000; local RoPE uses theta 10,000. `local_attention=128` corresponds to
an inclusive **64 tokens to either side**, not 128 to either side. There are no
learned absolute position embeddings despite the legacy `position_embedding_type`
field in the public JSON.

The public config sets mean pooling and SiLU classification activation. Those
settings are not proof of the user's trained classifier configuration. The
benchmark checkpoint explicitly sets CLS pooling and GELU with a deterministic
untrained classification head. It is a throughput surrogate with real public
backbone weights; its scores have no validated medical retrieval meaning.

## Native vLLM forward path

The relevant implementation is
[modernbert.py](https://github.com/vllm-project/vllm/blob/main/vllm/model_executor/models/modernbert.py).
In the installed source snapshot:

| Component | Source location | Operation |
|---|---:|---|
| `ModernBertEmbeddings` | line 39 | Vocabulary embedding then LayerNorm. No position lookup. |
| `ModernBertAttention` | line 68 | Fused QKV projection, RoPE on Q and K, encoder attention, output projection. |
| `ModernBertMLP` | line 139 | Fused input/gate projection; `GELU(input) * gate`; output projection. |
| `ModernBertLayer` | line 170 | Pre-normalized attention/residual then pre-normalized MLP/residual. Layer zero omits attention LayerNorm. |
| `ModernBertEncoderLayer` | line 217 | Sequential loop through all 22 layers. |
| `ModernBertModel` | line 248 | Embeddings, encoder, final LayerNorm. |
| `ModernBertPooler` | line 318 | Configured CLS or mean pooling, dense/GELU/LayerNorm head. |
| `ModernBertForSequenceClassification` | line 358 | Backbone plus pooler and final linear classification. |

QKV and MLP projections use tensor-parallel vLLM linear classes. Their forwards
return `(output, optional_bias)` tuples, unlike `torch.nn.Linear`. The checkpoint
QKV weight ordering is Q, then K, then V, with each block 768 rows. The MLP
`Wi` weight has input and gate blocks, each 1,152 rows. Native linear parameters
can therefore be reused directly in an unquantized single-GPU custom executor.
The weight loader maps HF `model.layers.*` to vLLM
`model.encoder_layer.layers.*`, and HF `head.*` to `pooling.*`.

The native sequence-classification pooler hardcodes `nn.GELU()` in this version,
even when the HF config says `classifier_activation="silu"`. A trained SiLU head
requires a corrected pooler before comparing scores. Both measured surrogate
implementations use GELU, avoiding this mismatch. Dropout must be disabled for
reusable deterministic document states.

## Why enabling stock prefix caching does not implement Variant B

[`EncoderOnlyAttention`](https://github.com/vllm-project/vllm/blob/main/vllm/model_executor/layers/attention/encoder_only_attention.py)
inherits the generic attention infrastructure, but its `get_kv_cache_spec`
returns `None`. Its metadata builder forces noncausal attention.

In the installed FlashAttention backend, `do_kv_cache_update` returns immediately
for encoder attention. `_forward_encoder_attention` (line 1644 of the saved
snapshot) passes fresh Q, K and V directly to FlashAttention, sets `causal=False`,
and uses the same sequence boundaries and maximum length for Q and K. There is
neither a persistent document cache nor an asymmetric document/query mask in
this path. The same backend rejects quantized KV for encoder attention.

Conventional decoder prefix reuse relies on a causal prefix. A bidirectional
document prefix needs all its document tokens before any layer can be finalized,
and Variant B has bidirectional query self-attention as well. Merely moving the
document to the front, setting `enable_prefix_caching=True`, or changing one
attention-type flag is not an exact solution.

vLLM's [pooling documentation](https://docs.vllm.ai/en/latest/models/pooling_models/)
also explicitly avoids guaranteeing a speed advantage over Transformers. A
measured stock vLLM baseline remains necessary.

## Exact decomposition

Let Q denote all query-side tokens, including CLS and the query separator, and
D denote the document wrapper, content, and document separator. For each layer,
Variant B retains these attention blocks:

```text
            keys
            Q       D
queries Q   allowed allowed
        D   blocked allowed
```

Intersect this block mask with padding and the layer's original local/global
mask. Replacing every layer with global attention is a different model.

Induction over layers establishes that D's hidden states are independent of Q.
At each layer, cache the document **K and V projected from that layer's normalized
input**, then update the document branch using document-only attention and its
MLP. A final pooled document embedding alone cannot reconstruct these 22 pairs
of layer inputs. During scoring, update only Q through all layers, attending to
its own private Q keys/values and that document's cached keys/values.

Each query becomes document-dependent after layer zero. Reusing one query hidden
state across all documents at later layers is incorrect. Packing all 50 queries
into one group must block query A from attending query B; otherwise the model
and scores change. The shared document cache must never be updated by a query.

For CLS pooling, only Q's final CLS representation is required. For true mean
pooling, preserve the separately cached sum of final-normalized D states and
combine it with the sum of valid final-normalized Q states before the head.
Mean pooling does not intrinsically prevent exact caching, but ignoring the
document contribution would change the result.

## Position handling and variable query lengths

For a query with actual length q, original logical query positions are `i` and
document positions are `q+j`. Document-only RoPE attention depends only on
differences `j-k`, so shifting all document positions leaves document hidden
states unchanged mathematically. Cache document keys using relative positions
`j`. Score query Q and its private query K at positions `i-q`. All dot-product
relative positions then match the original concatenated sequence. Values are
not rotated. Floating-point evaluation order can still produce small differences.

Do not index the stock RoPE cache using negative positions: ordinary tensor
negative indexing can silently select positions from the far end of the cache.
Compute sine/cosine explicitly or shift both branches by a fixed positive anchor.
Rotary convention is the NeoX half-split convention, matching HF `rotate_half`.

Right-padding a query from 35 to 64 tokens and then placing the document at
position 64 changes its distances from the query even if padding is masked.
The benchmark token tensors carry actual per-query lengths. Exact cached
implementations must use those lengths for positions and local masks.

FlashAttention's rectangular local-window convention is another trap: when
`len(Q) != len(K)`, window alignment is bottom-right. A query-only Q tensor with
K physically ordered `[query, document]` does not directly retain the original
top-left local windows. An explicit logical-position mask, a correctly adjusted
kernel, or a proved equivalent padded construction is required. Global layers
do not have this window-alignment issue.

## Throughput-oriented layout

Group work by document tile, with all 50 queries for that tile, so the GPU reads
shared document K/V repeatedly from nearby storage. A custom attention kernel
can take `(document_id, query_id)` and read one shared K/V tensor without
materializing 50 document copies. Maintain private query K/V for each pair.
The per-token MLP and projection cost is removed for document tokens on each
additional query, while query-dependent attention and MLP still run.

For local layers, Q's last logical position is `q-1`; with radius 64 it can only
see document indices 0 through 63. Only that prefix's local-layer K/V must remain
cached for subsequent query scoring, although the full document branch still
has to run while building deeper-layer states. Global-layer cache needs the
whole document. At 256 document tokens, BF16 all-layer K/V costs 16.5 MiB/chunk;
retaining only 64 tokens in local layers lowers this to 8.625 MiB/chunk. With the
benchmark's 263 wrapper-inclusive document tokens those figures are about
16.95 MiB and 8.79 MiB. Five thousand documents therefore do not leave a useful
memory margin on a 46-GiB GPU; process bounded tiles and release them.

A second exact schedule works layer by layer: compute one document tile's layer
K/V, advance all 50 private query branches through that layer, then discard the
layer cache. This avoids retaining all 22 layer caches. It is well suited to
the fixed all-queries-at-once workload, but does not provide reusable persistent
document caches for future unknown queries. Report this distinction.

Avoid promising a 50x speedup from 50 queries. A rough linear-work estimate is
`50*(D+Q)/(D+50*Q)`, before attention, memory traffic, padding, or launch overhead.
For D=263 and mean Q=35.48 it is about 7.33x. Padding query computation to 64
reduces that estimate to about 4.72x. These are intuition for the linear work,
not hardware throughput bounds or measured results.

## Practical vLLM integration levels

1. **Stock baseline:** `LLM.classify` on the exact concatenated token IDs. This
   uses the ordinary scheduler, native ModernBERT executor and encoder backend.
   `bench_vllm.py` times pretokenized offline API wall time after warmup, including
   scheduling and output delivery.
2. **Custom executor inside a real vLLM worker:** `LLM.apply_model(callable)` runs
   code on the loaded native model in each worker. A single-GPU callable can use
   the actual native weights to build document caches and execute the cached
   branches. This is a valid vLLM-worker integration experiment, but bypasses
   ordinary per-pair scheduler batching and is not the stock `/rerank` endpoint.
   Keep the RPC for control and small results; load data in the worker rather
   than transferring huge tensors through RPC.
3. **Production serving integration:** register an external model executor and
   define a document-cache lifecycle plus query/document association metadata.
   Allocate cache memory with a bounded budget; key by model/checkpoint,
   tokenizer/template, token IDs, dtype, RoPE and mask settings. Implement
   batch-level metadata for per-document sharing, query isolation, padding and
   local offsets. Extend the runner/scheduler or expose a dedicated batch API so
   every pair does not become an unrelated ordinary encoder request. Consider
   multi-worker ownership and invalidation before cross-worker cache reuse.

A model registry entry alone does not add the missing scheduler metadata or
cache lifecycle. A custom kernel alone is not an end-to-end serving benchmark.
These integration levels must be labeled separately in the final report.

## Correctness checks required before throughput claims

- Compare full unmasked cross-encoder results between HF and stock vLLM with the
  identical head, precision, token IDs, masks and real positions.
- Compare an uncached dense Variant B reference against cached execution using
  the same weights and local/global masks. Compare hidden states as well as the
  small classifier output; a random head can conceal some errors.
- Include multiple query lengths, padding, multiple documents, all query groups,
  CLS placement, local-window boundary positions, and query isolation.
- Count every produced score. Time cold document construction plus 50-query
  scoring for the real workload; also report warm-cache scoring separately.
- Keep model loading, compilation and warmup out of steady-state rates, but
  record their cost. Compare kernel-only and API-end-to-end rates separately.

These checks establish implementation equivalence, not the retrieval quality of
the user's unavailable trained checkpoints or clinical relevance of synthetic
unlabeled data.
