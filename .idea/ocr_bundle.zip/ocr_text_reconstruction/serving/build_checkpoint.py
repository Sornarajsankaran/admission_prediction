"""
Build the random-weight benchmark checkpoint.
=============================================

No trained weights are available, so this builds an ``OcrTwoStageModel`` with the
pretrained Heron encoder and random decoders, then adjusts the random decoders so they
*behave* like a trained model where it matters for serving:

  * decode length: the formatter's EMIT_NEXT bias is calibrated so greedy decoding
    places one block every ``--tokens-per-block`` tokens (formatter length ~ 2.5 K), and
    EOS is biased so decoding stops once every block is placed.
  * decision margins: freshly initialised pointer / formatter logits are nearly flat
    (top-2 gaps ~1e-3 nats), so any fp noise flips argmax. A trained model is confident;
    the pointer key projection and formatter head are scaled up until the median top-2
    gap is ``--target-gap`` nats, which makes greedy parity between backends meaningful.

    python serving/build_checkpoint.py --out /workspace/models/ocr_twostage_random/model.pt
"""

from __future__ import annotations

from pathlib import Path

import click
import torch

from common import (DEFAULT_CKPT, attach_pixels, build_random_model, calibrate_emit_bias,
                    collate, load_pages, save_checkpoint)


@torch.no_grad()
def order_gap(model, pages) -> float:
    """Median top-1/top-2 pointer-logit gap along greedy order decoding."""
    om = model.order
    gaps = []
    for p in pages:
        px, bx, mk = collate([p])
        H = om.encode_boxes(px, bx, box_mask=mk)
        order, _ = om.generate_order(px, bx, box_mask=mk)
        normed, key = om.box_input_norm(H), om.pointer_key_proj(H)
        K = order.size(1)
        inp = torch.cat([om.order_bos, normed[:, order[0, :-1]]], dim=1)
        causal = torch.triu(torch.full((K, K), float("-inf"), device=px.device), 1)
        h = om.decoder_norm(om.order_decoder(tgt=inp + om.pos_embedding[:, :K], memory=H, tgt_mask=causal))
        logits = (h @ key.transpose(1, 2))[0] * om.pointer_scale
        used = torch.zeros(K, K, dtype=torch.bool, device=px.device)
        for t in range(1, K):
            used[t] = used[t - 1]
            used[t, order[0, t - 1]] = True
        top2 = logits.masked_fill(used, float("-inf")).topk(2, dim=-1).values[:-1]
        gaps.append(top2[:, 0] - top2[:, 1])
    return torch.cat(gaps).median().item()


@torch.no_grad()
def formatter_gap(model, pages) -> float:
    """Median top-1/top-2 formatter-logit gap along greedy decoding (identity order)."""
    fmt = model.formatter
    px, bx, mk = collate(pages)
    order = torch.arange(bx.size(1), device=bx.device).expand(bx.size(0), -1)
    H = fmt.encode_boxes(px, bx, box_mask=mk)
    records = []
    fmt._ar_generate(H, order, mk, max_new_tokens=512, debug_logits=records)
    gaps = [r["logits"].topk(2, dim=-1).values for r in records]
    gaps = torch.cat([g[:, 0] - g[:, 1] for g in gaps])
    return gaps[torch.isfinite(gaps)].median().item()


@click.command()
@click.option("--out", default=str(DEFAULT_CKPT), show_default=True)
@click.option("--seed", default=0, show_default=True)
@click.option("--tokens-per-block", default=2.5, show_default=True)
@click.option("--target-gap", default=3.0, show_default=True, help="median top-2 logit gap (nats)")
@click.option("--calib-pages", default=24, show_default=True)
@click.option("--min-boxes", default=250, show_default=True, help="calibrate on pages like the target workload")
def main(out, seed, tokens_per_block, target_gap, calib_pages, min_boxes):
    pages = load_pages(min_boxes=min_boxes, max_boxes=450)[:calib_pages]
    attach_pixels(pages)
    model = build_random_model(seed).cuda().eval()
    torch.set_grad_enabled(False)

    g0 = order_gap(model, pages[:4])
    scale = target_gap / g0
    model.order.pointer_key_proj.weight.mul_(scale)
    print(f"pointer: median gap {g0:.4f} -> x{scale:.1f} -> {order_gap(model, pages[:4]):.3f} nats")

    g0 = formatter_gap(model, pages[:4])
    scale = target_gap / g0
    model.formatter.head.weight.mul_(scale)
    model.formatter.head.bias.mul_(scale)
    print(f"formatter head: median gap {g0:.4f} -> x{scale:.1f} -> {formatter_gap(model, pages[:4]):.3f} nats")

    # A trained formatter stops right after the last block. EOS is masked until every
    # block is placed, so a large EOS bias only affects that final decision.
    model.formatter.head.bias[model.formatter.config.eos_token_id] += 1000.0
    # logits were scaled by `scale`, so the useful bias range scales with it
    bias = calibrate_emit_bias(model, pages, tokens_per_block=tokens_per_block,
                               lo=-5.0 * scale, hi=15.0 * scale)
    print(f"EMIT_NEXT bias offset {bias:+.3f}")
    save_checkpoint(model, Path(out), tokens_per_block=tokens_per_block, target_gap=target_gap, seed=seed)
    print(f"saved {out}")


if __name__ == "__main__":
    main()
