#!/bin/sh
# Install into the base image's Python, whichever installer it ships (uv or pip).
set -e
if command -v uv >/dev/null 2>&1; then
    uv pip install --system --break-system-packages --no-cache "$@"
else
    python3 -m pip install --no-cache-dir --break-system-packages "$@"
fi
