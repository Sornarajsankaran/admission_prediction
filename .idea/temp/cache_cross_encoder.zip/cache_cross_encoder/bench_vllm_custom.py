"""Run exact cached Variant B inside a native vLLM worker, reusing its weights.

This is an executor integration benchmark through LLM.apply_model, not the stock
per-pair classify scheduler or an HTTP rerank serving benchmark.
"""
import argparse
import json
import os
from pathlib import Path
import time

os.environ.setdefault("OMP_NUM_THREADS", "8")
os.environ.setdefault("TOKENIZERS_PARALLELISM", "false")
os.environ.setdefault("VLLM_WORKER_MULTIPROC_METHOD", "spawn")
os.environ.setdefault("VLLM_ENABLE_V1_MULTIPROCESSING", "0")


def run_in_worker(native_model, settings):
    import torch
    from bench_cached import benchmark

    args = argparse.Namespace(**settings)
    args.executor = "native_vllm_worker_custom"
    native_model.eval()
    from transformers.activations import ACT2FN
    native_model.pooling.act = ACT2FN[native_model.config.classifier_activation]
    if native_model.config.num_labels != 1:
        raise ValueError("This scalar scoring runner requires num_labels=1")
    if getattr(native_model, "quant_config", None) is not None:
        raise ValueError("This custom executor requires unquantized native weights")
    if native_model.classifier.weight.dtype != getattr(torch,args.dtype):
        raise ValueError("Native classifier must match requested backbone dtype")
    result = benchmark(native_model, args)
    result["native_model_class"] = type(native_model).__name__
    result["integration"] = "LLM.apply_model; native loaded weights; custom batched attention; scheduler bypassed"
    return result


def main():
    from bench_cached import parser
    p = parser()
    p.set_defaults(output="results/vllm_custom.jsonl")
    p.add_argument("--configs-json", help="JSON list of argument overrides, run sequentially on one loaded worker")
    args = p.parse_args()

    from vllm import LLM
    from vllm.config import PoolerConfig

    start = time.perf_counter()
    llm = LLM(
        model=args.model,
        runner="pooling",
        dtype=args.dtype,
        hf_overrides={"head_dtype": "model"},
        max_model_len=327,
        max_num_batched_tokens=4096,
        max_num_seqs=32,
        enable_prefix_caching=False,
        enable_chunked_prefill=False,
        enforce_eager=True,
        compilation_config=0,
        pooler_config=PoolerConfig(task="classify", use_activation=False),
        gpu_memory_utilization=0.9,
        seed=17,
        disable_log_stats=True,
    )
    initialization_s = time.perf_counter() - start
    configs = [{}] if args.configs_json is None else json.loads(Path(args.configs_json).read_text())
    for overrides in configs:
        settings = vars(args).copy()
        settings.update(overrides)
        start = time.perf_counter()
        results = llm.apply_model(lambda native_model: run_in_worker(native_model, settings))
        callback_s = time.perf_counter() - start
        if len(results) != 1:
            raise ValueError("This benchmark currently requires tensor_parallel_size=1")
        result = results[0]
        result["vllm_initialization_seconds"] = initialization_s
        result["callback_wall_seconds_including_warmup"] = callback_s
        Path(settings["output"]).parent.mkdir(parents=True, exist_ok=True)
        with open(settings["output"], "a") as f:
            f.write(json.dumps(result) + "\n")
        print(json.dumps(result, indent=2), flush=True)


if __name__ == "__main__":
    main()
