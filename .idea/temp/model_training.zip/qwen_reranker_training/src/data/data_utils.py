"""Data loading, preprocessing, and split utilities."""
from __future__ import annotations
import os
import math
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, Tuple

import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split

from ..utils import calculate_sha256, ensure_dir, get_logger, save_json

REQUIRED_COLUMNS = [
    "condition",
    "indicator",
    "category",
    "instruction",
    "query",
    "doc",
    "label",
]


def normalize_label(value) -> int:
    if isinstance(value, str):
        value = value.strip().lower()
        if value in {"yes",'true' , '1'}:
            return 1
        if value in {"no", "false" , '0'}:
            return 0
    if isinstance(value, bool):
        return int(value)

    if isinstance(value, int) and value in {0, 1}:
        return value
        
    raise ValueError(f"Unsupported label value: {value}")


def read_raw_dataframe(path: Path) -> pd.DataFrame:
    if not path.exists():
        raise FileNotFoundError(f"Raw parquet not found at {path}")
    df = pd.read_parquet(path)
    missing = [col for col in REQUIRED_COLUMNS if col not in df.columns]
    if missing:
        raise ValueError(f"Missing required columns: {missing}")
    return df

# Backward compatibility alias expected by older modules.
load_raw_dataframe = read_raw_dataframe

def clean_dataframe(df):
    df = df.copy()  
    # drops duplicates
    df = df.drop_duplicates()

    # drop nan
    df = df.dropna(subset=REQUIRED_COLUMNS)

    # clean labels
    df["label"] = df["label"].apply(normalize_label)

    return df


def _get_distribution(df, cols):
    """Return value counts (absolute + percentage) for given columns."""
    dist = {}
    for col in cols:
        value_counts = df[col].value_counts(dropna=False)
        percent_counts = df[col].value_counts(normalize=True, dropna=False) * 100
        dist[col] = {
            str(k): {
                "count": int(value_counts[k]),
                "percent": round(float(percent_counts[k]), 2)
            }
            for k in value_counts.index
        }
    return dist

def dump_splits_with_metadata(
    processed_dir: Path,    
    train_df: pd.DataFrame,
    val_df: pd.DataFrame,       
    test_df: pd.DataFrame,
    stratify_columns: list
) -> None:
    
    ensure_dir(processed_dir)

    train_path = os.path.join(processed_dir, "train_df.parquet")
    val_path   = os.path.join(processed_dir, "val_df.parquet")
    test_path  = os.path.join(processed_dir, "test_df.parquet")
    meta_path  = os.path.join(processed_dir, "metadata.json") 

    train_df.to_parquet(train_path)
    val_df.to_parquet(val_path)    
    test_df.to_parquet(test_path)

    # Prepare metadata and save metadata.json
    metadata = {
        "num_samples": {
            "train": len(train_df),
            "val": len(val_df),
            "test": len(test_df),
            "total": len(train_df) + len(val_df) + len(test_df)
        },
        "file_paths": {
            "train": train_path,
            "val": val_path,
            "test": test_path
        },
        "columns": list(train_df.columns),
        "labels" : train_df["label"].unique().tolist(), 
        "stratify_columns": stratify_columns, 
        "distribution": {
                    "train": _get_distribution(train_df, stratify_columns),
                    "val": _get_distribution(val_df, stratify_columns),
                    "test": _get_distribution(test_df, stratify_columns),         
                    },

        "created_at": datetime.now(timezone.utc).isoformat(),
    }

    save_json(metadata, meta_path)
        








