from fuzzysearch.search_exact import search_exact
from fuzzysearch import find_near_matches
from loguru import logger
import numpy as np
from tqdm import tqdm


class CustomTokenizer:
    SPECIAL_TOKENS = {
        "<bos>": 10000,
        "<eos>": 10001,
        "<pad>": 10002,
        "<unk>": 10003,

        "\n": 10004,
        " ": 10005,

        "###": 10006,
        "##": 10007,
        "#": 10008,

        "**": 10009,
        "*": 10010,

        "|": 10011,
        "---": 10012,
        "--": 10013,

        ":": 10014,
        ".": 10015,
        ",": 10016,
    }

    MIN_CHAR_FOR_FUZZY_SEARCH = 5

    def __init__(self):
        self.id_to_special_token = {
            v: k for k, v in self.SPECIAL_TOKENS.items()
        }

        self.markdown_tokens = sorted(
            [
                t
                for t in self.SPECIAL_TOKENS
                if t not in {"<bos>", "<eos>", "<pad>", "<unk>"}
            ],
            key=len,
            reverse=True,
        )

    def get_max_l_dist(self, text: str) -> int | None:
        min_fuzzy_text_length = 3
        fuzzy_edit_ratio = 0.20
        max_l_dist = 10
        min_l_dist = 0

        text_len = len(text.strip())

        if text_len < min_fuzzy_text_length:
            return None

        value = max(
            min_l_dist,
            round(text_len * fuzzy_edit_ratio),
        )

        if max_l_dist is not None:
            value = min(value, max_l_dist)

        return value

    def exact_search(self, ocr_lines, teacher_markdown):
        exact_match_spans = []
        duplicate_text_end_map = {}
        unmatched_ocr_ids = []
        dropped_ocr_ids = []
        matched = []

        for i, line in enumerate(ocr_lines):
            if line in self.SPECIAL_TOKENS or line == "":
                dropped_ocr_ids.append(i)
                continue

            search_pointer = duplicate_text_end_map.get(line, 0)

            matches = list(
                search_exact(
                    line,
                    teacher_markdown,
                    start_index=search_pointer,
                )
            )

            if len(matches) == 0:
                unmatched_ocr_ids.append(i)
                continue

            elif (len(matches) == 1) or (not exact_match_spans):
                match_start = matches[0]

            else:
                previous_span_end = exact_match_spans[-1][-1]
                span_distances = abs(
                    previous_span_end - np.array(matches)
                )
                match_start = matches[np.argsort(span_distances)[0]]

            match_end = match_start + len(line)
            span = (match_start, match_end)

            if span in exact_match_spans:
                logger.warning(
                    f"Already the span is available: {line}, Skipping..."
                )
                continue

            exact_match_spans.append(span)

            matched.append(
                {
                    "span": span,
                    "ocr_id": i,
                    "line": line,
                }
            )

            duplicate_text_end_map[line] = match_end

        return {
            "exact_matches": matched,
            "unmatched_ocr_ids": unmatched_ocr_ids,
            "dropped_ocr_ids": dropped_ocr_ids,
            "exact_match_coverage": len(matched)
            / (len(ocr_lines) - len(dropped_ocr_ids)),
        }

    def is_overlapping_span(self, candidate_span, available_spans):
        for span in available_spans:
            if (
                len(
                    set(range(span[0], span[1]))
                    & set(
                        range(
                            candidate_span[0],
                            candidate_span[1],
                        )
                    )
                )
                > 0
            ):
                return True

        return False

    def drop_overlapping_spans(self, candidates, available_spans):
        selected_candidates = []

        for candidate in candidates:
            span = (candidate.start, candidate.end)

            if not self.is_overlapping_span(span, available_spans):
                selected_candidates.append(candidate)

        return selected_candidates

    def fuzzy_search(
        self,
        unmatched_ocr_ids,
        ocr_lines,
        teacher_markdown,
        exact_matches,
        dropped_ocr_ids,
    ):
        failed_ids = []
        fuzzy_match_results = []

        exact_match_spans = list(
            map(lambda i: i["span"], exact_matches)
        )

        exact_match_span_total = []
        previous = (0, 0)

        for i in range(len(ocr_lines)):
            match = list(
                filter(
                    lambda m: m["ocr_id"] == i,
                    exact_matches,
                )
            )

            if match:
                exact_match_span_total.append(match[0]["span"])
                previous = match[0]["span"]
            else:
                exact_match_span_total.append(previous)

        for ocr_id in tqdm(unmatched_ocr_ids):
            ocr_line = ocr_lines[ocr_id]

            if len(ocr_line) < self.MIN_CHAR_FOR_FUZZY_SEARCH:
                logger.warning(
                    f"All OCR Lines are not allowed for Fuzzy search: "
                    f"{ocr_line}"
                )
                failed_ids.append(ocr_id)
                continue

            max_l_dist = self.get_max_l_dist(ocr_line)

            fuzzy_matches = find_near_matches(
                ocr_line,
                teacher_markdown,
                max_l_dist=max(max_l_dist, 10),
            )

            fuzzy_matches = self.drop_overlapping_spans(
                fuzzy_matches,
                exact_match_spans,
            )

            if not fuzzy_matches:
                failed_ids.append(ocr_id)
                continue

            else:
                best_l_distance = min(
                    fuzzy_matches,
                    key=lambda i: i.dist,
                ).dist

                candidates = list(
                    filter(
                        lambda i: i.dist == int(best_l_distance),
                        fuzzy_matches,
                    )
                )

                if len(candidates) == 1:
                    best_match = candidates[0]

                else:
                    previous_span_end = exact_match_span_total[
                        ocr_id - 1
                    ][-1]

                    candidates_start = list(
                        map(lambda c: c.start, candidates)
                    )

                    span_distances = abs(
                        previous_span_end
                        - np.array(candidates_start)
                    )

                    best_match = candidates[
                        np.argsort(span_distances)[0]
                    ]

                if not best_match.matched:
                    continue

                span = (best_match.start, best_match.end)

                if self.is_overlapping_span(
                    span,
                    exact_match_spans,
                ):
                    failed_ids.append(ocr_id)

                    logger.warning(
                        f"Fuzzy Match span overlap with exact match span "
                        f"{span} | id: {ocr_id} for line: {ocr_line}"
                    )
                    continue

                fuzzy_match_results.append(
                    {
                        "span": span,
                        "ocr_id": ocr_id,
                        "line": best_match.matched,
                    }
                )

        return {
            "fuzzy_matches": fuzzy_match_results,
            "un_matched_ids": failed_ids,
            "ocr_total_coverage": (
                (len(exact_matches) + len(fuzzy_match_results))
                / (len(ocr_lines) - len(dropped_ocr_ids))
            ),
        }

    def build_mixed_sequence(
        self,
        teacher_markdown,
        exact_matches,
        fuzzy_matches,
    ):
        all_matches = exact_matches + fuzzy_matches
        all_matches.sort(key=lambda m: m["span"][0])

        # Deduplicate overlapping spans - keep the first (earliest/largest)
        deduped = []
        occupied = [False] * len(teacher_markdown)

        for m in all_matches:
            s, e = m["span"]

            if any(occupied[s:e]):
                continue

            for pos in range(s, e):
                occupied[pos] = True

            deduped.append(m)

        sequence = []
        cursor = 0

        for m in deduped:
            s, e = m["span"]

            if cursor < s:
                sequence.append(
                    {
                        "type": "text",
                        "text": teacher_markdown[cursor:s],
                    }
                )

            sequence.append(
                {
                    "type": "ocr",
                    "ocr_id": m["ocr_id"],
                    "line": m["line"],
                    "match_type": m.get("match_type", "exact"),
                }
            )

            cursor = e

        if cursor < len(teacher_markdown):
            sequence.append(
                {
                    "type": "text",
                    "text": teacher_markdown[cursor:],
                }
            )

        return sequence

    def tokenize_markdown_span(
        self,
        text,
        markdown_tokens,
        special_tokens,
    ):
        pieces = []
        buffer = []
        pos = 0

        while pos < len(text):
            matched_token = None

            for token in markdown_tokens:
                if text.startswith(token, pos):
                    matched_token = token
                    break

            if matched_token is None:
                buffer.append(text[pos])
                pos += 1
                continue

            if buffer:
                pieces.append(
                    {
                        "type": "text",
                        "text": "".join(buffer),
                    }
                )
                buffer = []

            pieces.append(
                {
                    "type": "markdown",
                    "token": matched_token,
                    "id": special_tokens[matched_token],
                }
            )

            pos += len(matched_token)

        if buffer:
            pieces.append(
                {
                    "type": "text",
                    "text": "".join(buffer),
                }
            )

        return pieces

    def encode(self, teacher_markdown, ocr_lines, use_unk=True):
        exact_results = self.exact_search(
            ocr_lines=ocr_lines,
            teacher_markdown=teacher_markdown,
        )

        fuzzy_results = self.fuzzy_search(
            exact_results["unmatched_ocr_ids"],
            ocr_lines,
            teacher_markdown,
            exact_results["exact_matches"],
            exact_results["dropped_ocr_ids"],
        )

        mixed_sequence = self.build_mixed_sequence(
            teacher_markdown,
            exact_results["exact_matches"],
            fuzzy_results["fuzzy_matches"],
        )

        ids = []
        unknown_spans = []

        ids.append(self.SPECIAL_TOKENS["<bos>"])

        for item in mixed_sequence:
            if item["type"] == "ocr":
                ids.append(item["ocr_id"])
                continue

            if item["type"] == "markdown":
                ids.append(item["id"])
                continue

            if item["type"] != "text":
                continue

            pieces = self.tokenize_markdown_span(
                item["text"],
                self.markdown_tokens,
                self.SPECIAL_TOKENS,
            )

            for piece in pieces:
                if piece["type"] == "markdown":
                    ids.append(piece["id"])

                else:
                    unresolved = piece["text"]

                    if unresolved.strip():
                        unknown_spans.append(unresolved)

                        if use_unk:
                            ids.append(
                                self.SPECIAL_TOKENS["<unk>"]
                            )

        ids.append(self.SPECIAL_TOKENS["<eos>"])

        return ids, unknown_spans

    def decode(
        self,
        ids,
        ocr_lines,
        skip_special_tokens=True,
    ):
        parts = []

        for token_id in ids:
            if 0 <= token_id <= 9999 and token_id < len(ocr_lines):
                parts.append(ocr_lines[token_id])
                continue

            token = self.id_to_special_token.get(token_id)

            if token is None:
                continue

            if token == "<eos>":
                break

            if token in ("<bos>", "<pad>", "<unk>") and skip_special_tokens:
                continue

            parts.append(token)

        return "".join(parts)