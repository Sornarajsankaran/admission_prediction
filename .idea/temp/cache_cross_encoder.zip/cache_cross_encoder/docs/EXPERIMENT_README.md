# BioClinical ModernBERT cross-encoder caching experiment

The runnable implementation is in `cached_model.py` and `shared_attention.py`.
`bench_vllm_custom.py` executes it inside a native vLLM worker via `LLM.apply_model`,
reusing native loaded model weights. This is an offline custom executor integration;
it does not modify the stock classify scheduler or expose an HTTP reranking API.

## Environment and workload

One NVIDIA L40S (48 GB nominal), Python 3.12, vLLM 0.33.0, PyTorch 2.14.0+cu130,
Transformers 5.20.2, Triton 3.8.0. Exact installed packages: `requirements.lock.txt`.
Public checkpoint revision and deterministic head provenance are saved under models/.
The public model is masked-LM pretrained, not a trained cross-encoder. All experiments
use the same pretrained backbone and deterministic untrained CLS/GELU scalar head.
CLS/GELU is an explicit benchmark assumption; original config has mean/SiLU.
These are throughput and implementation-equivalence experiments, not retrieval-quality tests.

Synthetic data is one record: 5000 distinct chunks, 256 content tokens each, 50
ICD-style queries, 250000 scores. Document wrappers add 7 tokens, giving 263 tokens;
queries have 30–41 tokens (mean 35.48). Every score counts one chunk/query pair,
not one unique chunk. One hundred records require 25 million scores.

## Exact attention contract

First SEP belongs to query. Document tokens cannot attend query tokens. Query tokens
can attend their own query and document. Full layers use this mask; local layers
add inclusive abs(i-j)<=64, matching the provided `masked_ce.build_masks()`.
Queries never attend other query branches. Document states are computed once per
layer per tile and reused across all 50 queries. Shared relative RoPE coordinates
query position i-true_query_length, doc position j preserve relative distances.
Reduced-precision rounding changes with this coordinate shift; numerical errors
are recorded in `results/correctness.json`.

Modes tested: stock vLLM full cross-encoder; HF SDPA; reusable per-layer document
KV caches; hot-cache query timing; layerwise streaming; joint document/query
projections and MLP; tile sizes1–32; compilation of dense operations; CUDA graphs.
Hot-cache measurements explicitly exclude cache construction. Full-workload custom
measurements include document computation, query computation, classifier and
input/output transfers, excluding initialization, warmup, compilation and tokenization.
Stock vLLM API timings also include per-pair scheduling and output-object handling.
HF and tile microbenchmarks measure resident-input forward throughput, so those
are reported separately rather than treated as identical measurement boundaries.

There are 22 layers, with 8 global and 14 local. Full BF16 document KV is~82.8GiB
for 5000 wrapped chunks. Keeping just the first 64 document positions at local
layers reduces it to~42.9GiB, still tight with model and working memory. Streaming
avoids storing every layer's KV. Final CLS-only attention/MLP avoids unnecessary
final query outputs; this optimization is disabled for mean pooling.

## Reproduce

```bash
cd /path/to/cached_cross_encoder_codex
uv pip install --python .venv/bin/python -r requirements.lock.txt
.venv/bin/python prepare_data.py
.venv/bin/python validate.py --dtypes fp32 bf16 fp16
.venv/bin/python bench_vllm.py --pairs 250000 --max-num-batched-tokens 8192 --max-num-seqs 64
.venv/bin/python bench_vllm_custom.py --mode joint --tile 4 --compile-parts --graph --full-docs 5000
```

`best_config.json` records the actual best measured full-workload settings.
`sweep.json`, `sweep_compile.json`, and `run_remaining.py` reproduce experiments.
All GPU experiments run sequentially to avoid interference. Microbenchmarks use
warmup and synchronized CUDA-event/wall timing; results retain individual samples.

The optimized executor currently requires single-GPU unquantized ModernBERT-base
(768 hidden,12 heads,64 head dimension). FlashAttention document encoding requires
equal unpadded document lengths; the benchmark checks this. The SDPA fallback
supports varied document lengths. Query lengths are masked correctly and positions
use actual lengths. Production scheduling, cache invalidation/eviction, varied
record lengths, trained checkpoint validation and HTTP serving remain integration work.

Detailed source review: `docs/executor_analysis.md`; derivation: `docs/design_review.md`.
Executor source snapshots are under `vendor/`.

Primary references:
- https://huggingface.co/thomas-sounack/BioClinical-ModernBERT-base
- https://github.com/vllm-project/vllm/blob/main/vllm/model_executor/models/modernbert.py
- https://docs.vllm.ai/en/latest/models/pooling_models/
